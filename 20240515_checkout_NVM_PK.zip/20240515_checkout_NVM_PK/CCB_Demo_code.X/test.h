
#ifndef _TEST_H
#define _TEST_H

#include "xc.h"
#include "cpu.h"
#include "spi.h"
#include "i2c_temp.h"
#include "bldc.h"
#include "angle_sensor.h"
#include "lru-global.h"
#include "bldc_drv.h"
#include "timer_manager.h"
#include "can.h"
#include "pwm.h"
#include "uart1.h"
#include "adc_manager.h"
#include "angle_sensor.h"
#include "current.h"
#include "hall.h"
void test();

#endif