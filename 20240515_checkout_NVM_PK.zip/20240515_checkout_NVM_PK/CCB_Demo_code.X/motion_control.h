/*
 Author(s): Russell Everett <reverett@righthandtech.com> <reverett@righthandtech.com>
 Status: Preliminary
 Release Date:
 Revision:
 Description: Header file for the Actuator Motion Control Module.
 */

#ifndef MOTIONCTRL_H
#define	MOTIONCTRL_H
/*********************************************************************************************
Includes
*********************************************************************************************/
#include "obstacle.h"
#include "typedef.h"

/*********************************************************************************************
 * Preprocessor definitions
 ********************************************************************************************/
/* RPM to degrees per second == 360 / 60 == 6 */
#define ACT_RPM_TO_DPS             6

/*********************************************************************************************
Function declarations
*********************************************************************************************/
/*********************************************************************************************
Author(s):   Russell Everett <reverett@righthandtech.com>
Description: The initialization function for the Actuator Motion Control module.
Parameters:  None
Returns:     None
*********************************************************************************************/
ERR_RET motn_init(void);

/*********************************************************************************************
Author(s):   Russell Everett <reverett@righthandtech.com>
Description: The periodic function for the Actuator Motion Control module.
Parameters:  None
Returns:     None
*********************************************************************************************/
void motn_exec(void);

/*********************************************************************************************
Author(s):   PK
Description: Push in commanded speed
Parameters:  speed_degrees_per_second (in) - commanded speed in degrees per second.
Returns:     None
*********************************************************************************************/
void motn_set_commanded_speed(INT16S speed_in_rpm);

/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Returns the system time when BLDC motor last started commutating.
Parameters:  None.
Returns:     See description.
*********************************************************************************************/
INT32U motn_get_motor_start_time();

/*********************************************************************************************
Author(s):   Abraham Greenwell
Description: Returns the commanded speed.
Parameters:  None.
Returns:     INT16S - signed commanded speed value.
*********************************************************************************************/
INT16S motn_get_command_speed();

/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Returns TRUE if the motor has stopped and FALSE if it's moving.
Parameters:  None
Returns:     See description.
*********************************************************************************************/
BOOL motn_is_motor_stopped(void);

/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Returns TRUE if the BLDC motor is commutating.
Parameters:  None
Returns:     See description.
*********************************************************************************************/
BOOL motn_is_motor_commutating(void);

/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: Returns the configured gearbox ratio.
Parameters:  None
Returns:     INT16S - returns the configured gearbox ratio.
*********************************************************************************************/
INT16S motn_get_gearbox_ratio( void );

/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: Returns the commanded motion direction.
Parameters:  None
Returns:     MOTION_DIRECTION - indicates the commanded direction of motion.
*********************************************************************************************/
MOTION_DIRECTION motn_get_motion_dir( void );

/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: Sets a flag indicating a brake disengage failure has occurred.
Parameters:  None
Returns:     None.
*********************************************************************************************/
void motn_set_disengage_failed( void );

#endif	/*MOTIONCTRL_H */

