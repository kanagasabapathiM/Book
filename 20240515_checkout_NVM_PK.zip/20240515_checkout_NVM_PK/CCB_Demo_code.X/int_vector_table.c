/*********************************************************************************************
 *
 * NOTICE - PROPRIETARY INFORMATION COPYRIGHT � 2018
 *
 * B/E AEROSPACE CONSIDERS THIS DOCUMENT TO CONTAIN INFORMATION OF A
 * PROPRIETARY NATURE.  THEREFORE, THE RECEIVER OF THIS DOCUMENT IS REQUESTED
 * TO TREAT IT ACCORDINGLY AND TO NOT TRANSMIT, REVEAL, OR DISCLOSE IT OR ANY
 * PART THEREOF WITHOUT EXPRESS WRITTEN PERMISSION OF B/E AEROSPACE.
 * DISTRIBUTION AND/OR REPRODUCTION OF THIS DOCUMENT (IN WHOLE OR IN PART)
 * OUTSIDE OF B/E AEROSPACE MUST BE AUTHORIZED BY B/E AEROSPACE MANAGEMENT.
 *
 *********************************************************************************************
 *
 * Author:      M VanderZouwen
 * Status:      Preliminary
 * Date:        ??/??/??
 * Revision:    0.1
 * Description:  The Interrupt Vector Table module defines the interrupt service
 *               routines used by the program. It is responsible for getting
 *               an interrupt to the correct interrupt handler.
 *
 *********************************************************************************************
 *
 * Revision History:
 *      0.1 MVZ     Initial creation
 *
 ********************************************************************************************/

/*********************************************************************************************
 * Included files
 ********************************************************************************************/
#include <xc.h>
#include "cpu.h"
#include "global.h"
#if 0
/*********************************************************************************************
 * Private Preprocessor definitions
 ********************************************************************************************/
//#define

/*********************************************************************************************
 * Private type definitions
 ********************************************************************************************/
//typedef

/*********************************************************************************************
 * Global variable definitions
 ********************************************************************************************/
//type name;

/*********************************************************************************************
 * Private function declarations
 *
 * (in this case, the functions are external to this file)
 ********************************************************************************************/
/*********************************************************************************************
Author(s):      Jonathan R. Saliers
Description:    Handles any of the 3 hall sensor GPIO changes.
    Perfoms the following tasks:
    - Controls which of the 6 of H-bridge transistors are being driven (commutation)
    - Measures the time since the last hall sensor value change (to compute RPM)
Parameters:     None
Returns:        None
*********************************************************************************************/
extern void __attribute__((interrupt, no_auto_psv)) _CNInterrupt(void);

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: The interrupt service routine for timer 1 - the 1 millisecond timer.  The
 *              number of milliseconds since power up gets incremented each time the timer
 *              times out.
 * Parameters:  None.
 * Returns:     None.
 *********************************************************************************************/
#ifndef BOOTLOADER
extern void __attribute__((interrupt, no_auto_psv)) _T1Interrupt( void );
#else
extern void __attribute__((interrupt, no_auto_psv)) _T1_ISR( void );
#endif

/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: The interrupt service routine for timer 3 - the hall delta timer.
             This ISR is called 25ms after the timer is enabled.
Parameters:  None.
Returns:     None.
 *********************************************************************************************/
extern void __attribute__((interrupt, no_auto_psv)) _T3Interrupt(void);

#ifndef PRIVACY_DIVIDER
/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: The interrupt handler for T4 interrupt, which controls the Brake Step line.
Parameters:  None.
Returns:     None.
*********************************************************************************************/
extern void __attribute__((interrupt, no_auto_psv)) _T4Interrupt(void);
#endif

/*********************************************************************************************
 * Author(s):   mfarver
 * Description: Interrupts when one cycle of ADC samples has been acquired.
 * Parameters:  None.
 * Returns:     None.
 *********************************************************************************************/
extern void __attribute__((interrupt, no_auto_psv)) _DMA3Interrupt(void);

/*********************************************************************************************
 * Function definitions
 ********************************************************************************************/

/*********************************************************************************************
 * Author(s):   M VanderZouwen
 * Description: Default routine to handle all not-otherwise-handled interrupts.
 *              Captures debug information about the cause of the interrupt.
 *********************************************************************************************/
void __attribute__((interrupt, no_auto_psv)) _DefaultInterrupt(void)
{
    /*
     * INTTREG
     * 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
     * 0 0 0 0|I Level|  vector num   |
     */
    /* Copy of interrupt control register */
    INTTREGBITS IntrReg = INTTREGbits;   /* Save Interrupt register for debug */
    long i;                                                   /* Loop counter */
    (void) IntrReg; /* Stop compiler whine */

    GREEN_LED_PIN = PORT_OUT_LOW;                           /* Turn off green */
    for ( ; ; ) /* For ever */
    {
        for (i = 0; i < 0x30000; ++i)
        {
            Nop();
        }
        RED_LED_PIN = ~RED_LED_PIN;                             /* Toggle red */
        if (i == 0x40000) break;   /* Load "i" to escape manually in debugger */
    }
}

/*
 *  ISR JUMP TABLE
 *
 *  It is necessary to define jump table as a function because xc16 will
 *  not store 24-bit wide values in program memory as variables.
 *
 *  This function should be stored at an address where the goto instructions
 *  line up with the remapped vectors from the bootloader's linker script.
 *
 *      The bootloader contains a handler that decides if maintenance or
 *      application firmware is running and redirects to this table.  This
 *      increases interrupt latency with two more jumps, since each interrupt
 *      is now IVT -> BootLoader redirect code -> App ISRTable -> ISR.
 *      For more information on why this is neccesary and why modifying the
 *      boot record is a bad idea see Microchip App Note AN1157
 *
 *      Any interrupts used by this application need to have their functions
 *      replace the DefaultInterrupt below.
 *
 *      Note that GOTOs are two instruction words long, so these won't line up
 *      in memory the same way as the IVTs does.
 */
#ifndef BOOTLOADER
void __attribute__((address(0x10004))) ISRTable()
#else
void __attribute__((address(0x204))) ISRTable()
#endif
{
    asm("reset"); /* reset instruction to prevent runaway code */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 000 OscillatorFail              */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 001 AddressError                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 002 HardTrapError               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 003 StackError                  */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 004 MathError                   */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 005 DMACError                   */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 006 SoftTrapError               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 007 ReservedTrap7               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 008 INT0Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 009 IC1Interrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 010 OC1Interrupt                */
#ifndef BOOTLOADER
    asm("goto %0"::"i"(&_T1Interrupt));      /* 011 T1Interrupt                 */
#else
    asm("goto %0"::"i"(&_T1_ISR));           /* 011 T1Interrupt                 */
#endif
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 012 DMA0Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 013 IC2Interrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 014 OC2Interrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 015 T2Interrupt                 */
#ifndef BOOTLOADER
    asm("goto %0"::"i"(&_T3Interrupt)); /* 016 T3Interrupt                 */
#else
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 016 T3Interrupt                 */
#endif
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 017 SPI1ErrInterrupt            */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 018 SPI1Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 019 U1RXInterrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 020 U1TXInterrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 021 AD1Interrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 022 DMA1Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 023 NVMInterrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 024 SI2C1Interrupt              */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 025 MI2C1Interrupt              */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 026 CM1Interrupt                */
#ifndef BOOTLOADER
    asm("goto %0"::"i"(&_CNInterrupt)); /* 027 CNInterrupt                 */
#else
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 027 CNInterrupt                 */
#endif
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 028 INT1Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 029 AD2Interrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 030 IC7Interrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 031 IC8Interrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 032 DMA2Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 033 OC3Interrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 034 OC4Interrupt                */
#if !defined(BOOTLOADER) && !defined(PRIVACY_DIVIDER)
    asm("goto %0"::"i"(&_T4Interrupt)); /* 035 T4Interrupt                 */
#else
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 035 T4Interrupt                 */
#endif
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 036 T5Interrupt                 */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 037 INT2Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 038 U2RXInterrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 039 U2TXInterrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 040 SPI2ErrInterrupt            */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 041 SPI2Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 042 C1RxRdyInterrupt            */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 043 C1Interrupt                 */
#ifndef BOOTLOADER
    asm("goto %0"::"i"(&_DMA3Interrupt)); /* 044 DMA3Interrupt               */
#else
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 044 DMA3Interrupt               */
#endif
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 045 IC3Interrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 046 IC4Interrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 047 IC5Interrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 048 IC6Interrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 049 OC5Interrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 050 OC6Interrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 051 OC7Interrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 052 OC8Interrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 053 PMPInterrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 054 DMA4Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 055 T6Interrupt                 */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 056 T7Interrupt                 */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 057 SI2C2Interrupt              */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 058 MI2C2Interrupt              */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 059 T8Interrupt                 */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 060 T9Interrupt                 */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 061 INT3Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 062 INT4Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 063 C2RxRdyInterrupt            */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 064 C2Interrupt                 */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 065 PWMSpEventMatchInterrupt    */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 066 QEI1Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 067 DCIEInterrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 068 DCIInterrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 069 DMA5Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 070 RTCCInterrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 071 Interrupt63                 */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 072 Interrupt64                 */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 073 U1ErrInterrupt              */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 074 U2ErrInterrupt              */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 075 CRCInterrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 076 DMA6Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 077 DMA7Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 078 C1TxReqInterrupt            */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 079 C2TxReqInterrupt            */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 080 Interrupt72                 */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 081 PWMSecSpEventMatchInterrupt */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 082 Interrupt74                 */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 083 QEI2Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 084 Interrupt76                 */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 085 Interrupt77                 */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 086 Interrupt78                 */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 087 Interrupt79                 */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 088 Interrupt80                 */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 089 U3ErrInterrupt              */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 090 U3RXInterrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 091 U3TXInterrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 092 Interrupt84                 */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 093 Interrupt85                 */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 094 USB1Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 095 U4ErrInterrupt              */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 096 U4RXInterrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 097 U4TXInterrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 098 SPI3ErrInterrupt            */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 099 SPI3Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 100 OC9Interrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 101 IC9Interrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 102 PWM1Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 103 PWM2Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 104 PWM3Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 105 PWM4Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 106 PWM5Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 107 PWM6Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 108 Interrupt100                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 109 Interrupt101                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 110 Interrupt102                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 111 Interrupt103                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 112 Interrupt104                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 113 Interrupt105                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 114 Interrupt106                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 115 Interrupt107                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 116 Interrupt108                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 117 Interrupt109                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 118 Interrupt110                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 119 Interrupt111                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 120 Interrupt112                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 121 Interrupt113                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 122 Interrupt114                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 123 Interrupt115                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 124 Interrupt116                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 125 Interrupt117                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 126 DMA8Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 127 DMA9Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 128 DMA10Interrupt              */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 129 DMA11Interrupt              */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 130 SPI4ErrInterrupt            */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 131 SPI4Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 132 OC10Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 133 IC10Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 134 OC11Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 135 IC11Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 136 OC12Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 137 IC12Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 138 DMA12Interrupt              */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 139 DMA13Interrupt              */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 140 DMA14Interrupt              */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 141 Interrupt133                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 142 OC13Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 143 IC13Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 144 OC14Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 145 IC14Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 146 OC15Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 147 IC15Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 148 OC16Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 149 IC16Interrupt               */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 150 ICDInterrupt                */
    asm("goto %0"::"i"(&_DefaultInterrupt)); /* 151 JTAGInterrupt               */
}

#endif //#if 0