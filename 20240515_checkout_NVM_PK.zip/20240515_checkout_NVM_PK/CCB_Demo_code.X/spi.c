/*
 * File:   spi1.c
 * Author: e40063636
 *
 * Created on December 18, 2023, 9:11 PM
 */

#include "cpu.h"
#include "spi.h"
#include <xc.h>

#define SPI_TRY_COUNT      200               /* Iterate 200 times attempting to read SPI buffer. */
#define WAIT_FOR_NOT_BUSY_COUNT   5000

static void _spi1_exchange( INT8U *pTransmitData, INT8U *pReceiveData );
static void _spi3_exchange(INT16U *pTransmitData, INT16U *pReceiveData);
INT32U receiveData;
INT32U TransmitData = 0;
/*********************************************************************************************
 * Author(s):    E40063636
 * Description:  Initialization SPI1 interface.
 * Parameters:   None
 * Returns:      None
 *
*********************************************************************************************/
void spi1_init(void)
{
    // AUDEN disabled; FRMEN disabled; AUDMOD I2S; FRMSYPW One clock wide; AUDMONO stereo; FRMCNT 0; MSSEN disabled; FRMPOL disabled; IGNROV disabled; SPISGNEXT not sign-extended; FRMSYNC disabled; URDTEN disabled; IGNTUR disabled; 
    SPI1CON1H = 0x00;
   
    // SPIROV disabled; FRMERR disabled; 
    SPI1STATL = 0x00;
    // SPITBFEN disabled; SPITUREN disabled; FRMERREN disabled; SRMTEN disabled; SPIRBEN disabled; BUSYEN disabled; SPITBEN disabled; SPIROVEN disabled; SPIRBFEN disabled; 
    SPI1IMSKL = 0x00;
    // RXMSK 0; TXWIEN disabled; TXMSK 0; RXWIEN disabled; 
    SPI1IMSKH = 0x00;
    // SPI2URDTL 0; 
    SPI1URDTL = 0x00;
    // SPI2URDTH 0; 
    SPI1URDTH = 0x00;
    
    /* Configure SPI */
    SPI1CON1Lbits.DISSCK = 0; /* SCK1 pin is controlled by the module */
    SPI1CON1Lbits.DISSDO = 0; /* SDO1 pin is controlled by the module */
    
    /*Set SPI length to 24 Bits*/
    SPI1CON1Lbits.MODE16 = 0; 
    SPI1CON1Lbits.MODE32 = 0;
    
    //WLENGTH 24; 
    SPI1CON2L = 0x17;

    /* Input data is sampled at the middle of data output time */
    SPI1CON1Lbits.SMP = 0;

    /* Serial output data changes on transition from active clock state to idle clock state */
    SPI1CON1Lbits.CKE = 1;

    /* Idle state for clock is a low-level; active state is a high-level */
    SPI1CON1Lbits.CKP = 0;

    SPI1CON1Lbits.MSTEN = 1;    /* Master mode enabled */
    //SPI1BRGLbits.BRG    = 0x03; //Fp = 40 Sck = fp/(2(3+1)))   2Mhz
    SPI1BRGLbits.BRG    = 0x07; //Fp = 80 Sck = fp/(2(3+1)))   5Mhz
    SPI1CON1Lbits.ENHBUF = 1; /* Enhanced buffer enabled */
    
    SPI1CON1Lbits.SPIFE = 1;  //Frame Sync pulse (Idle-to-active edge) coincides with the first bit clock

    SPI1CON1Lbits.SPIEN = 1; /* Enable SPI module */
    
    /* from here, the device is ready to transmit and receive data. 
     * Buffer can be loaded to transmit data */
}

/* as the WLENGTH set to 24, only 24 clock cycles are provided,
*  so only 24 bits are transfered 31 to 8 (MSB to LSB))(lower bytes are ignored, ensure to set as 0))
*/

INT32U spi1_exchange24bit( INT32U data )
{

    TransmitData = data;
    _spi1_exchange((INT8U*)&TransmitData, (INT8U*)&receiveData);

    return (receiveData); // data available in 0 to 23 Bits, MSB is ignored
}

static void _spi1_exchange( INT8U *pTransmitData, INT8U *pReceiveData )
{

    while( SPI1STATLbits.SPITBF == true )
    {

    }
    SPI1BUFL = *((INT16U*)pTransmitData);
    SPI1BUFH = *((INT16U*)(pTransmitData + 2));

    while ( SPI1STATLbits.SPIBUSY == true)// wait finishing transaction
    {
    
    }

    while ( SPI1STATLbits.SPIRBE == true)
    {
    
    }

    *((INT16U*)pReceiveData)       = SPI1BUFL;
    *((INT16U*)(pReceiveData + 2)) = SPI1BUFH;

#ifdef UART_DEBUG_BLDC
    /*For debug print statement added to print 24 bit data and Chip need 
     * un-select otherwise time out error will occur on BLDC DRV */
    cpu_SetBldcCs(1);/*temporary to be remove*/
    //--//printf("\r\n RX_SPI1BUF: 0x%04X %04X \r\n",*((INT16U*)(pReceiveData + 2)), *((INT16U*)pReceiveData));
#endif

}

INT32U spi1_read(void)
{
    INT16U   idx = 0;
    INT32U*  pReceiveData = 0;

    /* Initiate bus cycle */
    SPI1BUFL = 0x00;
    SPI1BUFH = 0x00;

    for (idx = 0; idx < SPI_TRY_COUNT; idx++)
    {
        /* Check the Receive Buffer Full status bit of status register */
        if (!SPI1STATLbits.SPIRBE)
        {
            *((INT16U*)pReceiveData)       = SPI1BUFL;
            *((INT16U*)(pReceiveData + 2)) = SPI1BUFH;

            return (*pReceiveData);
        }
    }

    /* Return data byte */
    return -1;
}



/*********************************************************************************************
 * Author(s):    
 * Description:  Initialization SPI3 interface.
 * Parameters:   None
 * Returns:      None
 *
*********************************************************************************************/
void spi3_init(void)
{
    // AUDEN disabled; FRMEN disabled; AUDMOD I2S; FRMSYPW One clock wide; AUDMONO stereo; FRMCNT 0; MSSEN disabled; FRMPOL disabled; IGNROV disabled; SPISGNEXT not sign-extended; FRMSYNC disabled; URDTEN disabled; IGNTUR disabled; 
    SPI3CON1H = 0x00;
   
    // SPIROV disabled; FRMERR disabled; 
    SPI3STATL = 0x00;
    // SPITBFEN disabled; SPITUREN disabled; FRMERREN disabled; SRMTEN disabled; SPIRBEN disabled; BUSYEN disabled; SPITBEN disabled; SPIROVEN disabled; SPIRBFEN disabled; 
    SPI3IMSKL = 0x00;
    // RXMSK 0; TXWIEN disabled; TXMSK 0; RXWIEN disabled; 
    SPI3IMSKH = 0x00;
    // SPI2URDTL 0; 
    SPI3URDTL = 0x00;
    // SPI2URDTH 0; 
    SPI3URDTH = 0x00;
    
    /* Configure SPI */
    SPI3CON1Lbits.DISSCK = 0; /* SCK1 pin is controlled by the module */
    SPI3CON1Lbits.DISSDO = 0; /* SDO1 pin is controlled by the module */
    
    /*Set SPI length to 16 Bits*/
    SPI3CON1Lbits.MODE16 = 1; 
    SPI3CON1Lbits.MODE32 = 0;
    SPI3CON2L = 0;

    /* Input data is sampled at the middle of data output time */
    SPI3CON1Lbits.SMP = 0;

    /* Serial output data changes on transition from idle clock state to active clock state */
    SPI3CON1Lbits.CKE = 0;

    /* Idle state for clock is a low-level; active state is a high-level */
    SPI3CON1Lbits.CKP = 0;

    SPI3CON1Lbits.MSTEN = 1;    /* Master mode enabled */
    //SPI3BRGLbits.BRG    = 0x13; //Fp = 40MHz Sck = fp/(2(19+1)))   1MHz /*TBD as per angle sensor it is mentioned as 8Mbits/sec */
    //SPI3BRGLbits.BRG    = 0x4; //Fp = 80MHz Sck = fp/(2(4+1)))   8MHz
    SPI3BRGLbits.BRG    = 0x9; //Fp = 80MHz Sck = fp/(2(9+1)))   4MHz
    
    SPI3CON1Lbits.ENHBUF = 1; /* Enhanced buffer enabled */
    
    SPI3CON1Lbits.SPIFE = 1;  //Frame Sync pulse (Idle-to-active edge) coincides with the first bit clock

    SPI3CON1Lbits.SPIEN = 1; /* Enable SPI module */
    
    /* from here, the device is ready to transmit and receive data. 
     * Buffer can be loaded to transmit data */
}

INT32U spi3_exchange16bit(INT16U data) {
    
    INT16U receiveData;

    _spi3_exchange(& data,& receiveData);

    return (receiveData); // data available in 0 to 23 Bits, MSB is ignored
}

static void _spi3_exchange(INT16U *pTransmitData, INT16U *pReceiveData) {

    while (SPI3STATLbits.SPITBF == true) {

    }

    SPI3BUFL = *pTransmitData;

    while (SPI3STATLbits.SPIBUSY == true)// wait finishing transaction
    {

    }

    while (SPI3STATLbits.SPIRBE == true) {

    }

    *pReceiveData = SPI3BUFL;

}

INT16U spi3_read(void)
{
    INT16U   idx = 0;
    INT16U  *pReceiveData = 0;

    /* Initiate bus cycle */
    SPI3BUFL = 0x00;

    for (idx = 0; idx < SPI_TRY_COUNT; idx++)
    {
        /* Check the Receive Buffer Full status bit of status register*/
        if (!SPI3STATLbits.SPIRBE)
        {
            *pReceiveData       = SPI3BUFL;

            return (*pReceiveData);
        }
    }

    /* Return data byte */
    return -1;
}

/******************************************************************************
*//**
* @brief .
* @parm Void.
* @return Void.
* 
*******************************************************************************/
void spi2_Init(void)
{
    SPI2CON1H = 0x00;
    SPI2CON2L = 0x00;
    SPI2STATL = 0x00;
    SPI2BRGL  = 0x03;
    SPI2IMSKL = 0x00;
    SPI2IMSKH = 0x00;
    SPI2URDTL = 0x00;
    SPI2URDTH = 0x00;
    SPI2CON1L = 0x8121;
    return;
}


INT8U SPI2_ByteExchange(INT8U byteData)
{
    while(1U == SPI2STATLbits.SPITBF)
    {

    }

    SPI2BUFL = byteData;

    while (1U == SPI2STATLbits.SPIRBE)
    {
    
    }

    return SPI2BUFL;
}