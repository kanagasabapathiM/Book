/*
 Author(s):     Andrew Kilkenny <akilkenny@righthandtech.com>,
                David Yuen <dyuen@righthandtech.com>
 Status:        Preliminary
 Release        Date:
 Revision:
 Description:   Header file for the Temperature Module.
 */

/*********************************************************************************************
 * Recursive header block
 ********************************************************************************************/
#ifndef TEMPERATURE_H
#define	TEMPERATURE_H

/*********************************************************************************************
 * Includes
 ********************************************************************************************/
#include "typedef.h"

/*********************************************************************************************
 * Any type definitions defined by the header file
 ********************************************************************************************/

/*********************************************************************************************
 * Preprocessor definitions
 ********************************************************************************************/
#define TEMP_OUTSIDE_LIMITS 0x1

/*********************************************************************************************
 * Function declarations
 ********************************************************************************************/
/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: The initialization function for the temperature module.
 * Parameters:  None.
 * Returns:     None.
 ********************************************************************************************/
ERR_RET temp_init( void );

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Periodically calculates the PCB and stepper temperatures.
 * Parameters:  None
 * Returns:     BOOL - indicates whether the timer should be updated (TRUE = both PCB and
 *              STP temps have been calculated) or not (FALSE).
 ********************************************************************************************/
BOOL temp_calc_temps( void );

/*********************************************************************************************
Author(s):      Michael Ansolis.
Description:    Returns PCB temperature.
Parameters:     None.
Returns:        See description.
*********************************************************************************************/
INT16S temp_get_pcb_temp( void );

/*********************************************************************************************
Author(s):      Michael Ansolis.
Description:    Returns stepper motor temperature.
Parameters:     None.
Returns:        See description.
*********************************************************************************************/
INT16S temp_get_stepper_temp( void );


#endif	/* TEMPERATURE_H */
