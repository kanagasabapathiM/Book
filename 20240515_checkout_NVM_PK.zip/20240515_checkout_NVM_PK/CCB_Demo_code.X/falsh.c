/*Software Driver
SST26VF080A 8 Mbit(1M x 8) Serial Quad I/O (SQI) Flash Memory */
#include <stdio.h>
#include "cpu.h"
#include "xc.h"
#include "spi.h"
/* Pin Function Prototypes */

void CE_High();
void CE_Low();
void Reset_Hold_Low();
void Reset_Hold_High();
void WP_Low();
void WP_High();

void init();
void Send_Byte(unsigned char out); 
unsigned char Get_Byte(); 
unsigned char SPI_Read_Status_Register(); 
unsigned char SPI_Read_Configuration_Register();  
void SPI_WREN(); 
void Jedec_ID_Read(); 
void SPI_HighSpeed_Read_Cont(unsigned long Dst, unsigned long no_bytes); 
void SPI_Page_Program(unsigned long Dst); 
void SPI_Chip_Erase(); 
void SPI_4K_Sector_Erase(INT32U); 
void SPI_4K_Sector_Read(INT32U); 
void SPI_Write_Status_Register(unsigned int data1, unsigned char datalen); 
void SPI_Wait_Busy(); 
unsigned int data_256[256]; 
unsigned char   Manufacturer_Id, Device_Type, Device_Id;
/* global array to store Manufacturer and Device id information */


/************************************************************************/
/* PROCEDURE: CE_High							*/
/*									*/
/* This procedure set CE = High.					*/
/************************************************************************/
void CE_High()
{
	_LATD8 = 1;			/* set CE high */
}

/************************************************************************/
/* PROCEDURE: CE_Low							*/
/*									*/
/* This procedure drives the CE of the device to low.  			*/
/************************************************************************/
void CE_Low()
{
	_LATD8 = 0;			/* set CE high */
}

/************************************************************************/
/* PROCEDURE: WP_Low()							*/
/*									*/
/* This procedure clears the WP pin to low.				*/
/************************************************************************/
void WP_Low()
{
  _LATB8 = 0;			/* clear WP pin */
}

/************************************************************************/
/* PROCEDURE: WP_High()							*/
/*									*/
/* This procedure sets the WP pin to high.				*/
/************************************************************************/
void WP_High()
{
   _LATB8 = 1;				/* set WP pin */
}

/************************************************************************/
/* PROCEDURE: Send_Byte							*/
/*									*/
/* This procedure outputs a byte shifting out 1-bit per clock rising	*/
/* edge on the the SI pin (SIO0 pin) LSB 1st.				*/
/************************************************************************/
void Send_Byte(unsigned char out)
{
  SPI2_ByteExchange(out);
}

/************************************************************************/
/* PROCEDURE: Get_Byte							*/
/*									*/
/* This procedure inputs a byte shifting in 1-bit per clock falling	*/
/* edge on the SIO1 pin(LSB 1st).					*/
/************************************************************************/
unsigned char Get_Byte()
{
	unsigned char in = 0;

	in = SPI2_ByteExchange(0xFF);
	return in;
}

/************************************************************************/
/* PROCEDURE: Read_Status_Register					*/
/*									*/
/* This procedure reads the status register and returns the byte.	*/
/************************************************************************/
unsigned char SPI_Read_Status_Register()
{
	unsigned char byte = 0;
	CE_Low();			/* enable device */
	SPI2_ByteExchange(0x05);		/* send RDSR command */
	byte = SPI2_ByteExchange(0xFF);		/* receive byte */
	CE_High();			/* disable device */
	return byte;
}

/************************************************************************/
/* PROCEDURE: Read_Configuration_Register				*/
/*									*/
/* This procedure reads the configuration register and returns the byte.*/
/************************************************************************/
unsigned char SPI_Read_Configuration_Register()
{
	unsigned char byte = 0;
	CE_Low();			/* enable device */
	SPI2_ByteExchange(0x35);		/* send RDSR command */
	byte = SPI2_ByteExchange(0xFF);		/* receive byte */
	CE_High();			/* disable device */
	return byte;
}

/************************************************************************/
/* PROCEDURE: WREN							*/
/*									*/
/* This procedure enables the Write Enable Latch.               	*/
/************************************************************************/
void SPI_WREN()
{
	CE_Low();			/* enable device */
	SPI2_ByteExchange(0x06);		/* send WREN command */
	CE_High();			/* disable device */
}

/************************************************************************/
/* PROCEDURE: Jedec_ID							*/
/*									*/
/* This procedure Reads the manufacturer's ID, device Type and device ID.  It will 	*/
/* use AFh as the command to read the ID.                               */
/* Returns:								*/
/*	ID1(Manufacture's ID = BFh, Device Type =26h , Device ID = 18h)	*/
/*									*/
/************************************************************************/
void Jedec_ID_Read()
{
	CE_Low();                            /* enable device */
	SPI2_ByteExchange(0x9F);                    /* send JEDEC ID command (9Fh) */
   	Manufacturer_Id = SPI2_ByteExchange(0xFF);       /* receive byte */
  	Device_Type = SPI2_ByteExchange(0xFF);           /* receive byte */
  	Device_Id = SPI2_ByteExchange(0xFF);            /* receive byte */
	CE_High();                          /* disable device */
}

/************************************************************************/
/* PROCEDURE:	HighSpeed_Read_Cont					*/
/*									*/
/* This procedure reads multiple addresses of the device and stores	*/
/* data into 256 byte buffer. Maximum number of bytes read is limited to 256 bytes*/
/*									*/
/* Input:								*/
/*		Dst:		Destination Address 000000H - 7FFFFFH	*/
/*      	no_bytes	Number of bytes to read	(max = 256)	*/
/************************************************************************/
void SPI_HighSpeed_Read_Cont(unsigned long Dst, unsigned long no_bytes)
{
	unsigned long i = 0;
	CE_Low();				/* enable device */
	SPI2_ByteExchange(0x0B); 			/* read command */
	SPI2_ByteExchange(((Dst & 0xFFFFFF) >> 16)); 	/* send 3 address bytes */
	SPI2_ByteExchange(((Dst & 0xFFFF) >> 8));
	SPI2_ByteExchange(Dst & 0xFF);
	SPI2_ByteExchange(0xFF);                	/*dummy byte*/
	if (no_bytes>256)
	{no_bytes=256;}

	for (i = 0; i < no_bytes; i++)		/* read until no_bytes is reached */
	{
		data_256[i] = SPI2_ByteExchange(0xFF);
	}
	CE_High();				/* disable device */
}

/************************************************************************/
/* PROCEDURE:	HighSpeed_Read_Cont					*/
/*									*/
/* This procedure reads multiple addresses of the device and stores	*/
/* data into 256 byte buffer. Maximum number of bytes read is limited to 256 bytes*/
/*									*/
/* Input:								*/
/*		Dst:		Destination Address 000000H - 7FFFFFH	*/
/*      	no_bytes	Number of bytes to read	(max = 256)	*/
/************************************************************************/
INT16U SPI_HighSpeed_Read_word(unsigned long Dst)
{
	unsigned long i = 0;
    INT16U val;
	CE_Low();				/* enable device */
	SPI2_ByteExchange(0x0B); 			/* read command */
	SPI2_ByteExchange(((Dst & 0xFFFFFF) >> 16)); 	/* send 3 address bytes */
	SPI2_ByteExchange(((Dst & 0xFFFF) >> 8));
	SPI2_ByteExchange(Dst & 0xFF);
	SPI2_ByteExchange(0xFF);                	/*dummy byte*/

	val = SPI2_ByteExchange(0xFF);
    val <<= 8;
	val |= SPI2_ByteExchange(0xFF);
    
	CE_High();				/* disable device */
    
    return val;
}

/************************************************************************/
/* PROCEDURE:	Page_Program						*/
/*									*/
/* This procedure does page programming.  The destination               */
/* address should be provided.                                  	*/
/* The data array of 256 bytes contains the data to be programmed.      */
/* Since the size of the data array is 256 bytes rather than 256 bytes, this page program*/
/* procedure programs only 256 bytes                                    */
/* Assumption:  Address being programmed is already erased and is NOT	*/
/*		block protected.					*/
/* Input:								*/
/*		Dst:		Destination Address 000000H - 7FFFFFH	*/
/*		data_256[256] containing 256 bytes of data will be programmed using this function */
/************************************************************************/

void SPI_Page_Program(unsigned long Dst)
{
	unsigned int i;
	i=0;

	CE_Low();				/* enable device */
	SPI2_ByteExchange(0x02); 			/* send Byte Program command */
	SPI2_ByteExchange(((Dst & 0xFFFFFF) >> 16));	/* send 3 address bytes */
	SPI2_ByteExchange(((Dst & 0xFFFF) >> 8));
	SPI2_ByteExchange(Dst & 0xFF);
	for (i=0;i<256;i++)
	{	SPI2_ByteExchange(data_256[i]);		/* send byte to be programmed */
	}
	CE_High();				/* disable device */
}


/************************************************************************/
/* PROCEDURE: Chip_Erase						*/
/*									*/
/* This procedure erases the entire Chip.				*/
/************************************************************************/

void SPI_Chip_Erase()
{
	CE_Low();				/* enable device */
	SPI2_ByteExchange(0xC7);			/* send Chip Erase command (C7h) */
	CE_High();				/* disable device */
}


/************************************************************************/
/* PROCEDURE: Sector_Erase						*/
/*									*/
/* This procedure erases the entire Chip.				*/
/************************************************************************/

void SPI_4K_Sector_Erase(INT32U addr)
{
	CE_Low();				/* enable device */
	SPI2_ByteExchange(0x20);			/* send Sector Erase command (20h) */
    SPI2_ByteExchange((INT8U) (addr >> 16));
    SPI2_ByteExchange((INT8U) (addr >> 8));
    SPI2_ByteExchange((INT8U) (addr & 0xFF));
	CE_High();				/* disable device */
}


/************************************************************************/
/* PROCEDURE: ResetEn                                                   */
/*									*/
/* This procedure Enables acceptance of the RST (Reset) operation.	*/
/************************************************************************/
void SPI_ResetEn()
{
	CE_Low();				/* enable device */
	SPI2_ByteExchange(0x66);
	CE_High();				/* disable device */
}

/************************************************************************/
/* PROCEDURE: Reset                                     		*/
/*									*/
/* This procedure resets the device in to normal operating Ready mode.	*/
/*									*/
/************************************************************************/

void SPI_Reset()
{
	CE_Low();				/* enable device */
	SPI2_ByteExchange(0x99);
	CE_High();				/* disable device */
}

/************************************************************************/
/* PROCEDURE: Write_Status_Register					*/
/*									*/
/* This procedure resumes Program/Erase operation.			*/
/************************************************************************/

void SPI_Write_Status_Register(unsigned int data1, unsigned char datalen)
{	  //For data1 - top 8 bits are status reg bits , lower 8 bits are configuration reg bits
	CE_Low();				/* enable device */
	SPI2_ByteExchange(0x01);
	SPI2_ByteExchange((data1>>8)&0xff);
	if (datalen==2)
	{
		SPI2_ByteExchange((data1)&0xff);
	}

	CE_High();				/* disable device */
}

/************************************************************************/
/* PROCEDURE: Wait_Busy							*/
/*									*/
/* This procedure waits until device is no longer busy (can be used by	*/
/* Byte-Program, Page-Program, Sector-Erase, Block-Erase and Chip-Erase).*/
/************************************************************************/

void SPI_Wait_Busy()
{
	while ((SPI_Read_Status_Register()& 0x01) == 0x01)	// waste time until not busy
	SPI_Read_Status_Register();
}



 /****************************************************/
 /* Main Function*/
 /*****************************************************/

int flash_main()
{

unsigned long i,j,highest_address, tempdatalong; //m,k
int check,tempcheck,status;
int tempdata;
unsigned char Read_Stat_Reg ;  //devicedata
unsigned int loop_var;

i=0;
j=0;
status=1;  //1 means memory/code works and 0 means fault has occured.
check=0;  //keeps track of code progress.
tempcheck=1;
highest_address=0xfffff;    //8Mb   //highest_address=256;

CE_High();
WP_High();

i=0;
SPI_WREN();
	tempdatalong = 0x00;
	tempdatalong = tempdatalong<<8;
    tempdatalong = tempdatalong |(0x00);
	
SPI_Write_Status_Register(tempdatalong, 2);
    tempdata = SPI_Read_Configuration_Register();
      
/************* Test Jedec ID *********/
    
Jedec_ID_Read();

if ((Manufacturer_Id == 0xbf)&& (Device_Type==0x26) && (Device_Id==0x18)&&(status==1))
{	check=(check + 1);
	printf("\r\n !!!! Manufacturer_Id , Device_Type & Device_Id are OK !!!! \r\n");
    printf("\r\n Manufacturer_Id :%X , Device_Type :%X , Device_Id :%X \r\n",Manufacturer_Id, Device_Type, Device_Id);
}
else
{	check=0;
	printf("\r\n !!!! Manufacturer_Id , Device_Type & Device_Id are NOT OK !!!! \r\n");	
}
 		
/************* Page program whole chip using SPI protocol and verify its OK. *********/

i=0;
while (i<=255)
{
 data_256[i]= 0x21; // filling data in buffer
	i++;
}
 	
SPI_WREN();

SPI_Chip_Erase();	//Erase the chip

SPI_Wait_Busy();
 i=0;
SPI_WREN();


while(i < highest_address)
{	
    SPI_WREN();
    SPI_Page_Program(i);
	SPI_Wait_Busy();
	i=i+256;
}

SPI_WREN();
j=0;
while(j < highest_address)
{
	SPI_HighSpeed_Read_Cont(j, 256);
	for (loop_var=0;loop_var<256;loop_var++)
		{
            if(data_256[loop_var]== 0x21)
			{
                tempcheck&=1;
			}
			  else
			{ 
                tempcheck=0;
			}
		}
	j=j+256;
}

if ((tempcheck == 1)&&(status==1))
{
    check=(check+1);
	status=status&1;
	printf("\r\n !!!! Page read and write is Pass !!!! \r\n");
}
else
{
    status=0;
	printf("\r\n !!!! Page read and write is Failed !!!! \r\n");
}


  
/************* Erase the chip and verify its OK. *************/
printf("\r\n !!!! ERASING MEMORY !!!! \n");

i=0;
while (i<=255)
{
 data_256[i]= 0x33; // filling data in buffer
	i++;
}
 	
SPI_WREN();

SPI_Chip_Erase();	//Erase the chip

SPI_Wait_Busy();
 i=0;
SPI_WREN();


while(i < highest_address)
{	
    SPI_WREN();
    SPI_Page_Program(i);
	SPI_Wait_Busy();
	i=i+256;
}

SPI_WREN();
j=0;
while(j < highest_address)
{
	SPI_HighSpeed_Read_Cont(j, 256);
	for (loop_var=0;loop_var<256;loop_var++)
		{
            if(data_256[loop_var]== 0x33)
			{
                tempcheck&=1;
			}
			  else
			{ 
                tempcheck=0;
			}
		}
	j=j+256;
}

if ((tempcheck == 1)&&(status==1))
{
    check=(check+1);
	status=status&1;
	printf("\r\n !!!! Page read and write is Pass !!!! \r\n");
}
else
{
    status=0;
	printf("\r\n !!!! Page read and write is Failed !!!! \r\n");
}


SPI_ResetEn();
SPI_Reset();

 /***************** End of checking *****************/
return 0;
}

int flash_main_bkp_001()
{

unsigned long i,j,highest_address, tempdatalong; //m,k
int check,tempcheck,status;
int tempdata;
unsigned char Read_Stat_Reg ;  //devicedata
unsigned int loop_var;

i=0;
j=0;
status=1;  //1 means memory/code works and 0 means fault has occured.
check=0;  //keeps track of code progress.
tempcheck=1;
highest_address=0xfffff;    //8Mb   //highest_address=256;

CE_High();
WP_High();

i=0;
SPI_WREN();
	tempdatalong = 0x00;
	tempdatalong = tempdatalong<<8;
    tempdatalong = tempdatalong |(0x00);
	
SPI_Write_Status_Register(tempdatalong, 2);
    tempdata = SPI_Read_Configuration_Register();
      
/************* Test Jedec ID *********/
#if 0    
Jedec_ID_Read();

if ((Manufacturer_Id == 0xbf)&& (Device_Type==0x26) && (Device_Id==0x18)&&(status==1))
{	check=(check + 1);
	printf("\r\n !!!! Manufacturer_Id , Device_Type & Device_Id are OK !!!! \r\n");
    printf("\r\n Manufacturer_Id :%X , Device_Type :%X , Device_Id :%X \r\n",Manufacturer_Id, Device_Type, Device_Id);
}
else
{	check=0;
	printf("\r\n !!!! Manufacturer_Id , Device_Type & Device_Id are NOT OK !!!! \r\n");	
}
#endif 		
/************* Page program whole chip using SPI protocol and verify its OK. *********/

i=0;
while (i<=255)
{
 data_256[i]= 0x21; // filling data in buffer
	i++;
}
 	
SPI_WREN();

SPI_Chip_Erase();	//Erase the chip

SPI_Wait_Busy();
 i=0;
SPI_WREN();


while(i < highest_address)
{	
    SPI_WREN();
    SPI_Page_Program(i);
	SPI_Wait_Busy();
	i=i+256;
}

SPI_WREN();
j=0;
while(j < highest_address)
{
	SPI_HighSpeed_Read_Cont(j, 256);
	for (loop_var=0;loop_var<256;loop_var++)
		{
            if(data_256[loop_var]== 0x21)
			{
                tempcheck&=1;
			}
			  else
			{ 
                tempcheck=0;
			}
		}
	j=j+256;
}

if ((tempcheck == 1)&&(status==1))
{
    check=(check+1);
	status=status&1;
	printf("\r\n !!!! 0x21 Page read and write is Pass !!!! \r\n");
}
else
{
    status=0;
	printf("\r\n !!!! 0x21 Page read and write is Failed !!!! \r\n");
}


  
/************* Erase the chip and verify its OK. *************/
printf("\r\n !!!! ERASING MEMORY !!!! \n");

i=0;
while (i<=255)
{
 data_256[i]= 0x33; // filling data in buffer
	i++;
}
 	
SPI_WREN();

SPI_Chip_Erase();	//Erase the chip

SPI_Wait_Busy();
 i=0;
SPI_WREN();


while(i < highest_address)
{	
    SPI_WREN();
    SPI_Page_Program(i);
	SPI_Wait_Busy();
	i=i+256;
}

SPI_WREN();
j=0;
while(j < highest_address)
{
	SPI_HighSpeed_Read_Cont(j, 256);
	for (loop_var=0;loop_var<256;loop_var++)
		{
            if(data_256[loop_var]== 0x33)
			{
                tempcheck&=1;
			}
			  else
			{ 
                tempcheck=0;
			}
		}
	j=j+256;
}

if ((tempcheck == 1)&&(status==1))
{
    check=(check+1);
	status=status&1;
	printf("\r\n !!!! 0x33 Page read and write is Pass !!!! \r\n");
}
else
{
    status=0;
	printf("\r\n !!!! 0x33 Page read and write is Failed !!!! \r\n");
}


SPI_ResetEn();
SPI_Reset();

 /***************** End of checking *****************/
return 0;
}


int flash_main_bkp_002() //passing for Sector Erase and read & write
{

unsigned long i,j,start_address, highest_address, tempdatalong; //m,k
int check,tempcheck,status;
int tempdata;
unsigned char Read_Stat_Reg ;  //devicedata
unsigned int loop_var;

i=0;
j=0;
status=1;  //1 means memory/code works and 0 means fault has occured.
check=0;  //keeps track of code progress.
tempcheck=1;
start_address=0x1000;    //beginning of 4k sector
highest_address=0x1fff;    //end of 4k sector


CE_High();
WP_High();

i=0;
SPI_WREN();
	tempdatalong = 0x00;
	tempdatalong = tempdatalong<<8;
    tempdatalong = tempdatalong |(0x00);
	
SPI_Write_Status_Register(tempdatalong, 2);
    tempdata = SPI_Read_Configuration_Register();
      
/************* Test Jedec ID *********/
#if 0    
Jedec_ID_Read();

if ((Manufacturer_Id == 0xbf)&& (Device_Type==0x26) && (Device_Id==0x18)&&(status==1))
{	check=(check + 1);
	printf("\r\n !!!! Manufacturer_Id , Device_Type & Device_Id are OK !!!! \r\n");
    printf("\r\n Manufacturer_Id :%X , Device_Type :%X , Device_Id :%X \r\n",Manufacturer_Id, Device_Type, Device_Id);
}
else
{	check=0;
	printf("\r\n !!!! Manufacturer_Id , Device_Type & Device_Id are NOT OK !!!! \r\n");	
}
#endif 		
/************* Page program whole chip using SPI protocol and verify its OK. *********/

i=0;
while (i<=255)
{
 data_256[i]= 0x21; // filling data in buffer
	i++;
}
 	
SPI_WREN();

//SPI_Chip_Erase();	//Erase the chip
SPI_4K_Sector_Erase(start_address);

SPI_Wait_Busy();
 i=start_address;
SPI_WREN();


while(i < highest_address)
{	
    SPI_WREN();
    SPI_Page_Program(i);
	SPI_Wait_Busy();
	i=i+256;
}

SPI_WREN();
j=start_address;
while(j < highest_address)
{
	SPI_HighSpeed_Read_Cont(j, 256);
	for (loop_var=0;loop_var<256;loop_var++)
		{
            if(data_256[loop_var]== 0x21)
			{
                tempcheck&=1;
			}
			  else
			{ 
                tempcheck=0;
			}
		}
	j=j+256;
}

if ((tempcheck == 1)&&(status==1))
{
    check=(check+1);
	status=status&1;
	printf("\r\n !!!! 0x21 Page read and write is Pass !!!! \r\n");
}
else
{
    status=0;
	printf("\r\n !!!! 0x21 Page read and write is Failed !!!! \r\n");
}


  
/************* Erase the chip and verify its OK. *************/
printf("\r\n !!!! ERASING MEMORY !!!! \n");

i=0;
while (i<=255)
{
 data_256[i]= 0x33; // filling data in buffer
	i++;
}
 	
SPI_WREN();

//SPI_Chip_Erase();	//Erase the chip
SPI_4K_Sector_Erase(start_address);

SPI_Wait_Busy();
 i=start_address;
SPI_WREN();


while(i < highest_address)
{	
    SPI_WREN();
    SPI_Page_Program(i);
	SPI_Wait_Busy();
	i=i+256;
}

SPI_WREN();
j=start_address;
while(j < highest_address)
{
	SPI_HighSpeed_Read_Cont(j, 256);
	for (loop_var=0;loop_var<256;loop_var++)
		{
            if(data_256[loop_var]== 0x33)
			{
                tempcheck&=1;
			}
			  else
			{ 
                tempcheck=0;
			}
		}
	j=j+256;
}

if ((tempcheck == 1)&&(status==1))
{
    check=(check+1);
	status=status&1;
	printf("\r\n !!!! 0x33 Page read and write is Pass !!!! \r\n");
}
else
{
    status=0;
	printf("\r\n !!!! 0x33 Page read and write is Failed !!!! \r\n");
}


SPI_ResetEn();
SPI_Reset();

 /***************** End of checking *****************/
return 0;
}

int flash_main_bkp_003() //passing for Sector Erase and read & write 4 bytes
{

unsigned long i,j,start_address, highest_address, tempdatalong; //m,k
int check,tempcheck,status;
int tempdata;
unsigned char Read_Stat_Reg ;  //devicedata
unsigned int loop_var;

i=0;
j=0;
status=1;  //1 means memory/code works and 0 means fault has occured.
check=0;  //keeps track of code progress.
tempcheck=1;
start_address=0x1000;    //beginning of 4k sector
highest_address=0x1fff;    //end of 4k sector


CE_High();
WP_High();

i=0;
SPI_WREN();
	tempdatalong = 0x00;
	tempdatalong = tempdatalong<<8;
    tempdatalong = tempdatalong |(0x00);
	
SPI_Write_Status_Register(tempdatalong, 2);
    tempdata = SPI_Read_Configuration_Register();
      
/************* Test Jedec ID *********/
#if 0    
Jedec_ID_Read();

if ((Manufacturer_Id == 0xbf)&& (Device_Type==0x26) && (Device_Id==0x18)&&(status==1))
{	check=(check + 1);
	printf("\r\n !!!! Manufacturer_Id , Device_Type & Device_Id are OK !!!! \r\n");
    printf("\r\n Manufacturer_Id :%X , Device_Type :%X , Device_Id :%X \r\n",Manufacturer_Id, Device_Type, Device_Id);
}
else
{	check=0;
	printf("\r\n !!!! Manufacturer_Id , Device_Type & Device_Id are NOT OK !!!! \r\n");	
}
#endif 		
/************* Page program whole chip using SPI protocol and verify its OK. *********/

i=0;
while (i<=255)
{
 data_256[i]= 0x21; // filling data in buffer
	i++;
}

data_256[0] = 0xB9;
data_256[1] = 0x57;
data_256[2] = 0x3C;
data_256[3] = 0xED;
 	
SPI_WREN();

//SPI_Chip_Erase();	//Erase the chip
SPI_4K_Sector_Erase(start_address);

SPI_Wait_Busy();
 i=start_address;
SPI_WREN();


//while(i < highest_address)
{	
    SPI_WREN();
    SPI_Page_Program(i);
	SPI_Wait_Busy();
	i=i+256;
}

SPI_WREN();
j=start_address;
while(j < highest_address)
{
	SPI_HighSpeed_Read_Cont(j, 256);
	for (loop_var=0;loop_var<256;loop_var++)
		{
            if(data_256[loop_var] == 0xB9)
                continue;
            if(data_256[loop_var] == 0x57)
                continue;
            if(data_256[loop_var] == 0x3C)
                continue;
            if(data_256[loop_var] == 0xED)
                continue;

            if(data_256[loop_var]== 0x21 || data_256[loop_var]== 0xFF)
			{
                tempcheck&=1;
			}
			  else
			{ 
                tempcheck=0;
			}
		}
	j=j+256;
}

if ((tempcheck == 1)&&(status==1))
{
    check=(check+1);
	status=status&1;
	printf("\r\n !!!! Page read and write is Pass !!!! \r\n");
}
else
{
    status=0;
	printf("\r\n !!!! Page read and write is Failed !!!! \r\n");
}

SPI_ResetEn();
SPI_Reset();

 /***************** End of checking *****************/
return 0;
}

void NVM_Erase_4K_Sector_store_2_words(INT32U addr, INT16U data1, INT16U data2)
{

unsigned long i,j,start_address, highest_address, tempdatalong; //m,k
int check,tempcheck,status;
int tempdata;
unsigned char Read_Stat_Reg ;  //devicedata
unsigned int loop_var;

i=0;
j=0;
status=1;  //1 means memory/code works and 0 means fault has occured.
check=0;  //keeps track of code progress.
tempcheck=1;
start_address = addr & 0x00FFF000;    //beginning of 4k sector
highest_address = start_address + 0xFFF;    //end of 4k sector


CE_High();
WP_High();

i=0;
SPI_WREN();
	tempdatalong = 0x00;
	tempdatalong = tempdatalong<<8;
    tempdatalong = tempdatalong |(0x00);
	
SPI_Write_Status_Register(tempdatalong, 2);
    tempdata = SPI_Read_Configuration_Register();
      
/************* Test Jedec ID *********/
#if 0
    
Jedec_ID_Read();

if ((Manufacturer_Id == 0xbf)&& (Device_Type==0x26) && (Device_Id==0x18)&&(status==1))
{	check=(check + 1);
	printf("\r\n !!!! Manufacturer_Id , Device_Type & Device_Id are OK !!!! \r\n");
    printf("\r\n Manufacturer_Id :%X , Device_Type :%X , Device_Id :%X \r\n",Manufacturer_Id, Device_Type, Device_Id);
}
else
{	check=0;
	printf("\r\n !!!! Manufacturer_Id , Device_Type & Device_Id are NOT OK !!!! \r\n");	
}
#endif 		
/************* Page program whole chip using SPI protocol and verify its OK. *********/

i=0;
while (i<=255)
{
 data_256[i]= 0x32; // filling data in buffer
	i++;
}

data_256[0] = (data1 >> 8) & 0xFF;
data_256[1] = data1 & 0xFF;
data_256[2] = (data2 >> 8) & 0xFF;
data_256[3] = data2 & 0xFF;
 	
SPI_WREN();

//SPI_Chip_Erase();	//Erase the chip
SPI_4K_Sector_Erase(start_address);

SPI_Wait_Busy();
 i=start_address;
SPI_WREN();


//while(i < highest_address)
{	
    SPI_WREN();
    SPI_Page_Program(i);
	SPI_Wait_Busy();
	i=i+256;
}

SPI_ResetEn();
SPI_Reset();

 /***************** End of checking *****************/
return 0;
}

INT16U NVM_read_ANG_BASE(INT32U addr)
{
    CE_High();
    WP_High();

    SPI_WREN();
	return SPI_HighSpeed_Read_word(addr);

}

void NVM_read_2_words(INT32U addr, INT16U *data1, INT16U *data2)
{
    *data1 = NVM_read_ANG_BASE(addr);
    *data2 = NVM_read_ANG_BASE(addr+2);
    
    return;
}
