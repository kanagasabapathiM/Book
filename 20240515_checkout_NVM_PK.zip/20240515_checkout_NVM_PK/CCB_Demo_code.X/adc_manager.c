/*
 * File:   adc_manager.c
 * Author: e40063636
 *
 * Created on March 21, 2024, 8:19 PM
 */

/*********************************************************************************************
Includes
 *********************************************************************************************/
#include "adc_manager.h"
#include "cpu.h"
#include "global.h"
#include "utility.h"

/*********************************************************************************************
Private Preprocessor definitions
 *********************************************************************************************/
/* ADC readings are converted to mv by multiplying by .806 */
#define ADC_CONVERSION_FACTOR 0.806 /* 3300mv vref / 4096 steps */
#define NO_OF_SAMPLES  50  //Samples required for ISENSE ADC value average
#define NO_OF_CHANNELS 4   // Total number of Analog channels
#define ENABLE_DMA  1
/*********************************************************************************************
Global- and File-Scope Variable definitions
 *********************************************************************************************/
// These variables will keep the conversion result.
volatile INT16U dataAN[4]; //ISENSE-AN0, ISENSE_REF-ANA1, SOL_VMON-AN3, VMON-AN9
static INT16U Isense_buf[NO_OF_SAMPLES];
static INT16U index = 0;
static bool Isense_buf_full = false;

#ifdef ENABLE_DMA
INT16U ADC_DMA_Bufferch0[50];
INT16U ADC_DMA_Bufferch1[1];
#endif
// Section: File specific functions
#ifdef ENABLE_DMA
static void _adcm_setup_dma();
#endif
/**
  Section: Driver Interface
*/
/*********************************************************************************************
Private Function declarations
 *********************************************************************************************/


static void ADC_PowerEnable(void);

/*********************************************************************************************
Function definitions
 *********************************************************************************************/

/*********************************************************************************************
*Initializes the ADC Core0,core1 for AN0,ANA1 respectively
 *********************************************************************************************/
void adcm_init()
{

    ADCON1Lbits.ADON = 0; // Turn off ADC module

    ADCON1Hbits.FORM = 0; // integer format
    ADCON1Hbits.SHRRES = 3; //SHRRES 12-bit resolution

    ADCON2L = 0x00;
   ADCON2Hbits.SHRSAMC = 0x12; //Shared ADC Core Sample Time

    ADCON3L = 0x00; // AVdd,AVss as voltage reference

    ADCON3Hbits.CLKSEL = 3;//FVCO/4 =120MHz  //0; // FP(Peripheral Clock)
    ADCON3Hbits.CLKDIV = 2; // dived by 2 //no clock divider (1:1)

    ADCON4L = 0x0;

    ADCON4Hbits.C0CHS = 0x00; //Dedicated ADC Core 0 Input Channel AN0
    ADCON4Hbits.C1CHS = 0x01; //Dedicated ADC Core 1 Input Channel ANA1
    ADCON4Hbits.C3CHS = 0x00; //Dedicated ADC Core 1 Input Channel ANA3
    
    //Input Mode Single ended
    ADMOD0L = 0x00;
    ADMOD0H = 0x00;
    ADMOD1L = 0x00;
    ADMOD1H = 0x00;

    ADIELbits.IE0 = 1; // enable interrupt for AN0
    ADIELbits.IE1 = 1; // enable interrupt for AN1
    ADIELbits.IE3 = 1; // enable interrupt for AN3
    ADIELbits.IE9 = 1; // enable interrupt for AN9
   // _ADCAN0IP = 7;//TEMPORARY

    // Configure the cores ADC clock.
    ADCORE0Hbits.ADCS = 0; // clock divider (1:2)
    ADCORE1Hbits.ADCS = 0; // clock divider (1:2)
    ADCORE3Hbits.ADCS = 0; // clock divider (1:2)
    ADCON2Lbits.SHRADCS = 0; //// clock divider (1:2)
    
    // Configure the cores ADC Resolution.
    ADCORE0Hbits.RES = 3; // 12-bit resolution core 0
    ADCORE1Hbits.RES = 3; // 12-bit resolution core 1
    ADCORE3Hbits.RES = 3; // 12-bit resolution core 2
    ADCON1Hbits.SHRRES = 3; // 12-bit resolution common Core
    
    ADCBUF0 = 0x0;
    ADCBUF1 = 0x0;
    ADCBUF3 = 0x0;
    ADCBUF9 = 0x0;
    
    //Dedicated ADC Core x Conversion Delay Selection bits
    ADCORE0Lbits.SAMC = 0; //2 TADCORE
    ADCORE1Lbits.SAMC = 0; //2 TADCORE
    ADCORE3Lbits.SAMC = 0; //2 TADCORE
    
    ADCON5Hbits.WARMTIME = 0xF; //// Set initialization time to maximum
    ADCON1Lbits.ADON = 1; // Turn on ADC module
#ifndef ENABLE_DMA
    _ADCAN0IF = 0; // clear interrupt flag for AN0
    _ADCAN0IE = 1; // enable interrupt for AN0

    _ADCAN1IF = 0; // clear interrupt flag for AN1
    _ADCAN1IE = 1; // enable interrupt for AN1

    _ADCAN3IF = 0; // clear interrupt flag for AN3
    _ADCAN3IE = 1; // enable interrupt for AN3

    _ADCAN9IF = 0; // clear interrupt flag for AN9
    _ADCAN9IE = 1; // enable interrupt for AN9
#endif
    //ADCCORE0Lbits.
#ifdef ENABLE_DMA
    _adcm_setup_dma();
#endif
    ADC_PowerEnable();

    /*ideal to set Level software trigger for continuous triggering, But some reason
    this is working for only core 0, currently source is Common software trigger every 
    iteration ADCON3Lbits.SWCTRG should be set*/
    ADTRIG0Lbits.TRGSRC0 = 0x12; // PWM8 Trigger 1 //PWM_init(); should be called)
    ADTRIG0Lbits.TRGSRC1 = 0x12; // PWM8 Trigger 1
    ADTRIG0Hbits.TRGSRC3 = 1;//0b01110; // Common software trigger
    ADTRIG2Lbits.TRGSRC9 = 1;//0b01110; // Common software trigger

}

/*********************************************************************************************
 * Author(s):   PK
 * Description: currently DMA is not used, if wanted disable ADC channel interrupt and enable DMA interrupts
 * Parameters:  None.
 * Returns:     None.
 *********************************************************************************************/
#ifdef ENABLE_DMA
static void _adcm_setup_dma()
{

    DMACON = 0x00; //The module is disabled, till other settings are configured
    DMAL= 0x1000; // LADDR 4096;
    DMAH= 0xFFFF; // HADDR 65535; 
    //CH0
    DMACH0bits.CHEN   = 0; //The channel is disabled, till other settings are configured.
    DMACH0bits.RELOAD = 1; //Address and Count Reload bit enable
    DMACH0bits.TRMODE = 1; //Repeated One-Shot
    DMACH0bits.SAMODE = 3; //DMASRCn is used in Peripheral Indirect Addressing and remains unchanged
    DMACH0bits.DAMODE = 1; //DMADSTn remains unchanged after a transfer completion
    
    DMAINT0bits.CHSEL = 0x28; //Trigger (Interrupt) ADC Done AN0

    DMASRC0= (volatile unsigned int)&ADCBUF0;; //DMA Data Source Address 
    DMADST0= __builtin_dmaoffset(ADC_DMA_Bufferch0); //DMA Data Destination Source
    DMACNT0= 50;  //DMA Transaction Counter
    
    IFS0bits.DMA0IF = 0; // Clearing Channel 0 Interrupt Flag
    IEC0bits.DMA0IE = 1; //  // Enabling Channel 0 Interrupt

    //CH1
    DMACH1bits.CHEN   = 0; //The channel is disabled, till other settings are configured.
    DMACH1bits.RELOAD = 1; //Address and Count Reload bit enable
    DMACH1bits.TRMODE = 1; //Repeated One-Shot
    DMACH1bits.SAMODE = 3; //DMASRCn is used in Peripheral Indirect Addressing and remains unchanged
    DMACH1bits.DAMODE = 1; //DMADSTn remains unchanged after a transfer completion
    
    DMAINT1bits.CHSEL = 0x28; //Trigger (Interrupt) ADC Done AN0

    DMASRC1= (volatile unsigned int)&ADCBUF1;; //DMA Data Source Address 
    DMADST1= __builtin_dmaoffset(ADC_DMA_Bufferch1); //DMA Data Destination Source
    DMACNT1= 1;  //DMA Transaction Counter
    
    IFS0bits.DMA1IF = 0; // Clearing Channel 0 Interrupt Flag
    IEC0bits.DMA1IE = 1; //  // Enabling Channel 0 Interrupt

    DMACONbits.DMAEN = 1; // Enable DMA
    DMACH0bits.CHEN = 1; //Enable DMA Channel 0
    DMACH1bits.CHEN = 1; //Enable DMA Channel 1
}
#endif

static void ADC_PowerEnable(void)
{
 
    ADCON5Lbits.C0PWR = 1;// Turn on analog power for dedicated core 0
    while (ADCON5Lbits.C0RDY == 0);// Wait when the core 0 is ready for operation
    ADCON3Hbits.C0EN = 1; // Turn on digital power to enable triggers to the core 0
    
   
    ADCON5Lbits.C1PWR = 1; // Turn on analog power for dedicated core 1
    while (ADCON5Lbits.C1RDY == 0);// Wait when the core 1 is ready for operation
    ADCON3Hbits.C1EN = 1;// Turn on digital power to enable triggers to the core 1
    
    ADCON5Lbits.C3PWR = 1; // Turn on analog power for dedicated core 1
    while (ADCON5Lbits.C3RDY == 0);// Wait when the core 1 is ready for operation
    ADCON3Hbits.C3EN = 1;// Turn on digital power to enable triggers to the core 
    
    ADCON5Lbits.SHRPWR = 1;// Turn on analog power for shared core
    while (ADCON5Lbits.SHRRDY == 0);// Wait when the shared core is ready for operation
    ADCON3Hbits.SHREN = 1;// Turn on digital power to enable triggers to the shared core
}

// ADC AN0 ISR
void __attribute__((interrupt, no_auto_psv)) _ADCAN0Interrupt(void) {
    
    if (index < NO_OF_SAMPLES) {
        Isense_buf[index] = ADCBUF0;
        index++;
    } else {
        index = 0;
        Isense_buf_full = true;//at least we 20 samples first time
    }
    _ADCAN0IF = 0; // clear interrupt flag
}
/*
void ADC_Isense_RawAvg() {
    
    INT32U avg = 0;
    
    if (Isense_buf_full == true) {
        for (INT8U i = 0; i < NO_OF_SAMPLES; i++) {
            avg = avg + Isense_buf[i];
        }
    }
    avg = avg / NO_OF_SAMPLES;

    dataAN[0] = (INT16U) avg;
}
*/


void ADC_Isense_RawAvg() {
    
    INT32U avg = 0;
    
    //if (Isense_buf_full == true) {
        for (INT8U i = 0; i < NO_OF_SAMPLES; i++) {
            avg = avg + ADC_DMA_Bufferch0[i];
        }
    //}
    avg = avg / NO_OF_SAMPLES;
    dataAN[1] = ADC_DMA_Bufferch1[0];
    dataAN[0] = (INT16U) avg;
}

// ADC AN1 ISR
void __attribute__((interrupt, no_auto_psv)) _ADCAN1Interrupt(void) {
    dataAN[1] = ADCBUF1; // read conversion result
    //RED_LED_PIN = RED_LED_PIN ^ 1;
    _ADCAN1IF = 0; // clear interrupt flag
}

// SOL_VMON
void __attribute__((interrupt, no_auto_psv)) _ADCAN3Interrupt(void) {
    dataAN[2] = ADCBUF3; // read conversion result
    _ADCAN3IF = 0; // clear interrupt flag
}

// VMON
void __attribute__((interrupt, no_auto_psv)) _ADCAN9Interrupt(void) {
    dataAN[3] = ADCBUF9; // read conversion result
    _ADCAN9IF = 0; // clear interrupt flag
}
void __attribute__ ( ( interrupt, no_auto_psv ) ) _DMA0Interrupt( void )
{
    IFS0bits.DMA0IF = 0;
}

void __attribute__ ( ( interrupt, no_auto_psv ) ) _DMA1Interrupt( void )
{
    IFS0bits.DMA1IF = 0;
}
/* AN0:   ADC_CHANNEL_ISENSE
   ANA1 :   ADC_CHANNEL_ISENSE_REF 
   AN3 :   ADC_CHANNEL_SOL_MON 
   AN9 :   ADC_CHANNEL_VMON   */
INT16U ADC_raw_value(INT8U channel) {
    
    if(channel<NO_OF_CHANNELS)
    {
        return dataAN[channel];
    }
    return 0;
}