/*
 Author(s): Andrew Kilkenny <akilkenny@righthandtech.com>
            James Pieterick <jpieterick@righthandtech.com>
 Status: Preliminary
 Release Date:
 Revision:
 Description: Header file for the Position Module.
 */

#ifndef POSITION_H
#define	POSITION_H

/*********************************************************************************************
Includes
*********************************************************************************************/
#include "typedef.h"

/*********************************************************************************************
Type Definitions
*********************************************************************************************/
typedef enum
{
    ENCODER_1,
    ENCODER_2,
    ENCODER_3
} ENCODER_ID_NUMBER;

typedef struct psn_position_data
{
    INT16U cosp1;
    INT16U cosn1;
    INT16U sinn1;
    INT16U sinp1;
    INT16U cosn2;
    INT16U sinn2;
    INT16U sinp2;
    INT16U cosp2;
} PSN_POSITION_DATA;

/*********************************************************************************************
Preprocessor definitions
*********************************************************************************************/
#ifndef PRIVACY_DIVIDER
#define MAX_ENC_RANGE   6840 /* The maximum encoder range of the actuator*/
#else
#define MAX_ENC_RANGE   5400 /* The maximum encoder range of the Privacy Divider*/
#endif

/*********************************************************************************************
Function declarations
*********************************************************************************************/

/*********************************************************************************************
 * Author(s):   Michael Ansolis
 * Description: Gets the encoder calibration parameters from the configuration module.
 * Parameters:  None
 * Returns:     NO_ERROR    - indicates success
 *              ERR_FAILURE - indicates failure
*********************************************************************************************/
ERR_RET psn_init(void);

/*********************************************************************************************
Author(s):   James Pieterick <jpieterick@righthandtech.com>
Description: Calculates the most recent calculated position
Parameters:  None.
Returns:     INT16U - the most recent calculated position info.
*********************************************************************************************/
INT16U psn_calc_position( void );

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Returns the most recent calculated position.
 * Parameters:  None.
 * Returns:     INT16U - the most recent calculated position info.
 ********************************************************************************************/
INT16U psn_get_latest_position( void );

/*********************************************************************************************
Author(s):   James Pieterick
Description: This function is intended for the ADC manager to use to push the position data to
             the position module from inside the ADC ISR.
Parameters:  P_pushed_data - Pointer to a structure containing the copy of the raw adc readings
                             That are to be copied to the local static structure
                             S_position_data.
Returns:     None.
 *********************************************************************************************/
void psn_isr_push_adc(PSN_POSITION_DATA *P_pushed_data);

/*********************************************************************************************
Author(s):   Michael Ansolis
Description: This function returns TRUE if encoder signals are invalid and FALSE otherwise.
Parameters:  None.
Returns:     See description.
 *********************************************************************************************/
BOOL psn_get_invalid_encoder_signals( INT16U encoder );

/*********************************************************************************************
 * Author(s):   Michael Ansolis
 * Description: This function returns raw position data measurements.
 * Parameters:  cos1 - pointer to the returned encoder 1 differential cos value.
 *              sin1 - pointer to the returned encoder 1 differential sin value.
 *              cos2 - pointer to the returned encoder 2 differential cos value.
 *              sin2 - pointer to the returned encoder 2 differential sin value.
 * Returns:     None
 *********************************************************************************************/
void psn_get_raw_position_data( INT16S* cos1, INT16S* sin1, INT16S* cos2, INT16S* sin2 );

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: This function returns the encoder swap value.
 * Parameters:  None
 * Returns:     INT16U - encoder swap value
 *********************************************************************************************/
INT16U psn_get_encoder_swap( void );

/*********************************************************************************************
 * Author(s):   M VanderZouwen
 * Description: gets the parameters for the Invalid Encoder Output event data frame
 *********************************************************************************************/
void psn_get_event_parameters(
    INT16U encoder,                           /* which encoder's data to send */
    INT16U* cosp,                               /* cosine positive millivolts */
    INT16U* cosn,                               /* cosine negative millivolts */
    INT16U* sinp,                                 /* sine positive millivolts */
    INT16U* sinn,                                 /* sine negative millivolts */
    INT16U* maxV,                                   /* max voltage millivolts */
    INT16U* minV);                                  /* min voltage millivolts */

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: This function returns the hall effect stop timeout value.
 * Parameters:  None
 * Returns:     INT32U - encoder swap value
 *********************************************************************************************/
INT32U psn_get_hef_stop_timeout( void );

#endif  /*POSITION_H */
