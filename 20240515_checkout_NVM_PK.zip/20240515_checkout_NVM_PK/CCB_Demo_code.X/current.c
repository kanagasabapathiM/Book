/*
Author(s):      Michael Ansolis
Status:         Preliminary
Release Date:
Revision:       Initial
Description:    Accepts 'pushed' raw current values from the ADC module and
                passes raw and offset & scale compensated current values to
                the system monitor, comms & bldc control modules as requested.
*/
/*********************************************************************************************
Includes
*********************************************************************************************/
#include "global.h"
#include "current.h"
#include "cpu.h"

/*********************************************************************************************
Private Type Definitions
*********************************************************************************************/

/*********************************************************************************************
Private Preprocessor definitions
*********************************************************************************************/

#define NUM_STATUS_SAMPLES      20ul     /* Number of samples used to computed current average value. */
#define ADC_RESOLUTION          4095.0f  /* Maximum voltage in ADC units. */
#define MAX_VOLTAGE_MV          3300.0f  /* Maximum voltage on ADC input in mV. */

/*********************************************************************************************
Global Variable definitions
*********************************************************************************************/


/*********************************************************************************************
Function definitions
*********************************************************************************************/

/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Computes and returns the average of the NUM_STATUS_SAMPLES most recently cached
             BLDC motor drive current measurements by summing the samples and then dividing by
             NUM_STATUS_SAMPLES.  The final value is converted into mA.
Parameters:  None.
Returns:     See description.
*********************************************************************************************/
// updated currently no avg calculations
INT16S crnt_get_current_average()
{
    INT16U isense = 0;
    INT16U isense_ref = 0;
    INT16S ret_val = 0; /* Current of 0 will be reported at start-up. */
    FP32   adc_val_in_mv;
    FP32   temp;
    const FP32  Op_gain = 15.7; // Op_gain_1 default value op2_gain1  011B , 26.90 (default)
    const FP32  shunt_resistor = 0.025;  //25m ohm
    /* At least 20 averaged samples have been accumulated at this point. */
   // if( G_offset_applied )
    {
        isense = cpu_GetCurrent();
        isense_ref = cpu_GetCurrentref(); 
        
       // int temp1 = isense*0.806;
        //int temp2 = isense_ref*0.806;
//printf("\r\isense_ref  isense  %d     %d\r\n",temp1,temp2);
        /* Convert the ADC count into a mV value and normalize it using the idle current offset */
        adc_val_in_mv = ( ( ( (FP32) isense - (FP32)isense_ref ) * MAX_VOLTAGE_MV ) /
                          ADC_RESOLUTION );

       /* For applied gain in BLDC driver refer Op_gain_1 TLE9180D-31QK Bridge Driver IC*/
        /* Convert the ADC count in mV to mA*/
        temp = ( adc_val_in_mv /Op_gain )/ shunt_resistor;
        ret_val = (INT16S)(temp);
    }
    //printf("\r\ncurretn %d\r\n",ret_val);
    return ret_val;
}
