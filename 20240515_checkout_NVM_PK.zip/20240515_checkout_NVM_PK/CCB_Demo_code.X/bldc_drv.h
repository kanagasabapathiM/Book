#ifndef _BLDC_DRV_H
#define _BLDC_DRV_H

/*********************************************************************************************
 * Includes
 ********************************************************************************************/
#include "typedef.h"
#include <stddef.h>
#include "cpu.h"
#include "spi.h"
#include "utility.h"
#include <xc.h>

//BLDC driver register address
#define     CONF_SIG_ADDR            0x00   // Configuration Signature
#define     CONF_GEN_1_ADDR          0x01   // General Configuration 1
#define     CONF_GEN_2_ADDR          0x02   // General Configuration 2
#define     CONF_GEN_3_ADDR          0x03   // General Configuration 3
#define     CONF_WWD_ADDR            0x04   // Window Watchdog
#define     TL_VS_ADDR               0x05   // Vs Over- and Undervoltage Thresholds
#define     TL_VDH_ADDR              0x06   // VDHP Over- and Undervoltage Thresholds
#define     TL_CBVCC_ADDR            0x07   // CB Under- and VCC Under- and Overvoltage Thresholds
#define     FM_1_ADDR                0x08   // Charge Pump/High-side Buffer Failure Modes
#define     FM_2_ADDR                0x09   // Miscellaneous Failure Modes
#define     FM_3_ADDR                0x0A   // Vs & VDHP & VCC Undervoltage Failure Modes
#define     FM_4_ADDR                0x0B   // Vs & VDHP & VCC Overvoltage Failure Modes
#define     FM_5_ADDR                0x0C   // Short Circuit Detection & Signal Path Supervision Failure Modes
#define     DT_HS_ADDR               0x0D   // Dead Time High-side
#define     DT_LS_ADDR               0x0E   // Dead Time High-side
#define     FT_1_LS_ADDR             0x0F   // Undervoltage Filter Times
#define     FT_2_LS_ADDR             0x10   // Overvoltage and VCC Filter Times
#define     FT_3_LS_ADDR             0x11   // Overtemperature & Short Circuit Detection Filter Times
#define     FT_4_LS_ADDR             0x12  // Overcurrent Filter Time
#define     FM_6_LS_ADDR             0x13   // Overcurrent Failure Modes
#define     OP_GAIN_1_ADDR           0x20   // Current Sense Amplifier 1&2 - Gain 1
#define     OP_GAIN_2_ADDR           0x21   // Current Sense Amplifier 1&2 - Gain 2
#define     OP_GAIN_3_ADDR           0x22   // Current Sense Amplifier 3 - Gain 1&2
#define     OP_0CL_ADDR              0x23   // Current Sense Amplifier Zero Current Offset
#define     OP_CON_ADDR              0x24   // Current Sense Amplifier Configuration
#define     SC_LS_1_ADDR             0x25   // Short Circuit Detection Threshold Low-side 1
#define     SC_LS_2_ADDR             0x26   // Short Circuit Detection Threshold Low-side 2
#define     SC_LS_3_ADDR             0x27   // Short Circuit Detection Threshold Low-side 3
#define     SC_HS_1_ADDR             0x28   // Short Circuit Detection Threshold High-side 1
#define     SC_HS_2_ADDR             0x29   // Short Circuit Detection Threshold High-side 2
#define     SC_HS_3_ADDR             0x2A   // Short Circuit Detection Threshold High-side 3
#define     LI_CTR_ADDR              0x2B   // Limp Home Activation and Half Bridge Deactivation
#define     MISC_CTR_ADDR            0x2C   // Shift Phase Voltage Feedback and CSA Gain
#define     ART_TLP_ADDR             0x2D   // Passive Rectification Threshold
#define     ART_TLA_ADDR             0x2E   // Active Rectification Threshold
#define     ART_FI_ADDR              0x2F   // Rectification Filter Time
#define     ART_ACC_ADDR             0x30   // Rectification Accuracy
#define     ART_ENTRY_ADDR           0x31   // Rectification Mode entry
#define     NOP_ADDR                 0x32   // Operation
#define     DREV_MARK_ADDR           0x33   // Reverse Diode Measurement
#define     DS_MARK_ADDR             0x34   // Drain Source Measurement
#define     SEL_ST_1_ADDR            0x35   // Self Test Selection 1
#define     SEL_ST_2_ADDR            0x36   // Self Test Selection 2
#define     EN_ST_ADDR               0x37   // Self Test Mode Entry
#define     OM_OVER_ADDR             0x40   // Operation Mode Overview
#define     ERR_OVER_ADDR            0x41   // Error Overview
#define     SER_ADDR                 0x42   // Special Event Register
#define     ERR_I_1_ADDR             0x43   // Internal Errors 1
#define     ERR_I_2_ADDR             0x44   // Internal Errors 2
#define     ERR_E_ADDR               0x45   // External Errors
#define     ERR_SD_ADDR              0x46   // Shutdown Errors
#define     ERR_SCD_ADDR             0x47   // Short Circuit Errors
#define     ERR_INDIAG_ADDR          0x48   // Input Pattern Violations
#define     ERR_OSF_ADDR             0x49   // Output Stage Feedback Errors
#define     ERR_SPICONF_ADDR         0x4A   // SPI Communication and Configuration Errors
#define     ERR_OP_12_ADDR           0x4B   // Current Sense Amplifiers 1 & 2 Errors
#define     ERR_OP_3_ADDR            0x4C   // Current Sense Amplifier 3
#define     ERR_OUTP_ADDR            0x4D   // Digital Output Pin Errors
#define     DSM_LS1_ADDR             0x4E   // Low-side 1 Drain Source Measurement
#define     DSM_LS2_ADDR             0x4F   // Low-side 2 Drain Source Measurement
#define     DSM_LS3_ADDR             0x50   // Low-side 3 Drain Source Measurement
#define     DSM_HS1_ADDR             0x51   // High-side 1 Drain Source Measurement
#define     DSM_HS2_ADDR             0x52   // High-side 2 Drain Source Measurement
#define     DSM_HS3_ADDR             0x53   // High-side 3 Drain Source Measurement
#define     RDM_LS1_ADDR             0x54   // Low-side 1 Reverse Diode Measurement
#define     RDM_LS2_ADDR             0x55   // Low-side 2 Reverse Diode Measurement
#define     RDM_LS3_ADDR             0x56   // Low-side 3 Reverse Diode Measurement
#define     RDM_HS1_ADDR             0x57   // High-side 1 Reverse Diode Measurement
#define     RDM_HS2_ADDR             0x58   // High-side 2 Reverse Diode Measurement
#define     RDM_HS3_ADDR             0x59   // High-side 3 Reverse Diode Measurement
#define     TEMP_LS1_ADDR            0x5A   // Low-side 1 Output Stage Temperature
#define     TEMP_LS2_ADDR            0x5B   // Low-side 2 Output Stage Temperature
#define     TEMP_LS3_ADDR            0x5C   // Low-side 3 Output Stage Temperature
#define     TEMP_HS1_ADDR            0x5D   // High-side 1 Output Stage Temperature
#define     TEMP_HS2_ADDR            0x5E   // High-side 2 Output Stage Temperature
#define     TEMP_HS3_ADDR            0x5F   // High-side 3 Output Stage Temperature
#define     WWLC_ADDR                0x60   // Window Watchdog Loop Counter
#define     RES_CC1_ADDR             0x61   // Watchdog Clock Counter 1
#define     RES_CC2_ADDR             0x62   // Watchdog Clock Counter 2
#define     RES_CC3_ADDR             0x63   // Watchdog Clock Counter 3
#define     RES_VCC_ADDR             0x64   // VCC Measurement Result
#define     RES_CB_ADDR              0x65   // CB Measurement Result
#define     RES_VS_ADDR              0x66   // Vs Measurement Result
#define     RES_VDH_ADDR             0x67   // VDHP Measurement Result 

#endif //_BLDC_DRV_H

//Operation Mode Overview
#define     NORMAL_MOTOR_MODE       0x800  // Normal Operation Mode (Motor Driving Mode) Active
#define     NORMAL_RECTI_MODE       0x400  // Normal Operation Mode (Rectification Mode) Active
#define     ERROR_MODE              0x200  // Error Mode Active
#define     SOFF_MODE               0x100  //  SOFF Mode Active
#define     SELF_TEST_MODE          0x080  // Self Test Mode Active
#define     CONF_LOCK_MODE          0x040  // Configuration Lock Mode Active
#define     CONF_MODE               0x02  // Configuration Mode Active
#define     IDLE_MODE               0x01  // Idle Mode Active

#define BLDC_DRV_READ                0
#define BLDC_DRV_WRITE               1
//Commands
#define BLDC_NOOP_READ            0x32000300
#define BLDC_OPERMODE_READ        0x40000600
#define BLDC_SHUTDWN_ERR_READ     0x46000300
#define BLDC_SPI_ERROR            0x00100000 //SPI Status Flags : TLE9180D-31QK Bridge Driver IC
#define BLDC_DRIVE_MODE           0x000800

//Move cpu.h
typedef enum
{
    BLDC_DRV_SELECTED,
    BLDC_DRV_UNSELECTED
} BLDC_DRV_CS_STATES;
/* Chip Select output for SPI/BLDC driver chip*/
#define BLDC_DRV_SELECT              _RB9       //nSPI2_CS

typedef enum
{
    BLDC_DRV_SOFF_ON,
    BLDC_DRV_SOFF_OFF
} BLDC_DRV_SOFF_STATES;
/* Chip Select output for SPI/BLDC driver chip*/
#define BLDC_DRV_SOFF               _RC11       //nSOFF

typedef enum
{
    BLDC_DRV_DISABLE,
    BLDC_DRV_ENABLE
} BLDC_DRV_STATES;
/* Chip Select output for SPI/BLDC driver chip*/
#define BLDC_DRV_ENABLEPIN          _RC5       //ENABLE

typedef enum
{
    BLDC_DRV_INHIBIT_ON,
    BLDC_DRV_INHIBIT_OFF
} BLDC_DRV_INHIBIT_STATES;
/* Chip Select output for SPI/BLDC driver chip*/
#define BLDC_DRV_INHIBIT           _RC4       //nINHIBIT

#define BLDC_READ_ERR              _RC10       //BLDC DRV ERR

// to be added as per the list
typedef enum
{ 
    BLDC_CMD_CONF_SIG = 0,
    BLDC_CMD_CONF_GEN_1,
    BLDC_CMD_CONF_GEN_2,
    BLDC_CMD_CONF_GEN_3,
    BLDC_CMD_CONF_WWD,
    BLDC_CMD_TL_VS,
    BLDC_CMD_TL_VDH,
    BLDC_CMD_TL_CBVCC,
    BLDC_CMD_FM_1,
    BLDC_CMD_FM_2,
    BLDC_CMD_FM_3,
    BLDC_CMD_FM_4,
    BLDC_CMD_FM_5,
    BLDC_CMD_DT_HS,
    BLDC_CMD_DT_LS,
    BLDC_CMD_FT_1_LS,
    BLDC_CMD_FT_2_LS,
    BLDC_CMD_FT_3_LS,
    BLDC_CMD_FT_4_LS,
    BLDC_CMD_FM_6_LS,
    BLDC_CMD_OP_GAIN_1,
    BLDC_CMD_OP_GAIN_2,
    BLDC_CMD_OP_GAIN_3,
    BLDC_CMD_OP_0CL,
    BLDC_CMD_OP_CON,
    BLDC_CMD_SC_LS_1,
    BLDC_CMD_SC_LS_2,
    BLDC_CMD_SC_LS_3,
    BLDC_CMD_SC_HS_1,
    BLDC_CMD_SC_HS_2,
    BLDC_CMD_SC_HS_3,
    BLDC_CMD_LI_CTR,
    BLDC_CMD_MISC_CTR,
    BLDC_CMD_ART_TLP,
    BLDC_CMD_ART_TLA,
    BLDC_CMD_ART_FI,
    BLDC_CMD_ART_ACC,
    BLDC_CMD_ART_ENTRY,
    BLDC_CMD_NOP,
    BLDC_CMD_DREV_MARK,
    BLDC_CMD_DS_MARK,
    BLDC_CMD_SEL_ST_1,
    BLDC_CMD_SEL_ST_2,
    BLDC_CMD_EN_ST,
    BLDC_CMD_OM_OVER,
    BLDC_CMD_ERR_OVER,
    BLDC_CMD_SER,
    BLDC_CMD_ERR_I_1,
    BLDC_CMD_ERR_I_2,
    BLDC_CMD_ERR_E,
    BLDC_CMD_ERR_SD,
    BLDC_CMD_ERR_SCD,
    BLDC_CMD_ERR_INDIAG,
    BLDC_CMD_ERR_OSF,
    BLDC_CMD_ERR_SPICONF,
    BLDC_CMD_ERR_OP_12,
    BLDC_CMD_ERR_OP_3,
    BLDC_CMD_ERR_OUTP,
    BLDC_CMD_DSM_LS1,
    BLDC_CMD_DSM_LS2,
    BLDC_CMD_DSM_LS3,
    BLDC_CMD_DSM_HS1,
    BLDC_CMD_DSM_HS2,
    BLDC_CMD_DSM_HS3,
    BLDC_CMD_RDM_LS1,
    BLDC_CMD_RDM_LS2,
    BLDC_CMD_RDM_LS3,
    BLDC_CMD_RDM_HS1,
    BLDC_CMD_RDM_HS2,
    BLDC_CMD_RDM_HS3,
    BLDC_CMD_TEMP_LS1,
    BLDC_CMD_TEMP_LS2,
    BLDC_CMD_TEMP_LS3,
    BLDC_CMD_TEMP_HS1,
    BLDC_CMD_TEMP_HS2,
    BLDC_CMD_TEMP_HS3,
    BLDC_CMD_WWLC,
    BLDC_CMD_RES_CC1,
    BLDC_CMD_RES_CC2,
    BLDC_CMD_RES_CC3,
    BLDC_CMD_RES_VCC,
    BLDC_CMD_RES_CB,
    BLDC_CMD_RES_VS,
    BLDC_CMD_RES_VDH,
    BLDC_CMD_NUMS
} BLDC_CMD_INDEX;



typedef struct __attribute__((packed))
{
    union
    {
        struct
        {
            INT8U  unused        : 8;   //just to make compatible with 32bit// LSB
            INT8U  crc           : 3;   // calculated CRC
            INT8U  reserved      : 5;   //should be always zero    //MSB
            INT8U  data          : 8;   // data to be write     //LSB
            INT8U  address       : 7;   //register address    
            INT8U  rw            : 1;   //read = 0, write = 1   //MSB
        };
        struct
        {
            INT32U word;
        };
    };
} BLDC_SPICMD;

typedef struct __attribute__((packed))
{
    union
    {
        struct
        {
            INT8U  crc          : 3;   // calculated CRC
            INT8U  reserved     : 1;   //ignore
            INT8U  data         : 8;   // data to be write
            INT8U  address      : 7;   //register address
            /*SPI status*/
            INT8U  error        : 1;   //ERR, ARE and LE indication via SPI
            INT8U  warning      : 1;   //Warning indication via SPI
            INT8U  config_valid : 1;   //Configuration registers valid
            INT8U  spi_error    : 1;   //Table 62 Overview of SPI Communication and Configuration Error
            INT8U  spcl_event   : 1;   //Table 63 Overview of Special Event Register
            INT8U  unused       : 8;   //just to ensure to in line for 32bit
        };
        struct
        {
            INT32U word;
        };
    };
} BLDC_SPIRCVMSG;

ERR_RET bldc_drv_init(); 
INT32U _bldc_drv_command(INT32U cmd); 
void bldc_drv_sleepmode(void); 
INT32U bldc_drv_read_error(INT8U index); 
void bldc_drv_read_config(); 
void bldc_normal_operation(); 
void cpu_SetBldcCs(BLDC_DRV_CS_STATES state); 
void cpu_SetBldcSoff(BLDC_DRV_SOFF_STATES state); 
void cpu_SetBldcEnable(BLDC_DRV_STATES state); 
void cpu_SetBldcInhibit(BLDC_DRV_INHIBIT_STATES state);
BOOL cpu_getbldcErr(void); 
INT16U cpu_GetIsense_ref(); 
INT16U cpu_GetIsense(); 
INT16U bldc_drv_get_OperMode();
void bldc_drv_read_other();