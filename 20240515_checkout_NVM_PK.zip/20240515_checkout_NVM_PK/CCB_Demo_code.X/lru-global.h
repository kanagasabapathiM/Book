/*
 * Author(s):       Jonathan R. Saliers
 *                  Doug Wendt      <dwendt@omnicongroup.com>
 * Status:          Preliminary
 * Release Date:
 * Revision:
 * Description:     This header file contains common includes and type definitions
 *                  for the actuator application.
 * History:          06/10/2016 Clay Barber - Changed Files updates
 */

#ifndef ACTUATOR_H
#define ACTUATOR_H
/*********************************************************************************************
Included files
 *********************************************************************************************/
#include "typedef.h"

/*********************************************************************************************
Preprocessor definitions
 *********************************************************************************************/
#define SW_VERSION "0.01"

#define TEST_DRV   1 // for test realted
/* CAN ID of this LRU - determined at runtime from CFG_ACT_CANID_TABLE_TYPE
 * config file for Actuators */
#define ECAN_LRU_CAN_ID         G_lru_can_id

/* CAN ID to send reprogramming replies to */
#define ECAN_REPROG_DEST_ID     MAINT_PC_CAN_ID

#define BOOTLOADER_OP_ADDRESS    0  /* Address of BootLoader Operational area */
#define BOOTLOADER_STORE_ADDRESS 0x8000u/* Address of BootLoader Storage area */
#define END_BOOTLOADER_ADDRESS   0xFFFFu/* Address of BootLoader Storage area */

#define ECAN_LRU_STATUS_FRAME UAP_APP_STATUS_FRAME /* status specific to this LRU */

/* We are using the internal fast RC oscillator (FRC) Define its frequency in Mhz: */
#define ACT_FRC_MHZ 8

/* 64 MHz (64 MIPS) was chosen for the instruction rate (FCY). The following equations are used
   to determine what values to use to obtain the desired clock rate using the on chip PLL:

   The system clock frequency is calculated:
   FOS = FRC * ((PLLDIV + 2) / (PLLPRE + 2) * (2 * (PLLPOST + 1)))

   The instruction rate is calculated:
   FCY = FOS / 2

   See section 7 of the dsPIC33E/PIC24E Family Reference Manual for further details
   of how to setup the instruction rate using the on chip PLL.
 */
/*FPLLO = FPLLI * M/(N1 * N2 * N3); */
//FPLLI = ACT_FRC_MHZ
//Fosc = FPLLO/2
#define ACT_PLLFBDIV  64  //M
#define ACT_PLLPRE    1   //N1
#define ACT_POST1DIV  2   //N2
#define ACT_POST2DIV  1   //N3

#define ACT_FOS_MHZ ((ACT_FRC_MHZ * ACT_PLLFBDIV/(ACT_PLLPRE * ACT_POST1DIV * ACT_POST2DIV)/2))
/* ACT_FOS_MHZ = 8 * 64 / (1 * 2 * 2)/2 = 128 */

#define TEMP_LOOKUP_TABLE_MAX_SIZE  40

/* ADC Setup */
#define ADCM_CONVERSIONS_PER_INPUT 32 /* Power of 2 */

#define ADCM_MAX_CHANNELS 20 /* dsPIC33CK256MP606 has 20 ADC channels */

#define SENSE_1_GND     0b00000001
#define SENSE_1_HIGH    0b00000010
#define SENSE_2_GND     0b00000100
#define SENSE_2_HIGH    0b00001000
#define SENSE_3_GND     0b00010000
#define SENSE_3_HIGH    0b00100000

/* Worst case with cushion for the number of occurrences to confirm an
 * event/fault - used to size the occurrence timestamp array */
#define MAX_EVENT_OCCUR   8u
#define MAX_EVENT_CODES   40

#define UART_DEBUG    1
#define TEST_ENABLE   1 //only during testing enable it
/*********************************************************************************************
Type Definitions
 *********************************************************************************************/
typedef enum fw_enum
{
    BOOTLOADER_OP_FW    = 0xFEED,       /* Operational copy of the bootloader */
    BOOTLOADER_STORE_FW = 0xF222,        /* The Stored copy of the bootloader */
    APPLICATION_FW      = 0x1234                  /* The application firmware */
} FW_ENUM_TYPE;

/*
 The possible states of the ACT status bits and parameter OK values.
 */
typedef enum
{
    ACT_STATUS_NOT_OK = 0,
    ACT_STATUS_OK     = 1
} ACT_STATUS;

/******************************************************************************/
/* Configuration table definitions                                            */
/******************************************************************************/
typedef struct motor_table
{
    INT16U table_id;
    /* Maximum Current value in mA for monitoring current errors during operation */
    INT16U max_motor_start_current;
    /* Reserved for future growth. */
    INT16U brake_engage_suppression;
    /* Maximum current consumption of the motor in mA, used for indicating if the motor is not
     operating as expected. */
    INT16U max_motor_current;
    /* Offset used with maximum temperature for hysteresis. */
    INT16S max_temp_delta;
    /* Temperature used to determine the critical motor temperature condition. */
    INT16S critical_motor_temp;
    /* Temperature used to determine the critical stepper temperature condition. */
    INT16S critical_stepper_temp;
    /* Temperature used to determine the critical PCB temperature condition. */
    INT16S critical_pcb_temp;
    /* High Load Current used to determine the Disengage Failure condition. */
    INT16U high_load_current;
    /* Position change used to determine the Disengage Failure condition. */
    INT16U delta_position;
    /* Delta Time used to determine the Disengage Failure condition. */
    INT16U delta_time;
    /* The number of Hall sensor state transitions used in Mechanical Brake Failure detection. */
    INT16U max_hall_change_count;
    /* Used to determine the Mechanical Brake Failure condition. */
    INT16U max_position_change;
    /* CRC-32 for the table. */
    INT32U crc;
} CFG_MOTOR_PARAM_TABLE_TYPE;

/******************************************************************************/
typedef struct temp_entry
{
    INT16U voltage;      /* Voltage in millivolts */
    INT16S temperature;  /* Temperature in degrees Celsius */
} CFG_TEMP_LOOKUP_ENTRY_TYPE;

typedef struct temp_table
{
    INT16U                     table_id;
    INT16U                     table_size;
    CFG_TEMP_LOOKUP_ENTRY_TYPE lookup[TEMP_LOOKUP_TABLE_MAX_SIZE];
    INT32U                     crc;
} CFG_TEMP_LOOKUP_TABLE_TYPE;

/******************************************************************************/
typedef struct current_param_table
{
    INT16U table_id;
    /* Linear offset for voltage-to-current conversion for motor current measurements. */
    INT16S current_offset;
    /* Multiplier for voltage-to current conversion. */
    INT16S current_multiplier;
    /* CRC-32 for the table. */
    INT32U crc;
} CFG_CURRENT_PARAM_TABLE_TYPE;

/******************************************************************************/
typedef struct obstacle_param_table
{
    INT16U table_id;
    /* Motor ramp time for obstacle detection */
    INT16U motor_ramp_time;
    /* Maximum distance between obstacle positions to be considered the same obstacle. */
    INT16U position_delta;
    /* Motor inertia for obstacle detection (J) */
    float motor_inertia;
    /*motor viscous friction for obstacle detection (b)*/
    float mvf;
    /* Motor torque constant for obstacle detection (kt) */
    float motor_torque;
    /* Electric inductance for obstacle detection (L) */
    float elec_induct;
    /* Electric resistance for obstacle detection (R) */
    float elec_resist;
    /* Electromotive force constant for obstacle detection (Ke) */
    float em_force;
    /* Linear adjustment x1 for obstacle detection*/
    float x1;
    /* Linear adjustment x2 for obstacle detection*/
    float x2;
    /* Linear adjustment y1 for obstacle detection*/
    float y1;
    /* Linear adjustment y2 for obstacle detection*/
    float y2;

    INT16U history_width;
    INT16U speed_threshold;
    INT32U increase_decrease_time;

    /* CRC-32 for the table. */
    INT32U crc;
} CFG_OBS_PARAM_TABLE_TYPE;

/******************************************************************************/
typedef struct act_param_table
{
    INT16U table_id;
    INT16U multizone_obs;
    INT16U pos_slope_threshold_zone1;
    INT16U pos_slope_width_zone1;
    INT16U pos_load_limit_zone1;
    INT16U neg_slope_threshold_zone1;
    INT16U neg_slope_width_zone1;
    INT16U neg_load_limit_zone1;
    INT16U spike_height_zone1;
    INT16U spike_width_zone1;
    INT16U temp;
    INT16U num_obs_zones;
    INT16U max_travel_zone1;

    INT16U max_travel_zone2;
    INT16U pos_slope_threshold_zone2;
    INT16U pos_slope_width_zone2;
    INT16U pos_load_limit_zone2;
    INT16U neg_slope_threshold_zone2;
    INT16U neg_slope_width_zone2;
    INT16U neg_load_limit_zone2;
    INT16U spike_height_zone2;
    INT16U spike_width_zone2;

    INT16U max_travel_zone3;
    INT16U pos_slope_threshold_zone3;
    INT16U pos_slope_width_zone3;
    INT16U pos_load_limit_zone3;
    INT16U neg_slope_threshold_zone3;
    INT16U neg_slope_width_zone3;
    INT16U neg_load_limit_zone3;
    INT16U spike_height_zone3;
    INT16U spike_width_zone3;

    INT16U max_travel_zone4;
    INT16U pos_slope_threshold_zone4;
    INT16U pos_slope_width_zone4;
    INT16U pos_load_limit_zone4;
    INT16U neg_slope_threshold_zone4;
    INT16U neg_slope_width_zone4;
    INT16U neg_load_limit_zone4;
    INT16U spike_height_zone4;
    INT16U spike_width_zone4;

    INT16U max_travel_zone5;
    INT16U pos_slope_threshold_zone5;
    INT16U pos_slope_width_zone5;
    INT16U pos_load_limit_zone5;
    INT16U neg_slope_threshold_zone5;
    INT16U neg_slope_width_zone5;
    INT16U neg_load_limit_zone5;
    INT16U spike_height_zone5;
    INT16U spike_width_zone5;

    INT16U max_travel_zone6;
    INT16U pos_slope_threshold_zone6;
    INT16U pos_slope_width_zone6;
    INT16U pos_load_limit_zone6;
    INT16U neg_slope_threshold_zone6;
    INT16U neg_slope_width_zone6;
    INT16U neg_load_limit_zone6;
    INT16U spike_height_zone6;
    INT16U spike_width_zone6;

    INT16U max_travel_zone7;
    INT16U pos_slope_threshold_zone7;
    INT16U pos_slope_width_zone7;
    INT16U pos_load_limit_zone7;
    INT16U neg_slope_threshold_zone7;
    INT16U neg_slope_width_zone7;
    INT16U neg_load_limit_zone7;
    INT16U spike_height_zone7;
    INT16U spike_width_zone7;

    INT16U max_travel_zone8;
    INT16U pos_slope_threshold_zone8;
    INT16U pos_slope_width_zone8;
    INT16U pos_load_limit_zone8;
    INT16U neg_slope_threshold_zone8;
    INT16U neg_slope_width_zone8;
    INT16U neg_load_limit_zone8;
    INT16U spike_height_zone8;
    INT16U spike_width_zone8;

    INT16U max_travel_zone9;
    INT16U pos_slope_threshold_zone9;
    INT16U pos_slope_width_zone9;
    INT16U pos_load_limit_zone9;
    INT16U neg_slope_threshold_zone9;
    INT16U neg_slope_width_zone9;
    INT16U neg_load_limit_zone9;
    INT16U spike_height_zone9;
    INT16U spike_width_zone9;

    INT16U max_travel_zone10;
    INT16U pos_slope_threshold_zone10;
    INT16U pos_slope_width_zone10;
    INT16U pos_load_limit_zone10;
    INT16U neg_slope_threshold_zone10;
    INT16U neg_slope_width_zone10;
    INT16U neg_load_limit_zone10;
    INT16U spike_height_zone10;
    INT16U spike_width_zone10;

    INT16U max_travel_zone11;
    INT16U pos_slope_threshold_zone11;
    INT16U pos_slope_width_zone11;
    INT16U pos_load_limit_zone11;
    INT16U neg_slope_threshold_zone11;
    INT16U neg_slope_width_zone11;
    INT16U neg_load_limit_zone11;
    INT16U spike_height_zone11;
    INT16U spike_width_zone11;
    INT32U crc;
} CFG_ACT_PARAM_TABLE_TYPE;

/******************************************************************************/
typedef struct stepper_param_table
{
    INT16U table_id;
    /* Pulse rate for moving the stepper motor to disengage or engage the brake. */
    INT16U pulse_rate;
    /* Number of steps to move the stepper motor to disengage the brake system. */
    INT16U pulse_count_disengage;
    /* Number of steps to move the stepper motor to engage the brake system. */
    INT16U pulse_count_engage;
    /* Duty Cycle used for holding the brake after it has been disengaged. */
    INT16U brake_hold_duty_cycle;
    /* Frequency in kHz used for holding the brake disengaged. */
    INT16U brake_period;

    /* added parameters to support 3rd sensor and closed loop control */
    INT16U min_enc3_voltage;
    INT16U max_enc3_voltage;
    INT16S brake_engage_tolerance;
    INT16S brake_disengage_tolerance;
    INT16S brake_correct_on_the_fly;    /* Limit to correct without stopping the BLDC */
    INT16S degrees_engaged;             /* Fully Engaged Value */

    /* CRC-32 for the table. */
    INT32U crc;
} CFG_STEPPER_PARAM_TABLE_TYPE;


/******************************************************************************/
typedef struct control_param_table
{
    INT16U table_id;
    /* Proportional speed constant for closed loop control. */
    FP32   p_speed;
    /* Integral speed constant for closed loop control. */
    FP32   i_speed;
    /* CRC-32 for the table. */
    INT32U crc;
} CFG_CONTROL_PARAM_TABLE_TYPE;

/******************************************************************************/
typedef enum
{
    PSN_ENCODER_1 = 0,
    PSN_ENCODER_2 = 1,
    PSN_NUM_ENCODERS = 2
} PSN_ENCODERS;

/* Structure for storing the calibration parameters for the position encoders. */
typedef struct position_param_table
{
    INT16U table_id;
    FP32   x_amplitude[PSN_NUM_ENCODERS];
    FP32   y_amplitude[PSN_NUM_ENCODERS];
    FP32   x_offset[PSN_NUM_ENCODERS];
    FP32   y_offset[PSN_NUM_ENCODERS];
    FP32   sine_minus_phi[PSN_NUM_ENCODERS];
    FP32   cosine_minus_phi[PSN_NUM_ENCODERS];
    INT16S encoder_zero_offset[PSN_NUM_ENCODERS];
    INT32U hef_stop_timeout;
    INT16U encoder_output_swap;
    INT16U min_enc1_voltage;
    INT16U max_enc1_voltage;
    INT16U min_enc2_voltage;
    INT16U max_enc2_voltage;
    INT32U crc;
} CFG_POSITION_PARAM_TABLE_TYPE;


/******************************************************************************/
/* Structure for storing motion-related parameters. */
typedef struct motion_param_table
{
    INT16U table_id;
    /* Scaling factor used when converting speed in degrees per second to RPM. */
    INT16S gearbox_ratio;
    /* The number of times the wiggle (forward/backward motion) sequence is repeated. */
    INT16U wiggle_count;
    /* Speed in RPM used when wiggling. */
    INT16U wiggle_rpm;
    /* The delay time in milliseconds while the wiggle direction changes. */
    INT16U wiggle_delay;
    /* The number of motor position steps to move forward while wiggling. */
    INT16U wiggle_steps_forward;
    /* The number of motor position steps to move backwards while wiggling. */
    INT16U wiggle_steps_reverse;
    /* Maximum BLDC motor speed in RPM that the commanded speed will be limited to. */
    INT16U max_rpm;
    /* Delay in commutation when changing rotation direction. */
    INT16U dir_change_delay;
    /* CRC-32 for the table. */
    INT32U crc;
} CFG_MOTION_PARAM_TABLE_TYPE;

/******************************************************************************/
/* Structure for storing slope/offset parameters for computing max PWM value. */
typedef struct pwm_param_table
{
    INT16U  table_id;
    FP32    max_pwm_slope;
    FP32    max_pwm_offset;
    INT32U  crc;
} CFG_PWM_PARAM_TABLE_TYPE;

/******************************************************************************/
/* Structure for storing adjustable parameters. */
typedef struct adjust_param_table
{
    INT16U  table_id;
    INT32U  mor_degree_tolerance;
    FP32    speed_adjustment;
    INT32U  speed_adjust_timing;
    INT32U  padding_1;
    INT32U  padding_2;
    INT32U  padding_3;
    INT32U  padding_4;
    INT32U  padding_5;
    INT32U  padding_6;
    INT32U  padding_7;
    INT32U  padding_8;
    INT32U  crc;
} CFG_ADJUST_PARAM_TABLE_TYPE;

/******************************************************************************/
typedef enum
{
    GAP_LOW         = 0,
    GAP_FLOAT       = 1,
    GAP_HIGH        = 2,
    GAP_DONT_CARE   = 3
} GAP_STATES_FOR_MOTION;

/* Structure for storing Actuator CAN ID */
typedef struct act_canid_table
{
    INT16U table_id;
    INT16U act_can_id;
    INT16U scm_can_id;
    INT16U term_resistor;
    INT16U gap_0_allow_motion; /* GAP_STATES_FOR_MOTION type */
    INT16U gap_1_allow_motion; /* GAP_STATES_FOR_MOTION type */
    INT16U gap_2_allow_motion; /* GAP_STATES_FOR_MOTION type */
    INT32U crc;
} CFG_ACT_CANID_TABLE_TYPE;

/******************************************************************************/
/* Defined LRU Events and Faults                                              */
/* The ID codes are used for ECAN_EVENT_REPORT_PART_1_SID,                    */
/* ECAN_EVENT_REPORT_CLEAR_SID and ECAN_ERROR_REPORT_SID messages.            */
/* The order of the names below MUST align with CFG_EVENT_PROCESS_TABLE_TYPE  */
/* configuration table array entries to index into the table.                 */
/* Note that all Faults are Events but not all Events are Faults.             */
/*   multi-LRU Common faults IDs = 1 - 31                                     */
/*   LRU unique faults IDs = 32 - 50                                          */
/*   future growth IDs = 51 - 32767 (0x7FFF)                                  */
/*   Event IDs = 32769 - 65535 (0x8001 - 0xFFFF)                              */
/* Coding convention: {name}_FAULT and {name}_EVENT */
/*                    {{name}_EVENT/FAULT}_FRAME for structure types */
typedef enum
{    /* All LRU common faults */
    PCB_OVER_TEMPERATURE_FAULT, /* printed circuit board temperature */
/*  PCB_CRITICAL_OVER_TEMPERATURE_FAULT,  use actuator-specific, below */
    CONFIGURATION_CRC_ERROR_FAULT, /* Configuration table CRC */
/*    PCB_OVER_CURRENT_FAULT, = N/A for actuator */
/*    PCB_CRITICAL_OVER_CURRENT_FAULT = N/A for actuator */
/*    INVALID_MESSAGE_RECEIVED_FAULT, = N/A for actuator */
/*  COMMUNICATION_FAULT = N/A for actuator */

    /* Actuator LRU unique faults */
    BLDC_MOTOR_OVER_TEMPERATURE_FAULT, /* Brush-Less DC motor */
    STEPPER_MOTOR_OVER_TEMPERATURE_FAULT,
    BLDC_MOTOR_CRITICAL_OVER_TEMPERATURE_FAULT,
    STEPPER_MOTOR_CRITICAL_OVER_TEMPERATURE_FAULT,
    PCB_CRITICAL_OVER_TEMPERATURE_FAULT,
    ENCODER_1_INVALID_OUTPUT_FAULT, /* Encoder out of range */
    ENCODER_2_INVALID_OUTPUT_FAULT, /* Encoder out of range */
    ENCODER_3_INVALID_OUTPUT_FAULT, /* Encoder out of range */
    ACTUATOR_POSITION_NO_CHANGE_FAULT, /* not changing while motor running */
    ACTUATOR_STALLED_FAULT, /* motor over current at < 100mS */
    ACTUATOR_STALLED_X5_FAULT, /* Stalled >= 5 times */
    OBSTACLE_DETECTED_X5_FAULT, /* Obstacle detected >= 5 times */
    BRAKE_DISENGAGE_FAULT, /* Brake didn't disengage */
    BRAKE_DISENGAGE_X3_FAULT, /* Brake didn't disengage >= 3 times */
    BRAKE_ENGAGE_FAULT, /* Brake didn't engage */
    BRAKE_ENGAGE_X5_FAULT, /* Brake didn't engage >= 5 times */
    MOTOR_CONTROLLER_FAULT, /* BLDC controller chip failure (FF2 High) */
    MOTOR_CONTROLLER_X5_FAULT, /* BLDC controller chip failure >= 5 times */
    OBSTACLE_DETECTED_FAULT, /* Obstacle detected  */

    /* LRU Events - ID's > 0x8000 (32768) */
    CAN_TRANSMIT_FAILED_EVENT, /* CAN bus transmission failed */
    PARAM_CONFIRM_EVENT, /* LRU received its parameter(s) from the SCM */
    STARTUP_EVENT, /* LRU has started */
    IMPENDING_SHUTDOWN_EVENT, /* LRU received impending shutdown message */
/*  BITE_COMPLETE_EVENT, N/A for actuators */
/*  UNEXPECTED_DEVICE_EVENT, N/A for actuator */
    IMPENDING_SHUTDOWN_CANCELED_EVENT, /* LRU shutdown canceled */
/*  NEW_SERIAL_NUMBER_EVENT, N/A for actuator */
/*  STUCK_BUTTON, N/A for actuator */
    NUM_EVENT_CODES,   /* The number of events defined for this LRU */

    /* A related number used by the software */
    EVENTS_START_CODE = 32768,/* 0x8000 separate Fault codes from Event codes */
} LRU_EVENT_CODES;

/******************************************************************************/
/******************************************************************************/
/******************************************************************************/

/******************************************************************************/
/* Printed Circuit Board Over Temperature fault data frame                    */
/* PCB_OVER_TEMPERATURE_FAULT */
typedef struct
{
    INT16U max_PCB_temp;                     /* configured limit - big endian */
    INT16U measured_PCB_temp;                  /* measured value - big endian */
    INT8U spare_zeros[4];                                /* spare - show as 0 */
} PCB_OVER_TEMPERATURE_PART_3;

typedef struct
{
    /* EVENT_REPORT_COMMON_FRAME - common for all error frames */
    /* ECAN_LRU_STATUS_FRAME - common for all error frames */
    PCB_OVER_TEMPERATURE_PART_3 Part_3;
    INT8U spare_zeros[8]; /* frame part 4 */
} PCB_OVER_TEMPERATURE_FAULT_FRAME;

/******************************************************************************/
/* Printed Circuit Board [critical] Over Temperature fault data frame         */
/* Brushless DC Motor [critical] Over Temperature fault data frame            */
/* Stepper Motor [critical] Over Temperature fault data frame                 */
/* PCB_CRITICAL_OVER_TEMPERATURE_FAULT */
/* BLDC_MOTOR_OVER_TEMPERATURE_FAULT */
/* BLDC_MOTOR_CRITICAL_OVER_TEMPERATURE_FAULT */
/* STEPPER_MOTOR_OVER_TEMPERATURE_FAULT */
/* STEPPER_MOTOR_CRITICAL_OVER_TEMPERATURE_FAULT */
typedef struct
{
    union /* Multipurpose - Temperature limit big endian */
    {
        INT16U critical_PCB_temp;     /* PCB_CRITICAL_OVER_TEMPERATURE_FAULT */
        INT16U max_motor_temp;        /* BLDC_MOTOR_OVER_TEMPERATURE_FAULT */
        INT16U critical_motor_temp;   /* BLDC_MOTOR_CRITICAL_OVER_TEMPERATURE_FAULT */
        INT16U max_stepper_temp;      /* STEPPER_MOTOR_OVER_TEMPERATURE_FAULT */
        INT16U critical_stepper_temp; /* STEPPER_MOTOR_CRITICAL_OVER_TEMPERATURE_FAULT */
    };
    union /* Multipurpose - Allowed temperature change  big endian */
    {
        INT16U max_PCB_delta;   /* for PCB */
        INT16U max_motor_delta;   /* for BLDC */
        INT16U max_stepper_delta; /* for stepper */
    };
    INT16U measured_BLDC_temp;  /* big endian */
    INT16U measured_stepper_temp; /* big endian */
    /* part 4 */
    INT16U measured_PCB_temp; /* big endian */
    INT16U speed;   /* big Endian */
} OVER_TEMPERATURE_UNIQUE;

typedef struct
{
    /* EVENT_REPORT_COMMON_FRAME - common for all error frames */
    /* ECAN_LRU_STATUS_FRAME - common for all error frames */
    OVER_TEMPERATURE_UNIQUE unique;
    INT8U spare_zeros[4]; /* the rest of part 4 */
} OVER_TEMPERATURE_FAULT_FRAME;

/******************************************************************************/
/* Printed Circuit Board over current fault data frame                        */
/* PCB_OVER_CURRENT_FAULT */
/* PCB_CRITICAL_OVER_CURRENT_FAULT */
typedef struct
{
    union /* Current limit */
    {
        INT16U max_PCB_current;     /* PCB_OVER_CURRENT_FAULT */
        INT16U critical_PCB_current;/* PCB_CRITICAL_OVER_CURRENT_FAULT */
    };
    INT16U measured_current;
    INT8U spare_zeros[4]; /* spare - show as 0 */
} OVER_CURRENT_PART_3;

typedef struct
{
    /* EVENT_REPORT_COMMON_FRAME - common for all error frames */
    /* ECAN_LRU_STATUS_FRAME - common for all error frames */
    OVER_CURRENT_PART_3 Part_3;
    INT8U spare_zeros[8]; /* frame part 4 */
} OVER_CURRENT_FAULT_FRAME;

/******************************************************************************/
/* Configuration Table CRC fault data frame                                   */
/* CONFIGURATION_CRC_ERROR_FAULT */
typedef struct
{
    INT8U expected_CRC_MS; /* big Endian */
    INT8U expected_CRC_UM; /* big Endian */
    INT8U expected_CRC_LM; /* big Endian */
    INT8U expected_CRC_LS; /* big Endian */
    INT8U actual_CRC_MS;   /* big Endian */
    INT8U actual_CRC_UM;   /* big Endian */
    INT8U actual_CRC_LM;   /* big Endian */
    INT8U actual_CRC_LS;   /* big Endian */
} CRC_FAULT_PART_3;

typedef struct
{
    /* EVENT_REPORT_COMMON_FRAME - common for all error frames */
    /* ECAN_LRU_STATUS_FRAME - common for all error frames */
    CRC_FAULT_PART_3 Part_3;
    INT8U spare_zeros[8]; /* frame part 4 */
} CRC_FAULT_FRAME;

/******************************************************************************/
/* Encoder [1, 2, 3] invalid output range fault data frame                    */
/* ENCODER_1_INVALID_OUTPUT_FAULT */
/* ENCODER_2_INVALID_OUTPUT_FAULT */
/* ENCODER_3_INVALID_OUTPUT_FAULT */
typedef struct
{
    INT16U cosp_mVolt; /* cosine positive millivolts, big Endian */
    INT16U cosn_mVolt; /* cosine negative millivolts, big Endian */
    INT16U sinp_mVolt; /* sine positive millivolts, big Endian */
    INT16U sinn_mVolt; /* sine negative millivolts, big Endian */
} ENCODER_INVALID_OUTPUT_PART_3;

typedef struct
{
    INT16U max_mVolt; /* max voltage millivolts, big Endian */
    INT16U min_mVolt; /* min voltage millivolts, big Endian */
    INT8U spare_zero[4]; /* spare - show as 0 */
} ENCODER_INVALID_OUTPUT_PART_4;

typedef struct
{
    /* EVENT_REPORT_COMMON_FRAME - common for all error frames */
    /* ECAN_LRU_STATUS_FRAME - common for all error frames */
    ENCODER_INVALID_OUTPUT_PART_3 Part_3;
    ENCODER_INVALID_OUTPUT_PART_4 Part_4; /* frame part 4 */
} ENCODER_INVALID_OUTPUT_FAULT_FRAME;

/******************************************************************************/
/* Actuator position not changing fault data frame                            */
/* ACTUATOR_POSITION_NO_CHANGE_FAULT */
typedef struct
{
    INT16U measured_speed;
    INT8U brake_engaged; /* boolean */
    INT8U spare_zero[5]; /* spare - show as 0 */
} POSITION_NO_CHANGE_PART_3;

typedef struct
{
    INT8U output_speed_diff_msb;
    INT8U output_speed_diff_umb;
    INT8U output_speed_diff_lmb;
    INT8U output_speed_diff_lsb;
    INT8U spare_zero[4]; /* spare - show as 0 */
} POSITION_NO_CHANGE_PART_4;

typedef struct
{
    /* EVENT_REPORT_COMMON_FRAME - common for all error frames */
    /* ECAN_LRU_STATUS_FRAME - common for all error frames */
    POSITION_NO_CHANGE_PART_3 Part_3;
    POSITION_NO_CHANGE_PART_4 Part_4;
} POSITION_NO_CHANGE_FAULT_FRAME;

/******************************************************************************/
/* Actuator start current over limit fault data frame                         */
/* ACTUATOR_STALLED_FAULT */
typedef struct
{
    INT16U max_start_current; /* big endian */
    INT16U measured_current;  /* big endian */
    INT16U time_since_start;  /* big endian */
    INT8U spare_zero[2];      /* spare - show as 0 */
} ACTUATOR_STALLED_PART_3;

typedef struct
{
    /* EVENT_REPORT_COMMON_FRAME - common for all error frames */
    /* ECAN_LRU_STATUS_FRAME - common for all error frames */
    ACTUATOR_STALLED_PART_3 Part_3;
    INT8U spare_zeros[8]; /* frame part 4 */
} ACTUATOR_STALLED_FAULT_FRAME;

/******************************************************************************/
/* Actuator start current over limit 5 times in a row fault data frame        */
/* ACTUATOR_STALLED_X5_FAULT */
/* data frame is empty - use GENERIC_EVENT_FRAME type filled with zeros */


/******************************************************************************/
/* Obstacle detected 5 times in a row fault data frame                        */
/* OBSTACLE_DETECTED_X5_FAULT */
typedef struct
{
    /* Part 3 */
    INT16U position_delta; /* big Endian */
    INT16U position_1;     /* big Endian */
    INT16U position_2;     /* big Endian */
    INT16U position_3;     /* big Endian */
    /* Part 4 */
    INT16U position_4;     /* big Endian */
    INT16U position_5;     /* big Endian */
} OBSTACLE_FAULT_PART;

typedef struct
{
    /* EVENT_REPORT_COMMON_FRAME - common for all error frames */
    /* ECAN_LRU_STATUS_FRAME - common for all error frames */
    OBSTACLE_FAULT_PART Unique;
    INT8U spare_zeros[4]; /* the rest of part 4 */
} OBSTACLE_DETECTED_FAULT_FRAME;

typedef struct
{
    /* EVENT_REPORT_COMMON_FRAME - common for all error frames */
    /* ECAN_LRU_STATUS_FRAME - common for all error frames */
    OBSTACLE_FAULT_PART Unique;
    INT8U spare_zeros[4]; /* the rest of part 4 */
} OBSTACLE_DETECTED_X5_FAULT_FRAME;

/******************************************************************************/
/* Brake disengage fault data frame                                           */
/* BRAKE_DISENGAGE_FAULT */
typedef struct
{
    /* Part 3 */
    INT16U delta_time; /* big Endian */
    INT16U delta_position; /* big Endian */
    INT16U high_load_current; /* in TBD units */
    INT16U measured_current; /* in TBD units */
    /* Part 4 */
    INT16U starting_position; /* big Endian */
    INT16U error_position; /* big Endian */
    INT16S on_the_fly;
    INT16U pulse_cnt_disengage;
} BRAKE_DISENGAGE_PART;

typedef struct
{
    /* EVENT_REPORT_COMMON_FRAME - common for all error frames */
    /* ECAN_LRU_STATUS_FRAME - common for all error frames */
    BRAKE_DISENGAGE_PART Unique;
    INT8U spare_zeros[6]; /* the rest of part 4 */
} BRAKE_DISENGAGE_FAULT_FRAME;

/******************************************************************************/
/* Brake engage fault 3 times in a row fault data frame        */
/* BRAKE_DISENGAGE_X3_FAULT */
/* data frame is empty - use GENERIC_EVENT_FRAME type filled with zeros */


/******************************************************************************/
/* Brake engage fault data frame                                              */
/* BRAKE_ENGAGE_FAULT */
typedef struct
{
    /* Part 3 */
    INT16U max_hall_change; /* big Endian */
    INT16U max_position_change; /* big Endian */
    INT16U commutation_stop_position; /* position when motor commutation stops big Endian */
    INT16U error_position; /* position when error is detected big Endian */
    /* Part 4 */
    /* Hall sensor value indicating how far the motor has moved since commutation has stopped */
    INT16U hall_change; /* big Endian */
} BRAKE_ENGAGE_PART;

typedef struct
{
    /* EVENT_REPORT_COMMON_FRAME - common for all error frames */
    /* ECAN_LRU_STATUS_FRAME - common for all error frames */
    BRAKE_ENGAGE_PART Unique;
    INT8U spare_zeros[6]; /* the rest of part 4 */
} BRAKE_ENGAGE_FAULT_FRAME;

/******************************************************************************/
/* Brake engage fault 5 times in a row fault data frame        */
/* BRAKE_ENGAGE_X5_FAULT */
/* data frame is empty - use GENERIC_EVENT_FRAME type filled with zeros */


/******************************************************************************/
/* Motor controller chip fault data frame                                     */
/* MOTOR_CONTROLLER_FAULT */
typedef struct
{
    /* Part 3 */
    INT16U measured_current; /* big Endian */
    INT16U max_motor_current; /* big Endian */
    INT8U FF2_value; /* position when motor commutation stops big Endian */
    INT8U spare_zero[3]; /* spare - show as 0 */
} MOTOR_CONTROLLER_PART_3;

typedef struct
{
    /* EVENT_REPORT_COMMON_FRAME - common for all error frames */
    /* ECAN_LRU_STATUS_FRAME - common for all error frames */
    MOTOR_CONTROLLER_PART_3 part_3;
    INT8U spare_zeros[8]; /* part 4 */
} MOTOR_CONTROLLER_FAULT_FRAME;

/******************************************************************************/
/* Motor controller failed 5 times in a row fault data frame                  */
/* MOTOR_CONTROLLER_X5_FAULT */
/* data frame is empty - use GENERIC_EVENT_FRAME type filled with zeros */


/******************************************************************************/
/* CAN bus transmission failed event data frame                              */
/* CAN_TRANSMIT_FAILED_EVENT */
/* data frame is empty - use GENERIC_EVENT_FRAME type filled with zeros */


/******************************************************************************/
/* LRU received its parameter(s) from the SCM at startup data frame           */
/* PARAM_CONFIRM_EVENT */
typedef struct
{
    /* Part 3 */
    INT8U spare_zero[2]; /* spare - show as 0 */
    INT8U parameter_msb; /* big Endian */
    INT8U parameter_lsb; /* big Endian */
    INT8U xspare_zero[4];
} PARAM_CONFIRM_PART_3;

typedef struct
{
    /* EVENT_REPORT_COMMON_FRAME - common for all error frames */
    /* ECAN_LRU_STATUS_FRAME - common for all error frames */
    PARAM_CONFIRM_PART_3 part_3;
    INT8U spare_zeros[8]; /* part 4 */
} PARAM_CONFIRM_EVENT_FRAME;

/******************************************************************************/
/* LRU start-up event data frame                                              */
/* STARTUP_EVENT */
typedef struct
{
    /* Part 3 */
    INT16U Boot_Count;
    INT8U spare_zero[6]; /* spare - show as 0 */
} STARTUP_PART_3;

typedef struct
{
    /* EVENT_REPORT_COMMON_FRAME - common for all error frames */
    /* ECAN_LRU_STATUS_FRAME - common for all error frames */
    STARTUP_PART_3 part_3;
    INT8U spare_zeros[8]; /* part 4 */
} STARTUP_EVENT_FRAME;

/******************************************************************************/
/* Obstacle detected event data frame                                         */
/* OBSTACLE_DETECTED_EVENT */
/* data frame is empty - use GENERIC_EVENT_FRAME type filled with zeros */


/******************************************************************************/
/* Impending shutdown message received data frame                             */
/* IMPENDING_SHUTDOWN_EVENT */
/* data frame is empty - use GENERIC_EVENT_FRAME type filled with zeros */


/******************************************************************************/
/* LRU start-up BITE event data frame                                         */
/* BITE_COMPLETE_EVENT */
typedef struct
{
    /* Part 3 */
    INT8U spare_zero[2]; /* spare - show as 0 */
    INT8U Success; /* Success = 1, unsuccessful = 0 */
     INT8U xspare_zero[4];
}  BITE_COMPLETE_PART_3;

typedef struct
{
    /* EVENT_REPORT_COMMON_FRAME - common for all error frames */
    /* ECAN_LRU_STATUS_FRAME - common for all error frames */
     BITE_COMPLETE_PART_3 part_3;
    INT8U spare_zeros[8]; /* part 4 */
}  BITE_COMPLETE_EVENT_FRAME;

/******************************************************************************/
/* Impending Shutdown Canceled event data frame                               */
/* IMPENDING_SHUTDOWN_CANCELED_EVENT */
/* data frame is empty - use GENERIC_EVENT_FRAME type filled with zeros */


/******************************************************************************/
/* Event processing configuration table definition                            */
typedef enum /* Event category codes */
{
    CAT_0 = 0,                                       /* an event, not a fault */
    CAT_A = 1,           /* use category A rules to confirm/consolidate fault */
    CAT_B = 2,           /* use category B rules to confirm/consolidate fault */
    CAT_C = 3,           /* use category C rules to confirm/consolidate fault */
} EVENT_CATEGORY;

typedef struct event_process_entry
{
    INT16U  ID;                 /* Event ID code from project's fault catalog */
    INT16U  category;           /* event/fault category - EVENT_CATEGORY type */
    INT16U  fault_color;                 /* ECAN_MAINTENANCE_FAULT_COLOR type */
    INT16U  record_SCM;                 /* flag - TRUE = also recorded by SCM */
    /* confirmation rules criteria */
    INT16U  num_occur;   /* number of occurrences to confirm fault and set
                          *  error_present in the LRU status message - set
                          * to 0 for Events that do not link to error_present */
    INT16U  fault_resolution;   /* Determines the error handling of the fault */
    INT32U  confirm_time;    /* millisecond time limit to confirm fault when
                              * num_occur > 1  - set to 0 for Events */
    /* Category A, B consolidation rules criteria (set to 0 for Events) */
    INT16U  num_reboots;            /* number of reboots to consolidate fault */
    /* number of confirmed occurrences between reboots to consolidate fault */
    INT16U  num_confirms_per_boot;
    /* millisecond time limit between reboots to consolidate fault */
    INT32U  time_between_reboots;

    /* Category C consolidation rules criteria (set to 0 for Events) */
    INT16U  num_periods;/* unused - number of time periods to consolidate fault */
    /* number of confirmed occurrences per period to consolidate fault */
    INT16U  confirms_per_period;
    INT32U  time_period;       /* milliseconds that equate to a "time period" */
} EVENT_PROCESS_ENTRY;

typedef struct event_processing_table
{
    INT16U table_id;                  /* unique identifier code for the table */
    INT16U num_entries;  /* number of entries in this table = NUM_EVENT_CODES */
    EVENT_PROCESS_ENTRY event[MAX_EVENT_CODES]; /* entries for this LRU */
    INT32U crc;                                           /* CRC of the table */
} CFG_EVENT_PROCESS_TABLE_TYPE;

/******************************************************************************/
/* Event processing consolidation table                                       */
/* Stored in program memory to remember event parameters across boot cycles   */
typedef struct
{
    INT16U ID;                                    /* Configured Event ID code */
    INTU   Num_Confirms;                           /* Number of confirmations */
    INTU   Num_Reboots;                     /* Used for category A & B faults */
    INT32U Accum_Time[MAX_EVENT_OCCUR];/* Accumulate time per confirms/reboots*/
} EVENT_CONSOL_ENTRY;

typedef struct event_consolidation_table
{
    INT16U table_id;                  /* unique identifier code for the table */
    INT16U num_entries;  /* number of entries in this table = NUM_EVENT_CODES */
    EVENT_CONSOL_ENTRY event[MAX_EVENT_CODES];  /* entries for this LRU */
    INT32U crc;                                           /* CRC of the table */
} CFG_EVENT_CONSOL_TABLE_TYPE;

/******************************************************************************/
/* Generic event/fault Log entry record data frame.  Used to overlay          */
/* (typecast) over type-specific frames                                       */
typedef struct
{
    union
    {
        INT32U long_array[8];
        INT16U word_array[16];
        INT8U  byte_array[32];
        struct
        {
            INT8U common[8]; /* EVENT_REPORT_COMMON_FRAME type */
            INT8U status[8]; /* LRU_STATUS_FRAME type */
            INT8U part_3[8]; /* Unique for each LRU event/fault code */
            INT8U part_4[8]; /* Unique for each LRU event/fault code */

        };
    };
}GENERIC_EVENT_LOG_FRAME;

/******************************************************************************/
/* LRU Event report part 1 frame - common to all events/faults                */
/******************************************************************************/
typedef struct
{
    INT16U Event_ID;                 /* LRU_EVENT_CODES type, sent big endian */
    INT8U CAN_id;                    /* This LRU's CAN ID */
    union /* Multipurpose - for Event Log & CAN message */
    {
        INT8U wrap_flag;         /* toggles state when the Log wraps in flash */
        INT8U record_SCM;            /* flag to record by SCM for CAN message */
    };
    union
    {
        INT32U TimeStamp;       /*  millisecond time of the event, big endian */
        struct
        {
            INT8U TimeStamp_MS;
            INT8U TimeStamp_UM;
            INT8U TimeStamp_LM;
            INT8U TimeStamp_LS;
        };
    };
} EVENT_REPORT_COMMON_FRAME;

/******************************************************************************/
/* Generic event/fault data frame for the unique portion of each event type.  */
/* Used to overlay (typecast) over type-specific frames                       */
typedef struct
{
    union
    {
        INT32U long_array[4];
        INT16U word_array[8];
        INT8U  byte_array[16];
        struct
        {
            INT8U part_3[8]; /* Unique for each event/fault code */
            INT8U part_4[8]; /* Unique for each event/fault code */

        };
    };
}GENERIC_EVENT_FRAME;


#endif /* ACTUATOR_H */
