/*
 * File:   bldc_drv.c
 * Author: e40063636
 *
 * Created on December 18, 2023, 9:11 PM
 */
#include <stdio.h>
#include "bldc_drv.h"

#define PIN_LOW  FALSE
#define PIN_HIGH TRUE

/*for more information on command format read TLE9180D-31QK Bridge Driver IC ,
 * Register Description.As command is of 24bit LSB byte should be append with 0*/
//BLDC Driver related Error registers read
INT32U Error_array[12] = {
    0x42000500, 0x43000100, 0x44000000, 0x45000400, 0x46000300, 0x47000700,
    0x48000100, 0x49000500, 0x4A000200, 0x4B000600, 0x4C000700, 0x4D000300
};
//BLDC commands read Configuration data
INT32U read_config[20] = {
    0x01800200, 0x02890100, 0x03000300, 0x04000200, 0x05000600,
    0x06000100, 0x07000500, 0x08000300, 0x09000700, 0x0A000000,
    0x0B000400, 0x0C000500, 0x0D000100, 0x0E000600, 0x0F000200,
    0x10000100, 0x11000500, 0x12000200, 0x13000600, 0x13000600
};
INT32U temp[6]={
0x25000700,
0x26000000,
0x27000400,
0x28000200,
0x29000600,
0x2a000100,
};
//BLDC Configuration registers & Control registers
INT32U cfg_ctrl[28] = {
    //, conf_gen_1(0x01) 0x80: 0b1000 0001 1000 0000 0000 0-110 0000 0000
    0x81800600,
    //, conf_gen_2 (0x02) 0x89: 0b1000 0010 1000 1001 0000 0-101 0000 0000
    0x82890500,
    //, conf_gen_3 (0x03) 0x1C: 0b1000 0011 0001 1100 0000 0-101 0000 0000
    // no need , this, because it is default value
    //, conf_wwd (0x04) 0x56: ________________________________
    // no need , this, because it is default value
    //, tl_vs (0x05) 0xAF: 0b1000 0101 1010 1111 0000 0-110 0000 0000
    0x85AF0600,
    //, tl_vdh (0x06) 0xD9: 0b1000 0110 1101 1100 0000 0-100 0000 0000
    0x86D90500,
    //, tl_cbvcc (0x07) 0x9A: 0b1000 0111 1001 1010 0000 0-110 0000 0000
    0x879A0600,
    //, fm_1 (0x08) 0xF3: 0b1000 1000 1111 0011 0000 0-000 0000 0000
    0x88F30000,
    //, fm_2 (0x09) 0x73: 0b1000 1001 0111 0011 0000 0-110 0000 0000
    0x89730600,
    //, fm_3 (0x0A) 0x3F: 0b1000 1010 0011 1111 0000 0-101 0000 0000
    0x8A3F0500,
    //, fm_4 (0x0B) 0x6F: 0b1000 1011 0110 1111 0000 0-111 0000 0000
    0x8B6F0700,
    //, fm_5 (0x0C) 0x7F: 0b1000 1100 0111 1111 0000 0-001 0000 0000
    0x8C7F0100,
    //, dt_hs (0x0D) 0x00: 0b1000 1101 0000 0000 0000 0-101 0000 0000
    0x8D890300,
    //, dt_ls (0x0E) 0x00: 0b1000 1110 0000 0000 0000 0-010 0000 0000
    0x8E890400,
    //, ft_1 (0x0F) 0x85: 0b1000 1111 1000 0101 0000 0-101 0000 0000
    0x8F850500,
    //, ft_2 (0x10) 0x50: 0b1001 0000 0101 0000 0000 0-011 0000 0000
    0x90500300,
    //, ft_3 (0x11) 0x0E: 0b1001 0001 0000 1110 0000 0-000 0000 0000
    0x910E0000,
    //, ft_4 (0x12) 0x02: 0b1001 0010 0000 0010 0000 0-010 0000 0000
    0x92030000,
    //, fm_6 (0x13) 0x03: 0b1001 0011 0000 0011 0000 0-100 0000 0000
    0x93030400,
    //, conf_sig (0x00) 0x05: 0b1000 0000 0000 0101 0000 0001 0000 0000
    0x80240600,
    //, op_gain_1 (0x20) 0x03: 0b1010 1000 0000 0011 0000 0000 0000 0000
    0xA8030000,
    //, op_0cl (0x23) 0x1F: 0b1010 0011 0001 1111 0000 0-010 0000 0000
    0xA31F0200,
    /*for default value commented sc_ls_1 to sc_hs_3*/
    //, sc_ls_1 (0x25) 0x06: 0b1010 0101 0000 0110 0000 0-100 0000 0000
    0xA57F0300,
    //, sc_ls_2 (0x26) 0x06: 0b1010 0110 0000 0110 0000 0-011 0000 0000
    0xA67F0400,
    //, sc_ls_3 (0x27) 0x06: 0b1010 0111 0000 0110 0000 0-111 0000 0000
    0xA77F0000,
    //, sc_hs_1 (0x28) 0x06: 0b1010 1000 0000 0110 0000 0-001 0000 0000
    0xA87F0600,
    //, sc_hs_2 (0x29) 0x06: 0b1010 1001 0000 0110 0000 0-101 0000 0000
    0xA97F0200,
    //, sc_hs_3 (0x2A) 0x06: 0b1010 1010 0000 0110 0000 0010 0000 0000
    0xAA7F0500,
    //, li_ctr (0x2B) 0xE8: 0b1010 1011 1110 1000 0000 0-001 0000 0000
    0xABE80100,
    //, misc_ctr (0x2C) 0xxx: 0b1010 1100 0000 0000 0000 0-000 0000 0000
    0xAC000000,
};

static void _bldc_drv_write_config(); 

static void _bldc_drv_read_Errspclop_reg(void); 

//Error checks need to be implemented
ERR_RET bldc_drv_init() 
{
    ERR_RET sys_err = NO_ERROR;
    ENABLE_5V_PIN = PORT_OUT_HIGH; //required for Halls sensor data
    
    bldc_normal_operation();
    
    return sys_err;

}

void bldc_drv_sleepmode(void) 
{
    cpu_SetBldcEnable(BLDC_DRV_DISABLE);
    cpu_SetBldcSoff(BLDC_DRV_SOFF_ON);
    cpu_SetBldcInhibit(BLDC_DRV_INHIBIT_ON);
    return;
}

INT32U bldc_drv_read_error(INT8U index) 
{
    INT32U rev_value;
    rev_value = _bldc_drv_command(Error_array[index]); //data for sent command
    return  rev_value;
}

//this function writes Bldc driver configuration registers and control registers
static void _bldc_drv_write_config() 
{
    INT32U value = 0;
#ifdef UART_DEBUG
    //--//printf("\r\n WRITING configuration/Control registers\r\n");
#endif
    for (INT8U i = 0; i < 28; i++) {
        value = _bldc_drv_command(cfg_ctrl[i]);
    }
    delay(5);
}

INT32U _bldc_drv_command(INT32U cmd) 
{
    INT32U ret = 0;
    cpu_SetBldcCs(BLDC_DRV_SELECTED);
    delay(1);
    ret = spi1_exchange24bit(cmd);
    cpu_SetBldcCs(BLDC_DRV_UNSELECTED);

    return ret;
}

void bldc_drv_read_config() 
{
    INT32U value = 0;

#ifdef UART_DEBUG
    //--//printf("\r\n READING all BLDC configuration registers\r\n");
#endif
    for (INT8U i = 0; i < 20; i++) {
        value = _bldc_drv_command(read_config[i]);
    }

}

void bldc_drv_read_other() 
{
    INT32U value = 0;
INT16U Lsb=0,Msb=0;
#ifdef UART_DEBUG
    //printf("\r\n READING all BLDC configuration registers\r\n");
#endif
    for (INT8U i = 0; i < 6; i++) {
        value = _bldc_drv_command(temp[i]);
            Lsb = (INT16U)value;
            Msb=(INT16U)(value>>16);
            //--//printf("\r\n Error Register 0x%02x%04x\r\n",(INT16U)Msb,(INT16U)Lsb);
    }

    value = _bldc_drv_command(BLDC_NOOP_READ); //read NO OP register
                Lsb = (INT16U)value;
            Msb=(INT16U)(value>>16);
            //--//printf("\r\n Error Register 0x%02x%04x\r\n",(INT16U)Msb,(INT16U)Lsb);
    delay(5);
}
//Configures BLDC driver IC to normal mode
void bldc_normal_operation() 
{
    INT32U value = 0;
    //reference: Power-up Diagram - TLE9180D-31QK Bridge Driver IC
    // Not implemented failure conditions and checks as it is only for Demo
    cpu_SetBldcSoff(BLDC_DRV_SOFF_ON);
    cpu_SetBldcEnable(BLDC_DRV_DISABLE);
    cpu_SetBldcInhibit(BLDC_DRV_INHIBIT_ON);

    delay(300 * 100);

    cpu_SetBldcSoff(BLDC_DRV_SOFF_ON);
    cpu_SetBldcEnable(BLDC_DRV_DISABLE);
    cpu_SetBldcInhibit(BLDC_DRV_INHIBIT_OFF);

    while (BLDC_READ_ERR != 1);

    value = _bldc_drv_command(BLDC_NOOP_READ); //read NO OP register
    delay(5);
    value = _bldc_drv_command(BLDC_NOOP_READ); //read NO OP register
    delay(5);

    //check for SPI ERROR
    if (value & BLDC_SPI_ERROR) {
        GREEN_LED_PIN = PORT_OUT_LOW;
        RED_LED_PIN = PORT_OUT_HIGH;
        return;
    }

    //read all error registers and special event register twice3)
    _bldc_drv_read_Errspclop_reg();
    //assuming no errors 
    _bldc_drv_read_Errspclop_reg();

#ifdef UART_DEBUG
    //--//printf("\r\n 05---------------EXPECTING CONFIG MODE ENTRY-----------------------");
#endif    

    cpu_SetBldcSoff(BLDC_DRV_SOFF_OFF);
    cpu_SetBldcEnable(BLDC_DRV_ENABLE);
    delay(100);

    value = _bldc_drv_command(BLDC_OPERMODE_READ); //op mode

    delay(10);
    value = _bldc_drv_command(BLDC_NOOP_READ); //read NO OP reg

    //bldc_drv_read_config();
    _bldc_drv_write_config();
    //bldc_drv_read_config();

    value = _bldc_drv_command(BLDC_OPERMODE_READ); //op mode

    value = _bldc_drv_command(BLDC_OPERMODE_READ); //op mode

    //check for normal mode reg:  Operation Mode Overview
    if (value & BLDC_DRIVE_MODE) {
        GREEN_LED_PIN = PORT_OUT_HIGH;
        RED_LED_PIN = PORT_OUT_LOW;
    } else {
        GREEN_LED_PIN = PORT_OUT_LOW;
        RED_LED_PIN = PORT_OUT_HIGH;
    }
}

//read all error registers and special event register twice3)
//(addr 0x42 ? 0x4D) and operation mode (addr 0x40)
static void _bldc_drv_read_Errspclop_reg(void) 
{
    INT32U value;
#ifdef UART_DEBUG
    //--//printf("\r\n 01-----ERROR REGISTERS--------------------------\r\n");
#endif
    //1st time reading: read all error registers and special event register twice
    for (int i = 0; i < 12; i++) {
        (void) bldc_drv_read_error(i);
        delay(10);
    }
    value = _bldc_drv_command(BLDC_OPERMODE_READ); //op mode
    delay(5);

    //2nd time reading: read all error registers and special event register twice
#ifdef UART_DEBUG
    //--//printf("\r\n 02-----ERROR REGISTERS--------------------------\r\n");
#endif
    for (int i = 0; i < 12; i++) {
        bldc_drv_read_error(i);
        delay(10);
    }
    value = _bldc_drv_command(BLDC_OPERMODE_READ); //op mode
    delay(5);

#ifdef UART_DEBUG
    //--//printf("\r\n 03-----Shutdown Errors--------------------------\r\n");
#endif
    value = _bldc_drv_command(BLDC_SHUTDWN_ERR_READ); //Shutdown errors? 
    delay(5);

    value = _bldc_drv_command(BLDC_NOOP_READ); //Shutdown errors
    delay(5);
}

//get the operational mode
INT16U bldc_drv_get_OperMode()
{    
    INT32U mode;

    mode = _bldc_drv_command (BLDC_OPERMODE_READ);
    
    //(INT32U) msg.word; //ignore first read will be dummy or data for previous command
    
    mode = _bldc_drv_command (BLDC_NOOP_READ);
    
    if(mode & NORMAL_MOTOR_MODE)
    {
        return  NORMAL_MOTOR_MODE;
    }
    
    if(mode & NORMAL_RECTI_MODE)
    {
        return  NORMAL_RECTI_MODE;
    }
    
    if(mode & ERROR_MODE)
    {
        return  ERROR_MODE;
    }
    
    if(mode & SOFF_MODE)
    {
        return  SOFF_MODE;
    }
    
    if(mode & SELF_TEST_MODE)
    {
        return  SELF_TEST_MODE;
    }
    
    if(mode & CONF_LOCK_MODE)
    {
        return  CONF_LOCK_MODE;
    }

    if(mode & CONF_MODE)
    {
        return  CONF_MODE;
    }

    if(mode & IDLE_MODE)
    {
        return  IDLE_MODE;
    }

    return 0;
}

//move to cpu.c
void cpu_SetBldcCs(BLDC_DRV_CS_STATES state) 
{
    BLDC_DRV_SELECT = (state == BLDC_DRV_SELECTED) ? 0 : 1;
    return;
}

void cpu_SetBldcSoff(BLDC_DRV_SOFF_STATES state) 
{
    BLDC_DRV_SOFF = (state == BLDC_DRV_SOFF_ON) ? 0 : 1;
    return;
}

void cpu_SetBldcEnable(BLDC_DRV_STATES state) 
{
    BLDC_DRV_ENABLEPIN = (state == BLDC_DRV_DISABLE) ? 0 : 1;
    return;
}

void cpu_SetBldcInhibit(BLDC_DRV_INHIBIT_STATES state) 
{
    BLDC_DRV_INHIBIT = (state == BLDC_DRV_INHIBIT_ON) ? 0 : 1;
    return;
}
//High is no ERROR
//Low is ERROR

BOOL cpu_getbldcErr(void) 
{
    return (BLDC_READ_ERR > 0);
}
