/*
 Author(s): 
 Status: Preliminary
 Release Date:
 Revision:
 Description: Header file for the Actuator Communications Module.
*/

#ifndef CAN_H
#define CAN_H

/*********************************************************************************************
Includes
*********************************************************************************************/
#include "typedef.h"

/*********************************************************************************************
Private Preprocessor definitions
*********************************************************************************************/
#define CAN_NUM_DATA_BYTES        8

#define ECAN_NO_ERROR             0x0
#define ECAN_ECAN_RXTX_FAILURE    0x20
#define ECAN_ECAN_INIT_FAILURE    0x40

/*********************************************************************************************
Type Definitions
*********************************************************************************************/
typedef enum
{
    BUFFER_0           = 0,
    BUFFER_1           = 1,
    BUFFER_2           = 2,
    BUFFER_3           = 3,
    BUFFER_4           = 4,
    BUFFER_5           = 5,
    BUFFER_6           = 6,
    BUFFER_7           = 7,
    NUM_BUFFERS        = 8,
    INVALID_BUFFER_NUM = 99
} CAN_BUFFERS;
   /*
    FIFO Object format:
    
    FIFO WORD_0:    |15:8|| EID<4:0>          | SID<10:8>              ||
                    | 7:0||           SID<7:0>                         ||
                             
    FIFO WORD_1:    |15:8|| SID<11>           | EID<17:13>             ||
                    | 7:0|| EID<12:5>                                  ||
                             
    FIFO WORD_2:    |15:8||FILHIT<4:0>  |   Reserved    |    ESI<1>    ||
                    | 7:0||FDF<1> | BRS<1> | RTR<1> | IDE<1> | DLC<3:0>||
                             
    FIFO WORD_3:    |15:8||          Reserved                          ||
                    | 7:0||          Reserved                          ||
                          
    FIFO WORD_4 to  |15:8||  Receive Data Byte 1,3,5.. n               || 
    FIFO WORD_n:    | 7:0||  Receive Data Byte 0,2,4.. n-1             ||
    */

typedef struct {
    union {
        struct {
    INT16U RSD:1;       /* Reserved */	
    INT16U Source:7;    /* Source CAN ID */
    INT16U LCC:3;       /* Logical communication channel */
    INT16U SIDL:5;
	
	INT16U SIDH:3;
	INT16U SID_Bit_9:1; /* Server ID bit 8 */
	INT16U Dest:7;      /* Destination CAN ID */		
	INT16U PVT:1;       /* Private data */
    INT16U LCL:1;       /* Local bus only */
    INT16U VOID1:3;
    
    INT16U DLC:4;  		/*  Data Length Code bits*/     
    INT16U IDE:1;  		/* Identifier Extension bit*/
    INT16U RTR:1; 	 	/* Remote Transmission Request bit*/
    INT16U BRS:1;  		/* Bit Rate Switch bit */
    INT16U FDF:1;  		/* FD Frame bit*/   
    INT16U ESI:1;  		/* Error Status Indicator bit*/  
    INT16U SEQ:7;
    
    INT16U VOID2; //unimplemented

    INT8U D[CAN_NUM_DATA_BYTES];
        };
        struct {
            INT16U value[8];
        };
    };
} ECAN_HW_MESSAGE;

enum CAN1_RX_FIFO_CHANNELS
{
    CAN1_FIFO_2 = 2,  /**< CAN1 Receive FIFO 2 */
    CAN1_FIFO_3 = 3,  /**< CAN1 Receive FIFO 3 */
};
enum CAN_TX_FIFO_STATUS
{
    CAN_TX_FIFO_FULL,       /**< Defines the Transmit FIFO is full */
    CAN_TX_FIFO_AVAILABLE,  /**< Defines the Transmit FIFO is available */
};

enum CAN_RX_FIFO_STATUS 
{
    CAN_RX_MSG_NOT_AVAILABLE = 0x0,
    CAN_RX_MSG_AVAILABLE = 0x1,
    CAN_RX_MSG_OVERFLOW = 0x8
};

enum CAN_TX_MSG_REQUEST_STATUS
{ 
    CAN_TX_MSG_REQUEST_SUCCESS = 0,             /**< Transmit message object successfully placed into Transmit FIFO */
    CAN_TX_MSG_REQUEST_DLC_EXCEED_ERROR = 1,    /**< Transmit message object DLC size is more than Transmit FIFO configured DLC size */
    CAN_TX_MSG_REQUEST_BRS_ERROR = 2,           /**< Transmit FIFO is configured has Non BRS mode and CAN TX Message object has BRS enabled */
    CAN_TX_MSG_REQUEST_FIFO_FULL = 3,           /**< Transmit FIFO is Full */
};


enum CAN_MSG_OBJ_FRAME_TYPE
{   
    CAN_FRAME_DATA      = 0,    /**< Data Frame CAN message object */
    CAN_FRAME_RTR       = 1,    /**< Remote Transmit Request Frame CAN message object */
};

enum CAN_MSG_OBJ_ID_TYPE 
{   
    CAN_FRAME_STD       = 0,    /**< Standard ID CAN message object */
    CAN_FRAME_EXT       = 1,    /**< Extended ID CAN message object */
};

enum CAN1_TX_FIFO_CHANNELS
{
    CAN1_TXQ = 0,   /**< CAN1 Transmit FIFO TXQ */
    CAN1_FIFO_1 = 1,   /**< CAN1 Transmit FIFO 1 */
}; 
/*********************************************************************************************
Function declarations
*********************************************************************************************/

/*********************************************************************************************
 * Author(s):   Michael Ansolis
 * Description: The initialization function for the ECAN module.
 * Parameters:  scm_id - CAN ID of the SCM controlling this actuator.
 *              can_id - CAN ID of this actuator.
 *              scm_id - destination CAN ID for the message controlling power shutdown
 *                       of this actuator.
 * Returns:     None.
*********************************************************************************************/
void ecan_init(INT8U scm_id, INT8U can_id, INT8U pwr_id);


/*********************************************************************************************
 * Author(s):   Michael Ansolis
 * Description: This function checks for receipt of messages and returns the first
 *              received message on FIFO basis.
 * Parameters:  p_msg - pointer to a message input buffer to store a received message.
 * Returns:     ERR_FAILURE - no message was received.
 *              NO_ERROR    - no error was detected (message received).
*********************************************************************************************/
bool ecan_rx_message(ECAN_HW_MESSAGE* p_msg);


/*********************************************************************************************
 * Author(s):   Michael Ansolis
 * Description: This function transmits outgoing messages.
 * Parameters:  p_msg       - pointer to the message that needs to be transmitted.
 * Returns:     ERR_FAILURE - message could not be transmitted (Tx buffer full).
 *              NO_ERROR    - no error was detected.
*********************************************************************************************/
ERR_RET ecan_tx_message(ECAN_HW_MESSAGE* p_msg);

/*********************************************************************************************
 * Author(s):   Mark Farver
 * Description: Breaks the SID up into three parts and puts them into the CAN frame
 * Parameters:  msg - the CAN frame to add the SID to
 *              sid - 9 bit SID value.
 * Returns:     None
 ********************************************************************************************/
void ecan_fill_sid(ECAN_HW_MESSAGE* msg, const INT16U sid);

/*********************************************************************************************
 * Author(s):   Mark Farver
 * Description: Extracts the SID from a CAN frame and into a single value.
 * Parameters:  msg - the CAN frame to add the SID to
 * Returns:     9 bit SID value.
 ********************************************************************************************/
INT16U ecan_extract_sid(const ECAN_HW_MESSAGE* msg);

/*********************************************************************************************
 * Author(s):   M VanderZouwen
 * Description: This function returns the number of the first available CAN
 *              transmit buffer.
 * Parameters:  None.
 * Returns:     The buffer number.
 ********************************************************************************************/
CAN_BUFFERS ecan_find_available_buffer( void );

/*********************************************************************************************
 * Author(s):   Jonathan Saliers
 * Description: This function transmits outgoing messages.
 * Parameters:  p_output_msg_buf - pointer to a message output buffer holding
 *                  messages to transmit.
 *              buffer_num - number of available transmit buffer.
 * Returns:     ECAN1_NO_ERROR = Transmit of messages successful.
 *              ECAN1_ECAN_RXTX_FAILURE = Failure during transmit of messages.
 ********************************************************************************************/
ERR_RET ecan_tx_msgs_express( ECAN_HW_MESSAGE* p_output_msg_buf, INT8U buffer_num );

#endif  /*ECAN_H */

