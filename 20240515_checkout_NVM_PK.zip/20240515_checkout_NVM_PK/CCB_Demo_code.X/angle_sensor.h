#ifndef _ANGLE_SENSOR_H
#define _ANGLE_SENSOR_H

/*********************************************************************************************
 * Includes
 ********************************************************************************************/
#include "typedef.h"
#include <stddef.h>
#include "cpu.h"
#include "spi.h"
#include <xc.h>

//Angle Sensor register address
#define     STAT_REG_ADDR            0x00   // Status Register
#define     ACSTAT_REG_ADDR          0x01   // Activation Status Register
#define     AVAL_REG_ADDR            0x02   // Angle Value Register
#define     ASPD_REG_ADDR            0x03   // Angle Speed Register
#define     AREV_REG_ADDR            0x04   // Angle Revolution Register
#define     FSYNC_REG_ADDR           0x05   // Frame Synchronization Register
#define     MOD_1_REG_ADDR           0x06   // Interface Mode1 Register
#define     SIL_REG_ADDR             0x07   // SIL Register
#define     MOD_2_REG_ADDR           0x08   // Interface Mode2 Register
#define     MOD_3_REG_ADDR           0x09   // Interface Mode3 Register
#define     OFFX_REG_ADDR            0x0A   // Offset X
#define     OFFY_REG_ADDR            0x0B   // Offset Y
#define     SYNCH_REG_ADDR           0x0C   // Synchronicity
#define     IFAB_REG_ADDR            0x0D   // IFAB Register
#define     MOD_4_REG_ADDR           0x0E   // Interface Mode4 Register
#define     TCO_Y_REG_ADDR           0x0F   // Temperature Coefficient Register
#define     ADC_X_REG_ADDR           0x10   // X-raw value
#define     ADC_Y_REG_ADDR           0x11   // Y-raw value
#define     IIF_CNT_REG_ADDR         0x20   // Y-raw value

typedef struct {
    union {
        struct {
            INT16U ND : 4; // 4-bit Number of Data Words(LSB))
            INT16U ADDR : 6; // 6-bit Address
            INT16U UPD : 1; // Update-Register Access 
            INT16U Lock : 4; // 4-bit Lock Value 
            INT16U RW : 1; // Read - Write  (MSB))
        };
        INT16U command;
    };
} CMD_WORD;

typedef struct {

    union {
        struct {
            INT16U CRC : 8; //Sensor number response indicator
            INT16U RESP : 4; //Sensor number response indicator
            INT16U Validity : 1; //Valid angle value (NO_GMR_A = 0; NO_GMR_XY = 0)
            INT16U Intf_err : 1; //Interface access error (access to wrong address; wrong lock)
            INT16U Sys_err : 1; //System error (e.g. overvoltage; undervoltage; VDD-, GND- off; ROM;...)
            INT16U Reset : 1; //Indication of chip reset or watchdog overflow
        };
        INT16U safety_word;
    };
} SAFTY_WORD;

typedef enum
{
    ANGLESENSOR_01, /*corresponds to U2 in CCB */
    ANGLESENSOR_02 /*corresponds to U3 in CCB */
} ANGLESENSOR_NUM;

void angle_readvalue(ANGLESENSOR_NUM sensor);

INT16U angle_getvalue(ANGLESENSOR_NUM sensor);

/*********************************************/
/* Code from 20240326 onwards is added below */
/*********************************************/

#define CONVERT2DEGREE(x) ((x << 1)/182) // Formula: ((360 degrees)/(2^15))* (x & 0x7FFF)
                                         // Modified formula: ((360 degrees)/(2^16))* (x << 1)
#define ANGLE_SENSOR_ANALYZE 1
#define ANGLE_SENSOR_SAFETY_WORD_ANALYZE 1
#define ANGLE_SENSOR_STATUS_ANALYZE 1
//#define STATUS_REG_PARTIAL_MASK 0x1EF6 // bits 12-9, 7-4, 2, 1
#define STATUS_REG_PARTIAL_MASK 0x1EFF // bits 15, 12-9, 7-0

#define ZERO_POS_CONFIG_COMPUTE_STORE_NVM 1
#define ZERO_POS_CONFIG_NVM_READ_USE      1

#endif /* _ANGLE_SENSOR_H */

INT16U flash_test();
void nvm_testNVM(void);
void angle_sensor_exec(void);