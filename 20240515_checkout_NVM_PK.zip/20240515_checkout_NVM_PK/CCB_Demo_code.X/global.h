/*
 * File:   global.h
 * Author: mfarver
 *
 * Created on April 6, 2015, 5:27 PM
 * History: 05/16/2016 Juan Kuyoc - Added Assy. and Cfg. part number types.
 *          06/27/2016 Clay Barber - Updates of Juan Kuyoc
 */

#ifndef GLOBAL_H
#define	GLOBAL_H

#ifdef	__cplusplus
extern "C" {
#endif

/* CRC32 checks will fail in debug mode, disable them */
#if defined(__DEBUG) && !defined(DISABLE_CRC32_CHECKS)
#define DISABLE_CRC32_CHECKS
#endif

#include <xc.h>
#include "typedef.h"
#include "lru-global.h"

/* Number of seats managed by this PDM.  Note that PDM cpu.c will need updating
 * with the IO ports associated with each seat
 */
#define NUM_PAXS 2
#define NUM_LRUS_PER_PAX 13
#define MAX_LRUS ((NUM_LRUS_PER_PAX * NUM_PAXS) +1)
typedef enum { PAXNUM_1, PAXNUM_2, PAXNUM_3 } PAXNUM;
#define ARINC_LRU_FILENAME_LEN 8
#define MAX_FAULT_IDS 255          /* Max number of faults to support */

#define MAX_CAN_TO_A485_MAPPING_RECORDS 50
#define MAX_A485_TO_CAN_MAPPING_RECORDS 50

#define ASSY_PN_NUM_BYTES  8   /* Number of bytes used to store the assembly number. */
#define SW_PN_NUM_BYTES    8   /* Number of bytes used to store the software part number. */
#define HW_PN_NUM_BYTES    6   /* Number of bytes used to store the hardware part number. */
#define CFG_PN_NUM_BYTES   8   /* Number of bytes used to store the configuration part number. */
#define SN_NUM_BYTES       8   /* Number of bytes used to store the serial number. */

#define CFG_NO_ERROR  NO_ERROR
#define CFG_READ_ERR  0x1

#define GAP_EXTERNAL_PULLUP_MIN_MV 2500 /* greater than 2.5V, GAP is external pull up */
#define GAP_EXTERNAL_PULLDOWN_MAX_MV 700 /* less than .7V GAP is external pull down */

/* Maximum number of configuration tables in any LRU */
#define MAX_NUM_CFG_TABLES  32
#define WRAP_FLAG_INDEX     3

/* Note that to store 16 bits of data (1 word), 1 PC unit is used,
   which is 3 bytes or two words in terms of PC addresses */
#define WORDS_PER_PC_UNIT   2

/* Unique CAN ID for the case of erasing DataFlash during ATP */
#define DF_ERASE_CAN_ID     0x7F

#define IGNORE_CRC          0x00000001

typedef enum boot_mode_enum
{
    /* Application mode.  This boot flag is set when the maintenance firmware reboots the second
       (and last) time after querying all other LRUs for their error history. */
    BOOT_INTO_APP       = 0x1234,

    /* Any value other than 0x1234 indicates that the maintenance FW is the selected boot mode. */

    BOOT_INTO_BOOTLOADER = 0xFEED,

    BOOT_INTO_MAINT_PCU = 0xFAFA,
} BOOT_MODE_TYPE;

typedef enum
{
    APP_ERROR   = 0xAAAA,
    BOOT_ERROR  = 0xBBBB,
    CFG_ERROR   = 0xCCCC,
    MAINT_ERROR = 0xDDDD
} ERR_LOG_CODE_TYPE;

typedef struct fw_crc_table
{
    INT16U table_id;
    INT32U fw_crc32;
    INT32U fw_start_addr;
    INT32U fw_end_addr;
    INT32U crc;
} CFG_FW_CRC_TABLE_TYPE;

typedef struct
{
    INT8U  bytes[ASSY_PN_NUM_BYTES];
} ASSY_PN_TYPE;

typedef struct sw_part_num
{
    INT8U  bytes[SW_PN_NUM_BYTES];
} SW_PN_TYPE;

typedef struct
{
    INT8U  bytes[CFG_PN_NUM_BYTES];
} CFG_PN_TYPE;

typedef struct fw_id_table
{
    INT16U          table_id;
    SW_PN_TYPE      sw_part_num;
    INT32U          crc;
} CFG_FW_ID_TABLE_TYPE;

typedef struct
{
    INT8U  bytes[SN_NUM_BYTES];
} SN_TYPE;

typedef struct
{
    INT8U  bytes[HW_PN_NUM_BYTES];
} HW_PN_TYPE;

typedef struct
{
    INT16U          table_id;
    SN_TYPE         serial_num;
    ASSY_PN_TYPE    assy_part_num;
    HW_PN_TYPE      hw_part_num;
    CFG_PN_TYPE     cfg_part_num;
    INT32U          crc32;
} LRU_ID_TABLE_TYPE;


#ifdef	__cplusplus
}
#endif

#endif	/* GLOBAL_H */

