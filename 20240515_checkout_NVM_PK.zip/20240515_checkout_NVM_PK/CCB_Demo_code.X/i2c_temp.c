/*
 Author(s): Michael Ansolis
 Status: Preliminary
 Release Date:
 Revision:
 Description: Definitions for the Actuator/UAP I2C module to read temperature 
 * sensor data on Board.
 */

/*********************************************************************************************
Includes
 *********************************************************************************************/
#include "i2c_temp.h"
#include "timer_manager.h"
#include <xc.h>

/*********************************************************************************************
Private Preprocessor definitions
 *********************************************************************************************/

#define I2C_BRIDGE_ADDRESS         0x48    /* Address of the Temp Sensor */

/* PIC I2C module bitfields for the I2C1CON control register  */
#define I2C_MODULE_ENABLE          0x8000  /* Enable the I2C1 module */
#define I2C_CONFIG_START           0x8001  /* Assert a Start condition */
#define I2C_CONFIG_REPEATED_START  0x8002  /* Assert a Repeated Start condition */
#define I2C_CONFIG_STOP            0x8004  /* Assert a Stop condition */
#define I2C_CONFIG_RCV_MODE        0x8008  /* Enable Receive mode */
#define I2C_CONFIG_SEND_NACK       0x8030  /* Send NACK */
#define I2C_CONFIG_SEND_ACK        0x8010  /* Send ACK */

#define I2C_BRG_VALUE              0xBB     /* BRG = (Fcy*((1/Fscl) - Pulse_Gobbler_Delay)) - 1
                                              where Pulse_Gobbler_Delay is assumed to be 0.00000015 (150ns) */
#define I2C_FINISHED          0xFF
#define I2C_UNFINISHED        0

#define I2C_CFG_WORD  0x00 //TBD

#define I2C_STATE_WRITE_CFG       1     /* I2C bridge Configuration command during setup */
#define I2C_STATE_READ_TEMP       2

#define SHORT_DELAY               2     /* Delay for 2ms. */
#define LONG_DELAY                1000  /* Delay for 1s. */

#define TEMP_FACTOR              0.0625 /*128/2048 */
/*********************************************************************************************
Type Definitions
 *********************************************************************************************/

/* Union for accessing individual bytes of the temperature value received from the digital thermometer. */
typedef struct temp_data {

    union {

        struct __attribute__((packed)) {
            INT8U temp_byte_1;
            INT8U temp_byte_2;
        };

        struct __attribute__((packed)) {
            INT16S Word;
        };
    };
} TEMP_WORD_TYPE;

typedef struct temp {
    INT16S temp : 12;
} TEMP_VALUE_TYPE;


TEMP_VALUE_TYPE temp_val;
/*********************************************************************************************
Private Function declarations
 *********************************************************************************************/

static INT16U _i2c_perform_write_cfg();
static INT16U _i2c_perform_temp_read();

/*********************************************************************************************
Global Variable definitions
 *********************************************************************************************/

static INT16S G_report_temperature;
static TEMP_WORD_TYPE G_Temperature;

/*********************************************************************************************
Function definitions
 *********************************************************************************************/

/*********************************************************************************************
 * Author(s):   Pratheep
 * Description: Returns the temperature value from the digital thermometer used in the BLDC motor.
 * Parameters:  None
 * Returns:     16-bit signed integer temperature value in degrees Celsius
 *********************************************************************************************/
INT16S i2c_get_temp() {
    return G_report_temperature;
}
/*should be changed to I2C2*/

/*********************************************************************************************
 * Author(s):   
 * Description: Initializes the I2C module.
 * Parameters:  None
 * Returns:     INIT_FAILED - Initialization failed (failed to read 85 degrees from thermometer).
 *              NO_ERROR    - Initialization succeeded.
 *********************************************************************************************/
ERR_RET i2c_init(void) {
    ERR_RET sys_err = NO_ERROR;

    I2C2BRG = I2C_BRG_VALUE; /* Baud Rate Generator Value */

    I2C2CONL = I2C_MODULE_ENABLE; /* Enable I2C module 1 */

    I2C2STAT = 0x0;

    /* Initialize temperature to 0 degrees Celsius. */
    G_Temperature.Word = 0;

    G_report_temperature = 0;

    return sys_err;
}

/*********************************************************************************************
 * Author(s):   Pratheep
 * Description: Issues a Write Configuration command to perform
 *              the initial chip configuration.
 * Parameters:  None
 * Returns:     I2C_UNFINISHED - I2C bus transactions are still in progress.
 *              I2C_FINISHED   - I2C bus has come to its final state.
 *********************************************************************************************/
static INT16U _i2c_perform_write_cfg() {
    static INT16U S_State = 0;

    INT16U ret_val = I2C_UNFINISHED;

    switch (S_State) {
            /* Assert Start condition */
        case 0:
            I2C2CONL = I2C_CONFIG_START;
            S_State = 1;
            break;

            /* Check for completion of the start condition */
        case 1:
            if (!I2C2CONLbits.SEN) {
                S_State = 2;
            }
            break;

            /* Write the 7-bit address of the bridge chip with a write indication
               (the 8th bit R/W = 0) to transmit buffer */
        case 2:
            I2C2TRN = (I2C_BRIDGE_ADDRESS << 1);
            S_State = 3;
            break;

            /* Check for master transmission complete and slave acknowledge received */
        case 3:
            if (!I2C2STATbits.TBF && !I2C2STATbits.TRSTAT && !I2C2STATbits.ACKSTAT) {
                S_State = 4;
            }
            break;

            /* Send the Write Configuration command to the I2C bridge chip */
        case 4:
            I2C2TRN = 0x01;
            S_State = 5;
            break;

            /* Check for master transmission complete and slave acknowledge received */
        case 5:
            if (!I2C2STATbits.TBF && !I2C2STATbits.TRSTAT && !I2C2STATbits.ACKSTAT) {
                S_State = 6;
            }
            break;

            /* Send configuration word to the I2C bridge to configure speed and pullups */
        case 6:
            I2C2TRN = I2C_CFG_WORD;
            S_State = 7;
            break;

            /* Check for master transmission complete and slave acknowledge received */
        case 7:
            if (!I2C2STATbits.TBF && !I2C2STATbits.TRSTAT && !I2C2STATbits.ACKSTAT) {
                S_State = 8;
            }
            break;

            /* Generate a Stop condition */
        case 8:
            I2C2CONL = I2C_CONFIG_STOP;
            S_State = 9;
            break;

            /* Check for completion of Stop condition generation */
        case 9:
            if (!I2C2CONLbits.PEN) {
                ret_val = I2C_FINISHED;
                S_State = 0;
            }
            break;
    }

    return ret_val;
}

/*********************************************************************************************
 * Author(s):   Pratheep
 * Description: To Read temperature data 
 * Parameters:  None
 * Returns:     I2C_UNFINISHED - I2C bus transactions are still in progress.
 *              I2C_FINISHED   - I2C bus has come to its final state.
 *********************************************************************************************/
static INT16U _i2c_perform_temp_read() {
    static INT16U S_State = 0;

    static TEMP_WORD_TYPE temp;

    INT16U ret_val = I2C_UNFINISHED;

    switch (S_State) {
            /* Assert Start condition */
        case 0:
            temp.Word = 0;
            I2C2CONL = I2C_CONFIG_START;
            S_State = 1;
            break;

            /* Check for completion of the start condition */
        case 1:
            if (!I2C2CONLbits.SEN) {
                S_State = 2;
            }
            break;

            /* Write the 7-bit address of the bridge chip with a write indication
               (the 8th bit R/W = 0) to transmit buffer */
        case 2:
            I2C2TRN = (I2C_BRIDGE_ADDRESS << 1);
            S_State = 3;
            break;

            /* Check for master transmission complete and slave acknowledge received */
        case 3:
            if (!I2C2STATbits.TBF && !I2C2STATbits.TRSTAT && !I2C2STATbits.ACKSTAT) {
                S_State = 4;
            }
            break;

            /* Send Set Read Pointer command to Temperature Register */
        case 4:
            I2C2TRN = 0x00;
            S_State = 5;
            break;

            /* Check for master transmission complete and slave acknowledge received */
        case 5:
            if (!I2C2STATbits.TBF && !I2C2STATbits.TRSTAT && !I2C2STATbits.ACKSTAT) {
                S_State = 6;
            }
            break;

            /* Generate a Repeated Start condition */
        case 6:
            I2C2CONL = I2C_CONFIG_REPEATED_START;
            S_State = 7;
            break;

            /* Check for completion of Repeated Start condition */
        case 7:
            if (!I2C2CONLbits.RSEN) {
                S_State = 8;
            }
            break;

            /* Write the 7-bit address of the bridge chip with a read indication
               (the 8th bit R/W = 1) to transmit buffer */
        case 8:
            I2C2TRN = (I2C_BRIDGE_ADDRESS << 1) + 1;
            S_State = 9;
            break;

            /* Check for master transmission complete and slave acknowledge received */
        case 9:
            if (!I2C2STATbits.TBF && !I2C2STATbits.TRSTAT && !I2C2STATbits.ACKSTAT) {
                S_State = 10;
            }
            break;

            /* Enable Receive mode for the I2C module */
        case 10:
            I2C2CONL = I2C_CONFIG_RCV_MODE;
            S_State = 11;
            break;

            /* Check for completion of Receive Sequence condition */
        case 11:
            if (!I2C2CONLbits.RCEN) {
                S_State = 12;
            }
            break;

            /* read the  Data Byte 1 Read Register */
        case 12:
            temp.temp_byte_1 = I2C2RCV;
            S_State = 13;
            break;
            /* Send Acknowledge Sequence to the I2C bridge chip. */
        case 13:
            I2C2CONL = I2C_CONFIG_SEND_ACK;
            S_State = 14;
            break;

            /* Check for completion of Acknowledge Sequence condition */
        case 14:
            if (!I2C2CONLbits.ACKEN) {
                S_State = 15;
            }
            break;

            /* Enable Receive mode for the I2C module */
        case 15:
            I2C2CONL = I2C_CONFIG_RCV_MODE;
            S_State = 16;
            break;

            /* Check for completion of Receive Sequence condition */
        case 16:
            if (!I2C2CONLbits.RCEN) {
                S_State = 17;
            }
            break;

            /* read the  Data Byte 2 Read Register */
        case 17:
            temp.temp_byte_2 = I2C2RCV;
            S_State = 18;
            break;

            /* Send Acknowledge Sequence to the I2C bridge chip.
               Note:  During reads, a master must terminate data requests
               to the slave by Not Acknowledging (generating a "NACK")
               on the last byte of the message. */
        case 18:
            I2C2CONL = I2C_CONFIG_SEND_NACK;
            S_State = 19;
            break;

            /* Check for completion of Acknowledge Sequence condition */
        case 19:
            if (!I2C2CONLbits.ACKEN) {
                S_State = 20;
            }
            break;

            /* Generate a Stop condition */
        case 20:
            I2C2CONL = I2C_CONFIG_STOP;
            S_State = 21;
            break;

            /* Check for completion of Stop condition generation */
        case 21:
            if (!I2C2CONLbits.PEN) {
                ret_val = I2C_FINISHED;
                S_State = 0;
            }
            /*convert to signed 12 bit value as per the received */
            /*refer 7.5.2 Temperature Register of TMP100-Q1 Data Sheet*/
            temp_val.temp = ((temp.temp_byte_1 << 4) | (temp.temp_byte_2 >> 4));
            break;
    }

    return ret_val;
}

/*********************************************************************************************
 * Author(s):   Pratheep
 * Description: Performs periodic processing for the I2C module.
 * Parameters:  None
 * Returns:     None
 *********************************************************************************************/
void i2c_temp_exec(void) {
    INT32U time = tmgr_get_system_time();
    static INT16U G_Next_State = I2C_STATE_WRITE_CFG;
    static INT32U S_Last_Time = 0;

    switch (G_Next_State) {

            /* Sequence for initializing the bridge chip. */

        case I2C_STATE_WRITE_CFG:
            if (_i2c_perform_write_cfg() == I2C_FINISHED) {
                G_Next_State = I2C_STATE_READ_TEMP;
                S_Last_Time = time;
            }
            break;

        case I2C_STATE_READ_TEMP:
                if (_i2c_perform_temp_read() == I2C_FINISHED) {
                    G_Next_State = I2C_STATE_READ_TEMP;
                    S_Last_Time = time;
                    G_report_temperature = (INT16S) (temp_val.temp * TEMP_FACTOR);
                }
            break;
    }
}