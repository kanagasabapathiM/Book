/*
 Author(s):     Jonathan R. Saliers
 Status:        Preliminary
 Release Date:
 Revision:
 Description:   Header file for the Actuator CPU Utility Module.
 */

/*********************************************************************************************
 * Recursive header block
 ********************************************************************************************/
#ifndef UTILITY_H
#define	UTILITY_H

/*********************************************************************************************
Includes
*********************************************************************************************/
#include "global.h"

#define CRC32_POLY      0xEDB88320ul
#define CRC_SEED        0xFFFFFFFFul

#define ONE_BYTE_SHIFT     8
#define TWO_BYTE_SHIFT    16
#define THREE_BYTE_SHIFT  24

#define DEGREES_PER_REV  360

#define PROG_MEM_PAGE_SIZE          0x10000ul     /* 65536 words */

#ifdef __DEBUG
#define HALT(void) {  }
#else
#define HALT(void) while(1) { ClrWdt();  }
#endif
/*********************************************************************************************
Function declarations
*********************************************************************************************/

/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: memset function to replace the standard library version. This function is needed
             to satisfy DO-178 review requirements.
Parameters:  p_dest - a pointer to the first member of the target memory location
                      into which the value is to be set.
             val    - the unsigned eight bit value to which all eight bit members of the target
                      memory are to be set
             length - the length in bytes of the destination memory to be set.
Returns:     None
*********************************************************************************************/
void util_memset(void* p_dest, INT8U val, INT16U length);

/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: memcpy function to replace the standard library version. This function is needed
             to satisfy DO-178 review requirements.
Parameters:  p_dest - A pointer to the first member of the target memory location into which
                      the memory contents  are to be copied.
             p_src  - A pointer to the first member of the memory from which the memory
                      contents are to be copied.
             length - the length in bytes of the destination memory space.
Returns:     None
*********************************************************************************************/
void util_memcpy(void* p_dest, const void* p_src, INT16U length);

/*********************************************************************************************
 * Author(s):   Mark Farver
 * Description: memcpy function that reads from program flash
 * Parameters:  p_dest - a pointer to the first  member of the target memory location
 *                       into which the values are to be copied.
 *              prog_start_addr  - Absolute (24 bit) start address in program memory
 *                       to start copy at.
 *              length - the length in bytes of the destination memory space.
 * Returns:     None
*********************************************************************************************/
void util_memcpy_from_prog(void* p_dest, INT32U prog_start_addr, INT16U length);

/*********************************************************************************************
 * Author(s):   Mark Farver
 * Description: memcpy function that reads from program flash, and checks CRC.
 *              Assumes last four bytes of the data is the CRC to compare against.
 * Parameters:  p_dest - a pointer to the first  member of the target memory location
 *                       into which the values are to be copied.
 *              prog_start_addr  - Absolute (24 bit) start address in program memory
 *                       to start copy at.
 *              length - the length in bytes of the destination memory space.
 *                  (crc is assumed to be last four bytes)
 * Returns:     None
*********************************************************************************************/
void util_memcpy_from_prog_w_crc(void* p_dest, INT32U prog_start_addr, INT16U length,
                                 INT32U * crc );

/*********************************************************************************************
Author(s):   Michael Ansolis
Description: atan function similar to the C math.h version. This function is needed
             to satisfy DO-178 review requirements. NOTE THAT THIS FUNCTION IS NOT A DIRECT
             REPLACEMENT FOR THE LIBRARY FUNCTION. IT RETURNS THE ARCTANGENT OF THE GIVEN
             TANGENT IN DEGREES - NOT RADIANS AS THE LIBRARY FUNCTION DOES.
Parameters:  tangent - The tangent (sine/cosine) whose arctangent is needed.
Returns:     The arctangent of the given tangent in degrees in the range 90 to -90.
*********************************************************************************************/
INT16S util_atan(FP32 tangent);

/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: abs() function to replace the C stdlib.h version. This function is needed
             to satisfy DO-178 review requirements. Returns the absolute value of the given
             integer.
Parameters:  number - A signed integer number.
Returns:     The absolute value of the given integer.
*********************************************************************************************/
INT32S util_abs(INT32S number);

/*********************************************************************************************
 * Author(s): mfarver
 * Description: memcmp function to replace the standard library version. This function is needed
 *  to satisfy DO-178 review requirements.
 * Parameters:  Ptr1 - a pointer to the first location of the left value to compare
 *              Ptr2  - a pointer to the first location of the right value to compare
 *              length - the length in bytes to compare.
 * Returns:     0 if equal, nonzero if not equal.
*********************************************************************************************/
INT16U util_memcmp(const void *Ptr1, const void *Ptr2, INT16U Count);

/*********************************************************************************************
 * Author(s): mfarver
 * Description: Endianness swap of a 16bit integer.  pic is little endian, CAN
 *              frames are big endian.
 * Parameters:  num - value to swap
 * Returns:     16 bit integer, reverse byte order.
*********************************************************************************************/
INT16U util_byteswap16(INT16U num);

/*********************************************************************************************
 * Author(s): mfarver
 * Description: Endianness swap of a 32bit integer.  pic is little endian, CAN
 *              frames are big endian.
 * Parameters:  num - value to swap
 * Returns:     32 bit integer, reverse byte order.
*********************************************************************************************/
INT32U util_byteswap32(INT32U num);

/*********************************************************************************************
 * Author(s): mfarver
 * Description: Convert a 6 byte hardware part number to ASCII
 * Parameters:  hwpn: pointer to 6 byte packed hardware part number
 *              hwpnstr: pointer to 16 byte ASCII result buffer.
 *              max_strlen: Size of the hwpnstr buffer
 * Returns:     Length of string
*********************************************************************************************/
INT8U util_hwpn2str(HW_PN_TYPE * hwpn, INT8U * hwpnstr, INT8U max_strlen);

/*********************************************************************************************
 * Author(s): mfarver
 * Description: Convert a 8 byte software part number to ASCII (last two bytes ignored)
 * Parameters:  swpn: pointer to 8 byte packed hardware part number
 *              swpnstr: pointer to 16 byte ASCII result buffer.
 *              max_strlen: Size of the swpnstr buffer
 * Returns:     Length of string
*********************************************************************************************/
INT8U util_swpn2str(SW_PN_TYPE * swpn, INT8U * swpnstr, INT8U max_strlen);

/*********************************************************************************************
 * Author(s): mfarver
 * Description: Convert a 4 bit nybble into ASCII 0-9A-F
 * Parameters:  digit: 4 bit value to convert
 * Returns:     ASCII value 0-9 or A-F
*********************************************************************************************/
INT8U util_nybbletohexchar(INT8U digit);

/*********************************************************************************************
 * Author(s): mfarver
 * Description: Convert a ASCII text character into 4 bit nybble
 * Parameters:  hexchar: ASCII character 0-9 or A-F
 * Returns:     4 bit nybble value, or -1 if failed.
*********************************************************************************************/
INT8S util_hexchartonybble(INT8U hexchar);

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Perform an integer square root approximation.
 * Parameters:  num - value to perform a square root on.
 * Returns:     INT32 - square root approximation of num with a result
 *              in the range of 0 - 255.
*********************************************************************************************/
INT32S util_sqrt( INT32S num );

void util_debug_can( INT8U d0, INT8U d1, INT8U d2, INT8U d3, INT8U d4, INT8U d5, INT8U d6, INT8U d7 );

/*********************************************************************************************
 * Recursive header block
 ********************************************************************************************/


void delay(unsigned int delay);
#endif	/* UTILITY_H */

