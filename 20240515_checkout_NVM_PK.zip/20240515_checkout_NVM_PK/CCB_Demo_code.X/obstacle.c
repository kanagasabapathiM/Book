/*
Author(s):      David Yuen <dyuen@righthandtech.com>
                James Pieterick <jpieterick@righthandtech.com>
Status:         Preliminary
Release Date:
Revision:       Initial
Description:    Implements Obstacle Detection.
History:        Juan Kuyoc 05/13/16: Added/Modified for new obstacle detection algorithm.
*/
/*********************************************************************************************
Includes
*********************************************************************************************/
#include "bldc.h"
#include "cpu.h"
#include "current.h"
#include "can.h"
#include "global.h"
#include "hall.h"
#include "motion_control.h"
#include "obstacle.h"
#include "position.h"
#include "pwm.h"
#include "system_monitor.h"
#include "timer_manager.h"
#include "utility.h"

/*********************************************************************************************
    Private Type Definitions
*********************************************************************************************/
/*
 Helper struct to store the obstacle detect parameters for a given direction.
 */
typedef struct ObsDetectParams
{
    INT16S pos_slope_thresh;
    INT16S pos_slope_width;
    INT16S pos_load_limit;
    INT16S neg_slope_thresh;
    INT16S neg_slope_width;
    INT16S neg_load_limit;
    INT16S spike_height;
    INT16S spike_width;
    INT16S max_travel_zone;

} OBS_DETECT_PARAMS;

/*********************************************************************************************
Private Preprocessor definitions
*********************************************************************************************/
#define NUM_REPEATING_OBS      5    /* Number of obstacles after which repeating OD flag is set. */
#define OD_EXPIRATION_TIME     110  /* Expiration time for obstacle detection status. */
#define NO_REPEAT_OBS         -1
#define FIRST_OBSTACLE         0
#define REP_OD_300_DEGREES     300
#define INVALID_POSITION       0x5A5A
#define LAST_ISENSE_VALUE      1
#define ROLLING_AVG_COUNT      250
#define MAX_NUM_ZONES          5    /* Number of zones used in obstacle detection */
#define MAX_RPM_SAMPLES        50   /* Number of samples to track in the Motor RPM Array */
#define MAX_VEL_SAMPLES        10   /* Number of samples to track in the Velocity Array */
#define MAX_LOAD_SAMPLES       250  /* Number of samples to track in the Load Array */
#define MAX_AVG_LOAD_SAMPLES   1000 /* Number of avg load samples to track in the avg load array*/
#define MAX_LOAD               500  /* The maximum load limit */
/*****************************/
#define SEAT_CAL_OBS_DETECT_ZONE    10         /* Zero based index to Zone 11 */

/* Special code for cal_offset to indicate seat calibration mode */
#define CAL_OFFSET_CALIBRATION_CODE   0x8000

#define OBS_DETECT_PERIOD_MS 1

#define OBS_RING_BUF_SIZE 512
//TODO:  Need to make these #defines as configuration values
#define SPEED_THRESHOLD 20
#define INCREASE_DECREASE_TIME 1000

#define HISTORY_WIDTH 60 //*> replaced with G_obs_params.history_width for runtime

/*********************************************************************************************
Private Function declarations
*********************************************************************************************/
static void _obs_check_repeating_od(void);
static INT16U _obs_increment_circ_array_index(INT16U counter, INT16U limit);
static INT16U _obs_decrement_circ_array_index(INT16S counter, INT16U limit);
static void _obs_update_velocity_average();
static void _obs_detect_obstacle();
static BOOL _obs_time_to_detect_obstacle();
static INT16S _obs_calc_modeled_velocity();
static float _obs_calc_adjustment_voltage(float voltage);
static INT16S _obs_get_latest_velocity();
static INT16U _obs_get_zone(INT16S act_position);
static void _obs_clearOBSBuffers();
static INT16S _obs_calcDecreaseLoad(INT16S modeled, INT16S actual, INT32U currentTime);
static INT16S _obs_calcIncreaseLoad(INT16S modeled, INT16S actual, INT32U currentTime);
static INT16S _obs_calcLoad(INT16S modeled, INT16S actual);
static INT32U _obs_calcPointLength(INT32U x1, INT16S y1, INT32U x2, INT16S y2);
void addSpeedAdjust(INT32S speed);
INT32S GetSpeedAdjust();
void ClearSpeedAdjust();

/*********************************************************************************************
 * Author(s):       Abraham Greenwell
 * Description:     When a change of direction occurs, we determine if it is a drop or rise in
 *                  motor behavior, and output that state for a time after the change occurs.
 * Parameters:      currentTime - the current msec timer value.
 * Returns:         INT8S - indicates whether we are steady-state (0), increasing (-1)
 *                          or decreasing (1)
 *********************************************************************************************/
static INT8S _obs_calcDirectionState(INT32U currentTime);

/*********************************************************************************************
Global Variable definitions
*********************************************************************************************/
static float S_current = 0;
static float S_velocity = 0;
static INT16S lastSpeedCommand = 0;
    
static INT16S osb_crnt_ring_buf[OBS_RING_BUF_SIZE];
static INT16U osb_crnt_ring_buf_idx;

/*  Parameter table local copy of scale & offset factors  */
static CFG_OBS_PARAM_TABLE_TYPE G_obs_params;
/* Increasing and decreasing position obstacle detection parameters. */
static CFG_ACT_PARAM_TABLE_TYPE G_params;
static volatile MOTION_DIRECTION G_motion_direction;

static volatile INT32U G_motion_start_time;

/* The number of valid current value samples received since the
   historical data in the ring buffer was flagged as invalid. */
static volatile INT16U G_valid_current_sample_count;

/* Local counter used to track current that exceeds the height. */
static INT16U volatile G_obs_count;

static OBS_DETECT volatile G_obstacle_detected_flag;
static OBS_DETECT volatile G_repeating_obstacle_detected_flag;
/* Indicates that obstacle was detected before motion stopped */
static BOOL volatile G_od_counted;

static INT16S volatile G_repeating_obstacle_counter;
static INT16U volatile G_obs_positions[NUM_REPEATING_OBS];
static volatile MOTION_DIRECTION G_obs_motn_dir;

static INT16S volatile G_slope_thresh;
static INT16S volatile G_slope_width;
static INT16S volatile G_load_limit;
static INT16S volatile G_spike_height;
static INT16U volatile G_spike_width;
static INT16U volatile G_zone; //current zone

/* multi-zone variables */
static INT16S volatile G_cal_offset;
static INT16U G_num_zones;
static MULTI_ZONE_DETECT G_multi_zone_detect;

static INT32S volatile G_vel_samples[MAX_VEL_SAMPLES];
static INT16U G_vel_idx;

static INT32S volatile G_rpm_samples[MAX_RPM_SAMPLES];
static INT16U G_rpm_idx;

static BOOL G_obstacle_detect;

static INT16S G_load[MAX_LOAD_SAMPLES];
static INT16U G_load_idx;

static INT16S G_avg_load[MAX_AVG_LOAD_SAMPLES];
static INT16U G_avg_load_idx;

static INT16S G_measured_velocity = 0;

static INT16S modelSpeedHistory[HISTORY_WIDTH];
static INT16S actualSpeedHistory[HISTORY_WIDTH];
static INT32U modelTimeHistory[HISTORY_WIDTH];
static INT32U actualTimeHistory[HISTORY_WIDTH];
static INT8U modelIndex = 0;
static INT8U actualIndex = 0;

#define ADJUST_SPEED_COUNT 100

static FP32     speedAdjustment;
static INT32U   speedAdjustTiming;

static INT32S adjustSpeedValue[ADJUST_SPEED_COUNT];
static INT32U adjustSpeedTime[ADJUST_SPEED_COUNT];
static INT16U adjustSpeedIndex;

/*****************************/

/*********************************************************************************************
Function definitions
*********************************************************************************************/
/*********************************************************************************************
 * Author(s):    Michael Ansolis
 * Description:  Initialize Obstacle_Detection module.
 * Parameters:   None
 * Returns:      NO_ERROR    - indicates success
 *               ERR_FAILURE - indicates failure
*********************************************************************************************/
ERR_RET obs_init(void)
{
    INT8U historyIndex;
    INT16U idx;
    ERR_RET sys_err;

    /*  Get offset & multiplier values from config module  */
   // sys_err  = cfg_load_parameters( TBL_OD_PARAM, (INT16U*)&G_obs_params);
    //sys_err |= cfg_load_parameters( TBL_ACT_PARAM, (INT16U*)&G_params);

    /* Initialize global variables. */
    G_obstacle_detected_flag = OBS_NOT_DETECTED;
    G_repeating_obstacle_detected_flag = OBS_NOT_DETECTED;
    G_motion_direction = NONE;
    G_motion_start_time = 0;
    G_valid_current_sample_count = 0;
    G_od_counted = FALSE;
    G_repeating_obstacle_counter = NO_REPEAT_OBS;

    G_slope_thresh = 0;
    G_slope_width = 0;
    G_load_limit = 0;
    G_spike_height = 0;
    G_spike_width = 0;
    G_zone = 0; //initialize to zone 1

    G_multi_zone_detect = G_params.multizone_obs;
    G_num_zones = G_params.num_obs_zones;
    G_cal_offset   = 0;

    G_obstacle_detect = TRUE;

    util_memset( &osb_crnt_ring_buf, 0, sizeof(osb_crnt_ring_buf));
    osb_crnt_ring_buf_idx = 0;
    util_memset( &G_vel_samples, 0, sizeof(G_vel_samples));
    G_vel_idx = 0;
    util_memset( &G_rpm_samples, 0, sizeof(G_rpm_samples));
    G_rpm_idx = 0;
    util_memset( &G_load, 0, sizeof(G_load));
    G_load_idx = 0;
    util_memset( &G_avg_load, 0, sizeof(G_avg_load));
    G_avg_load_idx = 0;

    for( idx = NO_REPEAT_OBS + 1; idx < NUM_REPEATING_OBS; idx++ )
    {
        G_obs_positions[idx] = INVALID_POSITION;
    }

    for( historyIndex = 0; historyIndex < G_obs_params.history_width; historyIndex++ )
    {
        modelSpeedHistory[historyIndex] = 0;
        actualSpeedHistory[historyIndex] = 0;
        modelTimeHistory[historyIndex] = 0;
        actualTimeHistory[historyIndex] = 0;
    }
    //initialize the speed adjust values to 0
    for(adjustSpeedIndex = 0; adjustSpeedIndex < ADJUST_SPEED_COUNT; adjustSpeedIndex++) {
        adjustSpeedValue[adjustSpeedIndex] = 0;
        adjustSpeedTime[adjustSpeedIndex] = 0;
    }
    adjustSpeedIndex = 0;
    
    speedAdjustment     = sm_get_speed_adjust();
    speedAdjustTiming   = sm_get_speed_adjust_time();

    return sys_err;
}

/*********************************************************************************************
Author(s):   Kenneth Richards
Description: Stores the ACT calibration offset parameter.
Parameters:  param_id (in)    - the D0 field of the obstacle detection parameter CAN message
             param_value (in) - the value of the calibration offset parameter
Returns:     None
 *********************************************************************************************/
void cal_set_parameter(COMM_PARAM_ID param_id, INT16U param_value)
{
     /* ACT.SRD.APP.205 */
    if (param_id == COMM_PID_CAL_OFFSET)
    {
        /* set the offset from starting point value */
        G_cal_offset = param_value;

        if( CAL_OFFSET_CALIBRATION_CODE == param_value )
        {
            /* If cal offset code, we are in seat calibration and should use a special zone. */
            G_multi_zone_detect = OFF;
            G_zone = SEAT_CAL_OBS_DETECT_ZONE;
        }
        else
        {
            /* If it isn't CAL_OFFSET_CALIBRATION_CODE, it should be a valid cal offset value,
             * so use the multi-zone indication from configuration. */
            G_multi_zone_detect = G_params.multizone_obs;
            G_zone = 0;
        }
    }
}

/*********************************************************************************************
Author(s):   Glenn Racette
             James Pieterick
Description: Stores the ACT obstacle detection configuration parameters.
Parameters:  param_id (in)    - the D0 field of the obstacle detection parameter CAN message
             param_value (in) - the value of the obstacle detection parameter
Returns:     None
History:     JK 5/23/16 - Updated for multi-zone functionality.
 *********************************************************************************************/
void obs_set_parameter(COMM_PARAM_ID param_id, INT16U param_value)
{
    INT32U  crc32;                            /* calculated CRC for the table */
    BOOL not_changed = FALSE;        /* Expect change, unless switch default: */
    BOOL obs_param = FALSE; /* Obstacle param table instead of Actuator param */
    /* ACT.SRD.APP.205 */
    switch (param_id)
    {
        case COMM_PID_POS_SLOPE_THRESH_ZONE1:
            /* set the positive slope threshold for zone 1, also used for single zone */
            G_params.pos_slope_threshold_zone1 = param_value;
            break;
        case COMM_PID_POS_SLOPE_WIDTH_ZONE1:
            /* set the positive slope width for zone 1, also used for single zone */
            G_params.pos_slope_width_zone1 = param_value;
            break;
        case COMM_PID_POS_LOAD_LIMIT_ZONE1:
            /* set the positive load limit for zone 1, also used for single zone */
            G_params.pos_load_limit_zone1 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_THRESH_ZONE1:
            /* set the negative slope threshold for zone 1, also used for single zone */
            G_params.neg_slope_threshold_zone1 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_WIDTH_ZONE1:
            /* set the negative slope width for zone 1, also used for single zone */
            G_params.neg_slope_width_zone1 = param_value;
            break;
        case COMM_PID_NEG_LOAD_LIMIT_ZONE1:
            /* set the negative load limit for zone 1, also used for single zone */
            G_params.neg_load_limit_zone1 = param_value;
            break;
        case COMM_PID_SPIKE_HEIGHT_ZONE1:
            /* set the negative spike height for zone 1, also used for single zone */
            G_params.spike_height_zone1 = param_value;
            break;
        case COMM_PID_SPIKE_WIDTH_ZONE1:
            /* set the negative spike width for zone 1, also used for single zone */
            G_params.spike_width_zone1 = param_value;
            break;
        case COMM_PID_TEMP:
            /* set the motor temperature value */
            G_params.temp = param_value;
            sm_set_max_temp( param_value );
            break;
        case COMM_PID_NUM_OBS_ZONES:
            /* set the number of zones value */
            G_params.num_obs_zones = param_value;
            G_num_zones = param_value;
            break;
        case COMM_PID_MAX_TRAVEL_ZONE1:
            /* set the max travel value for zone 1 */
            G_params.max_travel_zone1 = param_value;
            break;
        case COMM_PID_MAX_TRAVEL_ZONE2:
            /* set the max travel value for zone 2 */
            G_params.max_travel_zone2 = param_value;
            break;
        case COMM_PID_POS_SLOPE_THRESH_ZONE2:
            /* set the positive height for zone 2 */
            G_params.pos_slope_threshold_zone2 = param_value;
            break;
        case COMM_PID_POS_SLOPE_WIDTH_ZONE2:
            /* set the positive width for zone 2 */
            G_params.pos_slope_width_zone2 = param_value;
            break;
        case COMM_PID_POS_LOAD_LIMIT_ZONE2:
            /* set the positive count for zone 2 */
            G_params.pos_load_limit_zone2 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_THRESH_ZONE2:
            /* set the negative height for zone 2 */
            G_params.neg_slope_threshold_zone2 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_WIDTH_ZONE2:
            /* set the negative width for zone 2 */
            G_params.neg_slope_width_zone2 = param_value;
            break;
        case COMM_PID_NEG_LOAD_LIMIT_ZONE2:
            /* set the negative count for zone 2 */
            G_params.neg_load_limit_zone2 = param_value;
            break;
        case COMM_PID_SPIKE_HEIGHT_ZONE2:
            /* set the negative width for zone 2 */
            G_params.spike_height_zone2 = param_value;
            break;
        case COMM_PID_SPIKE_WIDTH_ZONE2:
            /* set the negative width for zone 2 */
            G_params.spike_width_zone2 = param_value;
            break;
        case COMM_PID_MAX_TRAVEL_ZONE3:
            /* set the max travel value for zone 3 */
            G_params.max_travel_zone3 = param_value;
            break;
        case COMM_PID_POS_SLOPE_THRESH_ZONE3:
            /* set the positive height for zone 3 */
            G_params.pos_slope_threshold_zone3 = param_value;
            break;
        case COMM_PID_POS_SLOPE_WIDTH_ZONE3:
            /* set the positive width for zone 3 */
            G_params.pos_slope_width_zone3 = param_value;
            break;
        case COMM_PID_POS_LOAD_LIMIT_ZONE3:
            /* set the positive count for zone 3 */
            G_params.pos_load_limit_zone3 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_THRESH_ZONE3:
            /* set the negative height for zone 3 */
            G_params.neg_slope_threshold_zone3 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_WIDTH_ZONE3:
            /* set the negative width for zone 3 */
            G_params.neg_slope_width_zone3 = param_value;
            break;
        case COMM_PID_NEG_LOAD_LIMIT_ZONE3:
            /* set the negative count for zone 3 */
            G_params.neg_load_limit_zone3 = param_value;
            break;
        case COMM_PID_SPIKE_HEIGHT_ZONE3:
            /* set the negative width for zone 3 */
            G_params.spike_height_zone3 = param_value;
            break;
        case COMM_PID_SPIKE_WIDTH_ZONE3:
            /* set the negative width for zone 3 */
            G_params.spike_width_zone3 = param_value;
            break;
        case COMM_PID_MAX_TRAVEL_ZONE4:
            /* set the max travel value for zone 4 */
            G_params.max_travel_zone4 = param_value;
            break;
        case COMM_PID_POS_SLOPE_THRESH_ZONE4:
            /* set the positive height for zone 4 */
            G_params.pos_slope_threshold_zone4 = param_value;
            break;
        case COMM_PID_POS_SLOPE_WIDTH_ZONE4:
            /* set the positive width for zone 4 */
            G_params.pos_slope_width_zone4 = param_value;
            break;
        case COMM_PID_POS_LOAD_LIMIT_ZONE4:
            /* set the positive count for zone 4 */
            G_params.pos_load_limit_zone4 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_THRESH_ZONE4:
            /* set the negative height for zone 4 */
            G_params.neg_slope_threshold_zone4 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_WIDTH_ZONE4:
            /* set the negative width for zone 4 */
            G_params.neg_slope_width_zone4 = param_value;
            break;
        case COMM_PID_NEG_LOAD_LIMIT_ZONE4:
            /* set the negative count for zone 4 */
            G_params.neg_load_limit_zone4 = param_value;
            break;
        case COMM_PID_SPIKE_HEIGHT_ZONE4:
            /* set the negative width for zone 4 */
            G_params.spike_height_zone4 = param_value;
            break;
        case COMM_PID_SPIKE_WIDTH_ZONE4:
            /* set the negative width for zone 4 */
            G_params.spike_width_zone4 = param_value;
            break;
        case COMM_PID_MAX_TRAVEL_ZONE5:
            /* set the max travel value for zone 5 */
            G_params.max_travel_zone5 = param_value;
            break;
        case COMM_PID_POS_SLOPE_THRESH_ZONE5:
            /* set the positive height for zone 5 */
            G_params.pos_slope_threshold_zone5 = param_value;
            break;
        case COMM_PID_POS_SLOPE_WIDTH_ZONE5:
            /* set the positive width for zone 5 */
            G_params.pos_slope_width_zone5 = param_value;
            break;
        case COMM_PID_POS_LOAD_LIMIT_ZONE5:
            /* set the positive count for zone 5 */
            G_params.pos_load_limit_zone5 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_THRESH_ZONE5:
            /* set the negative height for zone 5 */
            G_params.neg_slope_threshold_zone5 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_WIDTH_ZONE5:
            /* set the negative width for zone 5 */
            G_params.neg_slope_width_zone5 = param_value;
            break;
        case COMM_PID_NEG_LOAD_LIMIT_ZONE5:
            /* set the negative count for zone 5 */
            G_params.neg_load_limit_zone5 = param_value;
            break;
        case COMM_PID_SPIKE_HEIGHT_ZONE5:
            /* set the negative width for zone 5 */
            G_params.spike_height_zone5 = param_value;
            break;
        case COMM_PID_SPIKE_WIDTH_ZONE5:
            /* set the negative width for zone 5 */
            G_params.spike_width_zone5 = param_value;
            break;
        case COMM_PID_MAX_TRAVEL_ZONE6:
            /* set the max travel value for zone 6 */
            G_params.max_travel_zone6 = param_value;
            break;
        case COMM_PID_POS_SLOPE_THRESH_ZONE6:
            /* set the positive height for zone 6 */
            G_params.pos_slope_threshold_zone6 = param_value;
            break;
        case COMM_PID_POS_SLOPE_WIDTH_ZONE6:
            /* set the positive width for zone 6 */
            G_params.pos_slope_width_zone6 = param_value;
            break;
        case COMM_PID_POS_LOAD_LIMIT_ZONE6:
            /* set the positive count for zone 6 */
            G_params.pos_load_limit_zone6 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_THRESH_ZONE6:
            /* set the negative height for zone 6 */
            G_params.neg_slope_threshold_zone6 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_WIDTH_ZONE6:
            /* set the negative width for zone 6 */
            G_params.neg_slope_width_zone6 = param_value;
            break;
        case COMM_PID_NEG_LOAD_LIMIT_ZONE6:
            /* set the negative count for zone 6 */
            G_params.neg_load_limit_zone6 = param_value;
            break;
        case COMM_PID_SPIKE_HEIGHT_ZONE6:
            /* set the negative width for zone 6 */
            G_params.spike_height_zone6 = param_value;
            break;
        case COMM_PID_SPIKE_WIDTH_ZONE6:
            /* set the negative width for zone 6 */
            G_params.spike_width_zone6 = param_value;
            break;
        case COMM_PID_MAX_TRAVEL_ZONE7:
            /* set the max travel value for zone 7 */
            G_params.max_travel_zone7 = param_value;
            break;
        case COMM_PID_POS_SLOPE_THRESH_ZONE7:
            /* set the positive height for zone 7 */
            G_params.pos_slope_threshold_zone7 = param_value;
            break;
        case COMM_PID_POS_SLOPE_WIDTH_ZONE7:
            /* set the positive width for zone 7 */
            G_params.pos_slope_width_zone7 = param_value;
            break;
        case COMM_PID_POS_LOAD_LIMIT_ZONE7:
            /* set the positive count for zone 7 */
            G_params.pos_load_limit_zone7 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_THRESH_ZONE7:
            /* set the negative height for zone 7 */
            G_params.neg_slope_threshold_zone7 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_WIDTH_ZONE7:
            /* set the negative width for zone 7 */
            G_params.neg_slope_width_zone7 = param_value;
            break;
        case COMM_PID_NEG_LOAD_LIMIT_ZONE7:
            /* set the negative count for zone 7 */
            G_params.neg_load_limit_zone7 = param_value;
            break;
        case COMM_PID_SPIKE_HEIGHT_ZONE7:
            /* set the negative width for zone 7 */
            G_params.spike_height_zone7 = param_value;
            break;
        case COMM_PID_SPIKE_WIDTH_ZONE7:
            /* set the negative width for zone 7 */
            G_params.spike_width_zone7 = param_value;
            break;
        case COMM_PID_MAX_TRAVEL_ZONE8:
            /* set the max travel value for zone 8 */
            G_params.max_travel_zone8 = param_value;
            break;
        case COMM_PID_POS_SLOPE_THRESH_ZONE8:
            /* set the positive height for zone 8 */
            G_params.pos_slope_threshold_zone8 = param_value;
            break;
        case COMM_PID_POS_SLOPE_WIDTH_ZONE8:
            /* set the positive width for zone 8 */
            G_params.pos_slope_width_zone8 = param_value;
            break;
        case COMM_PID_POS_LOAD_LIMIT_ZONE8:
            /* set the positive count for zone 8 */
            G_params.pos_load_limit_zone8 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_THRESH_ZONE8:
            /* set the negative height for zone 8 */
            G_params.neg_slope_threshold_zone8 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_WIDTH_ZONE8:
            /* set the negative width for zone 8 */
            G_params.neg_slope_width_zone8 = param_value;
            break;
        case COMM_PID_NEG_LOAD_LIMIT_ZONE8:
            /* set the negative count for zone 8 */
            G_params.neg_load_limit_zone8 = param_value;
            break;
        case COMM_PID_SPIKE_HEIGHT_ZONE8:
            /* set the negative width for zone 8 */
            G_params.spike_height_zone8 = param_value;
            break;
        case COMM_PID_SPIKE_WIDTH_ZONE8:
            /* set the negative width for zone 8 */
            G_params.spike_width_zone8 = param_value;
            break;
        case COMM_PID_MAX_TRAVEL_ZONE9:
            /* set the max travel value for zone 9 */
            G_params.max_travel_zone9 = param_value;
            break;
        case COMM_PID_POS_SLOPE_THRESH_ZONE9:
            /* set the positive height for zone 9 */
            G_params.pos_slope_threshold_zone9 = param_value;
            break;
        case COMM_PID_POS_SLOPE_WIDTH_ZONE9:
            /* set the positive width for zone 9 */
            G_params.pos_slope_width_zone9 = param_value;
            break;
        case COMM_PID_POS_LOAD_LIMIT_ZONE9:
            /* set the positive count for zone 9 */
            G_params.pos_load_limit_zone9 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_THRESH_ZONE9:
            /* set the negative height for zone 9 */
            G_params.neg_slope_threshold_zone9 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_WIDTH_ZONE9:
            /* set the negative width for zone 9 */
            G_params.neg_slope_width_zone9 = param_value;
            break;
        case COMM_PID_NEG_LOAD_LIMIT_ZONE9:
            /* set the negative count for zone 9 */
            G_params.neg_load_limit_zone9 = param_value;
            break;
        case COMM_PID_SPIKE_HEIGHT_ZONE9:
            /* set the negative width for zone 9 */
            G_params.spike_height_zone9 = param_value;
            break;
        case COMM_PID_SPIKE_WIDTH_ZONE9:
            /* set the negative width for zone 9 */
            G_params.spike_width_zone9 = param_value;
            break;
        case COMM_PID_MAX_TRAVEL_ZONE10:
            /* set the max travel value for zone 10 */
            G_params.max_travel_zone10 = param_value;
            break;
        case COMM_PID_POS_SLOPE_THRESH_ZONE10:
            /* set the positive height for zone 10 */
            G_params.pos_slope_threshold_zone10 = param_value;
            break;
        case COMM_PID_POS_SLOPE_WIDTH_ZONE10:
            /* set the positive width for zone 10 */
            G_params.pos_slope_width_zone10 = param_value;
            break;
        case COMM_PID_POS_LOAD_LIMIT_ZONE10:
            /* set the positive count for zone 10 */
            G_params.pos_load_limit_zone10 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_THRESH_ZONE10:
            /* set the negative height for zone 10 */
            G_params.neg_slope_threshold_zone10 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_WIDTH_ZONE10:
            /* set the negative width for zone 10 */
            G_params.neg_slope_width_zone10 = param_value;
            break;
        case COMM_PID_NEG_LOAD_LIMIT_ZONE10:
            /* set the negative count for zone 10 */
            G_params.neg_load_limit_zone10 = param_value;
            break;
        case COMM_PID_SPIKE_HEIGHT_ZONE10:
            /* set the negative width for zone 10 */
            G_params.spike_height_zone10 = param_value;
            break;
        case COMM_PID_SPIKE_WIDTH_ZONE10:
            /* set the negative width for zone 10 */
            G_params.spike_width_zone10 = param_value;
            break;
        case COMM_PID_MAX_TRAVEL_ZONE11:
            /* set the max travel value for zone 11 */
            G_params.max_travel_zone11 = param_value;
            break;
        case COMM_PID_POS_SLOPE_THRESH_ZONE11:
            /* set the positive height for zone 11 */
            G_params.pos_slope_threshold_zone11 = param_value;
            break;
        case COMM_PID_POS_SLOPE_WIDTH_ZONE11:
            /* set the positive width for zone 11 */
            G_params.pos_slope_width_zone11 = param_value;
            break;
        case COMM_PID_POS_LOAD_LIMIT_ZONE11:
            /* set the positive count for zone 11 */
            G_params.pos_load_limit_zone11 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_THRESH_ZONE11:
            /* set the negative height for zone 11 */
            G_params.neg_slope_threshold_zone11 = param_value;
            break;
        case COMM_PID_NEG_SLOPE_WIDTH_ZONE11:
            /* set the negative width for zone 11 */
            G_params.neg_slope_width_zone11 = param_value;
            break;
        case COMM_PID_NEG_LOAD_LIMIT_ZONE11:
            /* set the negative count for zone 11 */
            G_params.neg_load_limit_zone11 = param_value;
            break;
        case COMM_PID_SPIKE_HEIGHT_ZONE11:
            /* set the negative width for zone 11 */
            G_params.spike_height_zone11 = param_value;
            break;
        case COMM_PID_SPIKE_WIDTH_ZONE11:
            /* set the negative width for zone 11 */
            G_params.spike_width_zone11 = param_value;
            break;
        case COMM_PID_ELEC_RESIST:
            obs_param = TRUE;
            G_obs_params.elec_resist = ((FP32)param_value / 1000.0);
            break;
        case COMM_PID_EM_FORCE:
            obs_param = TRUE;
            G_obs_params.em_force = ((FP32)param_value / 100000.0);
            break;
        case COMM_PID_SPEED_MULTI:
            speedAdjustment = ((FP32)param_value / 1000.0);
            break;
        case COMM_PID_SPEED_TIME:
            speedAdjustTiming = param_value;
            break;
        default:
            /* nothing to do */
            not_changed = TRUE;                     /* no tables were changed */
            break;
    }    /* END SWITCH */
    if (not_changed == FALSE)
    {
        /* Update table CRC */
        if (obs_param)                            /* Obstacle parameter table */
        {
         //   crc32new_buffer( &G_obs_params,
            //                 sizeof(G_obs_params) - sizeof(G_obs_params.crc),
              //               &crc32);
          //  G_obs_params.crc = crc32;

        }
        else                                      /* Actuator parameter table */
        {
           // crc32new_buffer( &G_params,
                  //           sizeof(G_params) - sizeof(G_params.crc),
                            // &crc32);
           // G_params.crc = crc32;
        }
    }
}  /* End obs_set_parameter() */


/*********************************************************************************************
Author(s):      Michael Ansolis
Description:    Run the obstacle detection algorithm.
Parameters:     None.
Returns:        None.
**********************************************************************************************/
void obs_isr_check_for_obstacle(void)
{
    /* ACT.SRD.APP.276 */

    /* Update the average velocity array */
    _obs_update_velocity_average();
    G_measured_velocity = _obs_get_latest_velocity();

    /* if the obstacle detection is enabled */
    if(G_obstacle_detect)
    {
        /* Calculate if an obstacle is present */
        _obs_detect_obstacle();
    }

    /* Check for repeating obstacles */
    _obs_check_repeating_od();
}

/*********************************************************************************************
Author(s):      Juan Kuyoc
Description:    Records the current motor speed and rolling average velocity.
Parameters:     None.
Returns:        None.
**********************************************************************************************/
static void _obs_update_velocity_average()
{
    INT32S average_rpm = 0;
    INT32S motor_rpm = 0;
    INT8U i = 0;

    //Get the motor speed from the actuator.c module
    motor_rpm = util_abs(bldc_get_current_RPM());

    //Add the motor speed to the last entry of the motor array
    G_rpm_samples[G_rpm_idx] = motor_rpm;

    //Add up all of the entries in the 'motor' array
    for(i = 0; i < MAX_RPM_SAMPLES; i++)
    {
        average_rpm += G_rpm_samples[i];
    }

    //Divide by the number of entries to get the average value
    average_rpm /= MAX_RPM_SAMPLES;

    //Add the average rpm to the last entry in the 'velocity' array
    G_vel_samples[G_vel_idx] = average_rpm;

    //Increment the 'motor' array index
    G_rpm_idx = _obs_increment_circ_array_index(G_rpm_idx, MAX_RPM_SAMPLES);

    //Increment the 'average velocity' array index
    G_vel_idx = _obs_increment_circ_array_index(G_vel_idx, MAX_VEL_SAMPLES);
}

/*********************************************************************************************
Author(s):      Juan Kuyoc
Description:    Calculates the average load.
Parameters:     load - The current load.
Returns:        INT16S - The average load
**********************************************************************************************/
INT16S _obs_calc_avg_load(INT16S load)
{
    INT32S average_load = 0;
    INT16U i = 0;

    //Quadruple the load to improve accuracy
    load = load * 4;

    //Add the latest load to the load array
    G_load[G_load_idx] = load;

    //Add up all of the entries of the load array
    for(i = 0; i < MAX_LOAD_SAMPLES; i++)
    {
        average_load += G_load[i];
    }

    //Divide by the number of entries in the array
    average_load /= MAX_LOAD_SAMPLES;

    //Add the average value to the average load array
    G_avg_load[G_avg_load_idx] = average_load;

    //increment the load array index
    G_load_idx = _obs_increment_circ_array_index(G_load_idx, MAX_LOAD_SAMPLES);

    //increment the average load array index
    G_avg_load_idx = _obs_increment_circ_array_index(G_avg_load_idx, MAX_AVG_LOAD_SAMPLES);

    return average_load;
}

INT16S _obs_calc_slope()
{
    INT16S latest_load_idx = 0;
    INT16S previous_load_idx = 0;
    INT16S slope = 0;

    //Calculate the index of the latest load
    latest_load_idx = _obs_decrement_circ_array_index(G_avg_load_idx, MAX_AVG_LOAD_SAMPLES);

    //calculate the index of the load width ago
    previous_load_idx = G_avg_load_idx - (INT16U)G_slope_width - 1;

    //if we are looking before the beginning index of the array, adjust the
    //index appropriately
    if( previous_load_idx < 0)
    {
        previous_load_idx = previous_load_idx + MAX_AVG_LOAD_SAMPLES;
    }

    //calculate the difference
    slope = G_avg_load[latest_load_idx] - G_avg_load[previous_load_idx];

    return slope;
}

/*********************************************************************************************
Author(s):      Juan Kuyoc
Description:    Detects an obstacle based on the area between the velocity limit and actual
                velocity.
Parameters:     None.
Returns:        None.
**********************************************************************************************/
static void _obs_detect_obstacle()
{
    /* ACT.SRD.APP.284 */
    static INT16S S_passenger_load = 0;
    static INT32S debugPassengerLoad = 0;
    static INT32S debugAdjustedPassLoad = 0;
    static INT16U S_spike_count = 0;
    INT16S modeled_velocity = 0;
//    INT16S rawVelocity = 0;
    INT16S velocity = 0;
    INT16S load = 0;
    INT32S avg_load = 0;
    INT16S slope = 0;
    INT32S object_load = 0;
    static INT16S oldCommandVelocity;
//    static BOOL speedAdjustFlag = FALSE;
    static BOOL lastTimeToDetectObstacle = TRUE;
    
    //get the commanded speed
    INT16S commandedVelocity = util_abs(motn_get_command_speed());
    
    //Get the modeled speed
    modeled_velocity = _obs_calc_modeled_velocity();
    //modeled_velocity -= commandedVelocity;
    //adjust the modeled velocity with the commanded speed
    
    
    //Get the latest raw velocity
    velocity = _obs_get_latest_velocity();
    //velocity = rawVelocity - commandedVelocity;
    //adjust the actual velocity with the commanded speed
    
    G_measured_velocity = velocity;
    
    INT32S speedDiff = 0;
    if(commandedVelocity != oldCommandVelocity) 
    {
        speedDiff = (commandedVelocity - oldCommandVelocity) * speedAdjustment;
        //if our speed change is substantial
        if(speedDiff != 0)
            addSpeedAdjust(util_abs(speedDiff));
    }
    
    oldCommandVelocity = commandedVelocity;
    if(commandedVelocity == 0) {
        ClearSpeedAdjust();
    }
    //if the velocity is zero
    if( velocity == 0 )
    {
        velocity = 0;
        //set the modeled velocity to zero
        modeled_velocity = 0;
        //clear the modeled current variable
        S_current = 0;
        //clear the modeled velocity variable
        S_velocity = 0;
    }

    INT32S adjustedLoad = _obs_calcLoad(modeled_velocity,velocity);

    //Add the load to the load array
    load = adjustedLoad;

    //Get the average load
    avg_load = _obs_calc_avg_load(load);

    //Get the time to detect flag
    BOOL timeToDetect = _obs_time_to_detect_obstacle();
    
    //if there is a rising edge on the timeToDetect signal
    if( timeToDetect && ( lastTimeToDetectObstacle == FALSE )) {
        //set the slope to 0
        slope = 0;
    //Any other time
    } else {
        //Calculate the slope value
        slope = _obs_calc_slope();
    }
    //Update the lastTimeToDetect
    lastTimeToDetectObstacle = timeToDetect;
    

    if((slope < G_slope_thresh) && (slope > -G_slope_thresh))
    {
        //set the passenger load to the average load
        S_passenger_load = avg_load;
        debugPassengerLoad = avg_load;
        debugAdjustedPassLoad = avg_load;
    }
    //if the speedAdjust is positive
    if(GetSpeedAdjust() > 0) {
        //add it to the passenger load
        debugAdjustedPassLoad = debugPassengerLoad  + GetSpeedAdjust();
    }   
      
    if(slope > G_spike_height)
    {
        if (S_spike_count < MAX_INT16U)
        {
            S_spike_count++;
        }
    }
    else
    {
        S_spike_count = 0;
    }

    object_load = avg_load - debugAdjustedPassLoad;

    //if its time to check for obstacles and the speed is non-zero
    if(timeToDetect && (commandedVelocity != 0))
    {
        /* ACT.SRD.APP.278,279,288,289,,290,291 */
        /* The same check is used whether or not multi-zone is off. If multi-
         * zone is on, the variable values being compared will reflect that
         * due to assignments in obs_set_commanded_direction */
        //if object load is gte Load Limit or spike counter gte spike width
        if((object_load >= (G_load_limit)) || (S_spike_count >= G_spike_width))
        {
            //Set obstacle flag
            G_obstacle_detected_flag = OBS_DETECTED;
        }
    }
    else
    {
        S_spike_count = 0;
    }
    //comm_update_debug(avg_load, object_load, debugAdjustedPassLoad, G_obstacle_detected_flag, 
           // G_zone, debugPassengerLoad, GetSpeedAdjust(), slope);
    
    //comm_update_debug2(G_measured_velocity, modeled_velocity, S_spike_count, G_spike_width, timeToDetect, G_slope_thresh);
}
//Calculates the load based on the modeled and actual speeds
//If we are ascending or descending, the modeled speed doesn't follow well, so
//we need to measure to the closest point, not the vertical distance.
static INT16S _obs_calcLoad(INT16S modeled, INT16S actual)
{
    INT32U currentTime = tmgr_get_system_time();
    //Store the last 60 data points
    //Calculate the modeled speed, add to the model history
    modelSpeedHistory[modelIndex] = modeled;
    modelTimeHistory[modelIndex] = currentTime;
    modelIndex++;
    if(modelIndex >= G_obs_params.history_width)
    {
        modelIndex = 0;
    }

    //Calculate the actual speed, add to the actual history
    actualSpeedHistory[actualIndex] = actual;
    actualTimeHistory[actualIndex] = currentTime;
    actualIndex++;
    if(actualIndex >= G_obs_params.history_width)
    {
        actualIndex = 0;
    }

    INT16S adjustedLoad;
    INT8S dir = _obs_calcDirectionState(currentTime);
    switch(dir) {
        case 1:    //if we are decreasing
            adjustedLoad = _obs_calcIncreaseLoad(modeled, actual, currentTime);
            break;
        case 0:     //if we steady state
            adjustedLoad = modeled - actual;
            break;
        case -1:     //if we are increasing
            adjustedLoad = _obs_calcDecreaseLoad(modeled, actual, currentTime);
            break;
        default:
            adjustedLoad = modeled - actual;
            break;
    }
    return adjustedLoad;
}

//    Notes
//        Calculates the difference between two points
//        Distance is returned squared, to reduce computations during square root
//        Inputs
//            x1
//            y1
//            x2
//            y2
static INT32U _obs_calcPointLength(INT32U x1, INT16S y1, INT32U x2, INT16S y2)
{
    //Calc xTravel (x2 - x1)
    INT32U xTravel = x2 - x1;
    //Calc yTravel (y2-y1)
    INT32S yTravel = y2 - y1;
    //Calc and return distance (xTravel*xTravel + yTravel*yTravel)
    return (xTravel * xTravel + (INT32U)(yTravel * yTravel));
}

/*********************************************************************************************
 * Author(s):       Abraham Greenwell
 * Description:     When a change of direction occurs, we determine if it is a drop or rise in
 *                  motor behavior, and output that state for a time after the change occurs.
 * Parameters:      currentTime - the current msec timer value.
 * Returns:         INT8S - indicates whether we are steady-state (0), increasing (-1)
 *                          or decreasing (1)
 *********************************************************************************************/
static INT8S _obs_calcDirectionState(INT32U currentTime)
{
    static INT8S savedDirection = 0;
    static INT32U timeout = 0;
    
    INT8U dir = 0;
    INT16S speedCommand;
    INT16S speedChange;
    
    speedCommand = motn_get_command_speed();
    speedChange = speedCommand - lastSpeedCommand;
    
    /* If we have a speed change */
    if(speedCommand != lastSpeedCommand)
    {
        //If the magnitude of the speed change is over the threshold */
        if(util_abs(speedChange) > G_obs_params.speed_threshold)
        {
            /* Update timeout to current time + timeout amount, and set
             * the savedDirection to 1 */
            timeout = currentTime + G_obs_params.increase_decrease_time;
            savedDirection = 1;
            
            /* If the speed change is positive and the command is negative, OR
             * if the speed change is negative and the speed is positive, then
             * set the saveDirection to -1
             */
            if(((speedChange > 0) && (speedCommand < 0)) || ((speedChange < 0) && (speedCommand > 0)))
            {
                savedDirection = -1;
            }
        }
    }
    
    /* Update the last speed with the current speed */
    lastSpeedCommand = speedCommand;
    
    /* If we are within timeout, set the direction to the savedDirection */
    if(currentTime <= timeout)
    {
        dir = savedDirection;
    }
    
    return dir;
}

//depending if the model or the actual value is higher, we look through the history
//and find the closest point to where we are at from the history.
static INT16S _obs_calcIncreaseLoad(INT16S modeled, INT16S actual, INT32U currentTime)
{
    //Create a minDistance, set to 65535
    INT32S minDistance = 0x7FFFFFFF;
    //If the model is below the actual
    if(modeled < actual) {
        //Loop through the actual history
        INT8U historyIndex;
        for(historyIndex = 0; historyIndex < G_obs_params.history_width; historyIndex++)
        {
            //Calculate distance between current model point to actual point
            INT32U distance = _obs_calcPointLength(currentTime, modeled, actualTimeHistory[historyIndex], actualSpeedHistory[historyIndex]);
            //If the distance is less than the minDistance
            if(distance < minDistance) {
                //set minDistance to currentDistance
                minDistance = distance;
            }
        }
        //set minDistance to -sqrt(minDistance)
        minDistance = -util_sqrt(minDistance);
    //If the actual is below the model
    }
    else
    {
        //Loop through the model History
        INT8U historyIndex;
        for(historyIndex = 0; historyIndex < G_obs_params.history_width; historyIndex++)
        {
            //Calculate distance between current actual point to model point from list
            INT32U distance = _obs_calcPointLength(currentTime, actual, modelTimeHistory[historyIndex], modelSpeedHistory[historyIndex]);
            //If the distance is less than the minDistance
            if(distance < minDistance) {
                //set minDistance to currentDistance
                minDistance = distance;
            }
        }
        //set minDistance to sqrt(minDistance)
        minDistance = util_sqrt(minDistance);
    }
    //Set load to minDistance
    return(minDistance);
}
//depending if the model or the actual value is higher, we look through the history
//and find the closest point to where we are at from the history.  Very similar
//to increase, except the test condition (modeled vs actual) is flipped
//and our final evaluation (minDistance) is flipped.
static INT16S _obs_calcDecreaseLoad(INT16S modeled, INT16S actual, INT32U currentTime) {
    //Create a minDistance, set to 65535
    INT32S minDistance = 0x7FFFFFFF;
    //If the model is below the actual
    if(modeled > actual) {
        //Loop through the actual history
        INT8U historyIndex;
        for(historyIndex = 0; historyIndex < G_obs_params.history_width; historyIndex++)
        {
            //Calculate distance between current model point to actual point
            INT32U distance = _obs_calcPointLength(currentTime, modeled, actualTimeHistory[historyIndex], actualSpeedHistory[historyIndex]);
            //If the distance is less than the minDistance
            if(distance < minDistance) {
                //set minDistance to currentDistance
                minDistance = distance;
            }
        }
        //set minDistance to -sqrt(minDistance)
        minDistance = util_sqrt(minDistance);
    //If the actual is below the model
    } else {
        //Loop through the model History
        INT8U historyIndex;
        for(historyIndex = 0; historyIndex < G_obs_params.history_width; historyIndex++)
        {
            //Calculate distance between current actual point to model point from list
            INT32U distance = _obs_calcPointLength(currentTime, actual, modelTimeHistory[historyIndex], modelSpeedHistory[historyIndex]);
            //If the distance is less than the minDistance
            if(distance < minDistance) {
                //set minDistance to currentDistance
                minDistance = distance;
            }
        }
        //set minDistance to sqrt(minDistance)
        minDistance = -util_sqrt(minDistance);
    }
    //Set load to minDistance
    return(minDistance);
}
/*********************************************************************************************
Author(s):      Juan Kuyoc
Description:    Returns the last recorded velocity.
Parameters:     None.
Returns:        INT16S - The last recorded velocity.
**********************************************************************************************/
static INT16S _obs_get_latest_velocity()
{
    INT16S latest_velocity = 0;

    latest_velocity = G_vel_idx - 1;

    //if the latest velocity is at the end of the circular buffer
    if (latest_velocity < 0 )
    {
        latest_velocity = MAX_VEL_SAMPLES - 1;
    }

    return G_vel_samples[latest_velocity];
}

/*********************************************************************************************
Author(s):      Juan Kuyoc
Description:    Calculates modeled velocity based on the commanded voltage.
Parameters:     None.
Returns:        INT16S - The modeled velocity.
**********************************************************************************************/
static INT16S _obs_calc_modeled_velocity()
{
    /* ACT.SRD.APP.285 */

    INT16S modeled_velocity = 0;
    float voltage = 0;
    float adjusted_voltage = 0;
    float didt = 0;
    float dvdt = 0;

    //Get the voltage the actuator is using
    voltage = pwm_get_command_voltage();

    //Calculate the di/dt
    didt = (voltage - (G_obs_params.elec_resist * S_current) - (G_obs_params.em_force * S_velocity))/ G_obs_params.elec_induct;

    //Calculate current
    S_current += didt;

    //Calculate dv/dt
    dvdt = ((G_obs_params.motor_torque * S_current) - (G_obs_params.mvf * S_velocity)) / G_obs_params.motor_inertia;

    //Calculate v
    S_velocity += dvdt;

    adjusted_voltage = _obs_calc_adjustment_voltage(voltage);

    modeled_velocity = (INT16S)(S_velocity - adjusted_voltage);

    return modeled_velocity;
}

/*********************************************************************************************
Author(s):      Abraham Greenwell
Description:    Sets obstacle model parameters.
Parameters:     index - which parameter to set
                value - the value to set it to
Returns:        None.
**********************************************************************************************/
void obsSetModelParam(INT8U index, FP32 value)
{
    switch(index)
    {
        case 0:
            G_obs_params.elec_resist = value;
            break;
        case 1:
            G_obs_params.em_force = value;
            break;
        case 2:
            G_obs_params.elec_induct = value;
            break;
        case 3:
            G_obs_params.motor_torque = value;
            break;
        case 4:
            G_obs_params.mvf = value;
            break;
        case 5:
            G_obs_params.motor_inertia = value;
            break;
        default:
            break;
    }
}

/*********************************************************************************************
Author(s):      Juan Kuyoc
Description:    Calculates an adjusted voltage based on the commanded voltage.
Parameters:     voltage - The commanded voltage.
Returns:        float - The adjusted voltage.
**********************************************************************************************/
static float _obs_calc_adjustment_voltage(float voltage)
{
    //Setup the variables for the linear calculation
    float slope = 0;
    float intercept = 0;
    float adjusted_voltage = 0;

    //Calculate the slope m = (y2-y1)/(x2-x1)
    slope = (G_obs_params.y2 - G_obs_params.y1) / (G_obs_params.x2 - G_obs_params.x1);

    //Calculate the y-offset b = y2-m * x2
    intercept = G_obs_params.y2 - (slope * G_obs_params.x2);

    //Calculate the increasing slope value y = m * commandRPM + b
    adjusted_voltage = (slope * voltage) + intercept;

    return adjusted_voltage;
}

/*********************************************************************************************
Author(s):      Juan Kuyoc
Description:    Checks to see if it is time to detect obstacles.
Parameters:     None.
Returns:        TRUE - Returned if there has been no obstacle detected and
                       the motor is in motion after the ramp time.
                FALSE - Returned if an obstacle was detected, there is no
                        motion, or the ramp time has not been met.
**********************************************************************************************/
static BOOL _obs_time_to_detect_obstacle()
{
    BOOL returnValue;
    INT32U time_now = 0;

    time_now = tmgr_get_system_time();

    if ( (time_now >= (G_motion_start_time + G_obs_params.motor_ramp_time)) &&
         (G_obstacle_detected_flag != OBS_DETECTED)                         &&
         (G_motion_direction != NONE) )
    {
        returnValue = TRUE;
    }
    else
    {
        returnValue = FALSE;
    }

    return returnValue;
}

/*********************************************************************************************
Author(s):      Juan Kuyoc
Description:    Decrements the index to a circular buffer/array.
Parameters:     counter - the index of a circular buffer/array.
                limit - the size of a circular buffer/array.
Returns:        INT16U - the new index value of the buffer/array.
**********************************************************************************************/
static INT16U _obs_decrement_circ_array_index(INT16S counter, INT16U limit)
{
    counter--;
    if(counter < 0)
    {
        counter = limit - 1;
    }

    return counter;
}

/*********************************************************************************************
Author(s):      Juan Kuyoc
Description:    Increments the index to a circular buffer/array.
Parameters:     counter - the index of a circular buffer/array.
                limit - the size of a circular buffer/array.
Returns:        INT16U - the new index value of the buffer/array.
**********************************************************************************************/
INT16U _obs_increment_circ_array_index(INT16U counter, INT16U limit)
{
    counter++;
    if(counter >= limit)
        counter = 0;

    return counter;
}

/*********************************************************************************************
Author(s):      Michael Ansolis
Description:    Check for repeating obstacle detection.
Parameters:     None.
Returns:        None.
**********************************************************************************************/
static void _obs_check_repeating_od(void)
{
    /* ACT.SRD.APP.277 */

    BOOL repeating_od = FALSE;
    INT16U idx = 0;

    /* Make sure G_repeating_obstacle_counter is not incremented until
       the speed direction changes or a zero-speed command is received. */
    if( G_obstacle_detected_flag == OBS_DETECTED &&
        !G_od_counted )
    {
        G_repeating_obstacle_counter++;
        G_od_counted = TRUE;

        /* Store the position of the obstacle */
        G_obs_positions[G_repeating_obstacle_counter] = psn_get_latest_position();
        G_obs_motn_dir = G_motion_direction;

        /* ACT.SRD.APP.292 */
        /* Check we have reached 5 obstacles within the configurable
         * tolerance of each other, we have a repeating obstacle. */
        if( G_repeating_obstacle_counter == NUM_REPEATING_OBS - 1 )
        {
            repeating_od = TRUE;
            for( idx = FIRST_OBSTACLE + 1; idx < NUM_REPEATING_OBS; idx++ )
            {
                if( (INT16U)( util_abs( (INT16S)G_obs_positions[FIRST_OBSTACLE] - (INT16S)G_obs_positions[idx] ) ) >
                    G_obs_params.position_delta )
                {
                    repeating_od = FALSE;
                    break;
                }
            }
        }

        if( repeating_od )
        {
            G_repeating_obstacle_detected_flag = OBS_DETECTED;
            G_repeating_obstacle_counter = NO_REPEAT_OBS;
        }

    }
}

/*********************************************************************************************
 * Author(s):      Juan Kuyoc
 * Description:    This function performs multi-zone detection
 * Parameters:     act_position - The current position of the actuator.
 * Returns:        INT16U - The zone the actuator is in.
**********************************************************************************************/
/*get_zone will search through and assign a zone based on the following:
------------------------------------------------------------------------
           z1max      z2max      z3max      z4max      z5max
  |          |          |          |          |          |
  |  zone 1  |  zone 2  |  zone 3  |  zone 4  |  zone 5  |
  |          |          |          |          |          |
*/
INT16U _obs_get_zone(INT16S act_position)
{
    /* Start with zone 1.  If multi-zone is disabled, zone 1 will be used. */
    INT16U index = 0;

    /* Multi-zone is enabled */
    if ( G_multi_zone_detect == ON )
    {
        if( ( act_position <= G_params.max_travel_zone1 ) )
        {
            index = 0;
        }
        else if( ( G_num_zones > 1 ) &&
            ( act_position >  G_params.max_travel_zone1 ) &&
            ( act_position <= G_params.max_travel_zone2 ) )
        {
            index = 1;
        }
        else if( ( G_num_zones > 2 ) &&
            ( act_position >  G_params.max_travel_zone2 ) &&
            ( act_position <= G_params.max_travel_zone3 ) )
        {
            index = 2;
        }
        else if( ( G_num_zones > 3 ) &&
            ( act_position >  G_params.max_travel_zone3 ) &&
            ( act_position <= G_params.max_travel_zone4 ) )
        {
            index = 3;
        }
        else if( ( G_num_zones > 4 ) &&
            ( act_position >  G_params.max_travel_zone4 ) &&
            ( act_position <= G_params.max_travel_zone5 ) )
        {
            index = 4;
        }
        else if( ( G_num_zones > 5 ) &&
            ( act_position >  G_params.max_travel_zone5 ) &&
            ( act_position <= G_params.max_travel_zone6 ) )
        {
            index = 5;
        }
        else if( ( G_num_zones > 6 ) &&
            ( act_position >  G_params.max_travel_zone6 ) &&
            ( act_position <= G_params.max_travel_zone7 ) )
        {
            index = 6;
        }
        else if( ( G_num_zones > 7 ) &&
            ( act_position >  G_params.max_travel_zone7 ) &&
            ( act_position <= G_params.max_travel_zone8 ) )
        {
            index = 7;
        }
        else if( ( G_num_zones > 8 ) &&
            ( act_position >  G_params.max_travel_zone8 ) &&
            ( act_position <= G_params.max_travel_zone9 ) )
        {
            index = 8;
        }
        else if( ( G_num_zones > 9 ) &&
            ( act_position >  G_params.max_travel_zone9 ) &&
            ( act_position <= G_params.max_travel_zone10 ) )
        {
            index = 9;
        }
        /* If the actuator position is beyond the max travel zone, use zone 1 */
        else
        {
            index = 0;
        }

        if( CAL_OFFSET_CALIBRATION_CODE == G_cal_offset )
        {
            index = SEAT_CAL_OBS_DETECT_ZONE;
        }
    }  /* End if multi zone enabled */

    return index;
}

/*********************************************************************************************
Author(s):      Michael Ansolis
Description:    Check if repeating obstacle detection positions can be cleared.
Parameters:     None.
Returns:        None.
**********************************************************************************************/
void obs_exec( void )
{
    /* ACT.SRD.APP.286 */

    INT16S act_position = 0;
    BOOL obs_cleared = FALSE;
    INT16U idx;

    /* Calculate the latest position */
    psn_calc_position();

    if ((G_multi_zone_detect == ON))
    {
        /* Get the actuator position and then integrate the offset to ensure
           the actuator position is always in range */
        act_position = ((INT16S)psn_get_latest_position());
        act_position = (act_position - G_cal_offset + MAX_ENC_RANGE) % MAX_ENC_RANGE;
        G_zone = _obs_get_zone(act_position);
    }
    else
    {
        G_zone = ( CAL_OFFSET_CALIBRATION_CODE == G_cal_offset )
               ? SEAT_CAL_OBS_DETECT_ZONE : 0;
    }

    /* Determine if the position is increasing or decreasing
       and use the pos or neg parameters structures as appropriate. */
    if (G_motion_direction == POSITIVE)
    {
        if (G_zone == 0)
        {
            G_slope_thresh = G_params.pos_slope_threshold_zone1;
            G_slope_width  = G_params.pos_slope_width_zone1;
            G_load_limit   = G_params.pos_load_limit_zone1;
            G_spike_height = G_params.spike_height_zone1;
            G_spike_width  = G_params.spike_width_zone1;
        }
        else if (G_zone == 1)
        {
            G_slope_thresh = G_params.pos_slope_threshold_zone2;
            G_slope_width  = G_params.pos_slope_width_zone2;
            G_load_limit   = G_params.pos_load_limit_zone2;
            G_spike_height = G_params.spike_height_zone2;
            G_spike_width  = G_params.spike_width_zone2;
        }
        else if (G_zone == 2)
        {
            G_slope_thresh = G_params.pos_slope_threshold_zone3;
            G_slope_width  = G_params.pos_slope_width_zone3;
            G_load_limit   = G_params.pos_load_limit_zone3;
            G_spike_height = G_params.spike_height_zone3;
            G_spike_width  = G_params.spike_width_zone3;
        }
        else if (G_zone == 3)
        {
            G_slope_thresh = G_params.pos_slope_threshold_zone4;
            G_slope_width  = G_params.pos_slope_width_zone4;
            G_load_limit   = G_params.pos_load_limit_zone4;
            G_spike_height = G_params.spike_height_zone4;
            G_spike_width  = G_params.spike_width_zone4;
        }
        else if (G_zone == 4)
        {
            G_slope_thresh = G_params.pos_slope_threshold_zone5;
            G_slope_width  = G_params.pos_slope_width_zone5;
            G_load_limit   = G_params.pos_load_limit_zone5;
            G_spike_height = G_params.spike_height_zone5;
            G_spike_width  = G_params.spike_width_zone5;
        }
        else if (G_zone == 5)
        {
            G_slope_thresh = G_params.pos_slope_threshold_zone6;
            G_slope_width  = G_params.pos_slope_width_zone6;
            G_load_limit   = G_params.pos_load_limit_zone6;
            G_spike_height = G_params.spike_height_zone6;
            G_spike_width  = G_params.spike_width_zone6;
        }
        else if (G_zone == 6)
        {
            G_slope_thresh = G_params.pos_slope_threshold_zone7;
            G_slope_width  = G_params.pos_slope_width_zone7;
            G_load_limit   = G_params.pos_load_limit_zone7;
            G_spike_height = G_params.spike_height_zone7;
            G_spike_width  = G_params.spike_width_zone7;
        }
        else if (G_zone == 7)
        {
            G_slope_thresh = G_params.pos_slope_threshold_zone8;
            G_slope_width  = G_params.pos_slope_width_zone8;
            G_load_limit   = G_params.pos_load_limit_zone8;
            G_spike_height = G_params.spike_height_zone8;
            G_spike_width  = G_params.spike_width_zone8;
        }
        else if (G_zone == 8)
        {
            G_slope_thresh = G_params.pos_slope_threshold_zone9;
            G_slope_width  = G_params.pos_slope_width_zone9;
            G_load_limit   = G_params.pos_load_limit_zone9;
            G_spike_height = G_params.spike_height_zone9;
            G_spike_width  = G_params.spike_width_zone9;
        }
        else if (G_zone == 9)
        {
            G_slope_thresh = G_params.pos_slope_threshold_zone10;
            G_slope_width  = G_params.pos_slope_width_zone10;
            G_load_limit   = G_params.pos_load_limit_zone10;
            G_spike_height = G_params.spike_height_zone10;
            G_spike_width  = G_params.spike_width_zone10;
        }
        else if (G_zone == SEAT_CAL_OBS_DETECT_ZONE)
        {
            G_slope_thresh = G_params.pos_slope_threshold_zone11;
            G_slope_width  = G_params.pos_slope_width_zone11;
            G_load_limit   = G_params.pos_load_limit_zone11;
            G_spike_height = G_params.spike_height_zone11;
            G_spike_width  = G_params.spike_width_zone11;
        }
        else
        {
            G_slope_thresh = G_params.pos_slope_threshold_zone1;
            G_slope_width  = G_params.pos_slope_width_zone1;
            G_load_limit   = G_params.pos_load_limit_zone1;
            G_spike_height = G_params.spike_height_zone1;
            G_spike_width  = G_params.spike_width_zone1;
        }
    }
    else if (G_motion_direction == NEGATIVE)
    {
        if (G_zone == 0)
        {
            G_slope_thresh = G_params.neg_slope_threshold_zone1;
            G_slope_width  = G_params.neg_slope_width_zone1;
            G_load_limit   = G_params.neg_load_limit_zone1;
            G_spike_height = G_params.spike_height_zone1;
            G_spike_width  = G_params.spike_width_zone1;
        }
        else if (G_zone == 1)
        {
            G_slope_thresh = G_params.neg_slope_threshold_zone2;
            G_slope_width  = G_params.neg_slope_width_zone2;
            G_load_limit   = G_params.neg_load_limit_zone2;
            G_spike_height = G_params.spike_height_zone2;
            G_spike_width  = G_params.spike_width_zone2;
        }
        else if (G_zone == 2)
        {
            G_slope_thresh = G_params.neg_slope_threshold_zone3;
            G_slope_width  = G_params.neg_slope_width_zone3;
            G_load_limit   = G_params.neg_load_limit_zone3;
            G_spike_height = G_params.spike_height_zone3;
            G_spike_width  = G_params.spike_width_zone3;
        }
        else if (G_zone == 3)
        {
            G_slope_thresh = G_params.neg_slope_threshold_zone4;
            G_slope_width  = G_params.neg_slope_width_zone4;
            G_load_limit   = G_params.neg_load_limit_zone4;
            G_spike_height = G_params.spike_height_zone4;
            G_spike_width  = G_params.spike_width_zone4;
        }
        else if (G_zone == 4)
        {
            G_slope_thresh = G_params.neg_slope_threshold_zone5;
            G_slope_width  = G_params.neg_slope_width_zone5;
            G_load_limit   = G_params.neg_load_limit_zone5;
            G_spike_height = G_params.spike_height_zone5;
            G_spike_width  = G_params.spike_width_zone5;
        }
        else if (G_zone == 5)
        {
            G_slope_thresh = G_params.neg_slope_threshold_zone6;
            G_slope_width  = G_params.neg_slope_width_zone6;
            G_load_limit   = G_params.neg_load_limit_zone6;
            G_spike_height = G_params.spike_height_zone6;
            G_spike_width  = G_params.spike_width_zone6;
        }
        else if (G_zone == 6)
        {
            G_slope_thresh = G_params.neg_slope_threshold_zone7;
            G_slope_width  = G_params.neg_slope_width_zone7;
            G_load_limit   = G_params.neg_load_limit_zone7;
            G_spike_height = G_params.spike_height_zone7;
            G_spike_width  = G_params.spike_width_zone7;
        }
        else if (G_zone == 7)
        {
            G_slope_thresh = G_params.neg_slope_threshold_zone8;
            G_slope_width  = G_params.neg_slope_width_zone8;
            G_load_limit   = G_params.neg_load_limit_zone8;
            G_spike_height = G_params.spike_height_zone8;
            G_spike_width  = G_params.spike_width_zone8;
        }
        else if (G_zone == 8)
        {
            G_slope_thresh = G_params.neg_slope_threshold_zone9;
            G_slope_width  = G_params.neg_slope_width_zone9;
            G_load_limit   = G_params.neg_load_limit_zone9;
            G_spike_height = G_params.spike_height_zone9;
            G_spike_width  = G_params.spike_width_zone9;
        }
        else if (G_zone == 9)
        {
            G_slope_thresh = G_params.neg_slope_threshold_zone10;
            G_slope_width  = G_params.neg_slope_width_zone10;
            G_load_limit   = G_params.neg_load_limit_zone10;
            G_spike_height = G_params.spike_height_zone10;
            G_spike_width  = G_params.spike_width_zone10;
        }
        else if (G_zone == SEAT_CAL_OBS_DETECT_ZONE)
        {
            G_slope_thresh = G_params.neg_slope_threshold_zone11;
            G_slope_width  = G_params.neg_slope_width_zone11;
            G_load_limit   = G_params.neg_load_limit_zone11;
            G_spike_height = G_params.spike_height_zone11;
            G_spike_width  = G_params.spike_width_zone11;
        }
        else
        {
            G_slope_thresh = G_params.neg_slope_threshold_zone1;
            G_slope_width  = G_params.neg_slope_width_zone1;
            G_load_limit   = G_params.neg_load_limit_zone1;
            G_spike_height = G_params.spike_height_zone1;
            G_spike_width  = G_params.spike_width_zone1;
        }
    }

    /* Obstacle Detect Periodic */
    obs_isr_check_for_obstacle();

    /* Only need to check if an obstacle has been recorded */
    if( G_repeating_obstacle_counter > NO_REPEAT_OBS )
    {

        /* Check if have advanced past the original obstacle
         * (beyond a configurable tolerance) */
        if( ( G_motion_direction == G_obs_motn_dir ) &&
            ( (INT16U)( util_abs( (INT16S)psn_get_latest_position() - (INT16S)G_obs_positions[FIRST_OBSTACLE] ) ) >
              G_obs_params.position_delta ) )
        {
            obs_cleared = TRUE;
        }

        /* Check if we have moved >300degrees away from the original obstacle */
        if( ( G_motion_direction != G_obs_motn_dir ) &&
            ( (INT16U)( util_abs( (INT16S)psn_get_latest_position() - (INT16S)G_obs_positions[FIRST_OBSTACLE] ) ) > REP_OD_300_DEGREES ) )
        {
            obs_cleared = TRUE;
        }

        if( obs_cleared == TRUE )
        {
            G_repeating_obstacle_counter = NO_REPEAT_OBS;
            G_repeating_obstacle_detected_flag = OBS_NOT_DETECTED;
            for( idx = NO_REPEAT_OBS + 1; idx < NUM_REPEATING_OBS; idx++ )
            {
                G_obs_positions[idx] = INVALID_POSITION;
            }
        }

    }

    /* Void return */
    return;
}

/*********************************************************************************************
Author(s):      Michael Ansolis
Description:    Return the last computed value of the obstacle_detected flag.
Parameters:     None.
Returns:        OBS_NOT_DETECTED - if the detection alogithm has not detected an obstacle
                OBS_DETECTED     - if the detection algorithm has detected an obstacle
**********************************************************************************************/
OBS_DETECT obs_get_od_status()
{
    OBS_DETECT od_status;

    DISABLE_INTERRUPTS();
    od_status = G_obstacle_detected_flag;
    ENABLE_INTERRUPTS();
    return od_status;
}


/*********************************************************************************************
Author(s):      Michael Ansolis
Description:    Return the last computed value of the obstacle_detected flag.
Parameters:     None.
Returns:        OBS_NOT_DETECTED - if the detection alogithm has not detected an obstacle
                OBS_DETECTED     - if the detection algorithm has detected an obstacle
**********************************************************************************************/
OBS_DETECT obs_get_repeat_od_status()
{
    OBS_DETECT repeat_od_status;

    DISABLE_INTERRUPTS();
    repeat_od_status = G_repeating_obstacle_detected_flag;
    ENABLE_INTERRUPTS();
    return repeat_od_status;
}


/*********************************************************************************************
Author(s):      Michael Ansolis
Description:    This function compares the new direction to the previous direction. If the new
                direction is different than the old direction, then the obstacle detection
                logic is reset.
Parameters:     New motion direction.
Returns:        None
History:        JK 5/25/16 - Updated for new obstacle detection algorithm.
**********************************************************************************************/
void obs_set_commanded_direction(MOTION_DIRECTION dir)
{
    /* Determine if the data in the S_accumulated_I_sense ring buffer is invalid
       for obstacle detection. */
    if ((dir != G_motion_direction ) || (dir == NONE))
    {
        /* The data in the ring buffer is invalid so clear the count of valid current
           measurements stored in the ring buffer. */
        DISABLE_INTERRUPTS();
        G_valid_current_sample_count = 0;

        /* The count of consecutive exceeded measurements is now invalid so clear it too. */
        G_obs_count = 0;

        /* Save the new motion direction in the global variable */
        G_motion_direction = dir;

        /* Save the start time of this new motion command */
        G_motion_start_time = tmgr_get_system_time();
        ENABLE_INTERRUPTS();
    }

}

/*********************************************************************************************
 * Author(s):      Michael Ansolis
 * Description:    This function clears the obstacle detection status after either:
 *                 1. A zero speed command is received.
 *                 2. 110ms after the last non-zero speed command was received.
 * Parameters:     None.
 * Returns:        None.
**********************************************************************************************/
void obs_clear_od_status( void )
{
    /* Clear the obstacle detection flag */
    G_obstacle_detected_flag = OBS_NOT_DETECTED;
    lastSpeedCommand = 0;
    
    _obs_clearOBSBuffers();

    /* Clear the obstacle counted flag. */
    G_od_counted = FALSE;
}

static void _obs_clearOBSBuffers()
{
    int i = 0;
    //Clear integral term of model
    S_current = 0;
    S_velocity = 0;

    //clear rpm sampling
    for(i = 0; i < MAX_RPM_SAMPLES; i++) {
        G_rpm_samples[i] = 0;
    }
    //clear the velocity array
    for(i = 0; i < MAX_VEL_SAMPLES; i++) {
        G_vel_samples[i] = 0;
    }
    //Clear the load array
    for(i = 0; i < MAX_LOAD_SAMPLES; i++) {
        G_load[i] = 0;
    }
    //Clear the average load array
    for(i = 0; i < MAX_AVG_LOAD_SAMPLES; i++) {
        G_avg_load[i] = 0;
    }
}
/*********************************************************************************************
 * Author(s):      Juan Kuyoc
 * Description:    This function enables or disables obstacle detection.
 * Parameters:     value - TRUE enables obstacle detection
 *                         FALSE disables obstacle detection.
 * Returns:        None.
**********************************************************************************************/
void obs_set_obstacle_detection(BOOL value)
{
    G_obstacle_detect = value;
}

/*********************************************************************************************
 * Author(s):      Juan Kuyoc
 * Description:    This function enables or disables multi-zone detection.
 * Parameters:     value - ON enables multi-zone detection
 *                         OFF disables multi-zone detection.
 * Returns:        None.
**********************************************************************************************/
void obs_set_multi_zone(MULTI_ZONE_DETECT value)
{
    G_multi_zone_detect = value;
}

/*********************************************************************************************
 * Author(s):      Juan Kuyoc
 * Description:    This function enables or disables obstacle detection.
 * Parameters:     None.
 * Returns:        MULTI_ZONE_DETECT - Returns multi-zone detection ON or OFF.
**********************************************************************************************/
MULTI_ZONE_DETECT obs_get_multi_zone()
{
    return G_multi_zone_detect;
}

/*********************************************************************************************
 * Author(s):      Jonathan R. Saliers
 * Description:    This function returns measured velocity.
 * Parameters:     None.
 * Returns:        INT16S - Returns latest measured velocity.
**********************************************************************************************/
INT16S obs_get_measured_velocity( void )
{
    return G_measured_velocity;
}

/*********************************************************************************************
 * Author(s):      Jonathan R. Saliers
 * Description:    This function returns configured maximum temperature.
 * Parameters:     None.
 * Returns:        INT16S - Returns configured maximum temperature value.
**********************************************************************************************/
INT16S obs_get_max_temp( void )
{
    return G_params.temp;
}

/*********************************************************************************************
 * Author(s):   M VanderZouwen
 * Description: gets the parameters for the obstacle detection event data frame
 *********************************************************************************************/
void obs_get_event_parameters (
    INT16U* position_delta,                    /* configuration table element */
    INT16U** obs_positions)                       /* obstacle positions array */
{
    *position_delta = G_obs_params.position_delta;
    *obs_positions = (INT16U*)&G_obs_positions;
}

//stores a collection of speed adjustment values over time
void addSpeedAdjust(INT32S speed) {
    adjustSpeedValue[adjustSpeedIndex] = speed; //populate the SpeedValue index with the speed value that was passed
    adjustSpeedTime[adjustSpeedIndex] = tmgr_get_system_time() + speedAdjustTiming; // populate SpeedTime with current time + speed adj time from params
    adjustSpeedIndex++; // increment the SpeedIndex
    
    if(adjustSpeedIndex >= ADJUST_SPEED_COUNT) {
        adjustSpeedIndex = 0;  //restart index once array is full
    }
}

//Adds up all active speed adjustments and returns the value
INT32S GetSpeedAdjust() {
    //create a speedAdjust value, set to 0
    INT32S speedAdjust = 0;
    //get the current time
    INT32U currentTime = tmgr_get_system_time();
    //loop through the speed adjustment list
    int adjustIndex;
    for(adjustIndex = 0; adjustIndex < ADJUST_SPEED_COUNT; adjustIndex++) {
        //if the adjustment time is less than the current time
        if(adjustSpeedTime[adjustIndex] > currentTime) {
            //add the adjusted speed to the speedAdjust value
            speedAdjust += adjustSpeedValue[adjustIndex];
        }
    }
    //return the adjusted value
    return speedAdjust;
}

void ClearSpeedAdjust() {
    int adjustIndex = 0;
    for(adjustIndex = 0; adjustIndex < ADJUST_SPEED_COUNT; adjustIndex++) {
        adjustSpeedValue[adjustIndex] = 0;
    }
}
