/*
 Author(s): James Pieterick <jpieterick@righthandtech.com>
 Status: Preliminary
 Release Date:
 Revision:
 Description: The Actuator Main Module.
 */

/*********************************************************************************************
 * Source file includes
 ********************************************************************************************/
#include "cpu.h"
#include "memorymgr.h"
#include "motion_control.h"
#include "system_monitor.h"
#include "communications.h"
#include "timer_manager.h"
#include "Event_Manager.h"
#include "utility.h"
#include "angle_sensor.h"
#ifdef UART_DEBUG
#include "uart1.h"
#endif
#ifdef TEST_DRV
#include "test.h"
#endif

/*********************************************************************************************
 * Private preprocessor definitions
 ********************************************************************************************/
#define RUNNING 1
#define SUCCESS 0

#define NORMAL_INIT FALSE
#define INIT_ERROR  TRUE

#define CFG_CRC_ID 0x03

/*********************************************************************************************
 * Private type definitions
 ********************************************************************************************/

/*********************************************************************************************
 * Private function declarations
 ********************************************************************************************/
    void NVM_Erase_4K_Sector_store_2_words(INT32U, INT16U, INT16U);
    INT16U NVM_read_ANG_BASE(int);
    INT16U NVM_read_ANG_BASE(int);

/*********************************************************************************************
 * Global variable definitions
 ********************************************************************************************/
/* Reserve flag for the interrupt redirect functions to determine if running
 * Application = 0xFFFF or Bootloader = 0x0000 */
unsigned int appflag __attribute__((address(0x1FFE))) = 0XFFFF;

/*********************************************************************************************
 Author(s):   
 Description: The Actuator main function.
 Parameters:  None.
 Returns:     void
*********************************************************************************************/
int main(void)
{
    
    ERR_RET sys_err = NO_ERROR;
__builtin_disable_interrupts();
    /* Initialize the system clock speed, DSC system configure clocks, pin-mux, etc.
       Note:  This initialization function must be called first. */
    cpu_init();
    
    /* Set LED RED In the start of Init */
    cpu_set_led_state( LED_STATE_RED );
    
#ifdef UART_DEBUG
    UART1_Initialize();
#endif

#ifdef TEST_DRV    
  //  test();// For testing it will never go beyond this while(1) inside test function
#endif

  /* Call the position module initialization function to get calibration parameters
       from the configuration module. */
    if(sys_err == NO_ERROR)
    {
       //sys_err = psn_init(); /*TBD*/
    } 
   
    /* Initializes the System Monitor module and sub-modules. I2c, ADC interfaces */
    if(sys_err == NO_ERROR)
    {
       sys_err = sm_init( );
    }
    /* Initialize the Motion_Control module and sub-modules. */
    if(sys_err == NO_ERROR)
    {
        sys_err = motn_init();
    }    
    /* Initialize the Timer_Manager to start the system clock. */
    tmgr_init();

    /* Initialize the Communication module and CAN hardware interface.*/
    /*parameters ignored , to be updated for filter configuration*/
    ecan_init(1,1,1);
    spi2_Init();
    spi3_init();
    angleSens_init();
 __builtin_enable_interrupts();
    /* Set LED Green for Main Loop */
    cpu_set_led_state( LED_STATE_GREEN );

    
    /**************************************************************************/
    /***>>> The main loop. <<<****/
    /**************************************************************************/
    for ( ; ; ) /* Forever */
    {
        angle_sensor_exec(); /* call this when mechanical setup is done &
                              * zero position configuration is needed
                              * CAN command needed: (rxCanMsg.D[5] == 0xE3) */
        psn_calc_position(); 

        //motn_set_commanded_speed(4999);

        comm_exec();
        /* Communication Periodic - called periodically to send CAN status*/
       //CAN_status();

        /* System Monitor Periodic - called periodically to execute the System
           Monitor module and sub-modules. */
       sm_exec();

        /* Motion Control Periodic - called periodically to execute the Motion
           Control module and sub-modules. */
        motn_exec();
        //bldc_exec();
        //printf("\r\n RPM meas/required: %d  \r\n",MDC);

        /* Watchdog Service - called periodically to reset Watchdog hardware timer. */
      //  cpu_service_watchdog();
    } /* End for ever loop */
    return (SUCCESS);
}