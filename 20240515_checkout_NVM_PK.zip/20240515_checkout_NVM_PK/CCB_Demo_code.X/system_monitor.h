/*
Author(s):      Glenn Racette   <gracette@righthandtech.com>
                David Yuen      <dyuen@righthandtech.com>
Status:         Preliminary
Release Date:
Revision:
Description:    API definition for the System Monitor module in the Actuator LRU software.
                The System Monitor module is responsible for providing the actuator status
                data to other modules upon request, and for updating the state of the
                status LEDs.
 */

#ifndef SYSTEM_MONITOR_H
#define	SYSTEM_MONITOR_H

/*********************************************************************************************
    Includes
 *********************************************************************************************/
#include "typedef.h"
#include "communications.h"

/*********************************************************************************************
Type Definitions
*********************************************************************************************/

/*
    Possible system power states as set by the SCM
 */
typedef enum
{
    SM_PWR_RESTORE  = 0,
    SM_PWR_SHUTDOWN = 1
} SM_POWER_STATE;

/*********************************************************************************************
    Function declarations
**********************************************************************************************/

/*********************************************************************************************
Author(s):   Glenn Racette
Description: The initialization function for the Actuator System Monitor module.
Parameters:  None
Returns:     None
**********************************************************************************************/
ERR_RET sm_init();

/*********************************************************************************************
Author(s):   Glenn Racette
Description: The periodic execution function for the Actuator System Monitor module.
Parameters:  None
Returns:     None
**********************************************************************************************/
void sm_exec(void);


/*********************************************************************************************
Author(s):      Jonathan R. Saliers
Description:    Returns the last calculated values of the ACT status bytes.
Parameters:     p_status_D7 - pointer to the location to write the status D7 byte
Returns:        None
 *********************************************************************************************/
void sm_get_status_bytes( INT8U* p_status_D7 );

/*********************************************************************************************
Author(s):      Michael Ansolis
Description:    Returns TRUE if the error flags in the status message are set
                as follows and FALSE otherwise:
                  FLAG
                Impending Shutdown                  FALSE
                Overcurrent                         FALSE
                Critical Overcurrent                FALSE
                Obstacle Detection                  FALSE
                Actuation Failure                   FALSE
                Motor Control Chip Failure          FALSE
                Param Var OK                        TRUE
                Motor Temp Critical                 FALSE
                Stepper Temp Critical               FALSE
                PCB Temp Critical                   FALSE
                Repeating Obstacle Detection        FALSE
                Invalid Encoder Signals             FALSE
                Application CRC Failure             FALSE
                Disengage Failure                   FALSE
                Mechanical Brake Failure            FALSE
                Repeating Mechanical Brake Failure  FALSE

Parameters:     None
Returns:        See description.
*********************************************************************************************/
BOOL sm_get_motion_allowed(void);

/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Function for setting the new power state.
Parameters:  power_state - the new value of power state.
Returns:     None
*********************************************************************************************/
void sm_set_power_state(SM_POWER_STATE power_state);

/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: Function for setting control of the status indicator LED.
Parameters:  led_control - indicates whether SCM is controlling the LED (1) or not (0).
Returns:     None
*********************************************************************************************/
void sm_set_led_control( INT8U led_control );


/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: Function for setting max temp value to be used in checking overtemp conditions.
Parameters:  temp - value to use as maximum temperature value.
Returns:     None
*********************************************************************************************/
void sm_set_max_temp( INT16U temp );

/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: Function for retrieving the speed adjustment value.
Parameters:  None.
Returns:     FP32 - speed adjustment configuration value.
*********************************************************************************************/
FP32 sm_get_speed_adjust( void );

/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: Function for retrieving the speed adjustment timing value.
Parameters:  None.
Returns:     INT32U - speed adjustment timing configuration value.
*********************************************************************************************/
INT32U sm_get_speed_adjust_time( void );

/*********************************************************************************************
 * Author(s):      Jonathan R. Saliers
 * Description:    Returns TRUE if the error flags in the status message are set
 *                 to allow motion on the wiggle restart.
 * Parameters:     None
 * Returns:        BOOL - indicates whether motion is allowed.
*********************************************************************************************/
BOOL sm_get_wiggle_restart_motion_allowed( void );
#endif  /*SYSTEM_MONITOR_H */

