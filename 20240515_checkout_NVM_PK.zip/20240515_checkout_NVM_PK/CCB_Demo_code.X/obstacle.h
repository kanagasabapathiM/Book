/*
Author(s):      David Yuen <dyuen@righthandtech.com>
Status:         Preliminary
Release Date:
Revision:
Description:    Interface definition for the Current module.   This module caches
                current readings for distribution to other software modules.
                This module is also responsible for providing periodic monitoring of the
                current consumption and determining if the seat has encountered an
                obstacle.
History:        Juan Kuyoc 05/13/16: Added/Modified for new obstacle detection algorithm.
 */

#ifndef OBSTACLE_H
#define OBSTACLE_H

/*********************************************************************************************
Includes
*********************************************************************************************/
#include "typedef.h"
#include "communications.h"

/*********************************************************************************************
Type Definitions
*********************************************************************************************/
/*
 The possible results of the obstacle detection algorithm.
 */
typedef enum
{
    OBS_NOT_DETECTED = 0,
    OBS_DETECTED     = 1
} OBS_DETECT;

/*
 Enumerated type that is used to keep track of the rotational direction of the motor that is
 currently being commanded by the SCM.
*/
typedef enum motion_direction
{
    NONE     = 0,
    POSITIVE = 1,
    NEGATIVE = 2
} MOTION_DIRECTION;

/*
 Enumerated type that is used to keep track of whether multi-zone obstacle detection is
 on or off.
*/
typedef enum
{
    OFF     = 0,
    ON      = 1
} MULTI_ZONE_DETECT;

/*********************************************************************************************
Function declarations
*********************************************************************************************/

/*********************************************************************************************
 * Author(s):    Michael Ansolis
 * Description:  Initialize Obstacle_Detection module.
 * Parameters:   None
 * Returns:      NO_ERROR    - indicates success
 *               ERR_FAILURE - indicates failure
*********************************************************************************************/
ERR_RET obs_init(void);

/*********************************************************************************************
Author(s):      Glenn Racette
                James Pieterick
Description:    Stores the obstacle detection configuration parameters.
Parameters:     param_id (in)    - the specific obstacle detection parameter ID
                param_value (in) - the value of the obstacle detection parameter
Returns:        None
**********************************************************************************************/
//void obs_set_parameter(COMM_PARAM_ID param_id, INT16U param_value);

/*********************************************************************************************
Author(s):      Kenneth Richards
Description:    Stores the starting calibration offset configuration parameter.
Parameters:     param_id (in)    - the specific calibration offset parameter ID
                param_value (in) - the value of the calibration offset parameter
Returns:        None
**********************************************************************************************/
//void cal_set_parameter(COMM_PARAM_ID param_id, INT16U param_value);

/*********************************************************************************************
Author(s):      Michael Ansolis
Description:    Run the obstacle detection algorithm.
Parameters:     None.
Returns:        None.
**********************************************************************************************/
void obs_isr_check_for_obstacle(void);

/*********************************************************************************************
Author(s):      Jonathan Saliers
Description:    Check if repeating obstacle detection positions can be cleared.
Parameters:     None.
Returns:        None.
**********************************************************************************************/
void obs_exec( void );

/*********************************************************************************************
Author(s):      Michael Ansolis
Description:    Return the last computed value of the obstacle_detected flag.
Parameters:     None.
Returns:        OBS_NOT_DETECTED - if the detection alogithm has not detected an obstacle
                OBS_DETECTED     - if the detection algorithm has detected an obstacle
**********************************************************************************************/
OBS_DETECT obs_get_od_status(void);

/*********************************************************************************************
Author(s):      Michael Ansolis
Description:    Return the last computed value of the repeating_obstacle_detected flag.
Parameters:     None.
Returns:        OBS_NOT_DETECTED - no repeating obstacle detected
                OBS_DETECTED     - repeating obstacle detected
**********************************************************************************************/
OBS_DETECT obs_get_repeat_od_status(void);

/*********************************************************************************************
Author(s):      Michael Ansolis
Description:    This function compares the new direction to the previous direction. If the new
                direction is different than the old direction, the valid sample count and the
                exceeded measurement count are cleared.
Parameters:     New motion direction.
Returns:        None
**********************************************************************************************/
void obs_set_commanded_direction(MOTION_DIRECTION dir);

/*********************************************************************************************
 * Author(s):      Michael Ansolis
 * Description:    This function clears the obstacle detection status after either:
 *                 1. A zero speed command is received.
 *                 2. 110ms after the last non-zero speed command was received.
 * Parameters:     None.
 * Returns:        None.
**********************************************************************************************/
void obs_clear_od_status( void );

/*********************************************************************************************
 * Author(s):      Juan Kuyoc
 * Description:    This function enables or disables obstacle detection.
 * Parameters:     value - TRUE enables obstacle detection
 *                         FALSE disables obstacle detection.
 * Returns:        None.
**********************************************************************************************/
void obs_set_obstacle_detection(BOOL value);

/*********************************************************************************************
 * Author(s):      Juan Kuyoc
 * Description:    This function enables or disables multi-zone obstacle detection.
 * Parameters:     value - TRUE enables multi-zone obstacle detection
 *                         FALSE disables multi-zone obstacle detection.
 * Returns:        None.
**********************************************************************************************/
void obs_set_multi_zone(MULTI_ZONE_DETECT value);

/*********************************************************************************************
 * Author(s):      Juan Kuyoc
 * Description:    This function enablesor disables obstacle detection.
 * Parameters:     None.
 * Returns:        MULTI_ZONE_DETECT - Returns multi-zone detection ON or OFF.
**********************************************************************************************/
MULTI_ZONE_DETECT obs_get_multi_zone();

/*********************************************************************************************
 * Author(s):      Jonathan R. Saliers
 * Description:    This function returns measured velocity.
 * Parameters:     None.
 * Returns:        INT16S - Returns latest measured velocity.
**********************************************************************************************/
INT16S obs_get_measured_velocity( void );

/*********************************************************************************************
 * Author(s):      Jonathan R. Saliers
 * Description:    This function returns configured maximum temperature.
 * Parameters:     None.
 * Returns:        INT16S - Returns configured maximum temperature value.
**********************************************************************************************/
INT16S obs_get_max_temp( void );

/*********************************************************************************************
 * Author(s):   M VanderZouwen
 * Description: gets the parameters for the obstacle detection event data frame
 *********************************************************************************************/
void obs_get_event_parameters (
    INT16U* position_delta,                    /* configuration table element */
    INT16U** obs_positions);                      /* obstacle positions array */

/*********************************************************************************************
Author(s):      Abraham Greenwell
Description:    Sets obstacle model parameters.
Parameters:     index - which parameter to set
                value - the value to set it to
Returns:        None.
**********************************************************************************************/
void obsSetModelParam(INT8U index, FP32 value);

#endif /* OBSTACLE_H */
