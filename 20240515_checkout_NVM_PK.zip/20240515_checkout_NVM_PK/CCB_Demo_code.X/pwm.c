/*
 * Author(s):     Pratheep Kumar
 * Status:        
 * Release Date:
 * Revision:
 * Description:   PWM_Control module responsible for computing and controlling the PWM duty cycle
 *                used to control the BLDC motor speed.
*/

/*********************************************************************************************
Includes
*********************************************************************************************/
#include "global.h"
#include "pwm.h"
#include "cpu.h"
#include "utility.h"
#include "hall.h"

#ifdef UART_DEBUG
#include "uart1.h"
#endif
/*********************************************************************************************
Preprocessor definitions
*********************************************************************************************/
/*
    PWM Configuration definitions
*/
/*For BLDC*/
#define PWM_PERIOD_TICKS      9999    //((FPGx_clk/FPWM) - 1) FPWM= 16KHz required, FPGx_clk = 80MHz

/*For Solenoid*/
//#define SOL_PERIOD_TICKS      49999//for 200Hz    //((FPGx_clk/FPWM) - 1) FPWM= 16KHz required, FPGx_clk = 80MHz
#define SOL_PERIOD_TICKS      9999//for 200Hz    //((FPGx_clk/FPWM) - 1) FPWM= 16KHz required, FPGx_clk = 80MHz

/*
    Possible IOCON register values for PWM control
    for all three PWM pairs: SWAP off, PENH/L set for PWM ctrl
    Additionally:
    IOCON_PWM_BOTH_OFF    = both drive of pair off (no pwm)
    IOCON_PWM_HIGHSIDE_ON = high side drive on, low side off (no pwm)
    IOCON_PWM_COMPLIM     = drive PWM pair in a complimentary (alternating) pattern
 */
#define IOCON_PWM_BOTH_OFF         0x3000
#define IOCON_PWM_HIGHSIDE_ON      0x3800
#define IOCON_PWM_COMPLIM          0x0000
#define IOCON_PWM_LOWSIDE_ON       0x3400

#define PWM_VOLTAGE            28

/*********************************************************************************************
Type Definitions
*********************************************************************************************/

/*
    Motor drive direction
*/


/*********************************************************************************************
Global variable definitions
*********************************************************************************************/
/* Current assigned motor PWM. */
static INT16S G_mdc_val;

/* Current speed demand in RPM calculated by the speed control loop. */
static INT16S G_speed_demand;

/* Flag indicating a speed command = 0 was received and the motor can be shut down. */
static BOOL volatile G_disable_drive;

/* The measured motor speed in RPM. */
static INT16S G_motor_speed;

/* BLDC motor drive direction. */
static BLDC_DRIVE_DIRECTION volatile G_drive_direction;

/* Configuration parameters retrived from flash memory. */
static CFG_PWM_PARAM_TABLE_TYPE G_params;

static INT16S G_duty_percent;

/*********************************************************************************************
Function declarations
*********************************************************************************************/

/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Sets up static drive direction var and PWM drive direction
Parameters:  drive_direction (in) - direction to change drive
Returns:     None
*********************************************************************************************/
//void pwm_change_drive_direction(BLDC_DRIVE_DIRECTION drive_direction);

/*********************************************************************************************
Function defintions
*********************************************************************************************/

/*********************************************************************************************
 * Author(s):    Pratheep Kumar
 * Description:  Initialization of the PWM_Control module, including initialization of PWM
 *               hardware module and special even interrupt that triggers at a certain phase of
 *               PWM duty cycle. PWM8 is used as trigger for ADC conversion of ISENSE/ISENSE.
 * Parameters:   None
 * Returns:      
*********************************************************************************************/
ERR_RET pwm_init(void)
{
    G_speed_demand = 0;
    G_disable_drive = TRUE;
    G_motor_speed = 0;
    G_drive_direction = BLDC_DRIVE_POSITIVE;
    G_mdc_val = 0;

   //sys_err = cfg_load_parameters( TBL_PWM_PARAM, (INT16U*)&G_params);
    
    PG2CONLbits.ON = 0;
    PG3CONLbits.ON = 0;
    PG4CONLbits.ON = 0;
    PG8CONLbits.ON = 0;
    
    /*PWM Master Clock Selection bits FOSC*/
    PCLKCONbits.MCLKSEL = 0; 
    
    //PWM Generator uses the master clock selected by the MCLKSEL[1:0]
    PG2CONLbits.CLKSEL = 1;
    PG3CONLbits.CLKSEL = 1;
    PG4CONLbits.CLKSEL = 1;
    PG8CONLbits.CLKSEL = 1;
    /*Independent edge triggered mode */
    PG2CONLbits.MODSEL = 0b000;
    PG3CONLbits.MODSEL = 0b000; 
    PG4CONLbits.MODSEL = 0b000; 
    PG8CONLbits.MODSEL = 0b000; 
    /* PWM Generator uses MDC register, PWM Generator uses MPER register*/
    PG2CONHbits.MDCSEL  = 1; 
    PG2CONHbits.MPERSEL = 1; 
    PG3CONHbits.MDCSEL  = 1; 
    PG3CONHbits.MPERSEL = 1; 
    PG4CONHbits.MDCSEL  = 1; 
    PG4CONHbits.MPERSEL = 1; 
    PG8CONHbits.MDCSEL  = 1; 
    PG8CONHbits.MPERSEL = 1;
    
    PG2CONHbits.MSTEN  = 1;
    PG2CONHbits.UPDMOD = 1; 
    PG3CONHbits.UPDMOD  = 3; 
    PG4CONHbits.UPDMOD  = 3;
    /*PWM Generator outputs operate in Complementary mode,PWM Generator controls
      the PWM1H and PWM1L output pins and PWMxH is output pin is  active low, 
      PWMxL output pin is  active high*/
    PG2IOCONH = 0x000E;
    PG3IOCONH = 0x000E;
    PG4IOCONH = 0x000E;
    PG8IOCONH = 0x0006;
    //PG8PHASE  = 4999/2;
    /*
     * 
        Set master PWM period & initialize the duty cycle to 0
    */
    MPER = PWM_PERIOD_TICKS; //configured at 16KHz
    MDC = PWM_PERIOD_TICKS; // during init it MDC kept maximum as the PWM signals were inverted
    ////PG8EVTLbits.PGTRGSEL = 3;//1;//PGxTRIGC is the PWM Generator Trigger Output
    //PG8EVTLbits.ADTR1EN1 = 1;//1;// PGxTRIGA register compare event is enabled as trigger source for ADC Trigger
    //PG8EVTHbits.ADTR2EN1 = 1;

    PG8EVTLbits.PGTRGSEL = 1;//1;//PGxTRIGC is the PWM Generator Trigger Output
    PG8EVTLbits.ADTR1EN1 = 1;//1;// PGxTRIGA register compare event is enabled as trigger source for ADC Trigger
    //PG8EVTLbits.ADTR1EN1 = 1
   // ADLVLTRGLbits.LVLEN0 = 1;
    
    //PG8TRIGC = (INT16U)4999/2;
   // PG8TRIGA =4900;
    //PG8TRIGB = (INT16U)4999/2;
   /*Enable PWM*/
   PG2CONLbits.ON = 1;
   PG3CONLbits.ON = 1;
   PG4CONLbits.ON = 1;
   PG8CONLbits.ON = 1;
    /*
        Initialize motor direction
        Note: this can be called from non-ISR context here because ISRs
        in this module have not yet been set up
    */
   pwm_change_drive_direction(BLDC_DRIVE_POSITIVE);
   
    return NO_ERROR;
}

void pwm_slnd_init( void )
{
    /*PWM control register configuration*/
    PCLKCONbits.DIVSEL = 0b11; /* divide ratio 1:16 */
    PCLKCONbits.MCLKSEL = 0;
    PG1CONLbits.CLKSEL = 0b10;
    PG1CONLbits.MODSEL = 0b000; /*Independent edge triggered mode */
    PG1CONH   = 0x0000;
    
    /*PWM Generator outputs operate in Complementary mode*/
    /*PWM Generator controls the PWM1H and PWM1L output pins*/
    /*PWM1H & PWM1L output pins are active high*/
    PG1IOCONH = 0x000C;
    
    /*PWM uses PG1DC, PG1PER, PG1PHASE registers*/
    /*PWM Generator does not broadcast UPDATE status bit state or EOC signal*/
    /*Update the data registers at start of next PWM cycle (SOC) */
    /*PWM Generator operates in Single Trigger mode*/
    /*Start of cycle (SOC) = local EOC*/
    /*Write to DATA REGISTERS*/
    PG1PER   = SOL_PERIOD_TICKS; 
    PG1DC    = 0; /* 25% duty*/
    PG1PHASE = 0; /*Phase offset in rising edge of PWM*/
    PG1DTH   = 0; /*Dead time on PWMH */
    PG1DTL   = 0; /*Dead time on PWML*/
    PG1EVTLbits.UPDTRG = 01; //A write of the PGxDC register automatically sets the UPDREQ bit
    /*Enable PWM*/
    PG1CONLbits.ON = 1; /*PWM module is enabled*/
}
/*********************************************************************************************
Author(s):      Jonathan R. Saliers
Description:    Changes which drive transitors are active/inactive
Parameters:     current_hall - bitfield representing the current Hall sensor readings.
Returns:        None
  Note that the protection feature for the IOCONx registers
  is disabled by clearing the PWMLOCK configuration bit.
*********************************************************************************************/
void pwm_isr_adjust_drive(INT16U current_hall)
{
    /*
        Commutate motor windings
    */

    /* Disable Interrupts */
    DISABLE_INTERRUPTS();
    //G_disable_drive= false;//just for testing to be updated as per the logic
    //G_drive_direction = 0;//just for testing to be updated as per the logic
    /* Short all motor phases to GROUND if disable is indicated */
    if( G_disable_drive == TRUE )
    {
        PG2IOCONL = IOCON_PWM_BOTH_OFF; //just added for current senor error
        PG3IOCONL = IOCON_PWM_BOTH_OFF;
        PG4IOCONL = IOCON_PWM_BOTH_OFF;
    }
    else
    {

        switch(current_hall)
        {
            case 1: /* HEF 1 active, HEF 2 inactive, HEF 3 inactive */
                PG2IOCONL = G_drive_direction ? IOCON_PWM_COMPLIM : IOCON_PWM_HIGHSIDE_ON;
                PG3IOCONL = IOCON_PWM_BOTH_OFF;
                PG4IOCONL = G_drive_direction ? IOCON_PWM_HIGHSIDE_ON : IOCON_PWM_COMPLIM;
                break;

            case 2: /* HEF 1 inactive, HEF 2 active, HEF 3 inactive */
                PG2IOCONL = G_drive_direction ? IOCON_PWM_HIGHSIDE_ON : IOCON_PWM_COMPLIM;
                PG3IOCONL = G_drive_direction ? IOCON_PWM_COMPLIM : IOCON_PWM_HIGHSIDE_ON;
                PG4IOCONL = IOCON_PWM_BOTH_OFF;
                break;

            case 3: /* HEF 1 active, HEF 2 active, HEF 3 inactive */
                PG2IOCONL = IOCON_PWM_BOTH_OFF;
                PG3IOCONL = G_drive_direction ? IOCON_PWM_COMPLIM : IOCON_PWM_HIGHSIDE_ON;
                PG4IOCONL = G_drive_direction ? IOCON_PWM_HIGHSIDE_ON : IOCON_PWM_COMPLIM;
                break;

            case 4: /* HEF 1 inactive, HEF 2 inactive, HEF 3 active */
                PG2IOCONL = IOCON_PWM_BOTH_OFF;
                PG3IOCONL = G_drive_direction ? IOCON_PWM_HIGHSIDE_ON : IOCON_PWM_COMPLIM;
                PG4IOCONL = G_drive_direction ? IOCON_PWM_COMPLIM : IOCON_PWM_HIGHSIDE_ON;
                break;

            case 5: /* HEF 1 active, HEF 2 inactive, HEF 3 active */
                PG2IOCONL = G_drive_direction ? IOCON_PWM_COMPLIM : IOCON_PWM_HIGHSIDE_ON;
                PG3IOCONL = G_drive_direction ? IOCON_PWM_HIGHSIDE_ON : IOCON_PWM_COMPLIM;
                PG4IOCONL = IOCON_PWM_BOTH_OFF;
                break;

            case 6: /* HEF 1 inactive, HEF 2 active, HEF 3 active */
                PG2IOCONL = G_drive_direction ? IOCON_PWM_HIGHSIDE_ON : IOCON_PWM_COMPLIM;
                PG3IOCONL = IOCON_PWM_BOTH_OFF;
                PG4IOCONL = G_drive_direction ? IOCON_PWM_COMPLIM : IOCON_PWM_HIGHSIDE_ON;
                break;

            default: /* HEF 1 active, HEF 2 active, HEF 3 active */
                PG2IOCONL = IOCON_PWM_BOTH_OFF;
                PG3IOCONL = IOCON_PWM_BOTH_OFF;
                PG4IOCONL = IOCON_PWM_BOTH_OFF;
                break;

        } /* switch(current_hall) */

    } /* G_disable_drive != TRUE */

    /* Re-enable interrupts */
    ENABLE_INTERRUPTS();

}


/*********************************************************************************************
Author(s):   Dave Zielinski
Description: Sets up static drive direction var and PWM drive direction
Parameters:  drive_direction (in) - direction to change drive
Returns:     None
*********************************************************************************************/
void pwm_change_drive_direction(BLDC_DRIVE_DIRECTION drive_direction)
{
    DISABLE_INTERRUPTS();
    G_drive_direction = drive_direction;
    ENABLE_INTERRUPTS();
    pwm_isr_adjust_drive(hall_get_position());
}


/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Safely sets the new value of the global variable G_disable_drive.
Parameters:  disable_drive - indicates whether BLDC motor needs to be stopped.
Returns:     None
*********************************************************************************************/
void pwm_set_disable_drive(BOOL disable_drive)
{
    DISABLE_INTERRUPTS();
    G_disable_drive = disable_drive;
    ENABLE_INTERRUPTS();
}


/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Sets the new value of the global variable G_speed_demand.
Parameters:  speed_demand - speed demand in RPM calculated by the speed control loop.
Returns:     None
*********************************************************************************************/
void pwm_set_speed_demand(INT16S speed_demand)
{
    G_speed_demand = speed_demand;
}


/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Sets the new value of the global variable G_motor_speed.
Parameters:  motor_speed - new actual motor speed in RPM.
Returns:     None
*********************************************************************************************/
void pwm_set_motor_speed(INT16S motor_speed)

{
    G_motor_speed = motor_speed;
    
    //printf("\r\n motor speed %d  \r\n",motor_speed);
}

INT16S pwm_get_motor_speed()
{
    return G_motor_speed;;
}

/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Computes the PWM duty cycle based on the speed demand and limits the PWM value
             based on the current motor speed.  The computed value is pushed to the hardware
             PWM module.
Parameters:  None
Returns:     None
*********************************************************************************************/
void pwm_adjust_pwm(void)
{
    static BLDC_DRIVE_DIRECTION S_previous_drive_direction = BLDC_DRIVE_POSITIVE;
    INT16S pwm_demand;  /* In RPM. */
    INT16S mdc_val;
    INT16S max_pwm, percent_dc;
    INT16S duty_cycle;

    /* Update the PWM demand */
    if( G_disable_drive )
    {
        pwm_demand = 0;
    }
    else
    {
        pwm_demand = G_speed_demand;
    }

    /* Update the drive direction if the pwm_demand is a new direction.  This will also
       cause the motor commutation to be updated. */
    if( pwm_demand < 0 )
    {
        if( S_previous_drive_direction == BLDC_DRIVE_POSITIVE )
        {
            pwm_change_drive_direction(BLDC_DRIVE_NEGATIVE);
            S_previous_drive_direction = BLDC_DRIVE_NEGATIVE;
        }
    }
    else
    {
        if( S_previous_drive_direction == BLDC_DRIVE_NEGATIVE )
        {
            pwm_change_drive_direction(BLDC_DRIVE_POSITIVE);
            S_previous_drive_direction = BLDC_DRIVE_POSITIVE;
        }
    }

    /* Set the PWM Master Duty Cycle register using the magnitude of the pwm_demand.
       The drive is in the second half of the duty cycle so setting MDC = 0 results in
       100% drive and setting MDC = PWM_PERIOD_TICKS is equivalent to 0% drive. */
    pwm_demand = (INT16S)util_abs(pwm_demand);

    /* pwm_demand is in the range 0 - MAX_INT_16S (max signed integer).
       duty_cycle is in the range 0 - PWM_PERIOD_TICKS (CPU ticks in a PWM period of 65us). */
    duty_cycle = (INT16S)(((INT32S)pwm_demand * (INT32S)PWM_PERIOD_TICKS) / (INT32S)MAX_INT_16S);

    /* Use actual motor speed if motor speed is between stall and 100 RPM.
       Use desired motor speed if measured motor speed is greater than 100 RPM. */

    /* Calculate duty cycle for demanded speed as percentage. */
    percent_dc = (INT16S)(((INT32S)duty_cycle * 100ul) / (INT32S)PWM_PERIOD_TICKS);
    G_duty_percent = percent_dc;
    G_params.max_pwm_slope = 0.00031;
    G_params.max_pwm_offset = 0.8;
    /* Calculate max pwm percentage. */
    max_pwm = (INT16S)((G_params.max_pwm_slope * (FP32)G_motor_speed + G_params.max_pwm_offset) *
                       100.0);
    
   if(percent_dc > max_pwm)
    {
        mdc_val = PWM_PERIOD_TICKS - ((PWM_PERIOD_TICKS * max_pwm) / 100);
        G_mdc_val = ((PWM_PERIOD_TICKS * max_pwm) / 100);
    }
    else
    {
        /* MDC_val is the value to be stored in the MDC register. */
        mdc_val = PWM_PERIOD_TICKS - duty_cycle;
        G_mdc_val = duty_cycle;

        /* Limit the duty cycle value between 0 and 100 percent */
        if(mdc_val > PWM_PERIOD_TICKS)
        {
            mdc_val = PWM_PERIOD_TICKS;
            G_mdc_val = 100;
        }
        if(mdc_val < 0)
        {
            mdc_val = 0;
            G_mdc_val = 0;
        }
    }

    /* Update Master Duty Cycle register of the PWM hardware peripheral. */
    MDC = mdc_val;
    PG8TRIGA = 9840;//For ADC trigger at the end just before 1 micro second at the end as the MOSFET on at the end(62.5/9999*159))
    /*To Update Duty cycle values to PG1-PG3,add two lines of code written
 below(In this example setting 50% Duty Cycle):
 After writing MDC register set Update request bit PG1STATbits.UPDREQ.
 This will transfer MDC value to all the PWM generators PG1-PG3.
 Note that Update Mode(UPDMOD) of PG2,PG3 is Slaved EOC and
 PG1 MSTEN bits is '1'*/
    PG2STATbits.UPDREQ = 1;
   //PG3STATbits.UPDREQ = 1;
   // PG4STATbits.UPDREQ = 1;
    PG8STATbits.UPDREQ = 1;
    //--//printf("\r\n Duty cycle %d\r\n", mdc_val);
}


/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Return the currently assigned motor PWM value.
Parameters:  None.
Returns:     The currently assigned motor PWM value.
*********************************************************************************************/
INT16S pwm_get_current_pwm(void)
{
    return G_mdc_val;
}

/*********************************************************************************************
Author(s):   Juan Kuyoc
Description: Returns the voltage applied to the PWM by multiplying the duty
             percentage and the PWM voltage.
Parameters:  None
Returns:     float - The voltage applied to the PWM.
*********************************************************************************************/
float pwm_get_command_voltage()
{
    return ((float)G_duty_percent)* 0.28;
}
#if 0
//this PWM is used to triggering source for ADC
void pwm_ADCtrig_init( void )
{
    /*PWM control register configuration*/
    PCLKCONbits.MCLKSEL = 0;
    PG6CONLbits.CLKSEL = 1;
    PG6CONLbits.MODSEL = 0b000; /*Independent edge triggered mode */
    PG6CONLbits.HREN = 1;
    PG6CONH   = 0x0000;
    /*PWM Generator outputs operate in Complementary mode*/
    /*PWM Generator controls the PWM6H and PWM6L output pins*/
    /*PWM6H & PWM6L output pins are active high*/
    PG6IOCONH = 0x000C;

    /*PWM uses PG1DC, PG1PER, PG1PHASE registers*/
    /*PWM Generator does not broadcast UPDATE status bit state or EOC signal*/
    /*Update the data registers at start of next PWM cycle (SOC) */
    /*PWM Generator operates in Single Trigger mode*/
    /*Start of cycle (SOC) = local EOC*/
    /*Write to DATA REGISTERS*/
    PG6PER   = PWM_PERIOD_TICKS; /*PG1PER= ((FPGx_clk/FPWM) - 1), FPWM = 16KHz*/
    PG6DC    = PWM_PERIOD_TICKS/2; /* 50% duty*/
    PG6PHASE = 0; /*Phase offset in rising edge of PWM*/
    PG6DTH   = 0; /*Dead time on PWMH */
    PG6DTL   = 0; /*Dead time on PWML*/

    PG6IOCONLbits.OVRDAT = 1;// OVRDAT0 provides data for output on the PWMxL pin
    PG6IOCONLbits.OVRENH = 1;// OVRDAT1 provides data for output on the PWMxH pin
    PG6EVTLbits.PGTRGSEL = 3;//PGxTRIGC is the PWM Generator Trigger Output
    PG6EVTLbits.ADTR1EN1 = 1;// PGxTRIGA register compare event is enabled as trigger source for ADC Trigger
    //PG6EVTLbits.UPDTRG = 3;
   // PWMEVTCbits.EVTCSEL = 8;
   // PG6TRIGC = 1000; // Set PGxTRIGC (n = 2500 => n/PGxPER =  12.50% )
    // Set PWM signal generation trigger output timing
    PG6TRIGC = 1000; // Set PGxTRIGC (n = 2500 => n/PGxPER =  12.50% )
    /*Enable PWM*/
    PG6CONLbits.ON = 1; /*PWM module is enabled*/
}

#endif
