/*
 * Author(s):    Pratheep
 * Status:       Incomplete
 * Release Date: 01/22/2024
 * Revision:     0.1
 * Description:  UART module for debug purpose
 */

/*********************************************************************************************
 * Source file includes
 ********************************************************************************************/
#include "uart1.h"
#ifdef UART_DEBUG
#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*********************************************************************************************
 * Global variable definitions
 ********************************************************************************************/
/* Received data is stored in array Rx_Buffer */
char rx_Buffer[8];
char * receivedData = NULL;
uint8_t ful_Msg_Rcvd =0;
int32_t rcvd_Command =0;
/*********************************************************************************************
 * Private function declarations
 ********************************************************************************************/

static bool UART1_IsTxReady(void);
static bool UART1_IsTxDone(void);
static void UART1_convert_rcvmsg(void);
void __attribute__ ( ( interrupt, no_auto_psv ) ) _U1RXInterrupt(void);

/*********************************************************************************************
 * Source file function definitions
 ********************************************************************************************/
void UART1_Initialize(void)
{
    IEC0bits.U1TXIE = 0;
    IEC0bits.U1RXIE = 0;
    
    U1MODEbits.MOD = 0x2; //Asynchronous 8-bit UART without address detect, ninth bit is used as an odd parity bit
    U1MODEHbits.STSEL = 0; //1 Stop bit sent, 1 checked at receive
    U1MODEHbits.BCLKMOD = 1; //Uses fractional Baud Rate Generation
    U1MODEHbits.FLO = 0; //Flow control off
    U1MODEHbits.BCLKSEL = 0; //Baud Clock Source FOSC/2 (FP)
    U1MODEbits.BRGH = 0; //0 = Low Speed: Baud rate is baudclk/16
    U1MODEbits.ABAUD = 0; //Auto-Baud Detect disabled

    // URXISEL ; UTXBE ; UTXISEL TX_BUF_EMPTY; URXBE ; STPMD ; TXWRE ; 
    U1STAH = 0x2E;
    
    //UxBRG = Fp/2; Fp =80Mhz, 57600
    // BaudRate 57605.7; BRG 1389; 
    U1BRG = 1389;//416;//0x0457;
    U1BRGH = 0x0;
    
    // UART Receive Interrupt
    IEC0bits.U1RXIE = 1;
    
    U1MODEbits.UARTEN = 1;   // enabling UART ON bit
    U1MODEbits.UTXEN = 1;
    U1MODEbits.URXEN = 1;
    
    receivedData = rx_Buffer;
}

uint8_t UART1_Read(void)
{
    while((U1STAHbits.URXBE == 1))
    {
        
    }

    if ((U1STAbits.OERR == 1))
    {
        U1STAbits.OERR = 0;
    }
    
    return U1RXREG;
}

void UART1_Write(uint8_t txData)
{
    while(U1STAHbits.UTXBF == 1)
    {
        
    }

    U1TXREG = txData;    // Write the data byte to the USART.
}

static bool UART1_IsTxReady(void)
{
    return ((!U1STAHbits.UTXBF) && U1MODEbits.UTXEN);
}

static bool UART1_IsTxDone(void)
{
    return (bool)(U1STAbits.TRMT && U1STAHbits.UTXBE);
}

//this function to send uart tx data console using printf function
int __attribute__((__section__(".libc.write"))) write(int handle, void *buffer, unsigned int len) {
    unsigned int numBytesWritten = 0 ;
    while(!UART1_IsTxDone());
    while(numBytesWritten<len)
    {
        while(!UART1_IsTxReady());
        UART1_Write(*((uint8_t *)buffer + numBytesWritten++));
    }
    return numBytesWritten;
}

// capture the received message in rx_Buffer
void __attribute__ ( ( interrupt, no_auto_psv ) ) _U1RXInterrupt(void)
{
    IFS0bits.U1RXIF = 0;
    
    while((U1STAHbits.URXBE == 1))
    {
        
    }

    *(receivedData) = U1RXREG;

    if(*receivedData == 'S' || *receivedData == 's')
    {
        ful_Msg_Rcvd = 1;
        receivedData = rx_Buffer;
    }
    else
    {
        receivedData++;
    }
}

//this function converts received UART message string to the integer
//input string range should be -32,768 to 32,767 followed By 'S'
static void UART1_convert_rcvmsg(void)
{
    if (ful_Msg_Rcvd == 1) {

        rcvd_Command = atoi(rx_Buffer);
        //CAN_TP_Tasks();
#ifdef UART_DEBUG
        //--//printf("\r\nReceived Message command:%ld \r\n", rcvd_Command);
#endif
        ful_Msg_Rcvd = 0;
    }
}

int32_t UART1_Get_cmd()
{
    return rcvd_Command;
}
void UART1_test(void)
{
    UART1_convert_rcvmsg();
}
#endif