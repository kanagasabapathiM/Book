/*
 Author(s): Russell Everett <reverett@righthandtech.com>
 Status: Preliminary
 Release Date:
 Revision:
 Description: Definitions for the Actuator Motion_Control Module.
 History:
 06/11/2010 Clay Barber Changed Files updates
 06/24/2016 Clay Barber Updates of Juan Kuyoc
 */

/*********************************************************************************************
Includes
*********************************************************************************************/
#include "global.h"
#include "bldc.h"
#include "hall.h"
#include "motion_control.h"
#include "brake_control.h"
#include "system_monitor.h"
#include "timer_manager.h"
#include "utility.h"
#ifdef UART_DEBUG
#include "uart1.h"
#endif
/********************************************************************************************
Private Type Definitions
*********************************************************************************************/
/*
 Defines the states of the motion control state machine (motn_exec)
 */
typedef enum
{
    MOTN_STATE_STOPPED     = 0,
    MOTN_STATE_DISENGAGING = 1,
    MOTN_STATE_RUNNING     = 2,
    MOTN_STATE_DIR_CHANGE  = 3,
    MOTN_STATE_STOPPING    = 4,
} MOTN_STATE_TYPE;

/*********************************************************************************************
Private Preprocessor definitions
*********************************************************************************************/
/* Wait at most 500ms if BLDC motor isn't moving before applying the brake. */
#define MAX_TIME_BEFORE_BRAKING    2000ul

#define WAIT_FOR_BRAKE_SPEED       200

#define DELAY_BRK_DISENG          2000ul  //10ms delay required for motor to run after brake disengaged

#define MOTOR_RUN_TIME           32000 //30sec motor running time for endurance test
#define MOTOR_STOP_TIME          90000 //10sec  motor stop time for endurance test

#define BLDC_MAX_RPM             3000  // maximum allowed RPM
/******************************************************s***************************************
Global Variable definitions
*********************************************************************************************/

/* Stores the last speed command in RPM. */
static INT16S    G_commanded_speed       = 0;
/* Gearbox ratio and wiggle parameters. */
static CFG_MOTION_PARAM_TABLE_TYPE G_params;
/* Last motor start time. */
static INT32U    G_motor_start_time      = 0;
static INT32U    G_motor_stop_time       = 0;
static INT32U    G_motion_commanded_time = 0;
/* Next state of the motion control state machine */
static MOTN_STATE_TYPE G_next_motn_state;
/* Indicates that direction needs to be reversed. */
static BOOL      G_direction_reversed    = FALSE;
/* Motion direction from the latest computed speed command. */
MOTION_DIRECTION G_new_motion_dir        = NONE;
/* Flag for a brake disengage failure */
static BOOL      G_disengage_failed      = FALSE;
/* Time when BLDC motor was commanded to stop. */
static INT32U G_stop_cmd_time;
/* Brake command. */
static SLND_BRAKE_COMMAND G_brake_command = BRAKE_CMD_ENGAGE;

/*********************************************************************************************
Function definitions
*********************************************************************************************/
static void _motn_conti_test();
//static void _motn_normal_run();
/*********************************************************************************************
Author(s):   
Description: The initialization function for the Actuator Motion_Control module.
Parameters:  None
Returns:     None
History:
*********************************************************************************************/
ERR_RET motn_init( void )
{
    ERR_RET sys_err = NO_ERROR;

    /* Initialize the Stepper motor module and command the brake to the ENGAGED state */
    sys_err |= brake_init();

    /* Initialize the BLDC motor control module */
    sys_err |= bldc_init();
    G_params.dir_change_delay = 100;//sec

    return sys_err;
}

/*********************************************************************************************
Author(s):   E. Miller
Description: Common code for transition to MOTN_STATE_STOPPED
Parameters:  current_sys_time - transition time
Returns:     None
*********************************************************************************************/
static void _motn_stopping( INT32U current_sys_time )
{
    /* Set speed to 0 in case the system state error was detected. */
    G_commanded_speed = 0;
    /* Stop the BLDC motor. */
    bldc_set_desired_speed( 0 );
    /* Set new commanded direction = NONE to the Obstacle_Detection module. */
    //obs_set_commanded_direction( NONE );
    /* Store the time when stop was commanded. */
    G_stop_cmd_time = current_sys_time;
    /* Set next motion state to stopping. */
    G_next_motn_state = MOTN_STATE_STOPPING;
}

/*********************************************************************************************
Author(s):   E. Miller
Description: Common code for transition to MOTN_STATE_STOPPED
Parameters:  current_sys_time - transition time
Returns:     None
*********************************************************************************************/
static void _motn_stopped( INT32U current_sys_time )
{
    /* Stop the BLDC motor. */
    bldc_set_desired_speed( 0 );
    /* Set new commanded direction = NONE to the Obstacle_Detection module. */
   // obs_set_commanded_direction( NONE );
    /* Store the time when stop was commanded. */
    G_stop_cmd_time = current_sys_time;
    G_motor_stop_time = current_sys_time;
    /* Set next motion state to stopped. */
    G_next_motn_state = MOTN_STATE_STOPPED;
}
              
/*********************************************************************************************
Author(s):   
Description: The periodic function for the Actuator Motion Control module.
Parameters:  None
Returns:     None
*********************************************************************************************/
static INT16S rpm_cmd = 0;
void motn_exec( void )
{
    static INT32U S_dir_change_start_time;
    INT32U current_sys_time = tmgr_get_system_time(); /* Get current time */

    static bool test_cmd = 0;//brake_cmd = 0;
    
#if 0

    if(is_New_Msg_cmd() == true)
      { 
        test_cmd = get_Test_cmd();
        if (test_cmd == false) {
            rpm_cmd = (INT16S) get_Rpm_Desired_cmd();
            if (get_Direction_cmd() == 0) {
                motn_set_commanded_speed(-rpm_cmd);
            } else {
                motn_set_commanded_speed(rpm_cmd);
            }
        }else
        {
            motn_test();//for continuous test
        }
            
        
    }
    bldc_exec();
#endif
    /* Time when direction change was commanded. */
    if (is_New_Msg_cmd() == true) {//check for New CAN command
        test_cmd = get_Test_cmd(); //for continuous test
        rpm_cmd = (INT16S) get_Rpm_Desired_cmd();
        
        if (test_cmd == 0) {

             //To Have manual control on the Break
            if (rpm_cmd == 0xFFF) {
                G_brake_command = get_Brake_cmd();
                rpm_cmd = 0;
            }
            if (get_Direction_cmd() == 0) {
                rpm_cmd = -1 * rpm_cmd;
            }
           
            motn_set_commanded_speed(rpm_cmd);

        }
    }
    if (test_cmd == 1) {
            
            _motn_conti_test();
            
    }
  
    switch( G_next_motn_state )
    {
        case MOTN_STATE_STOPPED:
        {
            /* If commanded speed != 0 and at least 100ms since a change in motion commands */
            if( ( G_commanded_speed != 0 ) &&
                ( current_sys_time  > G_stop_cmd_time + G_params.dir_change_delay ) )
            {
                /* Command the stepper to disengage the brake. */
                G_brake_command = BRAKE_CMD_DISENGAGE;
                /* Save motion commanded time */
                G_motion_commanded_time = current_sys_time;
                /* Set next motion state is disengaging. */
                G_next_motn_state = MOTN_STATE_DISENGAGING;
            }
        }
        break;

        case MOTN_STATE_DISENGAGING:
        {
            if( current_sys_time  > (G_motion_commanded_time + DELAY_BRK_DISENG) ){
                /* Set BLDC desired speed = commanded speed */
                bldc_set_desired_speed( G_commanded_speed );
                /* Save the time when motor started */
                G_motor_start_time = current_sys_time;
                /* Set next motion state to running. */
                G_next_motn_state = MOTN_STATE_RUNNING;
            }

        }
        break;

        case MOTN_STATE_RUNNING:
        {
            /* If the motor needs to be stopped. */
            if( G_commanded_speed == 0 )
            {
                _motn_stopping( current_sys_time);
            }
            
            /* If the motor direction needs to be reversed. */
            if( G_direction_reversed     &&
                ( G_commanded_speed != 0 ))
            {
                /* Stop the BLDC motor. */
                bldc_set_desired_speed( 0 );
                /* Start the direction change timer. */
                S_dir_change_start_time = current_sys_time;
                G_direction_reversed = FALSE;
                /* Set new commanded direction = NONE to the Obstacle_Detection module. */
               // obs_set_commanded_direction( NONE );
                /* Set next motion state to direction change. */
                G_next_motn_state = MOTN_STATE_DIR_CHANGE;
            }else
            {
            bldc_set_desired_speed( G_commanded_speed );
            }

        }
        break;

        case MOTN_STATE_DIR_CHANGE:
        {
            /* If the motor needs to be stopped. */
            if(G_commanded_speed == 0)
            {
                /* Stop BLDC motor commutation. */
                bldc_set_desired_speed( 0 );
                /* Store the time when stop was commanded. */
                G_stop_cmd_time = current_sys_time;
                /* Next motion state stopping */
                G_next_motn_state = MOTN_STATE_STOPPING;
            }

            if( current_sys_time  > S_dir_change_start_time + G_params.dir_change_delay )
            {
                /* Start commutation in the new direction. */
                bldc_set_desired_speed( G_commanded_speed );
                /* Send the new commanded direction to the Obstacle_Detection module. */
                //obs_set_commanded_direction( G_new_motion_dir );
                /* Set next state to running. */
                G_next_motn_state = MOTN_STATE_RUNNING;
            }
        }
        break;

        case MOTN_STATE_STOPPING:
        {
            /* If BLDC hasn't moved in the last 25ms OR stopped moving long ago... */
            if( //( bldc_is_stopped() == BLDC_IS_STOPPED ) &&
                current_sys_time > G_stop_cmd_time + MAX_TIME_BEFORE_BRAKING  )
            {
                /* Command the stepper to engage the brake. */
                G_brake_command = BRAKE_CMD_ENGAGE;
                /* Store the time when wait was commanded */
                G_stop_cmd_time = current_sys_time;
                /* Set next state to wait */
                G_next_motn_state = MOTN_STATE_STOPPED;
            }
        }
        break;
    }
    /* Call BLDC module's periodic execution */
    bldc_exec();
    brake_exec(G_brake_command);
    //bldc_drv_read_other();

    return;

}  /* motn_exec() */

/*********************************************************************************************
Author(s):   PK
Description: For continuous test
 * run for 10sec
 * stop for 10sec
 * change direction
Parameters:  speed_degrees_per_second (in) - commanded speed in degrees per second.
Returns:     None
History:     
 *********************************************************************************************/
static void _motn_conti_test() {
    
    static INT32U change_start_time = 0;
    static INT32U speed_decline_time = 0;
    static bool first_time = true;
    static INT16U state = 0;
    static INT16U prev_state = 0;
    static INT16S local_rpm_stp = 0, local_rpm_strt = 0;
    static float i = 0, j = 1;
    INT32U current_sys_time = tmgr_get_system_time(); /* Get current time */

    if (first_time == true || current_sys_time < 100) {
        motn_set_commanded_speed(0);
        first_time = false;
        change_start_time = current_sys_time;
        state = 1;
    }
    if (rpm_cmd > BLDC_MAX_RPM)
        rpm_cmd = BLDC_MAX_RPM;
    
    if (rpm_cmd<-BLDC_MAX_RPM)
        rpm_cmd = -BLDC_MAX_RPM;
    
    if (rpm_cmd == 0) {
        state = 1; // to stop by reducing speed
    }
    switch (state) {

        case 0:
        {
            if (prev_state != state) {
                local_rpm_strt = 0;
                local_rpm_stp = rpm_cmd;
                prev_state = state;
            }
            if (current_sys_time > speed_decline_time) {
                speed_decline_time = current_sys_time + 100;
                if (local_rpm_strt != rpm_cmd) {
                    local_rpm_strt = (INT16S) (rpm_cmd * i);
                    i = i + 0.05;
                } else
                    i = 0;
                motn_set_commanded_speed(local_rpm_strt);
                printf("\r\n rpm_cmd, local_rpm_strt %d  %d\r\n",rpm_cmd,local_rpm_strt);

            }
            if (current_sys_time > change_start_time + MOTOR_RUN_TIME) {
                change_start_time = current_sys_time;
                state = 1;
            }
        }
            break;

        case 1:
        {
            //We can not set RPM to 0 from high RPM
            // reducing in 5 percentage of RPM every 2ms
            if (current_sys_time > speed_decline_time) {
                speed_decline_time = current_sys_time + 100;
                // local_rpm_stp = rpm_cmd * j; //reduce the RPM by 3%
                if (local_rpm_stp != 0) {
                    local_rpm_stp = (INT16S) (local_rpm_stp * j);
                    j = j - 0.02;// reduce every time 0.2%
                } else {
                    j = 1;
                }

                //if(abs(local_rpm_stp)<60){
                //   local_rpm_stp = 0;
                // }

                motn_set_commanded_speed(local_rpm_stp);
                printf("\r\nlocal rpm, rpm_cmd %d  %d\r\n", local_rpm_stp, rpm_cmd);
            }

            if (current_sys_time > change_start_time + MOTOR_STOP_TIME) {
                change_start_time = current_sys_time;
                prev_state = state;
                state = 0;
                //change direction
                rpm_cmd = -1 * rpm_cmd;
            }
        }
            break;

        default:
            break;
    }
}
/*********************************************************************************************
Author(s):   PK
Description: Push the speed received in Communications module.
Parameters:  speed_degrees_per_second (in) - commanded speed in degrees per second.
Returns:     None
History:     
*********************************************************************************************/
void motn_set_commanded_speed( INT16S speed_in_rpm )
{
    /* Motion direction from the previous speed command. */
    static MOTION_DIRECTION S_last_motion_dir = NONE;
   // const INT16S max_rpm = 5000;
   // G_params.max_rpm = 4000; //TBD with Varun
    /* Limit the speed in rpm to plus or minus MOTN_MAX_RPM */
   // if( speed_in_rpm > G_params.max_rpm )
    if( speed_in_rpm > BLDC_MAX_RPM )
    {
        G_commanded_speed = BLDC_MAX_RPM;
        G_new_motion_dir = POSITIVE;
    }
    //else if( speed_in_rpm < -(INT16S)G_params.max_rpm )
    else if( speed_in_rpm < -BLDC_MAX_RPM )
    {
        G_commanded_speed = -BLDC_MAX_RPM;
        G_new_motion_dir = NEGATIVE;
    }
    else
    {
        /* The speed in RPM was within the acceptable range, so we'll use it. */
        G_commanded_speed = (INT16S)speed_in_rpm;
        if( G_commanded_speed > 0 )
        {
            G_new_motion_dir = POSITIVE;
        }
        else if( G_commanded_speed < 0 )
        {
            G_new_motion_dir = NEGATIVE;
        }
        else
        {
            G_new_motion_dir = NONE;
            bldc_set_desired_speed( 0 );
        }
    }

    /* Set change direction flag if the direction was reversed while the motor was running. */
    if( ( G_next_motn_state == MOTN_STATE_RUNNING ) &&
        ( ( S_last_motion_dir == POSITIVE && G_new_motion_dir == NEGATIVE ) ||
          ( S_last_motion_dir == NEGATIVE && G_new_motion_dir == POSITIVE ) ) )
    {
        G_direction_reversed = TRUE;
    }

    /* For non-zero speeds, update the speed in BLDC_Control module. */
   if(( G_commanded_speed != 0 )&& ( G_next_motn_state == MOTN_STATE_RUNNING ) )
    {
        bldc_set_desired_speed( G_commanded_speed );
    }

    S_last_motion_dir = G_new_motion_dir;
}


/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Returns the system time when BLDC motor last started commutating.
Parameters:  None.
Returns:     See description.
*********************************************************************************************/
INT32U motn_get_motor_start_time( void )
{
    return G_motor_start_time;
}

/*********************************************************************************************
Author(s):   Abraham Greenwell
Description: Returns the commanded speed.
Parameters:  None.
Returns:     INT16S - signed commanded speed value.
*********************************************************************************************/
INT16S motn_get_command_speed( void )
{
    return G_commanded_speed;
}

/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Returns TRUE if the motor has stopped and FALSE if it's moving.
Parameters:  None
Returns:     See description.
*********************************************************************************************/
BOOL motn_is_motor_stopped( void )
{
    return ( G_next_motn_state == MOTN_STATE_STOPPED );
}

/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Returns TRUE if the BLDC motor is commutating.
Parameters:  None
Returns:     See description.
*********************************************************************************************/
BOOL motn_is_motor_commutating( void )
{
    return ( G_next_motn_state == MOTN_STATE_RUNNING );
}

/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: Returns the configured gearbox ratio.
Parameters:  None
Returns:     INT16S - returns the configured gearbox ratio.
*********************************************************************************************/
INT16S motn_get_gearbox_ratio( void )
{
    return G_params.gearbox_ratio;
}

/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: Returns the commanded motion direction.
Parameters:  None
Returns:     MOTION_DIRECTION - indicates the commanded direction of motion.
*********************************************************************************************/
MOTION_DIRECTION motn_get_motion_dir( void )
{
    return G_new_motion_dir;
}

/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: Sets a flag indicating a brake disengage failure has occurred.
Parameters:  None
Returns:     None.
*********************************************************************************************/
void motn_set_disengage_failed( void )
{
    G_disengage_failed = TRUE;
    return;
}
#if 0
static void _motn_normal_run() {
    static INT32U speed_ramp_time = 0;
    static INT16S local_rpm_strt = 0;
    static float i = 0;

    INT32U current_sys_time = tmgr_get_system_time(); /* Get current time */


    if (current_sys_time > speed_ramp_time) {
        speed_ramp_time = current_sys_time + 100;
        if (local_rpm_strt != rpm_cmd) {
            local_rpm_strt = (INT16S) (rpm_cmd * i);
            i = i + 0.05;
        } else
            i = 0;
        motn_set_commanded_speed(local_rpm_strt);
        //printf("\r\n rpm_cmd, local_rpm_strt %d  %d\r\n",rpm_cmd,local_rpm_strt);

    }



    //motn_set_commanded_speed(rpm_cmd);
    //To Have manual control on the Break
    if (rpm_cmd == 0) {
        G_brake_command = get_Brake_cmd();
        local_rpm_strt = 0;
    }
}
#endif