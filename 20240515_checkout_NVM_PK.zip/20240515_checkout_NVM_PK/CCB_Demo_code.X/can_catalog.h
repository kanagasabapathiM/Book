/*
 * File:   can_catalog.h
 * Author: mfarver
 *
 * Created on April 2, 2015, 12:18 PM
 * History: 05/16/2016 Juan Kuyoc - Added Assy. and Cfg. part number variables
 *          06/10/2016 Clay Barber
 *          06/27/2016 Clay Barber - Updates of Juan Kuyoc
 *          09/04/2018 M VanderZouwen - Update for Wolverine project
 */
/* Note: this module uses the following coding conventions
 * Each CAN message has the element definitions:
 * ECAN_{name}_DLC - data length code for the message
 * ECAN_{name}_SID - server identification code for the message
 * ECAN_{name}_FRAME - structure for the data bytes of the message
 * ECAN_{name}_CODE - list of specific values for data in the message
*/

/*********************************************************************************************
 * Recursive header blocker
 ********************************************************************************************/
#ifndef CAN_CATALOG_H
#define CAN_CATALOG_H

/*********************************************************************************************
 * Module Includes
 ********************************************************************************************/
#include "global.h"

/*********************************************************************************************
 * Module Preprocessor definitions
 ********************************************************************************************/
/******************************************************************************/
/* Data Length Codes for all CAN messages                                     */
/******************************************************************************/
/* 2 - LRU status */
#define ECAN_LRU_STATUS_DLC         8u

/* 3 - DataFlash Erase Status */
#define ECAN_DF_ERASE_STATUS_DLC    1u

/* 4 - LRU CRC Failure */
#define ECAN_LRU_CRC_FAIL_DLC       8u
#define ECAN_LRU_CRC_FAIL_CODE      {'B','A','D'}

/* 6 - BITE Error */
#define ECAN_BITE_ERROR_DLC         1u

/* 7 - LRU action command */
#define ECAN_LRU_ACTION_CMD_DLC   // variable

/* 7 - Motion Command (ECAN_MOTION_CMD_SID) */
#define ECAN_UAP_MOTION_CMD_DLC     2u
#define ECAN_LUM_MOTION_CMD_DLC     6u

/* 8 - Impending Shutdown */
#define ECAN_IMPENDING_SHUTDOWN_DLC 1u

/* 10 - Boot Mode Select */
#define ECAN_BOOT_SELECT_DLC        1u

/* 11 - Memory Request */
#define ECAN_MEMORY_REQUEST_DLC     4u
#define ECAN_MEM_RQ_DLC             4u

/* 13 - Configuration Status Request */
#define ECAN_CFG_STATUS_REQ_DLC     0u

/* 14 - Configuration Status Response (ACT) */
#define ECAN_CFG_STS_RESP_ACT_DLC   8u

/* 15 - Configuration Status Response (Misc) */
#define ECAN_CFG_STS_RESP_MISC_DLC  5u

/* 18 - SCM update config */
#define ECAN_SCM_UPDATE_CONFIG_DLC  0u

/* 20 - LRU Maintenance Request */
#define ECAN_MAINTENANCE_REQUEST_DLC 6u

/* 21 - Memory Response */
#define ECAN_MEMORY_RESPONSE_DLC    8u

/* 22 - Power Cycle Request */
#define ECAN_POWER_CYCLE_REQUEST_DLC 1u

/* 25 - LRU Temperature Request */
#define ECAN_TEMP_REQUEST_DLC       0u

/* 26 - LRU Temperature Response */
#define ECAN_TEMP_RESPONSE_DLC      6u

/* 29 - Serial/PN Request */
#define ECAN_SN_REQUEST_DLC         0u

/* 30 - Serial Number Response */
#define ECAN_SN_RESPONSE_DLC        SN_NUM_BYTES

/* 31 - Actuator Parameter Download */
#define ECAN_PARAM_DLC              3u

/* 32 - Assembly Part Number Response */
#define ECAN_ASSY_PN_RESPONSE_DLC   ASSY_PN_NUM_BYTES

/* 33 - Software Part Number Response */
#define ECAN_SW_PN_RESPONSE_DLC     SW_PN_NUM_BYTES

/* 34 - Privacy Divider Request */
#define ECAN_PRIV_DIV_DLC           1u

/* 35 - Power Reduction */
#define ECAN_POWER_REDUCTION_DLC    1u

/* 36 - Hardware Part Number Response */
#define ECAN_HW_PN_RESPONSE_DLC     HW_PN_NUM_BYTES

/* 37 - Raw ADC Request */
#define ECAN_RAW_ADC_REQUEST_DLC    1u

/* 38 - Raw ADC Response */
#define ECAN_RAW_ADC_RESPONSE_DLC   2u

/* 39 - Config Part Number Response */
#define ECAN_CFG_PN_RESPONSE_DLC    CFG_PN_NUM_BYTES

/* 40 - Raw Position Output */
#define ECAN_RAW_POS_OUTPUT_DLC     8u

/* 41 - Raw Position Request */
#define ECAN_POS_OUTPUT_REQUEST_DLC 1u

/* 42 Passenger control */
#define ECAN_PAX_CONTROL_DLC        8u

/* 43 Obstacle debug control */
#define ECAN_OBS_DEBUG_CONTROL_DLC  5u

/* 44 - Brake Position Output */
#define CAN_RAW_BRK_POS_OUTPUT_DLC  2u

/* 45 - Brake Retry Output */
#define ECAN_BRK_RETRY_OUTPUT_DLC   4u

/* 46 - Peripheral Status */
#define ECAN_PERIPH_STATUS_DLC      3u
/* 46 - Peripheral Status */
#define ECAN_TSPCU_LIGHT_REP_DLC    8u


/* 47 - Obstacle debug reply part 1 */
#define ECAN_OBSTACLE_DEBUG_1_DLC   8u

/* 48 - Obstacle debug reply part 1 */
#define ECAN_OBSTACLE_DEBUG_2_DLC   8u

/* 50 - Button Command */
#define ECAN_BUTTON_CMD_DLC         8u

/* 53 - Error Report */
#define ECAN_ERROR_REPORT_DLC       3u

/* 57 - Software Version Request */
#define ECAN_SW_VER_REQUEST_DLC     0u

/* 58 - Software Version Response */
#define ECAN_SW_VER_RESPONSE_DLC    4u

/* 64 - Flight Mode Data */
#define ECAN_FLIGHT_MODE_DATA_DLC   // variable

/* 65 - Event Report part 1 */
#define ECAN_EVENT_REPORT_PART_1_DLC 8u

/* 66 - Event Report part 1 */
#define ECAN_EVENT_REPORT_PART_2_DLC 8u

/* 67 - Event Report part 1 */
#define ECAN_EVENT_REPORT_PART_3_DLC 8u

/* 68 - Event Report Clear */
#define ECAN_LRU_EVENT_CLEAR_DLC        sizeof(LRU_EVENT_CLEAR_FRAME)
/******************************************************************************/
/* 68 - Event report clear message frame                                      */
/******************************************************************************/
typedef struct __attribute__((packed))
{
    union
    {
        INT16U Event_ID; /* LRU_EVENT_CODES enum type, sent big endian */
        struct
        {
            INT8U Event_ID_MS;
            INT8U Event_ID_LS;
        };
    };
} LRU_EVENT_CLEAR_FRAME;

/* 69 - LRU New BootLoader CRC Fail */
#define ECAN_LRU_NEW_BL_CRC_FAIL_DLC 8u

/* 70 - Reprogram Request*/
#define ECAN_REPROGRAM_REQUEST_DLC  1u
#define ECAN_REPROGRAM_REQUEST_CODE 0x55

/* 71 - Reprogram Setup */
#define ECAN_REPROGRAM_SETUP_DLC    8u

/* 72 - Reprogram Payload */
#define ECAN_REPROGRAM_PAYLOAD_DLC  8u

/* 73 - Reprogram Checksum */
#define ECAN_REPROGRAM_CKSUM_DLC    2u

/* 74 - Reprogram ACK */
#define ECAN_REPROGRAM_ACK_DLC      1u

/* 75 - Reprogram Confirm ACK */
#define ECAN_REPROGRAM_CONF_DLC     1u

/* 76 - Reprogram Complete */
#define ECAN_REPROGRAM_COMPLETE_DLC 0

/* 114 - BITE MODE COMPLETE Messages */
#define ECAN_BITE_MODE_COMPLETE_DLC 7u

/* 128 - Event Log Erase Command */
#define ECAN_EVENT_LOG_ERASE_DLC    8u
#define ECAN_EVENT_LOG_ERASE_CODE   {'E','R','A','S','E','L','O','G'}

/* 150 - Motor Model Param Update*/
#define ECAN_MOTOR_PARAM_DLC        5u

/* 300 - Lab mode - debug message */
#define ECAN_LAB_MODE_DEBUG_DLC /* variable */

/*********************************************************************************************
 * Module type definitions
 ********************************************************************************************/
/******************************************************************************/
/* LRU CAN IDs by name                                                        */
/******************************************************************************/
typedef enum
{
    MAINT_PC_CAN_ID         = 0x00,     /* Maintenance PC */
    DEBUG_DEST_CAN_ID       = 0x01,     /* Debug messages */
    BROADCAST_DEST_CAN_ID   = 0x10,     /* CAN ID for broadcast messages */
    HARNESS_CAN_ID          = 0x1F,     /* CAN ID for wire harness fault messages */
    SCM_CAN_ID              = 0x20,     /* Seat Control Module */
    /* ACT 1 - 20 CAN ID 0x21 - 0x34 specified in config table */
    /* CTME D(1 - 5) & E(1 - 5) CAN ID 0x35 - 0x3E specified in config table */
    RESERVED_CAN_ID         = 0x3F,     /* Reserved CAN ID */
    UNCAL_PERIPH_CAN_ID     = 0x40,     /* un-calibrated peripheral */
    /* PM 1 - 16 CAN ID 0x41 - 0x50 specified in config table */
    UNKNOWN_ACT_CAN_ID      = 0x51,     /* CAN id if config table corrupted */
    UNKNOWN_LUMBAR_CAN_ID   = 0x52,     /* CAN id if config table corrupted */
    UNKNOWN_CTM_CAN_ID      = 0x53,     /* CAN id if config table corrupted */
    UNKNOWN_PCU_CAN_ID      = 0x54,     /* CAN id if config table corrupted */
    /* Lumbar 1 - 8 CAN ID 0x60 - 0x67 specified in config table */
    /* (TS)PCU 1 - 8 CAN ID 0x68 - 6F specified in config table */
    SM_CAN_ID               = 0x70,     /* Suite Module */
} CANBUS_LRU_IDS;

/******************************************************************************/
/* CAN message Server IDs by name */
/******************************************************************************/
typedef enum
{
    ECAN_LRU_STATUS_SID                     = 2u,
    ECAN_DF_ERASE_STATUS_SID                = 3u,
    ECAN_LRU_CRC_FAIL_SID                   = 4u,
    ECAN_BITE_ERROR_SID                     = 6u,
    ECAN_LRU_ACTION_CMD_SID                 = 7u,
    ECAN_MOTION_COMMAND_SID                 = 7u,
    ECAN_IMPENDING_SHUTDOWN_SID             = 8u,
    ECAN_BOOT_SELECT_SID                    = 10u,
    ECAN_MEMORY_REQUEST_SID                 = 11u,
    ECAN_CFG_STATUS_REQ_SID                 = 13u,
    ECAN_CFG_STS_RESP_ACT_SID               = 14u,
    ECAN_CFG_STS_RESP_MISC_SID              = 15u,
    ECAN_SCM_UPDATE_CONFIG_SID              = 18u,
    ECAN_MAINTENANCE_FAULT_SID              = 20u,
    ECAN_MEMORY_RESPONSE_SID                = 21u,
    ECAN_REBOOT_RQ_SID                      = 22u,
    ECAN_TEMP_REQUEST_SID                   = 25u,
    ECAN_TEMP_RESPONSE_SID                  = 26u,
    ECAN_PDM_CURRENT_REQUEST_SID            = 27u,
    ECAN_PDM_CURRENT_RESPONSE_SID           = 28u,
    ECAN_SN_REQUEST_SID                     = 29u,
    ECAN_SN_RESPONSE_SID                    = 30u,
    ECAN_PARAM_SID                          = 31u,
    ECAN_ASSY_PN_RESPONSE_SID               = 32u,
    ECAN_SW_PN_RESPONSE_SID                 = 33u,
    ECAN_PRIV_DIV_SID                       = 34u,
    ECAN_POWER_REDUCTION_SID                = 35u,
    ECAN_HW_PN_RESPONSE_SID                 = 36u,
    ECAN_RAW_ADC_REQUEST_SID                = 37u,
    ECAN_RAW_ADC_RESPONSE_SID               = 38u,
    ECAN_CFG_PN_RESPONSE_SID                = 39u,
    ECAN_RAW_POS_OUTPUT_SID                 = 40u,
    ECAN_POS_OUTPUT_REQUEST_SID             = 41u,
    ECAN_PAX_CONTROL_SID                    = 42u,
    ECAN_OBS_DEBUG_CONTROL_SID              = 43u,
    ECAN_RAW_BRK_POS_OUTPUT_SID             = 44u,
    ECAN_BRK_RETRY_OUTPUT_SID               = 45u,
    ECAN_TSPCU_LIGHT_REP_SID                = 46u,
    ECAN_OBSTACLE_DEBUG_1_SID               = 47u,
    ECAN_OBSTACLE_DEBUG_2_SID               = 48u,
            
    ECAN_OBSTACLE_DEBUG_3_SID               = 151u,
    ECAN_OBSTACLE_DEBUG_4_SID               = 152u,
            
    ECAN_TSPCU_LUM_SPEED_SID                = 49u,
    ECAN_TSPCU_CMD_SID                      = 50u,
    ECAN_ACT_POS_CURR_SID                   = 52u,
    ECAN_ERROR_REPORT_SID                   = 53u,
    ECAN_ACT_POS_SID                        = 54u,
    ECAN_SCM_PRESET_STATUS_SID              = 55u,
    ECAN_TTL_STATUS_SID                     = 56u,
    ECAN_SW_VER_REQUEST_SID                 = 57u,
    ECAN_SW_VER_RESPONSE_SID                = 58u,
//    ECAN_HIST_RQ_SID                        = 61u,
//    ECAN_HIST_RSP_SID                       = 62u,
    ECAN_RED_LED_REQ_SID                    = 63u,
    ECAN_FLIGHT_MODE_DATA_SID               = 64u,
    ECAN_EVENT_REPORT_PART_1_SID            = 65u,
    ECAN_EVENT_REPORT_PART_2_SID            = 66u,
    ECAN_EVENT_REPORT_PART_3_SID            = 67u,
    ECAN_LRU_EVENT_CLEAR_SID                = 68u,
    ECAN_LRU_NEW_BL_CRC_FAIL_SID            = 69u,
    ECAN_REPROGRAM_REQUEST_SID              = 70u,
    ECAN_REPROGRAM_SETUP_SID                = 71u,
    ECAN_REPROGRAM_PAYLOAD_SID              = 72u,
    ECAN_REPROGRAM_CKSUM_SID                = 73u,
    ECAN_REPROGRAM_ACK_SID                  = 74u,
    ECAN_REPROGRAM_CONF_SID                 = 75u,
    ECAN_REPROGRAM_COMPLETE_SID             = 76u,
    ECAN_ENGAGED_SID                        = 77u,
    ECAN_MAINT_ACK_SID                      = 78u,
    ECAN_VALIDATE_REQ_SID                   = 79u,
    ECAN_HWPN_PASSTHRU_ACT1_SID             = 80u,
    ECAN_SWPN_PASSTHRU_ACT1_SID             = 81u,
    ECAN_HWPN_PASSTHRU_ACT2_SID             = 82u,
    ECAN_SWPN_PASSTHRU_ACT2_SID             = 83u,
    ECAN_HWPN_PASSTHRU_ACT3_SID             = 84u,
    ECAN_SWPN_PASSTHRU_ACT3_SID             = 85u,
    ECAN_HWPN_PASSTHRU_ACT4_SID             = 86u,
    ECAN_SWPN_PASSTHRU_ACT4_SID             = 87u,
    ECAN_HWPN_PASSTHRU_ACT5_SID             = 88u,
    ECAN_SWPN_PASSTHRU_ACT5_SID             = 89u,
    ECAN_HWPN_PASSTHRU_ACT6_SID             = 90u,
    ECAN_SWPN_PASSTHRU_ACT6_SID             = 91u,
    ECAN_HWPN_PASSTHRU_ACT7_SID             = 92u,
    ECAN_SWPN_PASSTHRU_ACT7_SID             = 93u,
    ECAN_HWPN_PASSTHRU_ACT8_SID             = 94u,
    ECAN_SWPN_PASSTHRU_ACT8_SID             = 95u,
    ECAN_HWPN_PASSTHRU_LUM1_SID             = 96u,
    ECAN_SWPN_PASSTHRU_LUM1_SID             = 97u,
    ECAN_HWPN_PASSTHRU_LUM2_SID             = 98u,
    ECAN_SWPN_PASSTHRU_LUM2_SID             = 99u,
    ECAN_HWPN_PASSTHRU_SCM_SID              = 100u,
    ECAN_SWPN_PASSTHRU_SCM_SID              = 101u,
    ECAN_HWPN_PASSTHRU_TSPCU1_SID           = 102u,
    ECAN_SWPN_PASSTHRU_TSPCU1_SID           = 103u,
    ECAN_HWPN_PASSTHRU_TSPCU2_SID           = 104u,
    ECAN_SWPN_PASSTHRU_TSPCU2_SID           = 105u,
    ECAN_LRU_MAINT_SID                      = 106u,
    ECAN_SYS_RESET_SID                      = 107u,
    ECAN_CURR_FAULTS_ACT_SID                = 108u,
    ECAN_CURR_FAULTS_PL_SID                 = 109u,

    ECAN_HIST_FAULT_REQ_SID                 = 110u,
    ECAN_HIST_FAULT_END_SID                 = 111u,
    ECAN_HIST_FAULT_RSP_SID                 = 112u,
            
    ECAN_BITE_MODE_COMPLETE_SID             = 114u,
    ECAN_DIAGNOSTIC_REQ_SID                 = 115u,
    ECAN_DIAGNOSTIC_RSP_SID                 = 116u,
    ECAN_SCREEN_RESP_SID                    = 122u,
    ECAN_CAL_RESP_SID                       = 123u,
    ECAN_LRU_RPT_MSG_SID                    = 125u,
    ECAN_TSPCU_REBOOT_MSG_SID               = 127u,
    ECAN_TSPCU_CMD_EXT_SID                  = 128u,
    ECAN_EVENT_LOG_ERASE_SID                = 128u,
    ECAN_MODEL_PARAM_SID                    = 150u,
    ECAN_LAB_MODE_DEBUG_SID                 = 300u,
    ECAN_SID_MAX                            = 0x1FFu, /* 511 */
} ECAN_SIDS;

/* TSPCU Speed Update */
#define ECAN_TSPCU_LUM_SPEED_DLC    5u

/* TSPCU Key Command */
#define ECAN_TSPCU_CMD_DLC          8u

#define ECAN_ACT_POS_CURR_DLC       5

typedef struct
{
    /* BITE_MODE_COMPLETE byte 1 */
    INT8U act_id;
    union
    {
        struct
        {
            /* BITE_MODE_COMPLETE byte 2 */
            INT8U motor_over_temp          : 1;  // LSB
            INT8U stepper_over_temp        : 1;
            INT8U pcb_over_temp            : 1;
            INT8U overcurrent              : 1;
            INT8U critical_overcurrent     : 1;
            INT8U actuation_failure        : 1;
            INT8U motorchip_failure        : 1;
            INT8U motor_temp_critical      : 1;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } act_faults;
    union
    {
        struct
        {
            /* BITE_MODE_COMPLETE byte 3 */
            INT8U stepper_temp_critical     : 1;  // LSB
            INT8U pcb_temp_critical         : 1;
            INT8U reserved                  : 1;
            INT8U repeted_obstacle_detected : 1;
            INT8U brake_dis_failure         : 1;
            INT8U app_crc_failure           : 1;
            INT8U mech_brake_failure        : 1;
            INT8U rep_mech_brake_failure    : 1;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } act_faults_cont;
    union
    {
        struct
        {
            /* BITE_MODE_COMPLETE byte 4 */
            INT8U lum_1_installed          : 1;  // LSB
            INT8U lum_2_installed          : 1;
            INT8U reserved                 : 6;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } lum_installed;
    union
    {
        struct
        {
            /* BITE_MODE_COMPLETE byte 5 */
            INT8U motor_over_temp          : 1;  // LSB
            INT8U app_firmware_crc         : 1;
            INT8U config_data_crc          : 1;
            INT8U config_data_range        : 1;
            INT8U pcb_overtemp             : 1;
            INT8U overcurrent              : 1;
            INT8U overpressure             : 1;
            INT8U pneumatic_failure        : 1;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } lum_1_faults;
    union
    {
        struct
        {
            /* BITE_MODE_COMPLETE byte 5 */
            INT8U motor_over_temp          : 1;  // LSB
            INT8U app_firmware_crc         : 1;
            INT8U config_data_crc          : 1;
            INT8U config_data_range        : 1;
            INT8U pcb_overtemp             : 1;
            INT8U overcurrent              : 1;
            INT8U overpressure             : 1;
            INT8U pneumatic_failure        : 1;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } lum_2_faults;
    union
    {
        struct
        {
            /* BITE_MODE_COMPLETE byte 7 */
            INT8U bite_time_out            : 1;  // LSB
            INT8U reserved                 : 7;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } bite_status;
} LRU_BITEMODE_COMPLETE_FRAME;

/* Actuator Position */
#define ECAN_ACT_POS_DLC            8u

/* Preset Status */

/* TTL Status */
#define ECAN_TTL_STATUS_DLC         1u

/* Error History Request */
#define ECAN_HIST_RQ_DLC            4u

/* Error History Response */
#define ECAN_HIST_RSP_DLC           6u

/* Red LED Command On/Off */
#define ECAN_RED_LED_REQ_DLC        1u
typedef enum
{
    COMM_RED_LED_CMD_OFF    = 0,
    COMM_RED_LED_CMD_ON     = 1,
} RED_LED_COMMAND;

/* Reprog Request */
#define ECAN_PROG_RQ_DLC            1u

/* Reprog Setup */
typedef struct
{
    INT32U start_address;
    INT32U data_length;
} ECAN_PROG_SETUP_FRAME;
#define ECAN_PROG_SETUP_DLC         8u

/* Reprog Checksum */
#define ECAN_PROG_CKSUM_DLC         2u

/* Reprog Confirm ACK */
#define ECAN_PROG_CONF_DLC          1u

/* Maintenance Mode Engaged */
#define ECAN_ENGAGED_DLC            0u

/* Maintenance Mode Engaged ACK */
#define ECAN_MAINT_ACK_DLC          0u

/* Validation Request */
#define ECAN_VALIDATE_REQ_DLC       1u

/* LRU Maintenance Status Message */
typedef struct
{
    union
    {
        struct
        {
            /* Status byte 1 */
            INT8U scm_maint         : 1;  // LSB
            INT8U act_2_maint       : 1;
            INT8U act_3_maint       : 1;
#if defined(ETIHAD)
            INT8U pcs_maint         : 1;
#else
            INT8U lcu_maint         : 1;
#endif
            INT8U pdm_maint         : 1;
            INT8U reserved          : 3;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } lru_mode;
#if defined(GEN_2_SCM)
    union
    {
        struct
        {
            /* Status byte 2 */
            INT8U dot_forward       : 1;  // LSB
            INT8U dot_backward      : 1;
            INT8U reserved          : 6;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } dot_status;
    union
    {
        struct
        {
            /* Status byte 3 */
            INT8U seat_cal_in_prog  : 1;  // LSB
            INT8U pd_cal_in_prog    : 1;
            INT8U seat_calibrated   : 1;
            INT8U pd_calibrated     : 1;
            INT8U reserved          : 4;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } cal_status;
#else
    union
    {
        struct
        {
            /* Status byte 2 */
            INT8U cal_required      : 1;  // LSB
            INT8U reserved          : 7;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } cal_status;
    union
    {
        struct
        {
            /* Status byte 3 */
            INT8U seat_cal_in_prog  : 1;  // LSB
            INT8U reserved          : 7;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } cal_in_progress;
#endif
} LRU_MAINT_STATUS_FRAME;
#define ECAN_LRU_MAINT_DLC          3u

/* System Reset */
#define ECAN_SYS_RESET_DLC          0u

/* Current Faults Messages */
#define ECAN_CURR_FAULTS_ACT_DLC    4u
#if defined(ETIHAD)
#define ECAN_CURR_FAULTS_PL_DLC     3u
#else
#define ECAN_CURR_FAULTS_PL_DLC     5u
#endif

/* 2-Way Switch Test Messages */
#if defined(GEN_2_SCM)
#define ECAN_SEAT_2WAY_SWITCH_DLC   2
#define TWO_WAY_SWITCH_TTL          0x0001
#define TWO_WAY_SWITCH_BED          0x0002
#define TWO_WAY_SWITCH_PCS_INF      0x0004
#define TWO_WAY_SWITCH_PCS_DEF      0x0008
#define TWO_WAY_SWITCH_MOOD_TOG     0x0010
#define TWO_WAY_SWITCH_READ_TOG     0x0020
#define TWO_WAY_SWITCH_FEAT_TOG     0x0040
#define TWO_WAY_SWITCH_TASK_FWD     0x0080
#define TWO_WAY_SWITCH_TASK_BACK    0x0100
#define TWO_WAY_SWITCH_PRIV_UP      0x0200
#define TWO_WAY_SWITCH_PRIV_DN      0x0400
#else
#define ECAN_SEAT_2WAY_SWITCH_DLC   1
#define TWO_WAY_SWITCH_NONE         0x00
#define TWO_WAY_SWITCH_TTL          0x01
#define TWO_WAY_SWITCH_LOUNGE       0x02
#define TWO_WAY_SWITCH_BED          0x04
#endif

/* Screen Request */
#define ECAN_SCREEN_REQ_DLC         0u

/* Screen Response */
typedef struct
{
    union
    {
        struct
        {
#ifdef ETIHAD
            INT8U maint_home         : 1;  /* 0x01  LSB */
            INT8U historic_faults_1  : 1;  /* 0x02      */
            INT8U current_faults     : 1;  /* 0x04      */
            INT8U sys_status_diag    : 1;  /* 0x08      */
            INT8U historic_faults_2  : 1;  /* 0x10      */
            INT8U curr_hist_menu     : 1;  /* 0x20      */
            INT8U reserved           : 2;  /* 0xC0  MSB */
#else
            INT8U application        : 1;  /* 0x01  LSB */
            INT8U maint_home         : 1;  /* 0x02      */
            INT8U historic_faults_1  : 1;  /* 0x04      */
            INT8U current_faults     : 1;  /* 0x08      */
            INT8U sys_status_diag    : 1;  /* 0x10      */
            INT8U historic_faults_2  : 1;  /* 0x20      */
            INT8U curr_hist_menu     : 1;  /* 0x40      */
            INT8U reserved           : 1;  /* 0x80  MSB */
#endif
        };

        struct
        {
            INT8U byte;
        };
    };
} SCREEN_RESP_B0_TYPE;
#define ECAN_SCREEN_RESP_DLC        1u

/* Calibration Response */
#define ECAN_CAL_RESP_DLC           1u
typedef enum
{
    COMM_CAL_RESP_FAIL         = 0,
    COMM_CAL_RESP_SEAT_SUCCESS = 1,
    COMM_CAL_RESP_PD_SUCCESS   = 2,
} COMM_CAL_RESP;

/* TSPCU Reboot Request */
#define ECAN_TSPCU_REBOOT_MSG_DLC   1
typedef struct
{
    union
    {
        struct
        {
            INT8U scm_maint_only     : 1;  /* 0x01  LSB */
            INT8U all_lrus_maint     : 1;  /* 0x02      */
            INT8U all_lrus_app       : 1;  /* 0x04      */
            INT8U reserved           : 5;  /* 0xF1  MSB */
        };

        struct
        {
            INT8U byte;
        };
    };
} TSPCU_REBOOT_FRAME_B0;

/* TSPCU Command Extended*/
typedef struct
{
    union
    {
        struct
        {
            INT8U priv_cal_cancel    : 1;  /* 0x01  LSB */
            INT8U priv_cal_start     : 1;  /* 0x02      */
            INT8U priv_bite_cancel   : 1;  /* 0x04      */
            INT8U seat_bite_cancel   : 1;  /* 0x08      */
            INT8U recline_current    : 1;  /* 0x10      */
            INT8U seatpan_current    : 1;  /* 0x20      */
            INT8U privacy_current    : 1;  /* 0x40      */
            INT8U reserved           : 1;  /* 0x80  MSB */
        };

        struct
        {
            INT8U byte;
        };
    };
} TSPCU_CMD_EXT_B0;
#define ECAN_TSPCU_CMD_EXT_DLC          1u

/*******************************************************
 *
 * Maintenance mode/reprogramming
 *
 *******************************************************/
typedef struct
{
    union
    {
        struct
        {
            INT8U ready_to_run       : 1;  /* 0x01  LSB */
            INT8U over_temperature   : 1;  /* 0x02      */
            INT8U invalid_checksum   : 1;  /* 0x04      */
            INT8U invalid_address    : 1;  /* 0x08      */
            INT8U reprog_timeout     : 1;  /* 0x10      */
            INT8U reprog_successful  : 1;  /* 0x20      */
            INT8U reprog_failed      : 1;  /* 0x40      */
            INT8U mem_req_invalid    : 1;  /* 0x80  MSB */
        };

        struct
        {
            INT8U byte;
        };
    };
} REPROG_STATUS_B1;

/*******************************************************
 *
 * LCU Specific
 *
 *******************************************************/
/* Configuration parameter IDs set via
   CAN Configuration parameter messages */
typedef enum
{
    LCU_CONFIG_PARAM_ID_MOTOR_TEMPS = 0,
    LCU_CONFIG_PARAM_ID_PCB_TEMPS = 1,
    LCU_CONFIG_PARAM_ID_MAX_SOLENOID_CURRENT = 2,
    LCU_CONFIG_PARAM_ID_MAX_MOTOR_CURRENT = 3,
    LCU_CONFIG_PARAM_ID_MAX_CURRENT = 4,
    LCU_CONFIG_PARAM_ID_MIN_SYS_PRESSURE = 5,
    LCU_CONFIG_PARAM_ID_MAX_PUMP_ROTATIONS = 6,
    LCU_CONFIG_PARAM_ID_MIN_PUMP_ROTATIONS = 7,
    LCU_CONFIG_PARAM_ID_SPEED = 8,
    LCU_CONFIG_PARAM_ID_BAG1_PRESSURES_LOW = 9,
    LCU_CONFIG_PARAM_ID_BAG1_PRESSURES_HIGH = 10,
    LCU_CONFIG_PARAM_ID_BAG2_PRESSURES_LOW = 11,
    LCU_CONFIG_PARAM_ID_BAG2_PRESSURES_HIGH = 12,
    LCU_CONFIG_PARAM_ID_BAG3_PRESSURES_LOW = 13,
    LCU_CONFIG_PARAM_ID_BAG3_PRESSURES_HIGH = 14,
    LCU_CONFIG_PARAM_ID_BAG4_PRESSURES_LOW = 15,
    LCU_CONFIG_PARAM_ID_BAG4_PRESSURES_HIGH = 16,
} LCU_CONFIG_PARAM_IDS;
/* Status from LRU to SCM */
#define ECAN_LUMBAR_APP_TEMP_RSP_DLC           5u
#define ECAN_LUMBAR_MAINT_TEMP_RSP_DLC         2u
typedef struct
{
    INT8S motor_temp_1;
    INT8S motor_temp_2;
    INT8S motor_temp_3;
    INT8S motor_temp_4;
    INT8S pcb_temp;
} LCU_TEMP_RSP_FRAME;
/* LCU->SCM Status Frame */
typedef struct
{
    INT8S pressure_bag_1;
    INT8S pressure_bag_2;
    INT8S pressure_bag_3;
    INT8S pressure_bag_4;
    INT16U current;
    union
    {
        struct
        {
            /* Status byte 1 */
            INT8U motor_temps_ok        : 1;  // LSB
            INT8U reserved_1            : 1;  /* removed 4/2/15 was hold_pressure_ok */
            INT8U continued_run_ok      : 1;
            INT8U pneumatics_in_hold    : 1;
            INT8U app_fw_crc_ok         : 1;
            INT8U pcb_temp_ok           : 1;
            INT8U                       : 1;
            INT8U current_ok            : 1;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } status_b1;
    union
    {
        struct
        {
            /* Status byte 2 */
            INT8U over_pressure_ok          : 1;  // LSB
            INT8U pneumatic_function_ok     : 1;
            INT8U solenoid_over_current_ok  : 1;
            INT8U param_vars_ok             : 1;
            INT8U pump_motor_control_ok     : 1;
            INT8U pressure_sensor_ok        : 1;
            INT8U cfg_table_crc_ok          : 1;
            INT8U cfg_data_range_ok         : 1;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } status_b2;
} LCU_APP_STATUS_FRAME;

typedef struct
{
    REPROG_STATUS_B1   byte1;
    union
    {
        struct
        {
            INT8U err_check_in_progress       : 1;  /* 0x01  LSB */
            INT8U firmware_crc_error          : 1;  /* 0x02      */
            INT8U cfg_table_crc_error         : 1;  /* 0x04      */
            INT8U cfg_table_data_range_error  : 1;  /* 0x08      */
            INT8U cfg_table_error_fixed       : 1;  /* 0x10      */
            INT8U reserved                    : 3;
        };

        struct
        {
            INT8U byte;
        };
    } byte2;
    INT8U          byte3;    /* Table number where CRC or range check error was detected. */
    INT8U          byte4;    /* Item number where range check error was detected. */
} LCU_MAINT_STATUS_FRAME;

typedef enum
{
    LUM_MOTION_HOLD = 0,
    LUM_MOTION_INFLATE = 1,
    LUM_MOTION_DEFLATE = 2,
    LUM_MOTION_OFF = 3,
    LUM_MOTION_MASG_SYNC = 11,
    LUM_MOTION_MASG_ALT = 12,
} LUM_BAG_MOTION_OPER;
typedef enum
{
    LUM_MASG_NONE = 0,
    LUM_MASG_SYNC = 1,
    LUM_MASG_ALT = 2,
} LUM_BAG_MASG_MODE;
typedef struct
{
    INT8U motion_bag_1;
    INT8U motion_bag_2;
    INT8U motion_bag_3;
    INT8U motion_bag_4;
    INT8U sequence_bag_12;
    INT8U sequence_bag_34;
} LCU_MOTION_CMD_FRAME;
#define ECAN_LUMBAR_APP_STATUS_DLC         8u
#define ECAN_LUMBAR_MAINT_STATUS_DLC       4u

#define ECAN_CONFIG_MOTOR_TEMPS_DLC             3u
#define ECAN_CONFIG_PCB_TEMPS_DLC               3u
#define ECAN_CONFIG_MAX_SOLENOID_CURRENT_DLC    3u
#define ECAN_CONFIG_MAX_MOTOR_CURRENT_DLC       3u
#define ECAN_CONFIG_MAX_CURRENT_DLC             3u
#define ECAN_CONFIG_MIN_SYS_PRESSURES_DLC       3u
#define ECAN_CONFIG_MAX_PUMP_ROTATIONS_DLC      3u
#define ECAN_CONFIG_MIN_PUMP_ROTATIONS_DLC      3u
#define ECAN_CONFIG_SPEED_DLC                   5u
#define ECAN_CONFIG_BAG1_PRESSURES_LOW_DLC      3u
#define ECAN_CONFIG_BAG1_PRESSURES_HIGH_DLC     3u
#define ECAN_CONFIG_BAG2_PRESSURES_LOW_DLC      3u
#define ECAN_CONFIG_BAG2_PRESSURES_HIGH_DLC     3u
#define ECAN_CONFIG_BAG3_PRESSURES_LOW_DLC      3u
#define ECAN_CONFIG_BAG3_PRESSURES_HIGH_DLC     3u
#define ECAN_CONFIG_BAG4_PRESSURES_LOW_DLC      3u
#define ECAN_CONFIG_BAG4_PRESSURES_HIGH_DLC     3u

/*******************************************************
 *
 * SCM Specific
 *
 *******************************************************/
#define ECAN_SCM_TEMP_RSP_DLC   2u

/* Status from SCM */
#define SCM_APP_STATUS_FAULT_MASK_B1 0b11101111

/* SCM App Status Frame */
typedef struct
{
    union
    {
        struct
        {
            /* Status byte 1 */
            INT8U overtemperature           : 1;  // LSB
            INT8U impending_shut_down       : 1;
            INT8U memory_failure            : 1;
            INT8U pax_overcurrent           : 1;
            INT8U pbit_passed               : 1;
            INT8U reserved_5                : 1;
            INT8U config_data_crc_error     : 1;
            INT8U config_data_range_error   : 1;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } status_b1;

    union
    {
        struct
        {
            /* Status byte 4 */
            INT8U act_1_valid   : 1;  // LSB
            INT8U act_2_valid   : 1;
            INT8U act_3_valid   : 1;
            INT8U act_4_valid   : 1;
            INT8U act_5_valid   : 1;
            INT8U act_6_valid   : 1;
            INT8U act_7_valid   : 1;
            INT8U act_8_valid   : 1;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } status_b2;
    INT16U pax_current;
} SCM_APP_STATUS_FRAME;
#define ECAN_SCM_STATUS_APP_DLC         4u

/* SCM Maint Status Frame */
#define SCM_MAINT_STATUS_FAULT_MASK_B1 0b11011110
#define SCM_MAINT_STATUS_FAULT_MASK_B2 0b00011110

typedef struct
{
    REPROG_STATUS_B1 status_b1;
    union
    {
        struct
        {
            /* Status byte 2 */
            INT8U error_check_in_prog       : 1;  // LSB
            INT8U firmware_crc_error        : 1;
            INT8U config_table_crc_error    : 1;
            INT8U config_data_range_error   : 1;
            INT8U config_data_error_fixed   : 1;
            INT8U pax_overcurrent           : 1;
            INT8U reserved0                 : 2;  //MSB
        };
        struct
        {
            INT8U raw;
        };
    } status_b2;
    INT8U range_check_table_id;
    INT8U range_check_item_id;
    union
    {
        struct
        {
            /* Status byte 5 */
            INT8U diagnostic_complete       : 1;  // LSB
            INT8U diagnostic_in_progress    : 1;
            INT8U bite_complete             : 1;
            INT8U bite_in_progress          : 1;
            INT8U priv_bite_in_progress     : 1;
            INT8U priv_bite_complete        : 1;
            INT8U reserved0                 : 2;  //MSB
        };
        struct
        {
            INT8U raw;
        };
    } status_b5;
} SCM_MAINT_STATUS_FRAME;

#define ECAN_SCM_STATUS_MAINT_DLC         5u

/* SCM->PDM Preset Status Frame */
typedef struct
{
    INT8U at_ttl;               /* 0x0: Not at TTL, 0x1: At TTL */
    INT8U at_preset2;           /* 0x0: Not at Preset, 0x1: At Preset */
    INT8U at_preset3;           /* 0x0: Not at Preset, 0x1: At Preset */
    INT8U at_preset4;           /* 0x0: Not at Preset, 0x1: At Preset */
    INT8U at_mem_preset;        /* 0x0: Not at Preset, 0x1: At Preset */
    INT8U in_motion;            /* 0x0: Not in Motion, 0x1: In Motion */
    INT8U massage_active_lum1;  /* 0x0: Massage not Active, 0x1: Massage Active */
    INT8U massage_active_lum2;  /* 0x0: Massage not Active, 0x1: Massage Active */
} PDM_PRESET_STATUS_FRAME;
#define ECAN_SCM_PRESET_STATUS_DLC         8u


/*******************************************************
 *
 * PDM Specific
 *
 *******************************************************/
#define ECAN_PDM_STATUS_DEST            0x01
#define ECAN_PDM_TEMP_RSP_DLC           6u

/* DOORs ID: PDM.SRS.1152
 * The CAN bus shall output the periodic CAN status message PDM-STATUS
 * within 100 ms after Start-Up and every 20 ms thereafter.
 * Source Dest SID DLC |    D0     |    D1    |   D2
 *   0x00 0x01  2   3  | Status B1 | Status B2| Status B3
 *
 * BIT  Status B1                Status B2                   Status B3
 * 0    PAX 1 under voltage      PAX 1 over temperature      Configuration Table CRC Error
 * 1    PAX 2 under voltage      PAX 2 over temperaturee     Configuration Table Out of Range
 * 2    PAX 1 over voltage       PAX 1 soft over temperature
 * 3    PAX 2 over voltage       PAX 2 soft over temperature
 * 4    PAX 1 over current       Application CRC Error
 * 5    PAX 2 over current       ARINC Error
 * 6    PAX 1 soft over current  PAX1 Impending Shutdown
 * 7    PAX 2 soft over current  PAX2 Impending Shutdown
 *
 */
typedef struct
{
    union
    {
        struct
        {
            /* Status byte 1 */
            INT8U pax1_undervoltage     : 1;  // LSB
            INT8U pax2_undervoltage     : 1;
            INT8U pax1_overvoltage      : 1;
            INT8U pax2_overvoltage      : 1;
            INT8U pax1_overcurrent      : 1;
            INT8U pax2_overcurrent      : 1;
            INT8U pax1_softovercurrent  : 1;
            INT8U pax2_softovercurrent  : 1;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } status_b1;
    union
    {
        struct
        {
            /* Status byte 2 */
            INT8U pax1_overtemperature          : 1;  // LSB
            INT8U pax2_overtemperature          : 1;
            INT8U pax1_soft_overtemperature     : 1;
            INT8U pax2_soft_overtemperature     : 1;
            INT8U application_crc_error         : 1;
            INT8U arinc_error                   : 1;
            INT8U pax1_impending_shutdown       : 1;
            INT8U pax2_impending_shutdown       : 1;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } status_b2;
    union
    {
        struct
        {
            /* Status byte 3 */
            INT8U configuration_crc_error           : 1;  // LSB
            INT8U configuration_out_of_range_error  : 1;
            INT8U unexpected_pax1                   : 1;
            INT8U unexpected_pax2                   : 1;
            INT8U pax1_scm_comm_loss                : 1;
            INT8U pax2_scm_comm_loss                : 1;
            INT8U reserved                          : 2;
        };
        struct
        {
            INT8U raw;
        };
    } status_b3;
} PDM_APP_STATUS_FRAME;

typedef struct
{
    union
    {
        struct
        {
            /* Status byte 1 */
            INT8U pax1_undervoltage     : 1;  // LSB
            INT8U pax2_undervoltage     : 1;
            INT8U pax1_overvoltage      : 1;
            INT8U pax2_overvoltage      : 1;
            INT8U pax1_overcurrent      : 1;
            INT8U pax2_overcurrent      : 1;
            INT8U pax1_softovercurrent  : 1;
            INT8U pax2_softovercurrent  : 1;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } status_b1;
    union
    {
        struct
        {
            /* Status byte 2 */
            INT8U pax1_overtemperature          : 1;  // LSB
            INT8U pax2_overtemperature          : 1;
            INT8U pax1_soft_overtemperature     : 1;
            INT8U pax2_soft_overtemperature     : 1;
            INT8U application_crc_error         : 1;
            INT8U arinc_error                   : 1;
            INT8U pax1_impending_shutdown       : 1;
            INT8U pax2_impending_shutdown       : 1;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } status_b2;
    union
    {
        struct
        {
            /* Status byte 3 */
            INT8U configuration_crc_error           : 1;  // LSB
            INT8U configuration_out_of_range_error  : 1;
            INT8U unexpected_pax1                   : 1;
            INT8U unexpected_pax2                   : 1;
            INT8U pax1_scm_comm_loss                : 1;
            INT8U pax2_scm_comm_loss                : 1;
            INT8U reserved                          : 2;
        };
        struct
        {
            INT8U raw;
        };
    } status_b3;
    union
    {
        struct
        {
            /* Status byte 4 */
            INT8U ready_to_run              : 1;  // LSB
            INT8U reserved                  : 1;
            INT8U invalid_checksum          : 1;
            INT8U invalid_address           : 1;
            INT8U reprog_timeout            : 1;
            INT8U reprog_success            : 1;
            INT8U reprog_failed             : 1;
            INT8U memory_request_failed     : 1;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } status_b4;
} PDM_MAINT_STATUS_FRAME;

typedef struct
{
    INT8U fault_code;
    INT8U failure_category;
    INT8U suspected_lru;

} SCM_MAINTENANCE_FAULT_FRAME;

/* Maintenance Message */
#define SCM_MAINTENANCE_FAULT_DLC        3u

#define ECAN_PDM_APP_STATUS_DLC         3u
#define ECAN_PDM_MAINT_STATUS_DLC       4u

#define ECAN_PDM_CURRENT_RESPONSE_DLC 6u

/*******************************************************
 *
 * UAP Specific
 *
 *******************************************************/

typedef struct
{
    /* Status byte D[6] */
    INT8U sense_1_gnd          : 1;  /* 0x01  LSB */
    INT8U sense_1_high         : 1;  /* 0x02      */
    INT8U sense_2_gnd          : 1;  /* 0x04      */
    INT8U sense_2_high         : 1;  /* 0x08      */
    INT8U sense_3_gnd          : 1;  /* 0x10      */
    INT8U sense_3_high         : 1;  /* 0x20      */
    INT8U reserved             : 2;  /* 0xC0  MSB */
} SENSE_PINS;

typedef struct
{
    /* Status byte D[7] */
    INT8U error_present             : 1;  /* 0x01  LSB */
    INT8U unit_in_bootloader        : 1;  /* 0x02      */
    INT8U obstacle_detected         : 1;  /* 0x04      */
    INT8U param_vars_needed         : 1;  /* 0x08      */
    INT8U motn_stop_due_to_sense    : 1;  /* 0x10      */
    INT8U spare_56                  : 2;  /* 0x60      */
    INT8U term_resistor_enabled     : 1;  /* 0x80  MSB */
} LRU_STATUS_FLAGS;

typedef struct
{
    INT16U current;
    INT16U position;
    INT16U speed;
    union
    {
        SENSE_PINS pin;
        INT8U raw;
    } sense_D6;
    union
    {
        LRU_STATUS_FLAGS flag;
        INT8U raw;
    } status_D7;
} UAP_APP_STATUS_FRAME;

typedef struct
{
    REPROG_STATUS_B1 status_b1;
    union
    {
        struct
        {
            /* Status byte 2 */
            INT8U err_check_in_progress       : 1;  /* 0x01  LSB */
            INT8U firmware_crc_error          : 1;  /* 0x02      */
            INT8U cfg_table_crc_error         : 1;  /* 0x04      */
            INT8U cfg_table_data_range_error  : 1;  /* 0x08      */
            INT8U cfg_table_error_fixed       : 1;  /* 0x10      */
            INT8U reserved                    : 3;
        };
        struct
        {
            INT8U raw;
        };
    } status_b2;
    INT8U range_check_table_id;
    INT8U range_check_item_id;
} UAP_MAINT_STATUS_FRAME;
#define ECAN_UAP_MAINT_STATUS_DLC       4u

typedef enum
{
    LRU_DIAGNOSTIC_STACK_LAST_USED  = 0,
    LRU_DIAGNOSTIC_STACK_END        = 1,
    LRU_DIAGNOSTIC_STACK_START      = 2,
} LRU_DIAGNOSTIC_TYPE_ENUM;

/*******************************************************
 *
 * TSPCU Specific
 *
 *******************************************************/
/* TSPCU->SCM Status Frame */
typedef struct
{
    union
    {
        struct
        {
            /* TSPCU Status */
            INT8U pcb_under_temp        : 1;  // LSB
            INT8U pcb_over_temp         : 1;
            INT8U power_loss            : 1;
            INT8U watchdog_reset        : 1;
            INT8U impending_shutdown    : 1;
            INT8U crc_system_error      : 1;
            INT8U in_maint_mode         : 1;
            INT8U reserved              : 1;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } tspcu_status_bits;
} TSPCU_STATUS_FRAME;
#define ECAN_TSPCU_STATUS_DLC           1u

/*******************************************************
 *
 * PCS Specific
 *
 *******************************************************/
/* PCS->SCM Status Frame */
typedef struct
{

    INT8U current_firmness;
    INT8U target_firmness;
    union
    {
        struct
        {
            /* Pump Motor Status */
            INT8U pump_motor_off    : 1;  // LSB
            INT8U pump_motor_on     : 1;
            INT8U reserved          : 6;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } pump_motor_status;
    union
    {
        struct
        {
            /* Massage Status */
            INT8U massage_off   : 1;  // LSB
            INT8U massage_on    : 1;
            INT8U reserved      : 6;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } massage_status;
    union
    {
        struct
        {
            /* Status byte 1 */
            INT8U pump_failure              : 1;  // LSB
            INT8U valve_block_failure       : 1;
            INT8U lost_comm_to_valve_block  : 1;
            INT8U invalid_temperature       : 1;
            INT8U undervoltage              : 1;
            INT8U weak_system_performance   : 1;
            INT8U reserved                  : 2;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } status_b1;
    union
    {
        struct
        {
            /* Status byte 2 */
            INT8U outlet_5_or_6_blocked     : 1;  // LSB
            INT8U outlet_5_or_6_open        : 1;
            INT8U outlet_4_blocked          : 1;
            INT8U outlet_4_open             : 1;
            INT8U strong_leak_on_outlet_4   : 1;
            INT8U outlet_3_blocked          : 1;
            INT8U strong_leak_on_outlet_3   : 1;
            INT8U outlet_3_open             : 1;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } status_b2;
    union
    {
        struct
        {
            /* Status byte 3 */
            INT8U outlet_2_blocked          : 1;  // LSB
            INT8U strong_leak_on_outlet_2   : 1;
            INT8U outlet_2_open             : 1;
            INT8U outlet_1_blocked          : 1;
            INT8U strong_leak_on_outlet_1   : 1;
            INT8U outlet_1_open             : 1;
            INT8U reserved                  : 2;  // MSB
        };
        struct
        {
            INT8U raw;
        };
    } status_b3;
} PCS_APP_STATUS_FRAME;
#define ECAN_PCS_APP_STATUS_DLC 7u

/* PCS HW Response is 8 bytes */
#define ECAN_PCS_HW_PN_RSP_DLC  8u
/******************************************************************************/
/******************************************************************************/
/* CAN Message data D[0] - D[7] payload definitions ***************************/
/******************************************************************************/
/******************************************************************************/

/******************************************************************************/
/* 2 - LRU Status response message frame                                      */
/******************************************************************************/
/* ECAN_LRU_STATUS_FRAME - LRU status is unique for each LRU see above: */
/* the type is equated in lru-global.h */
/* LCU_APP_STATUS_FRAME */
/* SCM_APP_STATUS_FRAME */
/* PDM_APP_STATUS_FRAME */
/* UAP_APP_STATUS_FRAME */
/* TSPCU_STATUS_FRAME */
/* PCS_APP_STATUS_FRAME */

/******************************************************************************/
/* 4 - LRU CRC Failed frame                                                   */
/******************************************************************************/
/*ECAN_LRU_CRC_FAIL_FRAME is the fixed string "BAD" so assign D[0-2] directly */
/* from ECAN_LRU_CRC_FAIL_CODE                                                */
typedef struct
{
    INT8U B[ECAN_LRU_CRC_FAIL_DLC];
} ECAN_LRU_CRC_FAIL_FRAME;

/******************************************************************************/
/* 7 - LRU action command frame                                               */
/******************************************************************************/
/* ECAN_LRU_ACTION_CMD_FRAME - an incoming Rockwell Collins CAN packet buffer */
/* is parsed as an outgoing RS-485 packet including the CAN identifier        */
/* (source, dest, SID)                                                        */


/******************************************************************************/
/* 8 - Impending Shutdown Command frame                                       */
/******************************************************************************/
/* ECAN_IMPENDING_SHUTDOWN_FRAME is only 1 byte with only the boot code so    */
/*  test D[0] directly                                                        */
typedef enum
{
    IMPENDING_SHUTDOWN = 1,
    POWER_RESTORED     = 2,
} ECAN_IMPENDING_SHUTDOWN_CODE;

/******************************************************************************/
/* 10 - Boot Select Command frame                                             */
/******************************************************************************/
/* ECAN_BOOT_SELECT_FRAME is only 1 byte with only the boot code so           */
/*  load D[0] directly                                                        */
typedef enum
{
    BOOT_TO_APPLICATION_CMD = 0,
    BOOT_TO_BOOTLOADER_CMD  = 1,
} ECAN_BOOT_SELECT_CODES;

/******************************************************************************/
/* 11 - Memory Request message frame                                          */
/******************************************************************************/
typedef union
{
    INT32U address;        /* Received big Endian */
    INT8U  addr_byte[4];   /* Received big Endian */
} ECAN_MEMORY_REQUEST_FRAME;

/******************************************************************************/
/* 20 - Maintenance Request message frame                                     */
/******************************************************************************/
typedef enum /* CAN message fault category codes */
{
    CAN_CATEGORY_A = 0,
    CAN_CATEGORY_B = 1,
    CAN_CATEGORY_C = 2,
} ECAN_MAINTENANCE_REQUEST_CODES;

typedef enum fault_color
{
    FAULT_BLUE,                     // Highest Priority
    FAULT_RED,
    FAULT_AMBER                     // Lowest Priority
} ECAN_MAINTENANCE_FAULT_COLOR;

typedef struct
{
    INT16U  Event_ID;           /* Configured Event ID code, sent big Endian */
    INT8U   Category;           /* ECAN_MAINTENANCE_REQUEST_CODES type */
    INT8U   can_ID;             /* Our CAN ID */
    INT8U   fault_color;        /* ECAN_MAINTENANCE_FAULT_COLOR type */
    INT8U   fault_resolution;   /* ECAN_MAINTENANCE_FAULT_RESOLUTION type */
} ECAN_MAINTENANCE_REQUEST_FRAME;

typedef struct
{
    INT16U  Event_ID;        /* Configured Event ID code, sent big Endian */
    INT8U   Category;        /* ECAN_MAINTENANCE_REQUEST_CODES type */
    INT8U   can_ID;          /* Our CAN ID */
    INT8U   fault_color;     /* ECAN_MAINTENANCE_FAULT_COLOR type */
} ECAN_MAINTENANCE_FAULT_FRAME;

#define ECAN_MAINTENANCE_FAULT_DLC      5u

/* Fault History Request (to SCM) */
#define ECAN_FAULT_HIST_REQ_DLC         4u
typedef struct
{
    INT8U time_frame_high;
    INT8U time_frame_low;
    INT8U max_errors;
    INT8U rate;
} HIST_FAULT_REQ_TYPE;

/* Fault History Response */
#define ECAN_HIST_FAULT_END_DLC         1u
#define ECAN_HIST_FAULT_RSP_DLC         7u
typedef struct
{
    INT8U high_byte;
    INT8U low_byte;
} OCCUR_TIME_TYPE;

typedef struct
{
    INT8U  device_id;
    INT8U  error_num;
    OCCUR_TIME_TYPE first_occurrence;
    OCCUR_TIME_TYPE last_occurrence;
    INT8U  num_occurrences;
} ERROR_HISTORY_RESP_FRAME;

/******************************************************************************/
/* 21 - Memory Response message frame                                         */
/******************************************************************************/
/* ECAN_MEMORY_RESPONSE_FRAME is raw data bytes so load D[0] - D[7] directly  */

/******************************************************************************/
/* 22 - Power Cycle Request frame                                             */
/******************************************************************************/
/* ECAN_POWER_CYCLE_REQUEST_FRAME has no data                                 */

/******************************************************************************/
/* 41 - Position Output Command Message */
/******************************************************************************/
/* ECAN_POS_OUTPUT_REQUEST_FRAME is a single byte code - test it directly */
typedef enum
{
    COMM_MSG_POS_OUT_CMD_OFF    = 0,
    COMM_MSG_POS_OUT_CMD_ON     = 1,
    COMM_MSG_DBG_OD_OUT_CMD_ON  = 2,
} ECAN_POS_OUTPUT_REQUEST_CODE;

/******************************************************************************/
/* 43 - Obstacle debug messages control */
/******************************************************************************/
/* ECAN_OBS_DEBUG_ENABLE_FRAME is a single byte code - test it directly */
typedef enum
{
    OBS_DEBUG_DISABLE   = 0,
    OBS_DEBUG_ENABLE    = 1,
    OBS_DEBUG_UPDATE_OD = 2,
}ECAN_OBS_DEBUG_CONTROL_CODES;

/******************************************************************************/
/* 47 - Obstacle debug reply part 1                                           */
/******************************************************************************/
/* ECAN_OBSTACLE_DEBUG_1_FRAME is raw bytes - load them directly              */

/******************************************************************************/
/* 48 - Obstacle debug reply part 2                                           */
/******************************************************************************/
/* ECAN_OBSTACLE_DEBUG_2_FRAME is raw bytes - load them directly              */

/******************************************************************************/
/* 53 - Event report message frame                                            */
/******************************************************************************/
typedef struct
{
    union
    {
        INT16U Event_ID; /* LRU_EVENT_CODES enum type, sent big endian */
        struct
        {
            INT8U Event_MS_or_CAN_ID;/* CAN_ID for Faults (code < 255) */
            INT8U Event_ID_LS;
        };
    };
    INT8U   CAN_ID;
} ECAN_EVENT_REPORT_FRAME;

/******************************************************************************/
/* 64 - Flight Mode Data frame                                                */
/******************************************************************************/
/* ECAN_FLIGHT_MODE_DATA_FRAME - an incoming Rockwell Collins CAN packet      */
/* buffer is parsed as an outgoing RS-485 packet including the CAN identifier */
/* (source, dest, SID)                                                        */

/******************************************************************************/
/* 65 - LRU Event report part 1 message frame                                 */
/******************************************************************************/
/* The same as the event log frame */

/******************************************************************************/
/* 66 - Event report part 2 message frame                                     */
/******************************************************************************/
/* ECAN_EVENT_REPORT_PART_2_FRAME data is unique for each event, as defined   */
/* in lru-global.h, so load D[0] - D[7] directly                              */

/******************************************************************************/
/* 67 - Event report part 3 message frame                                     */
/******************************************************************************/
/* ECAN_EVENT_REPORT_PART_3_FRAME data is unique for each event, so           */
/*  load D[0] - D[7] directly                                                 */

/******************************************************************************/
/* 68 - Event report clear message frame                                      */
/******************************************************************************/
typedef struct
{
    union
    {
        INT16U Event_ID; /* LRU_EVENT_CODES enum type, sent big endian */
        struct
        {
            INT8U Event_ID_MS;
            INT8U Event_ID_LS;
        };
    };
} ECAN_EVENT_REPORT_CLEAR_FRAME;

/******************************************************************************/
/* 69 - LRU New BootLoader CRC Failed frame                                   */
/******************************************************************************/
/* ECAN_LRU_NEW_BL_CRC_FAIL_FRAME is the expected and actual CRCs             */
/* sent big endian                                                            */

typedef struct
{
    union
    {
        INT32U whole;
        INT8U byte[4];
    }expect; /* Big Endian */
   union
    {
        INT32U whole;
        INT8U byte[4];
    }actual; /* Big Endian */
} ECAN_LRU_NEW_BL_CRC_FAIL_FRAME;

/******************************************************************************/
/* 70 - Reprogram Request command message frame                               */
/******************************************************************************/
/* ECAN_REPROGRAM_REQUEST_FRAME is only 1 byte that must be set to the        */
/* ECAN_REPROGRAM_REQUEST_CODE magic number, so test D[0] directly            */

/******************************************************************************/
/* 71 - Reprogram Setup command message frame                                 */
/******************************************************************************/
typedef struct
{
    INT32U start_address; /* Received big Endian */
    INT32U data_length;   /* Received big Endian */
} ECAN_REPROGRAM_SETUP_FRAME;

/******************************************************************************/
/* 72 - Reprogram Payload command message frame                               */
/******************************************************************************/
typedef struct
{
    INT8U payload[ECAN_REPROGRAM_PAYLOAD_DLC]; /* Received data bytes */
} ECAN_REPROGRAM_PAYLOAD_FRAME;

/******************************************************************************/
/* 73 - Reprogram Checksum response message frame                             */
/******************************************************************************/
typedef union
{
    INT8U  bytes[ECAN_REPROGRAM_CKSUM_DLC]; /* Sent big Endian */
    INT16U sum;                             /* Whole word */
} ECAN_REPROGRAM_CKSUM_FRAME;

/******************************************************************************/
/* 74 - Reprogram ACK/NAK response message frame                              */
/******************************************************************************/
/* ECAN_REPROGRAM_ACK_FRAME is only 1 byte with only the Ack/Nak code so      */
/*  load D[0] directly                                                        */

typedef enum
{
    REPROG_NAK = 0,
    REPROG_ACK = 1,
} ECAN_REPROGRAM_ACK_CODES;

/******************************************************************************/
/* 75 - Reprogram Confirm Checksum command message frame                      */
/******************************************************************************/
/* ECAN_REPROGRAM_CONFIRM_FRAME is only 1 byte with only the Ack/Nak code so  */
/* test D[0] directly                                                         */

/******************************************************************************/
/* 76 - Reprogram Complete Command                                            */
/******************************************************************************/
/* ECAN_REPROGRAM_COMPLETE_FRAME has no data                                  */

/******************************************************************************/
/* 128 - Event Log Erase Command                                              */
/******************************************************************************/
/* ECAN_EVENT_LOG_ERASE_FRAME is the fixed string ECAN_EVENT_LOG_ERASE_CODE   */
/* ("ERASELOG") so just compare D[0-7] directly                               */

/******************************************************************************/
/* 300 - Lab mode - debug message                                             */
/******************************************************************************/
/* ECAN_LAB_MODE_DEBUG_FRAME is free form to aid in debugging software in the */
/* lab environment.  May be used in the field to identify problems that do    */
/*  not have specific requirements                                             */


#endif  /* CAN_CATALOG_H */

