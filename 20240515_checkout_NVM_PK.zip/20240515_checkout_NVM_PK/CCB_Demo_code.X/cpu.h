/*
 * Author(s):     Jonathan R. Saliers
 *                Doug Wendt      <dwendt@omnicongroup.com>
 * Status:        Preliminary
 * Release Date:
 * Revision:
 * Description:   Header file for the CPU_Utility module.
 * History:
 * 06/10/2010 Clay Barber Changed Files updates
 */

/*********************************************************************************************
 * Recursive header block
 ********************************************************************************************/
#ifndef CPU_H
#define CPU_H

/*********************************************************************************************
 * Includes
 ********************************************************************************************/
#include "typedef.h"
#include "position.h"
#include "i2c_temp.h"

/*********************************************************************************************
Type Definitions
*********************************************************************************************/
typedef enum
{
    FLASH_SELECTED,
    FLASH_UNSELECTED
} FLASH_CS_STATES;

typedef enum
{
    FLASH_WRITE,
    FLASH_WRITE_PROTECT
} FLASH_WP_STATES;

typedef enum
{
    FLASH_RESET,
    FLASH_NORMAL_OP
} FLASH_RESET_STATES;

/*********************************************************************************************
 * Preprocessor definitions
 ********************************************************************************************/
/* Port direction setting in TRIS register */
#define PORT_DIR_OUTPUT         0
#define PORT_DIR_INPUT          1

/* Port functional type set in the ANALOG_SELECT register */
#define PORT_TYPE_DIGITAL       0
#define PORT_TYPE_ANALOG        1

/* PIC peripheral module enable/disable bits */
#define PIC_MODULE_ENABLE       0
#define PIC_MODULE_DISABLE      1

/* Port state driven to digital output pins */
#define PORT_OUT_LOW            0
#define PORT_OUT_HIGH           1

/* Change notify enable/disable to get an interrupt from specific digital inputs */
#define PORT_CNOTIFY_DISABLE    0
#define PORT_CNOTIFY_ENABLE     1

/* Possible states for the statued LEDs - useful for debug */
#define LED_STATE_OFF           0
#define LED_STATE_GREEN         1
#define LED_STATE_RED           2
#define LED_STATE_YELLOW        3

/* Interupt enable/disable macros to protect shared resources - must be used as a pair */
#define DISABLE_INTERRUPTS()        { __builtin_disi(0x3FFF);
#define ENABLE_INTERRUPTS()         __builtin_disi(0); }

/* Flash is wired to SPI2 ( was SPI1) */
#define _FLASH_SPIBUF       SPI2BUFL
#define _FLASH_SPISTATbits  SPI2STATLbits
#define _FLASH_SPICON1bits  SPI2CON1bits
#define _FLASH_SPICON2bits  SPI2CON2bits

/* Chip Select output for SPI/Dataflash chip (was RC12) */
#define DATAFLASH_SELECT   _RD8     //was RA2

/* nReset output for SPI/Dataflash chip (was RB0)*/
#define DATAFLASH_RESET    _RC12 /*TBD*/ //temporary

/* nWriteProtect output for SPI/Dataflash chip (was RC15) */
#define DATAFLASH_WP    _RB8 //was RG1


/* Chip Select output for SPI Angle sensor chip*/
#define ANGLESENSOR1_SELECT   _RD15
#define ANGLESENSOR2_SELECT   _RB0
/* Turn on the CSSL bits for AN8-14, and AN27-31  */
/* AN0- ISENSE */
/* AN1-2 Digital/Unused */
/* AN3-AN4 COSP1 COSN1*/
/* AN5 VGMR1 */
/* AN6-AN7 SINN1 SINP1*/
/* AN8 Digital/Unused */
/* AN9 PCB NTC Temp */
/* AN10 STP NTC Temp */
/* AN11 VGMR2 */
/* AN12 COSN2 */
/* AN13 SINN2 */
/* AN14 SINP2 */
/* AN15 COSP2 */
/* AN16-31 Not available on 'MC506 device */
/* AN16 COSN3 */
/* AN17 COSP3 */
/* AN18 SINN3 */
/* AN19 SINP3 */
/* AN20 Unused */
/* AN21 Unused */
/* AN22 VGMR3 (scanned but unused in code) */
/* AN23-31 Unused */

/* Added scanning of 3rd sensor channels to 'SSL_BITS_H */
/* VGMR1, VGMR2, and VGMR3 are scanned but unused */
#define ADC_COLLECTION_SSL_BITS_H     0b0000000001001111
#define ADC_COLLECTION_SSL_BITS_L     0b1111111011111001

/* Timer definition */
#define ONE_MSEC_COUNTER              TMR1
#define ONE_MSEC_TMR_INTERRUPT_FLAG   IFS0bits.T1IF
#define ONE_MSEC_TIMER_ON_OFF         T1CONbits.TON

/* GAP pin and pull-up/pull-down definition */
#define GAP_0_PULL_UP   _CNPUC1	/* was _CNPUC13 */
#define GAP_0_PULL_DOWN _CNPDC1	/* was _CNPDC13 */
#define GAP_1_PULL_UP   _CNPUC2	/* was _CNPUA1 */
#define GAP_1_PULL_DOWN _CNPDC2	/* was _CNPDA1 */
#define GAP_2_PULL_UP   _CNPUC6	/* was _CNPUD8 */
#define GAP_2_PULL_DOWN _CNPDC6	/* was _CNPDD8 */

#define TERM_CONTROL_PIN        _LATD11		/* was _RC13 */
#define TERM_CONTROL_VCC_PIN    _LATD12		/* was _RA1 */
#define GAP_2_READ              _RC6		/* was _RD8 */

/* LED I/O pin definitions. */
#define GREEN_LED_PIN   _LATC3
#define RED_LED_PIN     _LATD12

//5V_PGOOD
#define PGOOD_5V_PIN      _RC15
#define ENABLE_5V_PIN     _LATC14
#define FLT_TRIP_PIN      _RC12

/* ADC Channel definitions */
#define ADC_CHANNEL_ISENSE     0  //AN0, 
#define ADC_CHANNEL_ISENSE_REF 1  // ANA1,
#define ADC_CHANNEL_SOL_MON    2   //AN3 
#define ADC_CHANNEL_VMON       3  // AN9


/* Macro added for Reading BLDC Motor driver chip FF2 pin */
#define READ_FF2   _RE8

/* Macro added for Reading HEF1-HEF3 on PORTbits RD1-RD3 and justifying to LSBs
 * used by Hall.c, previously hard coded port in Hall.c */
//for demo RD5-RD7
#define HALL_SENSORS_READ  ((PORTD >> 5) & 0x0007)

/*********************************************************************************************
 * Function declarations
 ********************************************************************************************/
/*********************************************************************************************
 * Author(s):       J Craymer
 * Description:     Sets the top of stack, should be called first in execution.
 * Parameters:      None
 * Returns:         None
 *********************************************************************************************/
void cpu_set_top_of_stack( void );

#ifdef ENABLE_STACK_DIAGNOSTIC
/*********************************************************************************************
 * Author(s):       J Craymer
 * Description:     Retrieves the top of stack.
 * Parameters:      None
 * Returns:         unsigned int * - pointer to top of stack
 *********************************************************************************************/
unsigned int * cpu_get_top_of_stack( void );

/*********************************************************************************************
 * Author(s):       J Craymer
 * Description:     Maps can_termination commands to correct output
 * Parameters:      p_last_address   - Fills with highest utilized stack address.
 * Parameters:      p_end_address    - Fills with end stack address.
 * Parameters:      p_start_address  - Fills with start stack address.
 *                  p_use_percentage - Fills with use percentage out of 100
 * Returns:         None
 *********************************************************************************************/
void cpu_get_stack_utilization( INT32U * p_last_address, INT32U * p_end_address, INT32U * p_start_address, INT8U * p_use_percentage );
#endif

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: The initialization function for the CPU_Utility module.
 * Parameters:  None.
 * Returns:     None.
 ********************************************************************************************/
void cpu_init( void );

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Services the watchdog to prevent software resets.
 * Parameters:  None.
 * Returns:     None.
 ********************************************************************************************/
void cpu_service_watchdog( void );

/*********************************************************************************************
 * Author(s):      Jonathan R. Saliers
 * Description:    Sets the state of the system LED.
 * Parameters:     led_state - desired state of the status LED, can be OFF, GREEN or RED
 * Returns:        None.
 *********************************************************************************************/
void cpu_set_led_state( INT16U led_state );

/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Retrieves the FF2 status bit from the BLDC motor drive chip.
Parameters:  None
Returns:     TRUE  - there has been a BLDC control fault
             FALSE - there has NOT been a BLDC control fault
*********************************************************************************************/
BOOL cpu_get_bldc_FF2_fault(void);

/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Sets the inverse Brake Enable line output to the input parameter value.
Parameters:  disable - a flag indicating the output logic level.
Returns:     None
*********************************************************************************************/
void cpu_stepper_disable(BOOL disable);

/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Sets the Brake Direction line output to the input parameter value.
Parameters:  disable - a flag indicating the output logic level.
Returns:     None
*********************************************************************************************/
void cpu_stepper_direction(BOOL direction);

/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Sets the Brake Step line output to the input parameter value.
Parameters:  disable - a flag indicating the output logic level.
Returns:     None
*********************************************************************************************/
void cpu_stepper_step(BOOL step);

/*********************************************************************************************
 * Author(s):       mfarver
 * Description:     Maps flash chip select to correct output
 * Parameters:      state, (in) - FLASH_SELECTED or FLASH_UNSELECTED
 * Returns:         None
 *********************************************************************************************/
void cpu_SetDataFlashCs( FLASH_CS_STATES state );

/*********************************************************************************************
 * Author(s):       mfarver
 * Description:     Maps flash reset to correct output
 * Parameters:      state, (in) - FLASH_RESET or FLASH_NORMAL_OP
 * Returns:         None
 *********************************************************************************************/
void cpu_SetDataFlashReset( FLASH_RESET_STATES state );

/*********************************************************************************************
 * Author(s):       mfarver
 * Description:     Maps flash write protect to correct output
 * Parameters:      state, (in) - FLASH_WRITE or FLASH_WRITE_PROTECT
 * Returns:         None
 *********************************************************************************************/
void cpu_SetDataFlashWp( FLASH_WP_STATES state );

/*********************************************************************************************
 * Author(s):       mfarver
 * Description:     Reads ADC DMA buffer for position data
 * Parameters:      position, (out) - Datastructure to store position data.
 * Returns:         None
 *********************************************************************************************/
void cpu_GetPosition(PSN_POSITION_DATA * position);

/*********************************************************************************************
 * Author(s):       mfarver
 * Description:     Reads ADC DMA buffer for motor current
 * Parameters:      None
 * Returns:         12bit ADC average raw value for current
 *********************************************************************************************/
INT16U cpu_GetCurrent();
INT16U cpu_GetCurrentref();
/*********************************************************************************************
 * Author(s):       mfarver
 * Description:     Reads ADC DMA buffer for PCB temp
 * Parameters:      None
 * Returns:         12bit ADC average raw value for current
 *********************************************************************************************/
INT16U cpu_GetPcbTemp();

/*********************************************************************************************
 * Author(s):       mfarver
 * Description:     Reads ADC DMA buffer for Stepper temp
 * Parameters:      None
 * Returns:         12bit ADC average raw value for current
 *********************************************************************************************/
INT16U cpu_GetStpTemp();

/*********************************************************************************************
 *
 * Recursive header block
 ********************************************************************************************/
#endif	/* CPU_H */
