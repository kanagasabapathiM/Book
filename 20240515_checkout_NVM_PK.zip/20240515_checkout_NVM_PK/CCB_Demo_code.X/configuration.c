/*
 * Author(s):    Jonathan R. Saliers
 * Status:       Incomplete
 * Release Date: 11/30/12
 * Revision:     0.1
 * Description: The Configuration module is responsible for the non-volatile storage and
 * retrieval of the UAP serial number information and firmware CRC data, as well as the
 * other configuration data tables stored in external Flash memory.  The Configuration
 * data is stored when the flash memory is programmed in the production environment.
 */

/*********************************************************************************************
 * Source file includes
 ********************************************************************************************/
#include "communications.h"
#include "cpu.h"
#include "Event_Manager.h"
#include "global.h"
#include "memorymgr.h"
#include "utility.h"
#include <xc.h>


/* Optionally include configuration data tables. */
//#define DEBUG

/* Note:  __DEBUG is automatically included when building in Debug mode. */
#if defined(__DEBUG) || defined(DEBUG)

#warning The configuration data tables included below are used for DEBUGGING only!

#include "debug_data.h"

#endif

/*********************************************************************************************
 * Private type definitions
 ********************************************************************************************/

typedef struct int_to_float
{
    union
    {
        struct
        {
            INT16U lsb;
            INT16U msb;
        };

        FP32 f_val;
    };
} INT_TO_FLOAT_TYPE;



/*********************************************************************************************
 * Private preprocessor definitions
 ********************************************************************************************/

/* Note that to store 16 bits of data (1 word), 1 PC unit is used,
   which is 3 bytes or two words in terms of PC addresses */
#define WORDS_PER_PC_UNIT             2

/* Number of times to try to get the computed CRC of a table to match the stored value. */
/* Also, the number of times to try range-check a value in case it failed previously. */
#define NUM_RETRIES                   5

#define TABLE_CRC_FIELD_SIZE          0x2   /* in 16-bit words */

/* 16-bit word offset into the table loaded into RAM for each of the table fields. */
#define TABLE_ID_OFST                 0x0
#define MAX_TEMP_DELTA_OFST           0x4
#define CRIT_BLDC_TEMP_OFST           0x5
#define CRIT_STP_TEMP_OFST            0x6
#define CRIT_PCB_TEMP_OFST            0x7
#define HIGH_LOAD_CURR_OFST           0x8
#define DELTA_POS_OFST                0x9
#define MAX_POS_CHANGE_OFST           0xC
#define TEMP_LUT_SIZE_OFST            0x1   /* Temperature lookup table size */
#define TEMP_LUT_ENTRY_SIZE           0x2   /* Size of a voltage/temperature pair in the temperature lookup table. */
#define TEMP_LUT_1ST_VOLT_OFST        0x2   /* Offset of the first voltage in the temperature lookup table. */
#define TEMP_LUT_1ST_TEMP_OFST        0x3   /* Offset of the first temperature in the temperature lookup table. */
#define CURR_MULT_OFST                0x2   /* Current multiplier. */
#define A_X_1_OFST                    0x1   /* Encoder 1 X amplitude. */
#define A_X_2_OFST                    0x3   /* Encoder 2 X amplitude. */
#define A_Y_1_OFST                    0x5   /* Encoder 1 Y amplitude. */
#define A_Y_2_OFST                    0x7   /* Encoder 2 Y amplitude. */
#define COS_N_PHI_1_OFST              0x15
#define COS_N_PHI_2_OFST              0x17
#define ENC_12_SWAP_OFST              0x1D
#define MIN_ENC_1_VOLT_OFST           0x1E
#define MAX_ENC_1_VOLT_OFST           0x1F
#define MIN_ENC_2_VOLT_OFST           0x20
#define MAX_ENC_2_VOLT_OFST           0x21
#define MAX_PWM_SLOPE_OFST            0x1
#define FW_START_ADDR_OFST            0x3
#define FW_END_ADDR_OFST              0x5


#define ACT_PARAM_ZONE_1_MAX_TRAVEL_OOR    2
#define ACT_PARAM_ZONE_2_MAX_TRAVEL_OOR    3
#define ACT_PARAM_ZONE_3_MAX_TRAVEL_OOR    4
#define ACT_PARAM_ZONE_4_MAX_TRAVEL_OOR    5
#define ACT_PARAM_ZONE_5_MAX_TRAVEL_OOR    6
#define ACT_PARAM_ZONE_6_MAX_TRAVEL_OOR    7
#define ACT_PARAM_ZONE_7_MAX_TRAVEL_OOR    8
#define ACT_PARAM_ZONE_8_MAX_TRAVEL_OOR    9
#define ACT_PARAM_ZONE_9_MAX_TRAVEL_OOR   10
#define ACT_PARAM_ZONE_10_MAX_TRAVEL_OOR  11
#define ACT_PARAM_ZONE_11_MAX_TRAVEL_OOR  12
#define ACT_PARAM_ZONE_1_SLOPE_WIDTH_OOR  13
#define ACT_PARAM_ZONE_2_SLOPE_WIDTH_OOR  14
#define ACT_PARAM_ZONE_3_SLOPE_WIDTH_OOR  15
#define ACT_PARAM_ZONE_4_SLOPE_WIDTH_OOR  16
#define ACT_PARAM_ZONE_5_SLOPE_WIDTH_OOR  17
#define ACT_PARAM_ZONE_6_SLOPE_WIDTH_OOR  18
#define ACT_PARAM_ZONE_7_SLOPE_WIDTH_OOR  19
#define ACT_PARAM_ZONE_8_SLOPE_WIDTH_OOR  20
#define ACT_PARAM_ZONE_9_SLOPE_WIDTH_OOR  21
#define ACT_PARAM_ZONE_10_SLOPE_WIDTH_OOR 22
#define ACT_PARAM_ZONE_11_SLOPE_WIDTH_OOR 23

#ifdef PRIVACY_DIVIDER
#define MAX_TRAVEL_RANGE    5400    /* Encoder range for the compact actuator */
#else
#define MAX_TRAVEL_RANGE    6840  /* Encoder range for the universal actuator */
#endif

#define MAX_ACT_SLOPE_WIDTH 1000

typedef enum
{
    NO_ERR,
    DELTA_OFFSET_EQ_ZERO,
    DELTA_OFFSET_GT_MAX,
    X_PARAM_DIV_BY_ZERO,
    ELEC_INDUCT_DIV_BY_ZERO,
    MOTOR_INERTIA_DIV_BY_ZERO
}
OBS_DATA_ERR;

/*********************************************************************************************
 * Private function declarations
 ********************************************************************************************/
/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Performs data range check on a given configuration data table.
 * Parameters:  table_num - table number identified in the SRS.
 *              buffer    - buffer with the table contents.
 * Returns:     NO_ERROR      - table check has completed successfully.
 *              ERR_FAILURE   - data range error has been found.
 ********************************************************************************************/
static ERR_RET _cfg_perform_data_range_check( INT16U table_num, INT16U* p_buffer );

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Utility function that loads a given configuration data table into RAM and
 *              performs a CRC check.  The process is repeated up to 5 times in case a CRC
 *              failure is detected.
 * Parameters:  table_num - 0-based table number in the order tables are stored in the memory.
 *              p_buffer  - buffer the table will be placed into.
 * Returns:     NO_ERROR      - a table has been loaded successfully.
 *              ERR_FAILURE   - CRC error has been detected.
 ********************************************************************************************/
static ERR_RET _cfg_load_table( INT16U table_num, INT16U* p_buffer );

/*********************************************************************************************
 * Global variable definitions
 ********************************************************************************************/
TABLE_DEFINITION_TYPE __attribute__((aligned(16))) tables[TBL_NUM_TABLES] =
{
    { "MOTOR_TB", MOTOR_PARAM_TABLE_ADDR,     sizeof(CFG_MOTOR_PARAM_TABLE_TYPE),     MOTOR_PARAM_TABLE_ID,         TRUE }, /* Motor parameters */
    { "TMP_LKUP", TEMP_LOOKUP_TABLE_ADDR,     sizeof(CFG_TEMP_LOOKUP_TABLE_TYPE),     TEMP_LOOKUP_TABLE_ID,         TRUE }, /* Temperature lookup table */
    { "CURRENT ", CURRENT_PARAM_TABLE_ADDR,   sizeof(CFG_CURRENT_PARAM_TABLE_TYPE),   CURRENT_PARAM_TABLE_ID,       TRUE }, /* Current parameters */
    { "OBSTACLE", OBSTACLE_PARAM_TABLE_ADDR,  sizeof(CFG_OBS_PARAM_TABLE_TYPE),       OBSTACLE_PARAM_TABLE_ID,      TRUE }, /* Obstacle detection parameters */
    { "STEPPER ", STEPPER_PARAM_TABLE_ADDR,   sizeof(CFG_STEPPER_PARAM_TABLE_TYPE),   STEPPER_PARAM_TABLE_ID,       TRUE }, /* Stepper parameters */
    { "CONTROL ", CONTROL_PARAM_TABLE_ADDR,   sizeof(CFG_CONTROL_PARAM_TABLE_TYPE),   CONTROL_PARAM_TABLE_ID,       TRUE }, /* Control loop parameters */
    { "POSITION", POSITION_PARAM_TABLE_ADDR,  sizeof(CFG_POSITION_PARAM_TABLE_TYPE),  POSITION_PARAM_TABLE_ID,      TRUE }, /* Position parameters */
    { "MOTION  ", MOTION_PARAM_TABLE_ADDR,    sizeof(CFG_MOTION_PARAM_TABLE_TYPE),    MOTION_PARAM_TABLE_ID,        TRUE }, /* Motion parameters */
    { "PWM_PARM", PWM_PARAM_TABLE_ADDR,       sizeof(CFG_PWM_PARAM_TABLE_TYPE),       PWM_PARAM_TABLE_ID,           TRUE }, /* PWM parameters */
    { "ACTUATOR", ACT_ID_TABLE_ADDR,          sizeof(LRU_ID_TABLE_TYPE),              ACT_ID_TABLE_ID,              TRUE }, /* UAP ID parameters */
    { "APP_CRC ", APP_FW_CRC_TABLE_ADDR,      sizeof(CFG_FW_CRC_TABLE_TYPE),          APP_FW_CRC_TABLE_ID,          TRUE }, /* Application fw CRC parameters */
    { "APP_FWID", APP_FW_ID_TABLE_ADDR,       sizeof(CFG_FW_ID_TABLE_TYPE),           APP_FW_ID_TABLE_ID,           TRUE }, /* Application fw ID parameters */
    { "BOOT_CRC", BL_FW_CRC_TABLE_ADDR,       sizeof(CFG_FW_CRC_TABLE_TYPE),          BL_FW_CRC_TABLE_ID,           TRUE }, /* Bootloader fw CRC parameters */
    { "BOOT_FW ", BL_FW_ID_TABLE_ADDR,        sizeof(CFG_FW_ID_TABLE_TYPE),           BL_FW_ID_TABLE_ID,            TRUE }, /* Bootloader fw ID parameters */
    { "ACT_PARM", ACT_PARAM_TABLE_ADDR,       sizeof(CFG_ACT_PARAM_TABLE_TYPE),       ACT_PARAM_TABLE_ID,           TRUE }, /* Extended obstacle detection parameters */
    { "CANID_TB", ACT_CANID_TABLE_ADDR,       sizeof(CFG_ACT_CANID_TABLE_TYPE),       ACT_CANID_TABLE_ID,           TRUE }, /* Actuator CAN ID */
    { "EVENT_PR", EVENT_PROCESS_TABLE_ADDR,   sizeof(CFG_EVENT_PROCESS_TABLE_TYPE),   EVENT_PROCESS_TABLE_ID,       TRUE }, /* Event processing parameters */
    { "ADJPARAM", ADJUST_PARAM_TABLE_ADDR,    sizeof(CFG_ADJUST_PARAM_TABLE_TYPE),    ADJUST_PARAM_TABLE_ID,        TRUE }, /* Adjustable parameters */
    { "CONSOLID", EVENT_CONSOL_TABLE_ADDR,    sizeof(CFG_EVENT_CONSOL_TABLE_TYPE),    EVENT_CONSOL_TABLE_ID_VALUE,  FALSE } /* Event consolidation parameters */
};

static INT16U  G_bad_table          = 0;
static BOOL    G_crc_error          = FALSE;
static BOOL    G_range_error        = FALSE;
static INT16U  G_bad_range_item     = 0;

/*********************************************************************************************
 * Source file function definitions
 ********************************************************************************************/

/*********************************************************************************************
 * Author(s):      Jonathan R. Saliers
 * Description:    Retrieves table data from the internal flash memory, copies it into a
 *                 buffer in RAM, and performs CRC and data range checks on it.  The function
 *                 also stores memory locations of the RAM buffers for each table.
 * Parameters:     table_num - table number
 *                 p_buffer  - a pointer to a copy of parameters in RAM.
 * Returns:        NO_ERROR    - indicates success
 *                 ERR_FAILURE - indicates failure
 ********************************************************************************************/
ERR_RET cfg_load_parameters( TABLE_NUM_TYPE table_num, INT16U* p_buffer )
{
    ERR_RET sys_err;
    INT16U  i;

    /* Load table data from flash memory and and perform a CRC check. */
    sys_err = _cfg_load_table( table_num, p_buffer );
    if( sys_err != NO_ERROR )
    {
        if( table_num != TBL_EVENT_CONSOL )
        {
            G_crc_error = TRUE;
        }
    }
    else
    {
        for( i = 0; i < NUM_RETRIES; i++ )
        {
            /* Perform a data range check. */
            sys_err = _cfg_perform_data_range_check( table_num, p_buffer );
            if ( sys_err != NO_ERROR )
            {
                G_range_error |= TRUE;
            }
            else
            {
                break;
            }
        }
    }

    /* Store the address of the RAM buffer where the data is stored. */
    bit_store_loaded_table_addr( table_num, p_buffer, tables[table_num] );

    /* Return status */
    return sys_err;
}


/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Performs data range check on a given configuration data table.
 * Parameters:  table_num - table number identified in the SRS.
 *              buffer    - buffer with the table contents.
 * Returns:     CFG_NO_ERROR      - table check has completed successfully.
 *              CFG_RANGE_ERROR   - data range error has been found.
 ********************************************************************************************/
static ERR_RET _cfg_perform_data_range_check( INT16U table_num, INT16U* p_buffer )
{
    ERR_RET           sys_err = CFG_NO_ERROR;
    INT16U            i;
    INT_TO_FLOAT_TYPE conversion;
    INT32U            start_addr;
    INT32U            end_addr;

    /* Check the table ID field. */
    if( p_buffer[TABLE_ID_OFST] != tables[table_num].id )
    {
        sys_err = CFG_RANGE_ERROR;
        G_bad_table = table_num;
        G_bad_range_item = 1;
    }

    switch( table_num )
    {
        case TBL_MOTOR_PARAM:
            /* Check if Max_Temp_Delta < Critical_Motor_Temperature */
            if( (INT16S)p_buffer[MAX_TEMP_DELTA_OFST] >= (INT16S)p_buffer[CRIT_BLDC_TEMP_OFST] )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 3;
            }
            /* Check if Max_Temp_Delta < Critical_Stepper_Temperature */
            else if( (INT16S)p_buffer[MAX_TEMP_DELTA_OFST] >= (INT16S)p_buffer[CRIT_STP_TEMP_OFST] )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 4;
            }
            /* Check if Max_Temp_Delta < Critical_PCB_Temperature */
            else if( (INT16S)p_buffer[MAX_TEMP_DELTA_OFST] >= (INT16S)p_buffer[CRIT_PCB_TEMP_OFST] )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 5;
            }
            /* Check if High_Load_Current > 0 */
            else if( p_buffer[HIGH_LOAD_CURR_OFST] == 0 )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 6;
            }
            /* Check if Delta_Position > 0 */
            else if( p_buffer[DELTA_POS_OFST] == 0 )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 7;
            }
            /* Check if Delta_Position <= 6840 (or 5400 for PD) */
            else if( p_buffer[DELTA_POS_OFST] > MAX_ENC_RANGE )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 8;
            }
            /* Check if Max_Position_Change > 0 */
            else if( p_buffer[MAX_POS_CHANGE_OFST] == 0 )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 9;
            }
            /* Check if Max_Position_Change <= 6840 (or 5400 for PD) */
            else if( p_buffer[MAX_POS_CHANGE_OFST] > MAX_ENC_RANGE )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 10;
            }
            break;

        case TBL_TEMP_LOOKUP:
            {
                CFG_TEMP_LOOKUP_TABLE_TYPE *p_temp_lookup_table;
                p_temp_lookup_table = (CFG_TEMP_LOOKUP_TABLE_TYPE*) p_buffer;
                INT16U curr_volt;
                INT16U next_volt;
                INT16S curr_temp;
                INT16S next_temp;
            
                if( p_temp_lookup_table->table_size <= 1 )
                {
                    sys_err = CFG_RANGE_ERROR;
                    G_bad_table = table_num;
                    G_bad_range_item = 2;
                }
                else
                {
                    /* Check if every voltage is greater than the previous. */
                    for( i = 0; i < ( p_temp_lookup_table->table_size - 1 ); i++ )
                    {
                        curr_volt = p_temp_lookup_table->lookup[i].voltage;
                        next_volt = p_temp_lookup_table->lookup[i+1].voltage;
                        if( next_volt <= curr_volt )
                        {
                            sys_err = CFG_RANGE_ERROR;
                            G_bad_table = table_num;
                            G_bad_range_item = 3;
                        }
                    }

                    /* Check if every temperature is less than the previous. */
                    for( i = 0; i < ( p_temp_lookup_table->table_size - 1 ); i++ )
                    {
                        curr_temp = p_temp_lookup_table->lookup[i].temperature;
                        next_temp = p_temp_lookup_table->lookup[i+1].temperature;
                        if( next_temp >= curr_temp )
                        {
                            sys_err = CFG_RANGE_ERROR;
                            G_bad_table = table_num;
                            G_bad_range_item = 4;
                        }
                    }

                    /* Check if every voltage is less than or equal to 3300. */
                    for( i = 0; i < p_temp_lookup_table->table_size; i++ )
                    {
                        curr_volt = p_temp_lookup_table->lookup[i].voltage;
                        if( curr_volt > 3300 )
                        {
                            sys_err = CFG_RANGE_ERROR;
                            G_bad_table = table_num;
                            G_bad_range_item = 5;
                        }
                    }

                    /* Check if every temperature is greater than or equal to -50. */
                    for( i = 0; i < p_temp_lookup_table->table_size; i++ )
                    {
                        curr_temp = p_temp_lookup_table->lookup[i].temperature;
                        if( curr_temp < -50 )
                        {
                            sys_err = CFG_RANGE_ERROR;
                            G_bad_table = table_num;
                            G_bad_range_item = 6;
                        }
                        else if( curr_temp > 185 )
                        {
                            sys_err = CFG_RANGE_ERROR;
                            G_bad_table = table_num;
                            G_bad_range_item = 7;
                        }
                    }
                }
            }
            break;

        case TBL_CURRENT_PARAM:
            /* Check if Current_Multiplier is not equal to 0. */
            if( p_buffer[CURR_MULT_OFST] == 0 )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 2;
            }
            break;

        case TBL_OD_PARAM:
        {
            OBS_DATA_ERR obs_data_err =  NO_ERR;
            CFG_OBS_PARAM_TABLE_TYPE *p_temp_param_table;
            p_temp_param_table = (CFG_OBS_PARAM_TABLE_TYPE*) p_buffer;

            /* Check if Position_Delta > 0. */
            if( p_temp_param_table->position_delta == 0 )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                obs_data_err = DELTA_OFFSET_EQ_ZERO;
            }
            /* Check if Position_Delta <= 6840 (or 5400 for PD). */
            if( p_temp_param_table->position_delta > MAX_ENC_RANGE )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                obs_data_err = DELTA_OFFSET_GT_MAX;
            }

            /* Check x1 and x2 to make sure a div by zero does not occur
             * during slope calculation. */
            if( p_temp_param_table->x1 == p_temp_param_table->x2 )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                obs_data_err = X_PARAM_DIV_BY_ZERO;
            }

            /* Check electric inductance to make sure a div by zero does not
             * occur during modeled velocity calculation. */
            if( p_temp_param_table->elec_induct == 0 )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                obs_data_err = ELEC_INDUCT_DIV_BY_ZERO;
            }

            /* Check motor inertia to make sure a div by zero does not
             * occur during modeled velocity calculation. */
            if( p_temp_param_table->motor_inertia == 0 )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                obs_data_err = MOTOR_INERTIA_DIV_BY_ZERO;
            }

            G_bad_range_item = (INT16U)obs_data_err;
            break;
        }
        case TBL_POS_PARAM:
            conversion.lsb = p_buffer[A_X_1_OFST];
            conversion.msb = p_buffer[A_X_1_OFST + 1];

            /* Check if Ax_1 > 0. */
            if( conversion.f_val <= 0 )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 2;
            }

            /* Check if Ax_2 > 0. */
            conversion.lsb = p_buffer[A_X_2_OFST];
            conversion.msb = p_buffer[A_X_2_OFST + 1];
            if( conversion.f_val <= 0 )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 3;
            }

            /* Check if Ay_1 > 0. */
            conversion.lsb = p_buffer[A_Y_1_OFST];
            conversion.msb = p_buffer[A_Y_1_OFST + 1];
            if( conversion.f_val <= 0 )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 4;
            }

            /* Check if Ay_2 > 0. */
            conversion.lsb = p_buffer[A_Y_2_OFST];
            conversion.msb = p_buffer[A_Y_2_OFST + 1];
            if( conversion.f_val <= 0 )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 5;
            }

            /* Check if Cosine_Neg_Phi_1 is not equal to 0. */
            if( ( p_buffer[COS_N_PHI_1_OFST] == 0 ) &&
                ( p_buffer[COS_N_PHI_1_OFST + 1] == 0 ) )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 6;
            }
            /* Check if Cosine_Neg_Phi_2 is not equal to 0. */
            else if( ( p_buffer[COS_N_PHI_2_OFST] == 0 ) &&
                     ( p_buffer[COS_N_PHI_2_OFST + 1] == 0 ) )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 7;
            }
            /* Check if Min_Enc1_Voltage < Max_Enc1_Voltage. */
            else if( p_buffer[MIN_ENC_1_VOLT_OFST] >= p_buffer[MAX_ENC_1_VOLT_OFST] )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 8;
            }
            /* Check if Min_Enc2_Voltage < Max_Enc2_Voltage. */
            else if( p_buffer[MIN_ENC_2_VOLT_OFST] >= p_buffer[MAX_ENC_2_VOLT_OFST] )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 9;
            }
            /* Check if Max_Enc1_Voltage <= 3300. */
            else if( p_buffer[MAX_ENC_1_VOLT_OFST] > 3300 )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 10;
            }
            /* Check if Max_Enc2_Voltage <= 3300. */
            else if( p_buffer[MAX_ENC_2_VOLT_OFST] > 3300 )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 11;
            }
            /* Check if encoder_output_swap is either 0 or 1. */
            else if( p_buffer[ENC_12_SWAP_OFST] > 1 )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 12;
            }
            break;

        case TBL_MOTION_PARAM:
            {
                CFG_MOTION_PARAM_TABLE_TYPE* mot_param =   /* pointer to type */
                        (CFG_MOTION_PARAM_TABLE_TYPE*)p_buffer;
                /* Check if signed Gearbox_Ratio > 0. */
                if( mot_param->gearbox_ratio <= 0 )
                {
                    sys_err = CFG_RANGE_ERROR;
                    G_bad_table = table_num;
                    G_bad_range_item = 2;
                }
                /* Check if unsigned Max_RPM > 0. */
                else if( mot_param->max_rpm == 0 )
                {
                    sys_err = CFG_RANGE_ERROR;
                    G_bad_table = table_num;
                    G_bad_range_item = 3;
                }
            }
            break;

        case TBL_PWM_PARAM:
            /* Check if Max_PWM_Slope is not equal to 0.
             * Test the float as 2 words */
            if( ( p_buffer[MAX_PWM_SLOPE_OFST] == 0 ) &&
                ( p_buffer[MAX_PWM_SLOPE_OFST + 1] == 0 ) )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 2;
            }
            break;

        case TBL_APP_FW_CRC:
        case TBL_BOOT_FW_CRC:
            /* Perform a range check on starting/ending addresses */
            start_addr = *(INT32U*)(p_buffer + FW_START_ADDR_OFST);
            end_addr   = *(INT32U*)(p_buffer + FW_END_ADDR_OFST);
            if( start_addr >= end_addr )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 2;
            }
            /* Check if the starting address is an even number. */
            else if( (start_addr % 2) != 0 )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 3;
            }
            /* Check if the ending address is an odd number. */
            else if( (end_addr % 2) == 0 )
            {
                sys_err = CFG_RANGE_ERROR;
                G_bad_table = table_num;
                G_bad_range_item = 4;
            }
            break;

        case TBL_ACT_PARAM:
            {
                /* Cast the buffer to the appropriate type to aid in range checking */
                CFG_ACT_PARAM_TABLE_TYPE* p_act_param_table;
                p_act_param_table = (CFG_ACT_PARAM_TABLE_TYPE*)p_buffer;

                if( p_act_param_table->multizone_obs == TRUE )
                {
                    /* Check if zone X max travel is less than or equal to that
                     *  of zone X+1 and less than the maximum for active zones. */
                    if ((p_act_param_table->num_obs_zones >= 1) &&
                        (p_act_param_table->max_travel_zone1 > MAX_TRAVEL_RANGE))
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_1_MAX_TRAVEL_OOR;
                    }

                    if ((p_act_param_table->num_obs_zones >= 2) &&
                        ((p_act_param_table->max_travel_zone1 >
                          p_act_param_table->max_travel_zone2) ||
                        (p_act_param_table->max_travel_zone2 > MAX_TRAVEL_RANGE)))
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_2_MAX_TRAVEL_OOR;
                    }

                    if ((p_act_param_table->num_obs_zones >= 3) &&
                        ((p_act_param_table->max_travel_zone2 >
                          p_act_param_table->max_travel_zone3) ||
                        (p_act_param_table->max_travel_zone3 > MAX_TRAVEL_RANGE)))
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_3_MAX_TRAVEL_OOR;
                    }

                    if ((p_act_param_table->num_obs_zones >= 4) &&
                        ((p_act_param_table->max_travel_zone3 >
                          p_act_param_table->max_travel_zone4) ||
                        (p_act_param_table->max_travel_zone4 > MAX_TRAVEL_RANGE)))
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_4_MAX_TRAVEL_OOR;
                    }

                    if ((p_act_param_table->num_obs_zones >= 5) &&
                        ((p_act_param_table->max_travel_zone4 >
                          p_act_param_table->max_travel_zone5) ||
                        (p_act_param_table->max_travel_zone5 > MAX_TRAVEL_RANGE)))
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_5_MAX_TRAVEL_OOR;
                    }

                    if ((p_act_param_table->num_obs_zones >= 6) &&
                        ((p_act_param_table->max_travel_zone5 >
                          p_act_param_table->max_travel_zone6) ||
                        (p_act_param_table->max_travel_zone6 > MAX_TRAVEL_RANGE)))
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_6_MAX_TRAVEL_OOR;
                    }

                    if ((p_act_param_table->num_obs_zones >= 7) &&
                        ((p_act_param_table->max_travel_zone6 >
                          p_act_param_table->max_travel_zone7) ||
                        (p_act_param_table->max_travel_zone7 > MAX_TRAVEL_RANGE)))
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_7_MAX_TRAVEL_OOR;
                    }

                    if ((p_act_param_table->num_obs_zones >= 8) &&
                        ((p_act_param_table->max_travel_zone7 >
                          p_act_param_table->max_travel_zone8) ||
                        (p_act_param_table->max_travel_zone8 > MAX_TRAVEL_RANGE)))
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_8_MAX_TRAVEL_OOR;
                    }

                    if ((p_act_param_table->num_obs_zones >= 9) &&
                        ((p_act_param_table->max_travel_zone8 >
                          p_act_param_table->max_travel_zone9) ||
                        (p_act_param_table->max_travel_zone9 > MAX_TRAVEL_RANGE)))
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_9_MAX_TRAVEL_OOR;
                    }

                    if ((p_act_param_table->num_obs_zones >= 10) &&
                        ((p_act_param_table->max_travel_zone9 >
                          p_act_param_table->max_travel_zone10) ||
                        (p_act_param_table->max_travel_zone10 > MAX_TRAVEL_RANGE)))
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_10_MAX_TRAVEL_OOR;
                    }
/* Zone 11 is for only used for obstacle detection calibration and the max
 * travel is not needed so don't let it fail */
//                    if( p_act_param_table->max_travel_zone11 > MAX_TRAVEL_RANGE )
//                    {
//                        sys_err = CFG_RANGE_ERROR;
//                        G_bad_table = table_num;
//                        G_bad_range_item = ACT_PARAM_ZONE_11_MAX_TRAVEL_OOR;
//                    }
                    if( ( p_act_param_table->pos_slope_width_zone1 >= MAX_ACT_SLOPE_WIDTH ) ||
                        ( p_act_param_table->neg_slope_width_zone1 >= MAX_ACT_SLOPE_WIDTH ) )
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_1_SLOPE_WIDTH_OOR;
                    }
                    if( ( p_act_param_table->pos_slope_width_zone2 >= MAX_ACT_SLOPE_WIDTH ) ||
                        ( p_act_param_table->neg_slope_width_zone2 >= MAX_ACT_SLOPE_WIDTH ) )
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_2_SLOPE_WIDTH_OOR;
                    }
                    if( ( p_act_param_table->pos_slope_width_zone3 >= MAX_ACT_SLOPE_WIDTH ) ||
                        ( p_act_param_table->neg_slope_width_zone3 >= MAX_ACT_SLOPE_WIDTH ) )
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_3_SLOPE_WIDTH_OOR;
                    }
                    if( ( p_act_param_table->pos_slope_width_zone4 >= MAX_ACT_SLOPE_WIDTH ) ||
                        ( p_act_param_table->neg_slope_width_zone4 >= MAX_ACT_SLOPE_WIDTH ) )
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_4_SLOPE_WIDTH_OOR;
                    }
                    if( ( p_act_param_table->pos_slope_width_zone5 >= MAX_ACT_SLOPE_WIDTH ) ||
                        ( p_act_param_table->neg_slope_width_zone5 >= MAX_ACT_SLOPE_WIDTH ) )
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_5_SLOPE_WIDTH_OOR;
                    }
                    if( ( p_act_param_table->pos_slope_width_zone6 >= MAX_ACT_SLOPE_WIDTH ) ||
                        ( p_act_param_table->neg_slope_width_zone6 >= MAX_ACT_SLOPE_WIDTH ) )
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_6_SLOPE_WIDTH_OOR;
                    }
                    if( ( p_act_param_table->pos_slope_width_zone7 >= MAX_ACT_SLOPE_WIDTH ) ||
                        ( p_act_param_table->neg_slope_width_zone7 >= MAX_ACT_SLOPE_WIDTH ) )
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_7_SLOPE_WIDTH_OOR;
                    }
                    if( ( p_act_param_table->pos_slope_width_zone8 >= MAX_ACT_SLOPE_WIDTH ) ||
                        ( p_act_param_table->neg_slope_width_zone8 >= MAX_ACT_SLOPE_WIDTH ) )
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_8_SLOPE_WIDTH_OOR;
                    }
                    if( ( p_act_param_table->pos_slope_width_zone9 >= MAX_ACT_SLOPE_WIDTH ) ||
                        ( p_act_param_table->neg_slope_width_zone9 >= MAX_ACT_SLOPE_WIDTH ) )
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_9_SLOPE_WIDTH_OOR;
                    }
                    if( ( p_act_param_table->pos_slope_width_zone10 >= MAX_ACT_SLOPE_WIDTH ) ||
                        ( p_act_param_table->neg_slope_width_zone10 >= MAX_ACT_SLOPE_WIDTH ) )
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_10_SLOPE_WIDTH_OOR;
                    }
                    if( ( p_act_param_table->pos_slope_width_zone11 >= MAX_ACT_SLOPE_WIDTH ) ||
                        ( p_act_param_table->neg_slope_width_zone11 >= MAX_ACT_SLOPE_WIDTH ) )
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_11_SLOPE_WIDTH_OOR;
                    }
                } /* End if multi-zone */
                else
                {
                    if( ( p_act_param_table->pos_slope_width_zone1 >= MAX_ACT_SLOPE_WIDTH ) ||
                        ( p_act_param_table->neg_slope_width_zone1 >= MAX_ACT_SLOPE_WIDTH ) )
                    {
                        sys_err = CFG_RANGE_ERROR;
                        G_bad_table = table_num;
                        G_bad_range_item = ACT_PARAM_ZONE_1_SLOPE_WIDTH_OOR;
                    }
                }
            }
            break;

        case TBL_ACT_CANID:
        {
            /* Cast the buffer to the appropriate type to aid in range checking */
            CFG_ACT_CANID_TABLE_TYPE* p_can_id_table;
            p_can_id_table = (CFG_ACT_CANID_TABLE_TYPE*)p_buffer;

            /* Make sure the Actuator's CAN ID is within valid CAN ID range */
            if( p_can_id_table->act_can_id > 0x7F )
            {
                sys_err = ERR_FAILURE;
                G_bad_table = table_num;
                G_bad_range_item = 2;
            }
            /* Make sure SCM CAN ID is within valid CAN ID range */
            else if( p_can_id_table->scm_can_id > 0x7F )
            {
                sys_err = ERR_FAILURE;
                G_bad_table = table_num;
                G_bad_range_item = 3;
            }
            /* Make sure term resistor setting is either On (1) or Off (0) */
            else if( p_can_id_table->term_resistor > 1 )
            {
                sys_err = ERR_FAILURE;
                G_bad_table = table_num;
                G_bad_range_item = 4;
            }
            /* Make sure GAP setting is in allowable range */
            else if( p_can_id_table->gap_0_allow_motion > GAP_DONT_CARE )
            {
                sys_err = ERR_FAILURE;
                G_bad_table = table_num;
                G_bad_range_item = 5;
            }
            /* Make sure GAP setting is in allowable range */
            else if( p_can_id_table->gap_1_allow_motion > GAP_DONT_CARE )
            {
                sys_err = ERR_FAILURE;
                G_bad_table = table_num;
                G_bad_range_item = 6;
            }
            /* Make sure GAP setting is in allowable range */
            else if( p_can_id_table->gap_2_allow_motion > GAP_DONT_CARE )
            {
                sys_err = ERR_FAILURE;
                G_bad_table = table_num;
                G_bad_range_item = 7;
            }
        }
        break;
        /**********************************************************************/
        case TBL_EVENT_PARAM:
        { /* Start local processing for private variables */
            CFG_EVENT_PROCESS_TABLE_TYPE* event_table =       /* Overlay type */
                        (CFG_EVENT_PROCESS_TABLE_TYPE*)p_buffer;

            for( i = 0; i < event_table->num_entries; ++i )
            {
                /* Maximum occurrences allowed for an event */
                /* Event IDs must be > 0 */
                if( event_table->event[i].num_occur >= MAX_EVENT_OCCUR )
                {
                    sys_err = ERR_FAILURE;
                    G_bad_table = table_num;
                    G_bad_range_item = i + 1;
                    break; /* Only need one failure */
                }
            }
        } /* End local processing */
        break;
        /**********************************************************************/
        case TBL_EVENT_CONSOL:
        { /* Start local processing for private variables */
            CFG_EVENT_CONSOL_TABLE_TYPE* consol_table =           /* Overlay type */
                        (CFG_EVENT_CONSOL_TABLE_TYPE*)p_buffer;

            if (consol_table->num_entries != NUM_EVENT_CODES)
            {
                sys_err = ERR_FAILURE;
                G_bad_table = table_num;
                G_bad_range_item = NUM_EVENT_CODES + 1;
            }
            else
            {
                for (i = 0; i < NUM_EVENT_CODES; ++i)
                {
                    /* Event IDs of 0 are from debug_data.h, init will fix it */
                    if (consol_table->event[i].ID == 0)
                    {
                        sys_err = ERR_FAILURE;
                        G_bad_table = table_num;
                        G_bad_range_item = i + 1;
                        break; /* Only need one failure */
                    }
                }
            }
        } /* End local processing */
        break;
    } /* End switch - all tables */

    return sys_err;
}


/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Utility function that loads a given configuration data table into RAM and
 *              performs a CRC check.  The process is repeated up to 5 times in case a CRC
 *              failure is detected.
 * Parameters:  table_num - 0-based table number in the order tables are stored in the memory.
 *              buffer    - buffer the table will be placed into.
 * Returns:     NO_ERROR      - a table has been loaded successfully.
 *              ERR_FAILURE   - CRC error has been detected.
 ********************************************************************************************/
static ERR_RET _cfg_load_table( INT16U table_num, INT16U* p_buffer )
{
#ifdef DISABLE_CRC32_CHECKS
#warning CRC checks have been disabled in _cfg_load_table()!!
    ERR_RET sys_err = NO_ERROR;
#else
    ERR_RET sys_err = ERR_FAILURE;
#endif
    INT16U  i;
    INT32U  computed_crc32;
    INT32U  table_crc32;
#ifndef BOOTLOADER
    ECAN_HW_MESSAGE tx_msg;
#endif

    if( table_num < TBL_NUM_TABLES )
    {
        /* Attempt to load and verify table CRC up to 5 times. */
        for( i = 0; i < NUM_RETRIES; i++ )
        {
            /* Copy table data from flash memory into the buffer in RAM. */
            util_memcpy_from_prog( p_buffer, tables[table_num].addr, tables[table_num].size );

            /* Perform a CRC32 check on the table excluding the CRC field. */
            crc32new_buffer( p_buffer, tables[table_num].size - SIZE_OF_CRC,
                             &computed_crc32);
            table_crc32 = *(INT32U*)(p_buffer + ( tables[table_num].size / WORDS_PER_PC_UNIT ) -
                                     TABLE_CRC_FIELD_SIZE );
            if( ( table_crc32 == computed_crc32 ) || ( table_crc32 == IGNORE_CRC ) )
            {
                sys_err = NO_ERROR;
                break;
            }
        }
    }
    if (sys_err) /* announce the event */
    {
        if( table_num == TBL_EVENT_CONSOL )
        {
#ifndef BOOTLOADER
            /* Initialize TX buffer */
            util_memset( &tx_msg, 0, sizeof(ECAN_HW_MESSAGE) );
            /* setup source and dest for common messages */
            tx_msg.Source   = ECAN_LRU_CAN_ID;
            tx_msg.Dest     = SCM_CAN_ID;
            ecan_fill_sid( &tx_msg, ECAN_ERROR_REPORT_SID );
            tx_msg.DLC  = ECAN_ERROR_REPORT_DLC;
            tx_msg.D[0] = ECAN_LRU_CAN_ID;
            tx_msg.D[1] = 3; // Config CRC Fault ID
            tx_msg.D[2] = ECAN_LRU_CAN_ID;
            ecan_tx_message( &tx_msg );
#endif
        }
        else
        {
            CRC_FAULT_FRAME frame = {{0}};
            /* Swap Endian */
            frame.Part_3.actual_CRC_LS = (INT8U)computed_crc32;
            computed_crc32 >>= 8;
            frame.Part_3.actual_CRC_LM = (INT8U)computed_crc32;
            computed_crc32 >>= 8;
            frame.Part_3.actual_CRC_UM = (INT8U)computed_crc32;
            computed_crc32 >>= 8;
            frame.Part_3.actual_CRC_MS = (INT8U)computed_crc32;
            /* Swap Endian */
            frame.Part_3.expected_CRC_LS = (INT8U)table_crc32;
            table_crc32 >>= 8;
            frame.Part_3.expected_CRC_LM = (INT8U)table_crc32;
            table_crc32 >>= 8;
            frame.Part_3.expected_CRC_UM = (INT8U)table_crc32;
            table_crc32 >>= 8;
            frame.Part_3.expected_CRC_MS = (INT8U)table_crc32;
            /* process the event */
            if( !comm_init_ok() )
            {
                ecan_init( SCM_CAN_ID, UNKNOWN_ACT_CAN_ID, BROADCAST_DEST_CAN_ID );
            }
            event_proc( CONFIGURATION_CRC_ERROR_FAULT, TRUE,
                       (GENERIC_EVENT_FRAME*)&frame);
        }
    }

    return sys_err;
}


/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Return flags indicating whether crc or range check errors have been detected.
 * Parameters:  p_crc_error   - pointer to variable set to TRUE if a CRC error was detected
 *                              and FALSE otherwise.
 *              p_range_error - pointer to variable set to TRUE if a range error was detected
 *                              and FALSE otherwise.
 * Returns:     None.
 ********************************************************************************************/
void cfg_get_error_status( BOOL* p_crc_error, BOOL* p_range_error )
{
    *p_crc_error   = G_crc_error;
    *p_range_error = G_range_error;

    /* Void return. */
    return;
}
