/*
 Author(s): Doug Wendt      <dwendt@omnicongroup.com>
 Status: Preliminary
 Release Date:
 Revision:
 Description: Header file for the Brake Module.
 */

#ifndef BRAKE_H
#define	BRAKE_H

/*********************************************************************************************
Includes
*********************************************************************************************/
#include "typedef.h"
#include "brake_control.h"

/*********************************************************************************************
Type Definitions
*********************************************************************************************/

/*********************************************************************************************
Preprocessor definitions
*********************************************************************************************/


/*********************************************************************************************
Function declarations
*********************************************************************************************/


/*********************************************************************************************
Author(s):   Doug Wendt      <dwendt@omnicongroup.com>
Description: Calculates the difference between the present brake position and a passed parameter
Parameters:  16 bit signed integer - Value to be compared against,
            (typically FULLY ENGAGED, FULLY DISENGAGED, or LAST Position)
Returns:     16 bit signed integer - see Description
********************************************************************************************/
INT16S brk_get_brake_delta (INT16S compare_value);

/*********************************************************************************************
Author(s):   Doug Wendt      <dwendt@omnicongroup.com>
Description: Hard Stop detection routine, Sets G_brake_status_flag = STOPPED when a Hard
             Stop has been detected
Parameters:  None.
Returns:     None.
********************************************************************************************/
void brk_check_hard_stop(void);

/*********************************************************************************************
Author(s):   Doug Wendt      <dwendt@omnicongroup.com>
Description: Updates the brake position Datastructure based on most reccent ADC data.
Parameters:  None.
Returns:     Error
 *********************************************************************************************/
//void brk_process_brake_data(STPC_POSITION_DATA * position);

/*********************************************************************************************
Author(s):   Doug Wendt      <dwendt@omnicongroup.com>
Description: This function returns TRUE if encoder signals are invalid and FALSE otherwise.
Parameters:  None.
Returns:     See description.
 *********************************************************************************************/
BOOL brk_get_invalid_encoder_signals(void);

#endif	/*BRAKE_H */
