/*
 Author(s): Andrew Kilkenny <akilkenny@righthandtech.com>
 Status: Preliminary
 Release Date:
 Revision:
 Description: Header file for the Actuator Communications Module.
 History:
 06/11/2010 Clay Barber Changed Files updates
 06/23/2016 Clay Barber Updates of Juan Kuyoc
 */

#ifndef COMMUNICATIONS_H
#define	COMMUNICATIONS_H

/*********************************************************************************************
Includes
*********************************************************************************************/
#include "global.h"
#include "can_catalog.h"
#include "can.h"
#include "brake_control.h"

/*********************************************************************************************
Type Definitions
*********************************************************************************************/

/*********************************************************************************************
Preprocessor definitions
*********************************************************************************************/

/*********************************************************************************************
 * Global variable definitions
 ********************************************************************************************/
/* Overlay status frame on message buffer data bytes */
extern ECAN_LRU_STATUS_FRAME* G_status_frame;

extern INT8U  G_lru_can_id;      /* Our CAN ID from config table */
extern INT8U  G_scm_can_id;      /* SCM CAN ID from config table */

/*********************************************************************************************
Function declarations
*********************************************************************************************/

/*********************************************************************************************
 * Author(s):   Andrew Kilkenny <akilkenny@righthandtech.com>
 * Description: The initialization function for the communication module.
 * Parameters:  None
 * Returns:     NO_ERROR    - indicates success
 *              ERR_FAILURE - indicates failure
*********************************************************************************************/
ERR_RET comm_init(void);

/*********************************************************************************************
Author(s):   Andrew Kilkenny <akilkenny@righthandtech.com>
Description: The periodic function function for the communication module.
Parameters:  None
Returns:     None
*********************************************************************************************/
void comm_exec(void);
void comm_status();
bool  is_New_Msg_cmd();
bool  get_Direction_cmd();
INT16U  get_Rpm_Desired_cmd();
bool  get_Test_cmd();
bool  get_Brake_cmd();


#endif  /*COMMUNICATIONS_H */

