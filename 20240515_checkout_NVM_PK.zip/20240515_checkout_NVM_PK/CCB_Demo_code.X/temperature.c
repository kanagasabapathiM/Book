/*
Author(s):      Andrew Kilkenny <akilkenny@righthandtech.com>
                    David Yuen <dyuen@righthandtech.com>
Status:         Preliminary
Release Date:
Revision:       Initial
Description:    Reads temperature for PCB, actuator motor & stepper motor
                    via I2C & ADC.  The ADC temperature values are 'pushed'
                    periodically, and the I2C values are read within the
                    temp_exec function.
*/
/*********************************************************************************************
Includes
*********************************************************************************************/
#include "global.h"
#include "cpu.h"
#include "i2c.h"
#include "temperature.h"

/*********************************************************************************************
 * Private type definitions
 ********************************************************************************************/
typedef enum
{
    PCB_TEMP_STATE = 0,
    STP_TEMP_STATE = 1,
} TEMP_STATE_ENUM;

/*********************************************************************************************
 * Private preprocessor definitions
 ********************************************************************************************/
#define ADC_MAX_ADC_OUTPUT     4095.0f  /* ADC output is between 0 and 4095 representing 0-3300mV */
#define ADC_MAX_VOLTAGE        3300.0f  /* in millivolts */

/*********************************************************************************************
 * Private function declarations
 ********************************************************************************************/
/*********************************************************************************************
 * Author(s):   Michael Ansolis.
 * Description: Calculates the PCB temperature.
 * Parameters:  None.
 * Returns:     None.
 ********************************************************************************************/
void _temp_calc_pcb_temp( void );

/*********************************************************************************************
 * Author(s):   Michael Ansolis.
 * Description: Calculates the Stepper temperature.
 * Parameters:  None.
 * Returns:     None.
 ********************************************************************************************/
void _temp_calc_stp_temp( void );

/*********************************************************************************************
 * Global variable definitions
 ********************************************************************************************/
static INT16S G_pcb_temp = 0;
static INT16S G_stepper_temp = 0;
/* Lookup table for temperature based on voltage. */
static CFG_TEMP_LOOKUP_TABLE_TYPE G_temp_params;


/*********************************************************************************************
 * Source file function definitions
 ********************************************************************************************/

/*********************************************************************************************
Author(s):      Michael Ansolis
Description:    The initialization function for the temperature module.
Parameters:     None
Returns:        None
*********************************************************************************************/
ERR_RET temp_init( void )
{
#ifdef I2C_DISABLED
    ERR_RET sys_err = NO_ERROR;
#else
    ERR_RET sys_err;
#endif

    /* Get the lookup table for voltage to temperature conversion. */
//    sys_err = cfg_load_parameters( TBL_TEMP_LOOKUP, (INT16U*)&G_temp_params );

    return sys_err;
}

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Periodically calculates the PCB and stepper temperatures.
 * Parameters:  None
 * Returns:     BOOL - indicates whether the timer should be updated (TRUE = both PCB and
 *              STP temps have been calculated) or not (FALSE).
 ********************************************************************************************/
BOOL temp_calc_temps ( void )
{
    static TEMP_STATE_ENUM temp_state = PCB_TEMP_STATE;
    BOOL update_time = FALSE;
#ifdef I2C_DISABLED
    return TRUE;
#endif
    if( PCB_TEMP_STATE == temp_state )
    {
        _temp_calc_pcb_temp();
        temp_state = STP_TEMP_STATE;
        update_time = FALSE;
    }
    else
    {
        _temp_calc_stp_temp();
        temp_state = PCB_TEMP_STATE;
        update_time = TRUE;
    }
    return update_time;
}


/*********************************************************************************************
 * Author(s):   Michael Ansolis.
 * Description: Calculates the PCB temperature.
 * Parameters:  None.
 * Returns:     None.
 ********************************************************************************************/
void _temp_calc_pcb_temp( void )
{
    INT16U voltage;
    INT16U n = 0;
    INT16S temp;
#ifdef I2C_DISABLED
    return;
#endif
    voltage = cpu_GetPcbTemp();

    if( voltage < (FP32)G_temp_params.lookup[0].voltage )
    {
        temp = G_temp_params.lookup[0].temperature;
    }
    else if( voltage > (FP32)G_temp_params.lookup[G_temp_params.table_size - 1].voltage )
    {
        temp = G_temp_params.lookup[G_temp_params.table_size - 1].temperature;
    }
    else
    {
        while( voltage > (FP32)G_temp_params.lookup[n+1].voltage )
            n++;

        temp = G_temp_params.lookup[n].temperature -
               (INT16S)( (voltage - (FP32)G_temp_params.lookup[n].voltage) *
                         (FP32)(G_temp_params.lookup[n].temperature - G_temp_params.lookup[n+1].temperature) /
                         (FP32)(G_temp_params.lookup[n+1].voltage - G_temp_params.lookup[n].voltage) );
    }

    G_pcb_temp = temp;
}

/*********************************************************************************************
Author(s):      Michael Ansolis.
Description:    Returns PCB temperature.
Parameters:     None.
Returns:        See description.
*********************************************************************************************/
INT16S temp_get_pcb_temp(void)
{
#ifdef I2C_DISABLED
    return 0x15;
#else
    return G_pcb_temp;
#endif
}

/*********************************************************************************************
 * Author(s):   Michael Ansolis.
 * Description: Calculates the Stepper temperature.
 * Parameters:  None.
 * Returns:     None.
 ********************************************************************************************/
void _temp_calc_stp_temp( void )
{
#ifdef I2C_DISABLED
    return;
#endif
    G_stepper_temp = 30;//valid value for demo
}

/*********************************************************************************************
Author(s):      Michael Ansolis.
Description:    Returns stepper motor temperature.
Parameters:     None.
Returns:        See description.
*********************************************************************************************/
INT16S temp_get_stepper_temp()
{
#ifdef I2C_DISABLED
    return 0x15;
#else
    return G_stepper_temp;
#endif
}
