/*********************************************************************************************
 *
 * NOTICE – PROPRIETARY INFORMATION COPYRIGHT © 2018
 *
 * B/E AEROSPACE CONSIDERS THIS DOCUMENT TO CONTAIN INFORMATION OF A
 * PROPRIETARY NATURE.  THEREFORE, THE RECEIVER OF THIS DOCUMENT IS REQUESTED
 * TO TREAT IT ACCORDINGLY AND TO NOT TRANSMIT, REVEAL, OR DISCLOSE IT OR ANY
 * PART THEREOF WITHOUT EXPRESS WRITTEN PERMISSION OF B/E AEROSPACE.
 * DISTRIBUTION AND/OR REPRODUCTION OF THIS DOCUMENT (IN WHOLE OR IN PART)
 * OUTSIDE OF B/E AEROSPACE MUST BE AUTHORIZED BY B/E AEROSPACE MANAGEMENT.
 *
 *********************************************************************************************
 *
 * Author:      M VanderZouwen
 * Status:	    Preliminary
 * Date:        06/10/20
 * Revision:    0.1
 * Description: Header file for the Event Manager module.
 *
 *********************************************************************************************
 *
 * Revision History:
 *      0.1 MVZ     Initial creation
 *
 ********************************************************************************************/

/*********************************************************************************************
 * Recursive header blocker
 ********************************************************************************************/
#ifndef EVENT_MANAGER_H
#define EVENT_MANAGER_H

/*********************************************************************************************
 * Included files
 ********************************************************************************************/
#include "global.h"

/*********************************************************************************************
 * Module Preprocessor definitions
 ********************************************************************************************/

/*********************************************************************************************
 * Module type definitions
 ********************************************************************************************/

/*********************************************************************************************
 * Module function declarations
 ********************************************************************************************/

/*********************************************************************************************
 * Author(s):   T Pashak
 * Description: Clears logs from memory and sends a CAN message if successful.
 * Parameters:  request_ID - The LRU requesting to erase the logs
 * Returns:     None.
 *********************************************************************************************/
void event_erase_log( INT8U request_ID );

/*********************************************************************************************
 * Author(s):   M VanderZouwen
 * Description: Determines if error(s) are active in the system
 * Parameters:  None
 * Returns:     If errors are active TRUE else FALSE
 *********************************************************************************************/
BOOL event_error_present( void );

/*********************************************************************************************
 * Author(s):   M VanderZouwen
 * Description: Searches event log in DataFlash to find the most recent
 *              boot count record.
 * Parameters:  None
 * Returns:     The boot count
 *********************************************************************************************/
INT16U event_find_boot_count( void );

/*********************************************************************************************
 * Author(s):   T Pashak
 * Description: Starts the process to retrieve historic fault information.
 * Parameters:  lru        - The LRU requesting historic faults
 *              time_frame - In hours for checking historic faults
 *              max_errors - The max number of errors to report for each LRU
 *              rate       - TRUE would add a 50 ms delay between messages
 *                         - FALSE means the messages are sent every cycle
 * Returns:     None.
 *********************************************************************************************/
void event_history_requested( INT8U lru, INT16U time_frame, INT8U max_errors, BOOL rate );

/*********************************************************************************************
 * Author(s):   M VanderZouwen
 * Description: Event manager module initialization prepares the module to
 *              manage events to be logged in DataFlash and/or sent to the SCM
 *              on the CAN bus.
 * Parameters:  None
 * Returns:     NO_ERROR     - Initialization was successful.
 *              INIT_FAILURE - Unable to load event parameters.
 *********************************************************************************************/
ERR_RET event_init( void );

/*********************************************************************************************
 * Author(s):   M VanderZouwen
 * Description: Sends the Log Frame to DataFlash and increments the pointer for
 *              the next entry.
 * Parameters:  p_log_frame  - Pointer to event log data frame
 * Returns:     None
 *********************************************************************************************/
void event_log_data( GENERIC_EVENT_LOG_FRAME* p_log_frame );

/*********************************************************************************************
 * Author(s):   T Pashak
 * Description: Returns the validity of a log based on the provided wrap flag.
 * Parameters:  flag  - The wrap flag of the log being checked
 * Returns:     See description
 *********************************************************************************************/
BOOL event_log_flag_valid( INT8U flag );

/*********************************************************************************************
 * Author(s):   M VanderZouwen
 * Description: Event Periodic is periodically run from the main loop to handle
 *              the event detection reporting ECAN_ERROR_REPORT CAN messages
 *              that need to occur every 100 mSec while a fault is active.
 * Parameters:  None
 * Returns:     None
 *********************************************************************************************/
void event_periodic( void );

/*********************************************************************************************
 * Author(s):   M VanderZouwen
 * Description: Event Processing handles the specified event according to the
 *              event-specific rules (in CFG_EVENT_PROCESS_TABLE_TYPE) for
 *              that event/fault.
 * Parameters:  event_code  - Event code
 *              event_state - Event state TRUE = set, FALSE = clear
 *              p_frame     - Pointer to event frame (Typecast for the event-specific frame)
 * Returns:     None
 *********************************************************************************************/
void event_proc(
    LRU_EVENT_CODES event_code,
    BOOL event_state,
    GENERIC_EVENT_FRAME* p_frame );

/*********************************************************************************************
 * Author(s):   M VanderZouwen
 * Description: Saves the event consolidation parameters to program memory
 *              for use in the next boot cycle
 * Parameters:  None
 * Returns:     None
 *********************************************************************************************/
void event_save_data( void );

/*********************************************************************************************
 * Author(s):   T Pashak
 * Description: Retrieves the next record address.
 * Parameters:  None.
 * Returns:     INT32U - address of next record to write.
 ********************************************************************************************/
INT32U event_get_next_record_addr( void );

/*********************************************************************************************
 * Author(s):   T Pashak
 * Description: Limits handling events if a shutdown is pending, and processes
 *              all events if the shutdown was canceled.
 * Parameters:  shutdown_pending - TRUE if a shutdown is pending.
 *                               - FALSE if initialization is complete.
 * Returns:     None
 ********************************************************************************************/
void event_inhibit(
        BOOL shutdown_pending );

/*********************************************************************************************
 * Author(s):   B Schaedig
 * Description: Returns the state of G_init_complete
 * Parameters:  None
 * Returns:     BOOL - if events are currently being inhibited
 ********************************************************************************************/
BOOL event_get_inhibit( void );

/*********************************************************************************************
 * Author(s):   C Rosendall
 * Description: Returns the ID of the given event index
 * Parameters:  index
 * Returns:     INT8U id of event at index
 ********************************************************************************************/
INT8U event_get_id( INT8U event_index );
/*********************************************************************************************
 * Recursive header blocker
 ********************************************************************************************/
#endif  /* EVENT_MANAGER_H */
