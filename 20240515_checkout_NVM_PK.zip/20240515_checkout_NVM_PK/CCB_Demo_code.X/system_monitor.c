/*
 Author(s):     Glenn Racette   <gracette@righthandtech.com>
                David Yuen      <dyuen@righthandtech.com>
                Doug Wendt      <dwendt@omnicongroup.com>
 Status:        Preliminary
 Release Date:
 Revision:
 Description:   Implementation of the Actuator System Monitor module.  This module is
                responsible for the initialization and periodic execution of several
                sub-modules, and the monitoring and reporting of the system status bits.
 History:
 06/11/2010 Clay Barber Changed Files updates
 06/24/2016 Clay Barber Updates of Juan Kuyoc
*/

/*********************************************************************************************
Includes
 *********************************************************************************************/
#include "adc_manager.h"
#include "bldc.h"
#include "bldc-temp.h"
#include "cpu.h"
#include "current.h"
#include "Event_Manager.h"
#include "global.h"
#include "hall.h"
#include "motion_control.h"
#include "position.h"
#include "brake_control.h"
#include "system_monitor.h"
#include "temperature.h"
#include "timer_manager.h"
#include "utility.h"

/*********************************************************************************************
Private Type Definitions
 *********************************************************************************************/
/* Bitfield containing the status bits for system monitoring. */
typedef struct tagStatusSM
{
    union
    {
        struct
        {
            INT8U motor_temp_ok          : 1;  /* 0x01  LSB */
            INT8U step_temp_ok           : 1;  /* 0x02      */
            INT8U shut_down              : 1;  /* 0x04      */
            INT8U _spare0                : 1;  /* 0x08      */
            INT8U brake_engaged          : 1;  /* 0x10      */
            INT8U pcb_temp_ok            : 1;  /* 0x20      */
            INT8U overcurrent            : 1;  /* 0x40      */
            INT8U critical_overcurrent   : 1;  /* 0x80  MSB */

            INT8U obstacle_detect        : 1;  /* 0x01  LSB */
            INT8U act_failure            : 1;  /* 0x02      */
            INT8U chip_failure           : 1;  /* 0x04      */
            INT8U param_vars_ok          : 1;  /* 0x08      */
            INT8U motor_temp_critical    : 1;  /* 0x10      */
            INT8U stepper_temp_critical  : 1;  /* 0x20      */
            INT8U pcb_temp_critical      : 1;  /* 0x40      */
            INT8U repeating_obstacle     : 1;  /* 0x80  MSB */

            INT8U invalid_enc_signals    : 1;  /* 0x01  LSB */
            INT8U app_crc_failure        : 1;  /* 0x02      */
            INT8U disengage_failure      : 1;  /* 0x04      */
            INT8U rep_disengage_failure  : 1;  /* 0x08      */
            INT8U mech_brake_failure     : 1;  /* 0x10      */
            INT8U rep_mech_brake_failure : 1;  /* 0x20      */
            INT8U cfg_crc_error          : 1;  /* 0x40      */
            INT8U cfg_range_error        : 1;  /* 0x80  MSB */
        };
        INT8U  raw_byte[4];
        INT16U raw_word[2];
        INT32U raw_long;
    };
} SM_STATUS;

/* Bitfield used to track the reception of all of the CAN Parameter msgs.
   Once all parameter msgs have been received, the params_vars_ok bit will be OK. */
typedef struct __attribute__((packed)) tagParamVars
{
    union
    {
        struct
        {
            INT16U pos_slope_thresh_zone1 : 1;  //LSB
            INT16U pos_slope_width_zone1 : 1;
            INT16U pos_load_limit_zone1 : 1;
            INT16U neg_slope_thresh_zone1 : 1;
            INT16U neg_slope_width_zone1 : 1;
            INT16U neg_load_limit_zone1 : 1;
            INT16U spike_height_zone1 : 1;
            INT16U spike_width_zone1 : 1;
            INT16U temp : 1;
            INT16U num_zones : 1;
            INT16U max_travel_zone1 : 1;
            INT16U max_travel_zone2 : 1;
            INT16U pos_slope_thresh_zone2 : 1;
            INT16U pos_slope_width_zone2 : 1;
            INT16U pos_load_limit_zone2 : 1;
            INT16U neg_slope_thresh_zone2 : 1;  //MSB

            INT16U neg_slope_width_zone2 : 1;   //LSB
            INT16U neg_load_limit_zone2 : 1;
            INT16U spike_height_zone2 : 1;
            INT16U spike_width_zone2 : 1;
            INT16U max_travel_zone3 : 1;
            INT16U pos_slope_thresh_zone3 : 1;
            INT16U pos_slope_width_zone3 : 1;
            INT16U pos_load_limit_zone3 : 1;
            INT16U neg_slope_thresh_zone3 : 1;
            INT16U neg_slope_width_zone3 : 1;
            INT16U neg_load_limit_zone3 : 1;
            INT16U spike_height_zone3 : 1;
            INT16U spike_width_zone3 : 1;
            INT16U max_travel_zone4 : 1;
            INT16U pos_slope_thresh_zone4 : 1;
            INT16U pos_slope_width_zone4 : 1;   //MSB

            INT16U pos_load_limit_zone4 : 1;    //LSB
            INT16U neg_slope_thresh_zone4 : 1;
            INT16U neg_slope_width_zone4 : 1;
            INT16U neg_load_limit_zone4 : 1;
            INT16U spike_height_zone4 : 1;
            INT16U spike_width_zone4 : 1;
            INT16U max_travel_zone5 : 1;
            INT16U pos_slope_thresh_zone5 : 1;
            INT16U pos_slope_width_zone5 : 1;
            INT16U pos_load_limit_zone5 : 1;
            INT16U neg_slope_thresh_zone5 : 1;
            INT16U neg_slope_width_zone5 : 1;
            INT16U neg_load_limit_zone5 : 1;
            INT16U spike_height_zone5 : 1;
            INT16U spike_width_zone5 : 1;
            INT16U cal_offset : 1;              //MSB

            INT16U max_travel_zone6 : 1;        //LSB
            INT16U pos_slope_thresh_zone6 : 1;
            INT16U pos_slope_width_zone6 : 1;
            INT16U pos_load_limit_zone6 : 1;
            INT16U neg_slope_thresh_zone6 : 1;
            INT16U neg_slope_width_zone6 : 1;
            INT16U neg_load_limit_zone6 : 1;
            INT16U spike_height_zone6 : 1;
            INT16U spike_width_zone6 : 1;
            INT16U max_travel_zone7 : 1;
            INT16U pos_slope_thresh_zone7 : 1;
            INT16U pos_slope_width_zone7 : 1;
            INT16U pos_load_limit_zone7 : 1;
            INT16U neg_slope_thresh_zone7 : 1;
            INT16U neg_slope_width_zone7 : 1;
            INT16U neg_load_limit_zone7 : 1;    //MSB

            INT16U spike_height_zone7 : 1;      //LSB
            INT16U spike_width_zone7 : 1;
            INT16U max_travel_zone8 : 1;
            INT16U pos_slope_thresh_zone8 : 1;
            INT16U pos_slope_width_zone8 : 1;
            INT16U pos_load_limit_zone8 : 1;
            INT16U neg_slope_thresh_zone8 : 1;
            INT16U neg_slope_width_zone8 : 1;
            INT16U neg_load_limit_zone8 : 1;
            INT16U spike_height_zone8 : 1;
            INT16U spike_width_zone8 : 1;
            INT16U max_travel_zone9 : 1;
            INT16U pos_slope_thresh_zone9 : 1;
            INT16U pos_slope_width_zone9 : 1;
            INT16U pos_load_limit_zone9 : 1;
            INT16U neg_slope_thresh_zone9 : 1;  //MSB

            INT16U neg_slope_width_zone9 : 1;   //LSB
            INT16U neg_load_limit_zone9 : 1;
            INT16U spike_height_zone9 : 1;
            INT16U spike_width_zone9 : 1;
            INT16U max_travel_zone10 : 1;
            INT16U pos_slope_thresh_zone10 : 1;
            INT16U pos_slope_width_zone10 : 1;
            INT16U pos_load_limit_zone10 : 1;
            INT16U neg_slope_thresh_zone10 : 1;
            INT16U neg_slope_width_zone10 : 1;
            INT16U neg_load_limit_zone10 : 1;
            INT16U spike_height_zone10 : 1;
            INT16U spike_width_zone10 : 1;
            INT16U max_travel_zone11 : 1;
            INT16U pos_slope_thresh_zone11 : 1;
            INT16U pos_slope_width_zone11 : 1;  //MSB

            INT16U pos_load_limit_zone11 : 1;   //LSB
            INT16U neg_slope_thresh_zone11 : 1;
            INT16U neg_slope_width_zone11 : 1;
            INT16U neg_load_limit_zone11 : 1;
            INT16U spike_height_zone11 : 1;
            INT16U spike_width_zone11 : 1;
            INT16U elec_resist : 1;
            INT16U em_force : 1;
            INT16U spare : 8;
        };

        struct
        {
            INT64U word1;
            INT64U word2;
        };
    };
} SM_PARAMS_RECV;

/* These params come from the CAN parameter messages. */
typedef struct
{
    INT16S max_motor_temp;
    INT16S max_step_temp;
    INT16S max_pcb_temp;
} SM_PARAMS;


/*********************************************************************************************
Private Preprocessor definitions
 *********************************************************************************************/
/* Refer to SM_STATUS type
 The value of status byte B1 indicating "OK" conditions that would allow motion:
    motor_temp_ok        = TRUE     (LSB)
    step_temp_ok         = TRUE
    impending_shutdown   = FALSE
    reserved             = FALSE
    brake_engaged        = TRUE
    pcb_temp_ok          = TRUE
    overcurrent          = FALSE
    critical_overcurrent = FALSE    (MSB)
    byte = 00110011
 **
 The value of status byte B2 indicating "OK" conditions that would allow motion:
    obstacle_detection    = FALSE        (LSB)
    actuation_failure     = FALSE
    motor_chip_failure    = FALSE
    param_var_ok          = TRUE
    motor_temp_critical   = FALSE
    stepper_temp_critical = FALSE
    pcb_temp_critical     = FALSE
    repeating_obstacle_detection = FALSE (MSB)
    byte = 00001000
 **
 The value of status byte B3 indicating "OK" conditions that would allow motion:
    invalid_encoder_signals            = FALSE      (LSB)
    application_crc_failure            = FALSE
    disengage_failure                  = Don't care
    repeating_disengage_failure        = FALSE
    mechanical_brake_failure           = FALSE
    repeating_mechanical_brake_failure = FALSE
    cfg_crc_error                      = FALSE
    cfg_range_error                    = FALSE      (MSB)
    byte = 00000000
 */
#define SM_STATUS_OK        0x00000833
#define SM_LED_STATUS_OK    0x00000800
#define SM_LED_MASK         0x00EBFC80
#define SM_MOTION_STATUS_OK 0x00000800
#define SM_MOTION_MASK      0x00FFFFC4
#define SM_ERROR_STATUS_OK  0x00000023
#define SM_ERROR_MASK       0x00FFF6E3
#define SM_WIGGLE_RESTART_MASK  0x00EFFFC4  // exclude mech brake failure

#define SM_LRU_STATUS_D7_DEFAULT 0x08

#define SCM_CONTROL_ACTIVE  1

/*
 The value of the SM_PARAMS_RECV bitfield indicating all parameter msgs have been received.
 */
#define PARAMS_VARS_RECV_OK      0xFFFFFFFFFFFF

/* Possible values of the S_params_recv bit fields */
#define SM_PARAM_RECEIVED        1
#define SM_PARAM_NOT_RECEIVED    0
#define MOTN_STARTUP_TIME        100ul     /* 100ms */
#define ERR_LOG_UPD_PERIOD       600000ul  /* 10 minutes in milliseconds. */

#define MIN_TIME_SINCE_STARTUP   500  /* Allow motion after 150ms after startup. */
#define STATUS_UPDATE_PERIOD     5    /* Update status bits every 5ms. */

#define CRIT_OVERCURRENT_COUNT_THRESHOLD   5      /* Number of times Overcurrent conditions must be met to flag an error. */
#define CHIP_FAILURE_COUNT_THRESHOLD       5      /* Number of times Chip Failure conditions must be met to flag an error. */
#define REP_DISENGAGE_COUNT_THRESHOLD      3      /* Number of times Disengage Failure conditions must be detected to flag the repeating error. */
#define REP_ENGAGE_FAILURE_COUNT_THRESHOLD 5      /* Number of times Mechanical Brake Failure conditions must be detected to flag the repeating error. */
#define ACT_FAILURE_EXPIRATION_TIME        100ul  /* Actuation Failure expires 100ms after it was last detected. */
#define DISENGAGE_FAILURE_EXPIRATION_TIME  100ul  /* Disengage Failure expires 100ms after it was last detected. */
#define BRAKE_FAILURE_EXPIRATION_TIME      100ul  /* Mechanical Brake failre expires 100ms after it was last detected. */
#define ACT_POS_NO_CHANGE_FAULT_DEBOUNCE_MS     1000ul   /* Actuator position not following motor drive debounce time */
#define FAULT_CLEAR_TIME        20ul

#define MOTOR_DEG_PER_PULSE             ( DEGREES_PER_REV / HALL_TRANS_PER_ROT )  /* There are 45 degrees per pulse of the hall sensors and 3 hall sensors */

/*********************************************************************************************
Private Function declarations
 *********************************************************************************************/
void _sm_update_status_bits( void );

/*********************************************************************************************
Global Variable definitions
 *********************************************************************************************/
/* Status bit flags for system monitoring. */

/*********************************************************************************************
Function definitions
 *********************************************************************************************/

/*********************************************************************************************
Author(s):     
Description:    
Parameters:     init_error - indicates if there was an error when initializing the system.
Returns:        None
History:        
 *********************************************************************************************/
ERR_RET sm_init( )
{
    ERR_RET sys_err=NO_ERROR;

    /* Initialize the Current module. */
    if(sys_err == NO_ERROR)
    {
       sys_err = i2c_init(); //Initialize the interface for board temperature
    }

    /* Initialize the ADC_Manager module to start background input measurements.
       Note:  This should be started as soon after startup as possible. */
    if(sys_err == NO_ERROR)
    {
        /* Initialize the ADC into a free running/DMA mode */
        adcm_init();//before this PWM init should be initialized as the trig source 
    }
    return sys_err;
}


/*********************************************************************************************
Author(s):      Michael Ansolis
Description:    The periodic execution function for the System Monitor module.
Parameters:     None
Returns:        None
 *********************************************************************************************/
void sm_exec(void)
{
   // INT32U now;

    /* Get the current system clock */
   // now = tmgr_get_system_time();
    /* This is executed periodically to advance the I2C temperature state machine */
    i2c_temp_exec();
    
    ADCON3Lbits.SWCTRG = 1; //SW trigger for ADC channel
    
    ADC_Isense_RawAvg();

    /* Void return */
    return;
}
