/*
Author(s): Doug Wendt      <dwendt@omnicongroup.com>
Status: Preliminary
Release Date:
Revision:
Description:   File containing the definition of the Brake Position module
 */
/*********************************************************************************************
Includes
 *********************************************************************************************/
#include "global.h"
#include "communications.h"
#include "cpu.h"
#include "brake.h"
#include "utility.h"
#include "adc_manager.h"
#include "brake_control.h"

/*********************************************************************************************
Private Type Definitions
 *********************************************************************************************/

/*********************************************************************************************
Private Preprocessor definitions
 *********************************************************************************************/

/* Macro for converting raw 12-bit ADC values to millivolts. */
#define TO_MV(x)     ( (INT16U) ( ( (INT32U)x * 3300ul ) / 4095ul ) )

/* Reversal from a hard stop should be at least a full step */
#define REVERSING_CHANGE        5

/* The number of times reversal is permitted before stopping a hard stop */
#define MAX_REVERSALS         2

/*********************************************************************************************
Private Function declarations
 *********************************************************************************************/

/*********************************************************************************************
Global Variable definitions
 *********************************************************************************************/
/* A flag indicating that at least one of the brake encoder signals is outside
   the normal range */
static BOOL volatile G_invalid_brake_signals = FALSE;

/*********************************************************************************************
Function definitions
 *********************************************************************************************/

/*********************************************************************************************
Author(s):   Doug Wendt      <dwendt@omnicongroup.com>
Description: This function returns TRUE if encoder signals are invalid and FALSE otherwise.
Parameters:  None.
Returns:     See description.
 *********************************************************************************************/
BOOL brk_get_invalid_encoder_signals(void)
{
    return G_invalid_brake_signals;
}