/**************************************************************************************************
 * Author(s):    Michael Ansolis
 * Status:       Preliminary
 * Release Date:
 * Revision:
 * Description:  This module is reponsible for reading the positino reported by the Hall sensors
 *               inside the BLDC motor and computing rotation speed of the BLDC motor shaft.
 * History:
 * 06/11/2010 Clay Barber Changed Files updates
 * 06/24/2016 Clay Barber Updates of Juan Kuyoc
 *************************************************************************************************/

/*********************************************************************************************
Includes
*********************************************************************************************/
#include "pwm.h"
#include "hall.h"
#include "cpu.h"
#include "timer_manager.h"
#include <xc.h>

/*********************************************************************************************
Preprocessor definitions
*********************************************************************************************/

#define INVALID_HALL_POSITION 0xFFFF
/* Total number of possible Hall sensor input signal combinations */
#define NUM_POSITONS          6

/*********************************************************************************************
Type Definitions
*********************************************************************************************/
//INT16U halldata[500]; //just for debug
INT16U i=0;
INT32S sum = 0;
/*********************************************************************************************
Global definitions
*********************************************************************************************/

/* Ring buffer for period times (used in both ISR & non-ISR context). */
static volatile INT16U G_hall_period_buf[HALL_TRANS_PER_ROT];

/* Period state of the motion (used in both ISR & non-ISR context). */
static volatile PERIOD_STATE G_period_state;

/* The number of position changes according to the Hall sensors. */
static volatile INT16U G_position_change_steps;

static INT32S G_motor_position = 0;

static INT32U G_max_hall_dlt_time = 30000ul;

/*********************************************************************************************
Function declarations
*********************************************************************************************/

static void _hall_period_isr_ring_write(INT16U value);
static void _hall_period_isr_ring_set_all(INT16U value);
static void _hall_isr_check_rpm_state(INT16U current_hall);

/*********************************************************************************************
Function definitions
*********************************************************************************************/

/*********************************************************************************************
 * Author(s):    Michael Ansolis
 * Description:  Initializes the Hall module.
 * Parameters:   None
 * Returns:      None
 * History:
 * 06/11/2010 Clay Barber Changed Files updates
 *********************************************************************************************/
void hall_init(void)
{
    INT16U data;
    CNCONDbits.ON = 1; /*Change Notification (CN) Control enabled*/
    _CNDIF = 0;  /* Clear the Change Notification Interrupt Flag. */
    _CNDIP = 7;  /* Set Hall Notification interrupt as highest priority interrupt. */
    _CNDIE = 1;  /* Enable Change Notification interrupt. */
    CNFD = 0x0000;
    //init_CHDI();
    /* Initializes the hall sensor period ring buffer. */
   // G_max_hall_dlt_time = psn_get_hef_stop_timeout(); /*TBD returns the default value*/
    _hall_period_isr_ring_set_all(G_max_hall_dlt_time);

    /* Initialize global variables. */
    G_period_state = PERIOD_INVALID;
    G_position_change_steps = 0;
    data = PORTD;

}


/*********************************************************************************************
Author(s):      Dave Zielinski
Description:    Handles any of the 3 hall sensor GPIO changes.
    Performs the following tasks:
    - Controls which of the 6 of H-bridge transistors are being driven (commutation)
    - Measures the time since the last hall sensor value change (to compute RPM)
Parameters:     None
Returns:        None
*********************************************************************************************/
void __attribute__((interrupt, no_auto_psv)) _CNDInterrupt(void)
{
    INT16U current_hall;
    INT16U Data = PORTD;
    
    current_hall = ((Data >> 5) & 0x0007);
    _hall_isr_check_rpm_state(current_hall);
    pwm_isr_adjust_drive(current_hall);

    /* Update the Hall sensors motion detection count. */
    G_position_change_steps++;
/*
    halldata[i] = Data;
    halldata[i] = current_hall;
    
    i++;
    if(i>=500)
        i=0;*/
                
    /* Clear interrupt Change Notification interrupt. */  
    CNFD = 0x0000;
    IFS4bits.CNDIF = 0;
    
}


/*********************************************************************************************
 * Author(s):   Michael Ansolis
 * Description: Retrieves the state of the BLDC motor rotor.
 * Parameters:  None
 * Returns:     Direction of rotation based on the period buffer
*********************************************************************************************/
PERIOD_STATE hall_get_period_state(void)
{
    PERIOD_STATE period_state;

    DISABLE_INTERRUPTS();
    period_state = G_period_state;
    ENABLE_INTERRUPTS();

    return period_state;
}


/*********************************************************************************************
Author(s):      
Description:    
Parameters:     None
Returns:        Rotation time
*********************************************************************************************/
/*seems to be some issue when return 32bit value only 16 bit is returned from function
 that is the reason current used pointer*/
INT32S *hall_get_rotation_time(void)
{
    INT16U i;
    INT32S *p_sum;
    
    p_sum = &sum;
    *p_sum = 0;
    /*
     * Sum all the values in S_hall_period_buf which represents the total time
     * for a single revolution of the motor.
     */
    DISABLE_INTERRUPTS();
    for(i = 0; i < HALL_TRANS_PER_ROT; i++)
    {
        *p_sum += G_hall_period_buf[i];
    }
    ENABLE_INTERRUPTS();

    return p_sum;
}


/*********************************************************************************************
Author(s):      Dave Zielinski
Description:    Writes a value to the hall sensor period ring buffer
Parameters:     None
Returns:        None
*********************************************************************************************/
static void _hall_period_isr_ring_write(INT16U value)
{
    /* Write pointer for hall period captures */
    static INT16U S_hall_period_buf_index = 0;

    /* Write the value at the current write location and increment the index */
    G_hall_period_buf[S_hall_period_buf_index++] = value;

    /* Limit the member wr_index member to HALL_TRANS_PER_ROT */
    S_hall_period_buf_index %= HALL_TRANS_PER_ROT;
}


/*********************************************************************************************
Author(s):      Dave Zielinski
Description:    Set all the values in the hall sensor period ring buffer to the passed value.
Parameters:     None
Returns:        None
*********************************************************************************************/
static void _hall_period_isr_ring_set_all(INT16U value)
{
    INT16U i;

    for(i = 0; i < HALL_TRANS_PER_ROT; i++)
    {
        G_hall_period_buf[i] = value;
    }
}


/*********************************************************************************************
Author(s):      Dave Zielinski
Description:    - Advances the bldc state (if necessary)
                - Adds the hall sensor period to the ring buffer or clears the entire buffer
Parameters:     p_current_hall (in) - current hall sensor values
Returns:        None
*********************************************************************************************/
static void _hall_isr_check_rpm_state(INT16U current_hall)
{

    static INT16U S_previous_position = 0;
    INT16U        time_since_last_hall;

    /* Rotor position, indexed with 3-bit Hall sensor value */
    /* The following sequence contains Hall input states. */
    /* Every value in the POSITION array represents the position of gray codes in a sequential list:
     Ordered by sequence of Gray codes:     Ordered by Gray code value:
       0. 2 = 010b                            4. 1 = 001b
       1. 6 = 110b                            0. 2 = 010b
       2. 4 = 100b                            5. 3 = 011b
       3. 5 = 101b                            2. 4 = 100b
       4. 1 = 001b                            3. 5 = 101b
       5. 3 = 011b                            1. 6 = 110b    */

    /* Every index of the array elements represents Gray codes from the Hall sensor inputs.
       Hall sensors cannot report values 0 (all sensors reporting 0) or 7 (all sensors reporting 1),
       so positions corresponding to Gray codes 0 and 7 are marked as invalid. */
    /* The array acts as a lookup table to find out what Gray code should follow what previous
       Gray code for clockwise and anti-clockwise rotation direction. */
    /* For example, if the previous Gray code received from Hall sensors was 2, and the last code
       was 6, then we can see a 0->1 transition based on the lookup table indicating clockwise
       rotation.  If previous and last Gray code values are 1 and 5, the lookup table yields the
       corresponding values of 4->3, which is implies anti-clockwise motion.  In general,
       incrementing values indicate clockwise rotation, and decrementing values indicate
       anti-clockwise rotation. */
    const INT16U POSITION[] =
    {
        INVALID_HALL_POSITION, 4, 0, 5, 2, 3, 1, INVALID_HALL_POSITION,
    };

    INT16U current_hall_pos = POSITION[current_hall];

    /* Get time since last hall timer transition */
    tmgr_isr_get_hall_delta_time(&time_since_last_hall);

    /* If the hall sensor reading is invalid or timeout occurred */
    if( (current_hall_pos == INVALID_HALL_POSITION) ||
        (time_since_last_hall == G_max_hall_dlt_time) )
    {
        _hall_period_isr_ring_set_all(G_max_hall_dlt_time);
        G_period_state = PERIOD_INVALID;
    }
    else
    {
        INT16U adjacent_position_positive_dir;
        INT16U adjacent_position_negative_dir;
        /*
            Compute the position number of the spot next in the positive direction
        */
        adjacent_position_positive_dir =
            ((current_hall_pos + 1) % NUM_POSITONS);
        adjacent_position_negative_dir =
            ((current_hall_pos + NUM_POSITONS - 1) % NUM_POSITONS);
        if(adjacent_position_positive_dir == S_previous_position)
        {
            //PERIOD_NEGATIVE_DIR - For old actuator
            //PERIOD_POSITIVE_DIR - for new motor
            /* Movement is in the negative direction */
            if(G_period_state == PERIOD_POSITIVE_DIR)// modified as per the new Motor direction TBD
            {
                _hall_period_isr_ring_write(time_since_last_hall);
                G_motor_position--;
            }
            else
            {
                G_period_state = PERIOD_POSITIVE_DIR; /**TBD*/
            }
        }
        else if(adjacent_position_negative_dir == S_previous_position)
        {
            /* Movement is in the positive direction */
            if(G_period_state == PERIOD_NEGATIVE_DIR)/**TBD*/
            {
                _hall_period_isr_ring_write(time_since_last_hall);
                G_motor_position++;
            }
            else
            {
                G_period_state = PERIOD_NEGATIVE_DIR;/**TBD*/
            }
        }
        else
        {
            _hall_period_isr_ring_set_all(G_max_hall_dlt_time);
            G_period_state = PERIOD_INVALID;
        }
        S_previous_position = current_hall_pos;
    }
}


/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Returns the value indicating how many times the Hall sensors have reported
             a rotor position change.
Parameters:  None.
Returns:     See description.
*********************************************************************************************/
INT16U hall_get_position_change_steps(void)
{
    INT16U steps;

    DISABLE_INTERRUPTS();
    steps = G_position_change_steps;
    ENABLE_INTERRUPTS();

    return steps;
}


/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Returns a bitfield (least significant bits 0 - 2) indicating Hall sensor
             readings from the BLDC motor.
Parameters:  None.
Returns:     See description.
History:
06/11/2010 Clay Barber Changed Files updates
*********************************************************************************************/
INT16U hall_get_position()
{
    /* Read the current Hall sensor state */
	/* Uses Macro defined in cpu.h based on pin definitions for Hall sensors defined there */
    return HALL_SENSORS_READ;
}

/*********************************************************************************************
Author(s):   Juan Kuyoc
Description: Returns the motor position.
Parameters:  None
Returns:     INT16S - The motor position.
*********************************************************************************************/
INT32S hall_get_motor_position() {
    return G_motor_position;
}
