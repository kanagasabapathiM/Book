/*
 * Author(s):    Jonathan R. Saliers
 * Status:       Incomplete
 * Release Date: 11/30/12
 * Revision:     0.1
 * Description:  The Timer_Manager module is responsible for providing system time to all
 * modules as needed.  The Timer_Manager establishes a 1ms timer tick that serves as the
 * system clock.  This timer provides the current timer tick value upon request.  Modules
 * can use this timer to schedule tasks, such as status updates and CAN message output.
 */

/*********************************************************************************************
 * Source file includes
 ********************************************************************************************/
#include "cpu.h"
#include "timer_manager.h"
#include "brake_control.h"
#include <xc.h>

/*********************************************************************************************
 * Private type definitions
 ********************************************************************************************/

/*********************************************************************************************
 * Private preprocessor definitions
 ********************************************************************************************/
#define HALL_DELTA_TIME               CCP1TMRL
#define HALL_DELTA_TMR_INTERRUPT_FLAG IFS0bits.CCT1IF
#define HALL_DELTA_TIMER_ON_OFF       CCP1CON1Lbits.CCPON
#define ONE_MSEC                      10000  //0.1us is Tcy (10000*0.1 = 1000))
#define TIMER_ON                      1
#define TIMER_OFF                     0
#define TIMER_INTERRUPT_CLEAR         0
#define TIMER_INTERRUPT_ENABLED       1

/*********************************************************************************************
 * Private function declarations
 ********************************************************************************************/
static void _tmgr_init_hall_delta_timer(void);
static void _tmgr_init_1msec_clock(void);

/*********************************************************************************************
 * Global variable definitions
 *********************************************************************************************/

/* G_msecs_since_pwr_up holds a count of milliseconds since device start-up.
   It is incremented in the T1 interrupt, which triggers every millisecond. */
static volatile INT32U G_msecs_since_pwr_up;

/* G_hall_delta_timer_expired_flag tracks whether or not the Hall delta timer has expired.
   It is set to TRUE when the timer expires (in the T3 interrupt) and cleared to FALSE when
   the timer is started or reset. */
static volatile BOOL G_hall_delta_timer_expired_flag;

static INT32U G_max_hall_dlt_time = HEF_STOP_TIMEOUT_DEFAULT;

/*********************************************************************************************
 * Source file function definitions
 ********************************************************************************************/


/*********************************************************************************************
Author(s):   James Pieterick
Description: initialization function for the timer manager
Parameters:  None.
Returns:     None.
 *********************************************************************************************/
void tmgr_init(void)
{
    /* Initialize the T1 timer to trigger interrupts every millisecond. */
    _tmgr_init_1msec_clock();

    /* Initialize the T3 timer to keep track of the Hall sensor transition time. */
#ifndef BOOTLOADER
   // G_max_hall_dlt_time = psn_get_hef_stop_timeout();
#endif
    _tmgr_init_hall_delta_timer();

    return;
}


/*********************************************************************************************
Author(s):   
Description: Timer Manager private function to setup function for the 1 millisecond clock timer
Parameters:  None.
Returns:     None.
 *********************************************************************************************/
static void _tmgr_init_1msec_clock(void)
{
    /* Clear the Msec since power up counter */
    G_msecs_since_pwr_up = 0;

    /* Disable Timer 1 */
    ONE_MSEC_TIMER_ON_OFF = TIMER_OFF;

    /* Internal peripheral clock (FP) */
    T1CONbits.TCS = 0;
    
    T1CONbits.TECS = 1; //Timer1 Extended Clock Select bits TCY( Instruction cycle period))

    /* Disable "Gated Timer" mode */
    T1CONbits.TGATE = 0;

    /* Select 1:8 Prescaler - assuming a 80MHz clock, timer will tick at 0.1usec intervals */
    T1CONbits.TCKPS = 0x01;

    /* Clear the timer register */
    ONE_MSEC_COUNTER = 0x00;

    /* Load the period value into the timers period register */
    PR1 = ONE_MSEC;

    /* Set the timer Interrupt Priority Level */
    IPC0bits.T1IP = 0x01;

    /* Clear the timers Interrupt Flag */
    ONE_MSEC_TMR_INTERRUPT_FLAG = TIMER_INTERRUPT_CLEAR;

    /* Enable the timers interrupt */
    IEC0bits.T1IE = TIMER_INTERRUPT_ENABLED;

    /* turn on the 1 millisecond timer. */
    ONE_MSEC_TIMER_ON_OFF = TIMER_ON;

    /* Void Return */
    return;

}


/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: The interrupt service routine for timer 1 - the 1 millisecond timer.  The
 *              number of milliseconds since power up get incremented each time the timer
 *              times out.
 * Parameters:  None.
 * Returns:     None.
 *********************************************************************************************/
void __attribute__((interrupt, no_auto_psv)) _T1Interrupt( void )
{
    /* increment G_msecs_since_pwr_up */
    ++G_msecs_since_pwr_up;
    /* Clear the the timers interrupt flag */

    ONE_MSEC_TMR_INTERRUPT_FLAG = TIMER_INTERRUPT_CLEAR;
}

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Returns the number of milliseconds since unit power up.
 * Parameters:  None.
 * Returns:     The number of milliseconds since power up.
 *********************************************************************************************/
INT32U tmgr_get_system_time( void )
{

    INT32U msec;

    DISABLE_INTERRUPTS();
    msec = G_msecs_since_pwr_up;
    ENABLE_INTERRUPTS();

    return msec;

}

/*********************************************************************************************
Author(s):   James Pieterick
Description: Set up function for the Hall delta timer.
Parameters:  None
Returns:     None
 *********************************************************************************************/
static void _tmgr_init_hall_delta_timer(void)
{
    G_hall_delta_timer_expired_flag = FALSE;

    /* Disable Timer 3 */
    /* Set the hall delta timer to off. */
    HALL_DELTA_TIMER_ON_OFF = TIMER_OFF;

   // CCPSLP = 1// Module continues to operate in Sleep modes
    CCP1CON1Lbits.T32 = 0; // 16 bit dual timer mode
    CCP1CON1Lbits.TMRSYNC = 0; // Set timebase synchronization (Synchronized)
    /* Select internal instruction cycle clock for the timers input */
    CCP1CON1Lbits.CLKSEL = 0; // Set the clock source (Tcy)
   /* Select 1:64 Prescaler - assuming a 80Mhz clock the timer will tick at
       0.8 usec intervals.
     */
    CCP1CON1Lbits.TMRPS = 3; // Set the clock pre-scaler (1:64)

    CCP1CON1Hbits.TRIGEN=0; // Set Sync/Triggered mode (Synchronous Mode)
    CCP1CON1Hbits.SYNC = 0; // rolls over at FFFFh or match 
    // with period register (self sync)
    
    /* Load the period value into the timers period register */
    CCP1PRL =G_max_hall_dlt_time; // 16 bit MCCP1 low period register /*TBD*/
    CCP1PRH =0x0000; // 16 bit MCCP1 high period register
    

    /* Clear timer register */
    HALL_DELTA_TIME = 0x00;

    /* Set the timers Interrupt Priority Level */
    IPC1bits.CCT1IP = 0x01;

    /* Clear the timers Interrupt Flag */
    HALL_DELTA_TMR_INTERRUPT_FLAG = TIMER_INTERRUPT_CLEAR;

    /* Enable the timers interrupt */
    IEC0bits.CCT1IE = TIMER_INTERRUPT_ENABLED;
    
    //CCP1CON1Lbits.CCPON=1; // Start the Timer
    /* Leave the timer off - it will be turned on later */

}

/*********************************************************************************************
Author(s):   James Pieterick
Description: The interrupt service routine for timer 3 - the hall delta timer.
             This ISR is called 25ms after the timer is enabled.
Parameters:  None.
Returns:     None.
 *********************************************************************************************/
void __attribute__((interrupt, no_auto_psv)) _CCT1Interrupt(void)
{


    /* G_max_hall_dlt_time has been reached. Turn off the timer. */
    HALL_DELTA_TIMER_ON_OFF = TIMER_OFF;

    /* set the hall delta timer expired flag to true. */
    G_hall_delta_timer_expired_flag = TRUE;
   //GREEN_LED_PIN=GREEN_LED_PIN^1;

    /* Clear Timer3 interrupt flag */
    HALL_DELTA_TMR_INTERRUPT_FLAG = TIMER_INTERRUPT_CLEAR;
}


/*********************************************************************************************
Author(s):   James Pieterick
Description: returns the time in microseconds since the last time that this function
             was called in *p_hall_delta_time. The timer is reset and restarted by this function.

             Note that the largest value that this function will return is
             G_max_hall_dlt_time.

Parameters:  p_hall_delta_time - A pointer to the time delta in microseconds since the last
                                 time this function was called with the reset flag set.

Returns:     None.
 *********************************************************************************************/
void tmgr_isr_get_hall_delta_time(INT16U* p_hall_delta_time)
{
    if((HALL_DELTA_TMR_INTERRUPT_FLAG != TIMER_INTERRUPT_CLEAR) ||
       (G_hall_delta_timer_expired_flag == TRUE))
    {
        /* stop the timer */
        HALL_DELTA_TIMER_ON_OFF = TIMER_OFF;
        /* reset the interrupt flag. */
        HALL_DELTA_TMR_INTERRUPT_FLAG = TIMER_INTERRUPT_CLEAR;
        /* reset the timer register. */
        HALL_DELTA_TIME = 0x00;
        /* clear the hall delta time expired flag. */
        G_hall_delta_timer_expired_flag = FALSE;
        /* return G_max_hall_dlt_time . */
        *p_hall_delta_time = G_max_hall_dlt_time;
    }
    /* If the interrupt flag is not set: */
    else if (HALL_DELTA_TMR_INTERRUPT_FLAG == TIMER_INTERRUPT_CLEAR)
    {
        /* stop the timer */
        HALL_DELTA_TIMER_ON_OFF = TIMER_OFF;
        /* store the current elapsed time from the timer register */
        *p_hall_delta_time = HALL_DELTA_TIME;
        /* reset the timer register. */
        HALL_DELTA_TIME = 0x00;
        /* if the stored elapsed time >= G_max_hall_dlt_time
            return G_max_hall_dlt_time
        else
            return the stored elapsed time
        */
        if (*p_hall_delta_time >= G_max_hall_dlt_time )
        {
            *p_hall_delta_time = G_max_hall_dlt_time ;
        }
    }
    /* restart the timer */
    HALL_DELTA_TIMER_ON_OFF = TIMER_ON;
    return;
}


/*********************************************************************************************
Author(s):   James Pieterick
Description: returns a flag that indicates whether or not the hall delta timer has
             expired (exceeded G_max_hall_dlt_time).
Parameters:  None.
Returns:     A flag that if TRUE indicates that the hall delta timer has expired.
 *********************************************************************************************/
BOOL tmgr_hall_delta_time_expired(void)
{
    return G_hall_delta_timer_expired_flag;
}
