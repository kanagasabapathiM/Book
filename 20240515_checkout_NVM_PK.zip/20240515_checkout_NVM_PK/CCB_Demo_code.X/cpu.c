/*
 * Author(s):    
 *               
 * Status:       
 * Release Date:
 * Revision:
 * Description:  The CPU_Utility module is responsible for general configuration of the
 * DSC resources, such as the system clocks, GPIO pin-muxing, disabling of unused
 * peripherals, etc.  This module will also serve as the location for any general-purpose
 * utility routines that may be implemented during development, such as the enabling and
 * disabling of interrupts.
 * History:
 */

/*********************************************************************************************
 * Source file includes
 ********************************************************************************************/
#include "cpu.h"
#include "global.h"
#include "adc_manager.h"

/*********************************************************************************************
 * Private preprocessor definitions
 ********************************************************************************************/
/* PIC peripheral module enable/disable bits */
#define PIC_MODULE_ENABLE   0
#define PIC_MODULE_DISABLE  1

/* Port functional type set in the ANALOG_SELECT register */
#define PORT_TYPE_DIGITAL   0
#define PORT_TYPE_ANALOG    1

/* Port direction setting in TRIS register */
#define PORT_DIR_OUTPUT     0
#define PORT_DIR_INPUT      1

/* Port state driven to digital output pins */
#define PORT_OUT_LOW        0
#define PORT_OUT_HIGH       1

/* Re-mappable pin output selection for UART1 Tx. */
#define UART1TX     1

#define PERIPHERAL_FUNCTION_C1TX   0x15 /* CAN1 TX Peripheral Mapping */

#define PIN_SELECTION_RPI74        0x4A /* CAN2 RX Peripheral Mapping */

#define PIN_SELECTION_RPI66        0x42 /* SDI1 Peripheral Mapping */

#define PIN_SELECTION_RPI78        0x4E /* SDI3 Peripheral Mapping */

#define PERIPHERAL_FUNCTION_SDO1   0x05 /* SDO1 Peripheral Mapping */

#define PERIPHERAL_FUNCTION_SDO2   0x08 /* SDO2 Peripheral Mapping */

#define PERIPHERAL_FUNCTION_SDO3   0x0B /* SDO3 Peripheral Mapping */

#define PERIPHERAL_FUNCTION_SCK1   0x06 /* SCK1 Peripheral Mapping */

#define PERIPHERAL_FUNCTION_SCK3   0x0C /* SCK3 Peripheral Mapping */

#define FUNC_OUTPUT_COMPARE_1      0x10 /* unchanged for 256MU810 */

#define PIN_SELECTION_RPI75        0x4B /* UART1 Receive Peripheral Mapping */

#define STACK_START_OFFSET  0x20

//#define EVAL_BOARD 1

#define DISABLE      0
#define ENABLE       1
/*********************************************************************************************
 * Global variable definitions
 ********************************************************************************************/
#ifdef ENABLE_STACK_DIAGNOSTIC
static INT16U * G_top_of_stack = 0;
#endif

/*********************************************************************************************
 * Configuration Registers Setup
 ********************************************************************************************/
/* Note that only one invocation of the following may be in this project.
 * _FOSSEL() and _FOSC() map the oscillator configuration registers into program memory
 * space at the time of device programming.
 * Being outside of any C function includes their setup in the compiler
 * initialization processing. */

/* Select the internal FRC at Power On Reset & PWM peripheral unlocked */
/* PWMLOCK_OFF is invalid for the 'MU810 */
#pragma config FNOSC = FRC
#pragma config IESO = OFF

/* Enable Clock Switching, turn off failsafe mode, set up OSC2 as a general purpose IO pin,
   configure Primary Oscillator to disabled */
////IOL1WAY_OFF

// FOSC
#pragma config FCKSM = CSECMD
#pragma config OSCIOFNC = ON
#pragma config POSCMD = NONE


/* Set up WDT so it can be enabled in software, with window mode disabled, with 1:32 prescaler
   and 1:1024 postscaler, with the Low-Power RC (LPRC) oscillator clock source of 32kHz
   resulting in WDT timeout period of 1024ms. */
#pragma config FWDTEN = ON_SW    //Watchdog Timer Enable bit->WDT controlled via SW, use WDTCON.ON bit
#pragma config WINDIS = OFF    //Watchdog Timer operates in Window mode
//As No Pre-Post Scaler increased
#pragma config RWDTPS = PS32768    //Run Mode Watchdog Timer Post Scaler select bits->1 : 32768
#pragma config RCLKSEL = LPRC    //Watchdog Timer Clock Select bits->Always use LPRC

/* Setup the device for debugging */
#pragma config ICS = PGD2    //ICD Communication Channel Select bits->Communicate on PGC2 and PGD2
#pragma config JTAGEN = OFF    //JTAG Enable bit->JTAG is disabled

/* Setup I2C1 on the Alternate pins defined by ASDA1/ASCK1
 * Enable Brown Out Reset (per MU810 errata)
 * Set Power On Reset Timer = 128mS */
//_FPOR(ALTI2C1_ON & BOREN_ON & FPWRT_PWR128); /*TBD*/

/*********************************************************************************************
 * Private function declarations
 ********************************************************************************************/
/*********************************************************************************************
 * Author(s):   Joshua Craymer
 * Description: Fills stack memory with 0xFF bytes.
 *              Needed for stack utilization tests.
 * Parameters:  None.
 * Returns:     None.
 ********************************************************************************************/
static void _cpu_initialize_memory_stack( void );

/*********************************************************************************************
 * Author(s):   Michael Ansolis
 * Description: Set up project-specific I/O pins and microcontroller modules.
 * Parameters:  None.
 * Returns:     None.
 ********************************************************************************************/
static void _cpu_set_pinmux( void );

/*********************************************************************************************
 * Source file function definitions
 ********************************************************************************************/
/*********************************************************************************************
 * Author(s):       J Craymer
 * Description:     Sets the top of stack, should be called first in execution.
 * Parameters:      None
 * Returns:         None
 *********************************************************************************************/
void cpu_set_top_of_stack( void )
{
#ifdef ENABLE_STACK_DIAGNOSTIC
    volatile INT16U markerValue = 0xFEFE;
    G_top_of_stack = (INT16U*)( (INT16U)( (INT16U*)&markerValue ) - STACK_START_OFFSET );
#endif
    return;
}

#ifdef ENABLE_STACK_DIAGNOSTIC
/*********************************************************************************************
 * Author(s):       J Craymer
 * Description:     Retrieves the top of stack.
 * Parameters:      None
 * Returns:         unsigned int * - pointer to top of stack
 *********************************************************************************************/
INT16U * cpu_get_top_of_stack( void )
{
    return G_top_of_stack;
}
#endif

/*********************************************************************************************
 * Author(s):   Joshua Craymer
 * Description: Fills stack memory with 0xFF bytes.
 *              Needed for stack utilization tests.
 * Parameters:  None.
 * Returns:     None.
 ********************************************************************************************/
static void _cpu_initialize_memory_stack( void )
{
#ifdef ENABLE_STACK_DIAGNOSTIC
    INT16U * p_start_address;
    INT16U * p_end;

    p_start_address = (void*)SPLIM - 2;
    p_end = cpu_get_top_of_stack();

    /* initialize stack */
    for( ; p_start_address >= p_end; p_start_address-- )
    {
        *((INT16U*)p_start_address) = 0xFFFF;
    }

    Nop();
#endif
    return;
}

#ifdef ENABLE_STACK_DIAGNOSTIC
/*********************************************************************************************
 * Author(s):       J Craymer
 * Description:     Maps can_termination commands to correct output
 * Parameters:      p_last_address   - Fills with highest utilized stack address.
 * Parameters:      p_end_address    - Fills with end stack address.
 * Parameters:      p_start_address  - Fills with start stack address.
 *                  p_use_percentage - Fills with use percentage out of 100
 * Returns:         None
 *********************************************************************************************/
void cpu_get_stack_utilization( INT32U * p_last_address, INT32U * p_end_address, INT32U * p_start_address, INT8U * p_use_percentage )
{
    INT16U * p_address;
    INT16U * p_start;
    INT16U * p_end;
    BOOL end_test = FALSE;
    INT32U stack_size = 0;
    INT32U utilization_size = 0;

    Nop();

    p_start = cpu_get_top_of_stack();
    *p_start_address = (INT16U)p_start;
    p_end = (void*)SPLIM-2;
    *p_end_address = (INT16U)p_end;

    p_address = p_end;

    while( !end_test )
    {
         if ( ( *p_address != 0xFFFF ) || ( p_address <= p_start ) )
         {
              break;
         }
         p_address--;
    }

    *p_last_address = (INT16U)p_address;

    stack_size = (INT32U)( (INT16U)( p_end ) - (INT16U)( p_start ) );
    utilization_size = (INT32U)( (INT16U)( p_address ) - (INT16U)( p_start ) );

    *p_use_percentage = (INT8U)( ( 100 * utilization_size ) / stack_size );
    return;
}
#endif

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: The initialization function for the CPU_Utility module.
 * Parameters:  None.
 * Returns:     None.
 ********************************************************************************************/
void cpu_init( void )
{
#if 0
    ///------------THIS IS CHANGED BECAUSE FOR THE CAN TO WORK AT 1MBPS ALL TIMING RELATED THINGS SHOULD BE CHECKED AGAIN
    /*  
   Input frequency                               :  8.00 MHz
   Clock source                                  :  FRC Oscillator with PLL
   System frequency (Fosc)                       :  80.00 MHz [(8.00 MHz / 1) * 60 / 3 / 2 = 80.00 MHz]
   PLL VCO frequency (Fvco)                      :  480.00 MHz [(8.00 MHz / 1) * 60 = 480.00 MHz]
   PLL output frequency (Fpllo)                  :  160.00 MHz [(8.00 MHz / 1) * 60 / 3 = 160.00 MHz]
   PLL VCO divider frequency (Fvcodiv)           :  120.00 MHz [480.00 MHz / 4 = 120.00 MHz]*/
    // RCDIV FRC/1; PLLPRE 1:1; DOZE 1:8; DOZEN disabled; ROI disabled; 
    //CLKDIV = 0x3001;
    CLKDIVbits.PLLPRE = 1;
    PLLFBDbits.PLLFBDIV = 0x3C;
    // PLLDIV 60; 
    //PLLFBD = 0x3C;

    // PLLPOST 1:3; VCODIV FVCO/4; POST2DIV 1:1; 
    // PLLDIV = 0x31;
    PLLDIVbits.POST1DIV = 3; // N2=3
    PLLDIVbits.POST2DIV = 1; // N3=1
    CANCLKCON = 0x8207;
    //------------
#endif

    /* Input frequency                               :  8.00 MHz
       Clock source                                  :  FRC Oscillator with PLL
       System frequency (Fosc)                       :  160.00 MHz [(8.00 MHz / 1) * 80 / 2 / 2 = 160.00 MHz]
       PLL VCO frequency (Fvco)                      :  640.00 MHz [(8.00 MHz / 1) * 80 = 640.00 MHz]
       PLL output frequency (Fpllo)                  :  320.00 MHz [(8.00 MHz / 1) * 80 / 2 = 320.00 MHz]
       PLL VCO divider frequency (Fvcodiv)           :  160.00 MHz [640.00 MHz / 4 = 160.00 MHz]
       */
    
    // RCDIV FRC/1; PLLPRE 1:1; DOZE 1:8; DOZEN disabled; ROI disabled; 
    CLKDIVbits.PLLPRE = 1;
    PLLFBDbits.PLLFBDIV = 80; // M

    // PLLPOST 1:3; VCODIV FVCO/4; POST2DIV 1:1; 
    PLLDIVbits.POST1DIV = 2; // N2=3
    PLLDIVbits.POST2DIV = 1; // N3=1
    
    // CANCLKEN enabled; CANCLKSEL FVCO/4; CANCLKDIV Divide by 8; 
    CANCLKCON = 0x8507;
 
    //------------

    /* Initiate the clock switch to "FRC with PLL" (NOSC = 0b001) */
    __builtin_write_OSCCONH(0x01);

    /* Set the Oscillator Switch Enable bit (OSWEN) to request that the oscillator
       switch to the selection specified in bit field NOSC. */
    __builtin_write_OSCCONL(OSCCON | 0x01);

    // Wait for Clock switch to occur
    while (OSCCONbits.OSWEN != 0);

    /* Wait for the the clock switch to occur */
    while (OSCCONbits.COSC != 0b001);

    /* Wait for the PLL to lock */
    while (OSCCONbits.LOCK != 1);

    /* Set the PIC pin I/Os to the project-specific settings for type, direction and level */
    _cpu_set_pinmux();

    /* Enable WDT in S/W.  It is set for a timeout period of 1.024s */
    //_SWDTEN = 1; /*default it is enable*/ /*TBD*/

    _cpu_initialize_memory_stack();

    return;
}


/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 *              Doug Wendt      <dwendt@omnicongroup.com>
 * Description: Set project-specific I/O pins for type, direction, and level
 * Parameters:  None.
 * Returns:     None.
 * History:
 * 06/11/2010 Clay Barber Changed Files updates
 * 09/07/2018 M VanderZouwn - Reorganized by pin number to match other LRUs
 *
 ********************************************************************************************/
static void _cpu_set_pinmux( void )
{
    /*
     * Note: the "//>" comment lines are not applicable to the pin configuration
     * but are retained for consistency
     */
    /* Note: The BLDC Motor Drive pins (E0, E1, E2, E3, E4 and E5) named
     *       DRIVE_1L, 1H, 2L, 2H, 3L and 3H are outputs that are set up
     *       by the PWM peripheral and therefore do not need to be defined
     *       as outputs.  They are designated as Digital pins by the ANSExx
     *       assignment statement below.
     */
    /*
     * Note: Unconnected pins are assigned as digital outputs driven low
     */

    /* Unlock the Peripheral Pin Select registers */
    __builtin_write_OSCCONL(OSCCON & ~(1 << 6));
    /* Unlock ?Peripheral Re mapping Registers */
    __builtin_write_RPCON(0x0000);

    /* Pin  1 - (RP46/PWM1H/PMD5/RB14) SOL_DRVH */
    _TRISB14 = PORT_DIR_OUTPUT;
    _LATB14  = PORT_OUT_LOW;

    /* Pin  2 - (RP47/PWM1L/PMD6/RB15) SOL_DRVL */
    //_TRISB15 = PORT_DIR_OUTPUT;
    //_LATB15  = PORT_OUT_LOW;
 

    /* Pin  3 - (RP60/PWM8H/PMD7/RC12) FLT_TRIP */
    _TRISC12 = PORT_DIR_INPUT;
    
    /* Pin  4 - (RP61/PWM8L/PMA5/RC13) No Connect */
    
    /* Pin  5 - (RP62/PWM6H/PMA4/RC14) 5V_ENABLE */
    _TRISC14 = PORT_DIR_OUTPUT;
    _LATC14  = PORT_OUT_LOW;    

    /* Pin  6 - (RP63/PWM6L/PMA3/RC15) 5V_PGOOD*/
    _TRISC15 = PORT_DIR_INPUT;
    
    /* Pin  7 - (nMCLR) nRESET*/
    /* No configuration required */
    
    /* Pin  8 - (RP79/PCI22/PMA2/RD15) SPI3_CS */
    _TRISD15 = PORT_DIR_OUTPUT;
    _LATD15  = PORT_OUT_HIGH;
    _CNPUD15  = ENABLE;   /*Enable internal pullup as per pin list*/

    /* Pin  9 - (VSS) VSS */
    /* No configuration required */

    /* Pin 10 - (VDD) VDD */
    /* No configuration required */

    /* Pin 11 - (RP78/PCI21/RD14) SPI3_SDI */
    _TRISD14 = PORT_DIR_INPUT;
    _SDI3R   = PIN_SELECTION_RPI78;
    _CNPUD14  = ENABLE;   /*Enable internal pullup as per pin list*/

    /* Pin 12 - (ANN4/CMP5B/RP77/RD13) SPI3_SDO */
    _TRISD13  = PORT_DIR_OUTPUT;
    _ANSELD13 = PORT_TYPE_DIGITAL;
    _LATD13   = PORT_OUT_LOW;
    _RP77R    = PERIPHERAL_FUNCTION_SDO3;

    /* Pin 13 - (AN12/ANN0/RP48/RC0) SPI3_SCK */
    _TRISC0   = PORT_DIR_OUTPUT;
    _ANSELC0  = PORT_TYPE_DIGITAL;
    _LATC0    = PORT_OUT_LOW;
    _RP48R   = PERIPHERAL_FUNCTION_SCK3;

    /* Pin  14 - (OA1OUT/AN0/CMP1A/IBIAS0/RA0) ISENSE */
    _TRISA0  = PORT_DIR_INPUT;
    _ANSELA0 = PORT_TYPE_ANALOG;

    /* Pin 15 - (OA1IN-/ANA1/RA1) ISENSE_REF */
    _TRISA1  = PORT_DIR_INPUT;
    _ANSELA1 = PORT_TYPE_ANALOG;

    /* Pin 16 - (OA1IN+/AN9/PMA6/RA2) VMON */
    _TRISA2  = PORT_DIR_INPUT;
    _ANSELA2 = PORT_TYPE_ANALOG;   

    /* Pin 17 - (DACOUT1/AN27/AN3/CMP1C/RA3) SOL_VMON */
    _TRISA3  = PORT_DIR_INPUT;
    _ANSELA3 = PORT_TYPE_ANALOG;

    /* Pin 18 - (OA3OUT/AN4/ANB1/ANB2/CMP3B/IBIAS3/RA4) Not connected */

    /* Pin 19 - (AVDD) AVDD */
    /* No configuration required */

    /* Pin 20 - (AVSS) AVSS */
    /* No configuration required */

    /* Pin 21 - (RP76/RD12) LED_RED */
    _TRISD12 = PORT_DIR_OUTPUT;
    _LATD12  = PORT_OUT_LOW;

#if 0
    /*GAP ID NOT USED IN THE DESIGN*/
    /* Pin 22 - (OA3IN-/AN13/CMP1B/ISRC0/RP49/PMA7/RC1) GAP1 */
    _TRISC1 = PORT_DIR_OUTPUT;
    _ANSELC1 = PORT_TYPE_DIGITAL;

    /* Pin 23 - (OA3IN+/AN14/CMP2B/ISRC1/RP50/PMD13/PMA13/RC2) GAP2 */
    _TRISC2  = PORT_DIR_INPUT;
    _ANSELC1 = PORT_TYPE_DIGITAL;

    /* Pin 24 - (AN17/ANN1/CMP4B/IBIAS1/RP54/PMD12/PMA12/RC6) GAP0*/
    _TRISC6 = PORT_DIR_OUTPUT;
    _LATC6 = PORT_OUT_HIGH;
#endif
    /* Pin 25 - (VDD) VDD */
    /* No configuration required */

    /* Pin 26 - (VSS) VSS */
    /* No configuration required */

    /* Pin 27 - (AN15/ANN2/CMP2A/IBIAS2/RP51/PMD11/PMA11/RC3) LED_GREEN */
    _TRISC3  = PORT_DIR_OUTPUT;
    _ANSELC3 = PORT_TYPE_DIGITAL;
    _LATC3   = PORT_OUT_LOW;

    /* Pin 28 - (OSCI/CLKI/AN5/RP32/PMD10/PMA10/RB0) ANG2_CS */
    _TRISB0  = PORT_DIR_OUTPUT;
    _ANSELB0 = PORT_TYPE_DIGITAL;
    _LATB0   = PORT_OUT_HIGH;
    _CNPUB0  = ENABLE; // Enable Internal PullUp

    /* Pin 29 - (OSCO/CLKO/AN6/RP33/PMA1/PMALH/PSA1/RB1) MONITOR_TX */
    _TRISB1   = PORT_DIR_OUTPUT;
    _ANSELB1  = PORT_TYPE_DIGITAL;
    _LATB1    = PORT_OUT_LOW;
    _RP33R     = UART1TX; //UART1 TX   

    /* Pin 30 - (AN19/ANB0/CMP2C/RP75/PMA0/PMALL/PSA0/RD11) MONITOR_RX */
    _TRISD11  = PORT_DIR_INPUT;
    _ANSELD11 = PORT_TYPE_DIGITAL;
    _U1RXR    = PIN_SELECTION_RPI75;
    _CNPUD11  = ENABLE;   /*Enable internal pullup as per pin list*/
   
     /* Pin 31 - (AN18/ANC2/CMP3C/ISRC3/RP74/PMD9/PMA9/RD10) CAN_RX */
    _TRISD10  = PORT_DIR_INPUT;
    _ANSELD10 = PORT_TYPE_DIGITAL;
    _CAN1RXR  = PIN_SELECTION_RPI74;
    _CNPUD10  = ENABLE;   /*Enable internal pullup as per pin list*/
    
    /* Pin 32 - (DACOUT2/AN16/CMP4C/ISRC2/RP55/PMD8/PMA8/RC7) CAN_TX */
    _TRISC7  = PORT_DIR_OUTPUT;
    _ANSELC7 = PORT_TYPE_DIGITAL;
    _RP55R  = PERIPHERAL_FUNCTION_C1TX;

    /* Pin 33 - (OA2OUT/AN1/AN7/ANA0/ANA2/ANA3/CMP1D/CMP2D/CMP3D/CMP4D/
       CMP5D/CMP6D/RP34/SCL3/INT0/RB2) SDA3_MOTOR_TEMP spare not used*/
    //_TRISB2 = PORT_DIR_OUTPUT;
   // _ANSELB2  = PORT_TYPE_DIGITAL;
   // _LATB2  = PORT_OUT_LOW;

    /* Pin 34 - (PGD2/OA2IN-/AN8/CMP4A/RP35/RB3) PGD */
    _ANSELB3 = PORT_TYPE_DIGITAL;

    /* Pin 35 -(PGC2/OA2IN+/RP36/RB4) PGC */
    _ANSELB4  = PORT_TYPE_DIGITAL;

    /* Pin 36 - (RP56/ASDA1/SCK2/RC8) SPI2_SCK */
    _TRISC8 = PORT_DIR_OUTPUT;
    _LATC6  = PORT_OUT_LOW;

    /* Pin 37 - (RP57/ASCL1/SDI2/RC9) SPI2_SDI */
    _TRISC9 = PORT_DIR_INPUT;
    _CNPUC9  = ENABLE;   /*Enable internal pullup as per pin list*/

    /* Pin 38 - (RP73/PCI20/RD9) SPI2_SDO */
    _TRISD9  = PORT_DIR_OUTPUT;
    _LATD9   = PORT_OUT_LOW;
    _RP73R  = PERIPHERAL_FUNCTION_SDO2;

    /* Pin 39 - (RP72/SDO2/PCI19/RD8) SPI2_CS */
    _TRISD8 = PORT_DIR_OUTPUT;
    _LATD8  = PORT_OUT_HIGH;
    _CNPUD8  = ENABLE;   /*Enable internal pull up as per pin list*/
    _ODCD8   =  ENABLE; /* configure as Open Drain*/

    /* Pin 40 - (VSS) VSS */
    /* No configuration required */

    /* Pin 41 - (VDD) VDD */
    /* No configuration required */

    /* Pin 42 - (RP71/PMD15/RD7) HEF3 */
    _TRISD7 = PORT_DIR_INPUT;
    /*For OLD Motor can be removed for new motor*/
    _CNPUD7  = ENABLE;   /*Enable internal pull up as per pin list*/
    /*Interrupt Change Notification Enable*/
    _CNEN0D7 = PORT_CNOTIFY_ENABLE;

    /* Pin 43 - (RP70/PMD14/RD6) HEF2 */
    _TRISD6 = PORT_DIR_INPUT;
    /*For OLD Motor can be removed for new motor*/
    _CNPUD6  = ENABLE;   /*Enable internal pull up as per pin list*/
    /*Interrupt Change Notification Enable*/
    _CNEN0D6 = PORT_CNOTIFY_ENABLE;

    /* Pin 44 - (RP69/PMA15/PMCS2/RD5) HEF1 */
    _TRISD5  = PORT_DIR_INPUT;
    /*For OLD Motor can be removed for new motor*/
    _CNPUD5  = ENABLE;   /*Enable internal pull up as per pin list*/
    /*Interrupt Change Notification Enable*/
   _CNEN0D5 = PORT_CNOTIFY_ENABLE;

    /* Pin 45 - (PGD3/RP37/SDA2/PMA14/PMCS1/PSCS/RB5) SDA2 /BR_TEMP_SENSE */
    /* used as I2C2 SDA */

    /* Pin 46 - (PGC3/RP38/SCL2/RB6) SCL2 / BR_TEMP_SENSE*/
    _TRISB6 = PORT_DIR_OUTPUT;
    _LATB6  = PORT_OUT_LOW;

    /* Pin 47 - (TDO/AN2/AN26/CMP3A/RP39/SDA3/RB7) SDA3_MOTOR_TEMP Spare not used*/
   // _ANSELB7  = PORT_TYPE_DIGITAL;
   // _TRISB7 = PORT_DIR_OUTPUT;
   // _LATB7  = PORT_OUT_LOW;
    
    /* Pin 48 - (PGD1/AN10/CMP6A/RP40/SCL1/RB8) SPI2_WP */
    _TRISB8   = PORT_DIR_OUTPUT;
    _ANSELB8  = PORT_TYPE_DIGITAL;
    _LATB8    = PORT_OUT_LOW;
    
    /* Pin 49 - (PGC1/AN11/CMP5A/RP41/SDA1/RB9) nSPI1_CS/ BLDC_CS */
    _TRISB9   = PORT_DIR_OUTPUT;
    _ANSELB9  = PORT_TYPE_DIGITAL;
    _LATB9    = PORT_OUT_HIGH;
    //_CNPUB9  = ENABLE;   /*Enable internal pullup as per pin list*/

    /* Pin 50 - (RP52/PWM5H/ASDA2/RC4) nINHIBIT */
    _TRISC4 = PORT_DIR_OUTPUT;
    _LATC4  = PORT_OUT_HIGH;
    
    /* Pin 51 - (RP53/PWM5L/ASCL2/PMWR/PMENB/PSWR/RC5) ENABLE */
    _TRISC5 = PORT_DIR_OUTPUT;
    _LATC5  = PORT_OUT_LOW;

    /* Pin 52 - (RP58/PWM7H/PMRD/PMWR/PSRD/RC10) ERR */
    _TRISC10 = PORT_DIR_INPUT;

    /* Pin 53 - (RP59/PWM7L/RC11) nSOFF */
    _TRISC11 = PORT_DIR_OUTPUT;
    _LATC11  = PORT_OUT_HIGH;

    /* Pin 54 -(RP68/ASDA3/RD4) BLDC_CLK */
    _TRISD4  = PORT_DIR_OUTPUT;
    _LATD4   = PORT_OUT_LOW;
    _RP68R  = PERIPHERAL_FUNCTION_SCK1;

    /* Pin 55 - (RP67/ASCL3/RD3) BLDC_SO */
    _TRISD3  = PORT_DIR_OUTPUT;
    _LATD3   = PORT_OUT_LOW;
    _RP67R  = PERIPHERAL_FUNCTION_SDO1;

    /* Pin 56 - (VSS) VSS */
    /* No configuration required */

    /* Pin 57 - (VDD) VDD */
    /* No configuration required */

    /* Pin 58 -(RP66/RD2) BLDC_SI */
    _TRISD2 = PORT_DIR_INPUT;
    _SDI1R  = PIN_SELECTION_RPI66;
    _CNPDD2  = ENABLE;   /*Enable internal pullup as per pin list*/
    

    /* Pin 59 - (RP65/PWM4H/RD1) nPWMH3 */
    _TRISD1 = PORT_DIR_OUTPUT;
    _LATD1  = PORT_OUT_HIGH;

    /* Pin 60 - (RP64/PWM4L/PMD0/RD0) PWML3 */
    _TRISD0 = PORT_DIR_OUTPUT;
    _LATD0  = PORT_OUT_LOW;

    /* Pin 61 - (TMS/RP42/PWM3H/PMD1/RB10) nPWMH2 */
    _TRISB10 = PORT_DIR_OUTPUT;
    _LATB10  = PORT_OUT_HIGH;

    /* Pin 62 - (TCK/RP43/PWM3L/PMD2/RB11) PWML2 */
    _TRISB11 = PORT_DIR_OUTPUT;
    _LATC11  = PORT_OUT_LOW;

    /* Pin 63 -(TDI/RP44/PWM2H/PMD3/RB12) nPWMH1 */
    _TRISB12 = PORT_DIR_OUTPUT;
    _LATC12  = PORT_OUT_HIGH;

    /* Pin 64 - (RP45/PWM2L/PMD4/RB13) PWML1 */
    _TRISC13 = PORT_DIR_OUTPUT;
    _LATC13  = PORT_OUT_LOW;

    RPINR22bits.SCK2R   = 0x0038;    //RC8->SPI2:SCK2OUT 
    RPOR12bits.RP56R    = 0x0009;    //RC8->SPI2:SCK2OUT 
    RPOR20bits.RP73R    = 0x0008;    //RD9->SPI2:SDO2 
    RPINR22bits.SDI2R   = 0x0039;    //RC9->SPI2:SDI2 
    RPOR20bits.RP72R    = 0x000A;    //RD8->SPI2:SS2OUT 
    
    /* Relock the Peripheral Pin Select registers */
    __builtin_write_OSCCONL(OSCCON | (1 << 6));
    
    /* Unlock ?Peripheral Remapping Registers */
    __builtin_write_RPCON(0x0800);

    /* Disable/Enable hardware modules. */
#if 0   
    //To checked and enbled only required 
    /* PMD1 */
    _ADC1MD  = PIC_MODULE_ENABLE;    /* ADC 1 */
    _C1MD    = PIC_MODULE_ENABLE;    /* CAN 1 Module */
//    _C2MD    = PIC_MODULE_DISABLE;   /* CAN 2 Module */
    _SPI1MD  = PIC_MODULE_ENABLE;    /* SPI 1 Module */
    _SPI2MD  = PIC_MODULE_ENABLE;    /* SPI 2 Module */
    _U1MD    = PIC_MODULE_ENABLE;    /* UART 1 Module */
    _U2MD    = PIC_MODULE_DISABLE;   /* UART 2 Module */
    _I2C1MD  = PIC_MODULE_DISABLE;    /* I2C 1 Module */
    _PWMMD   = PIC_MODULE_ENABLE;    /* PWM Module */
    _QEI1MD  = PIC_MODULE_DISABLE;   /* QEI 1 Module */
    _T1MD    = PIC_MODULE_ENABLE;    /* Timer A Module */
    
    /* PMD2 */
    _CCP1MD   = PIC_MODULE_DISABLE;    /* SCCP1 Module */
    _CCP2MD   = PIC_MODULE_DISABLE;    /* SCCP2 Module */
    _CCP3MD   = PIC_MODULE_DISABLE;    /* SCCP3 Module */
    _CCP4MD   = PIC_MODULE_DISABLE;    /* SCCP4 Module */
    _CCP5MD   = PIC_MODULE_DISABLE;    /* SCCP5 Module */
    _CCP6MD   = PIC_MODULE_DISABLE;    /* SCCP6 Module */
    _CCP7MD   = PIC_MODULE_DISABLE;    /* SCCP7 Module */
    _CCP8MD   = PIC_MODULE_DISABLE;    /* SCCP8 Module */
    _CCP9MD   = PIC_MODULE_DISABLE;    /* SCCP9 Module */
    
    /* PMD3 */
    _I2C2MD   = PIC_MODULE_DISABLE;    /* I2C2 Module */
    _I2C3MD   = PIC_MODULE_DISABLE;    /* I2C3 Module */
    _U3MD     = PIC_MODULE_DISABLE;    /* UART3 Module */
    _QEI2MD   = PIC_MODULE_DISABLE;    /* QEI 2 Module */
    _CRCMD    = PIC_MODULE_DISABLE;    /* CRC Module */
    _PMPMD    = PIC_MODULE_DISABLE;    /* Peripheral Port Module */
    
    /* PMD4 */
    _REFOMD   = PIC_MODULE_DISABLE;    /* Reference Clock Module */
    
    /* PMD6 */
    _SPI3MD   = PIC_MODULE_ENABLE;    /* SPI3 Module */
//    _QEI3MD   = PIC_MODULE_DISABLE;    /* QEI 3 Module */
    _DMA0MD   = PIC_MODULE_DISABLE;    /* DMA0 Module */
    _DMA1MD   = PIC_MODULE_DISABLE;    /* DMA1 Module */
    _DMA2MD   = PIC_MODULE_DISABLE;    /* DMA2 Module */
    _DMA3MD   = PIC_MODULE_DISABLE;    /* DMA3 Module */
    //_DMA4MD   = PIC_MODULE_DISABLE;    /* DMA4 Module */
    //_DMA5MD   = PIC_MODULE_DISABLE;    /* DMA5 Module */
    //_DMA6MD   = PIC_MODULE_DISABLE;    /* DMA6 Module */
   // _DMA7MD   = PIC_MODULE_DISABLE;    /* DMA7 Module */
    
    /* PMD7 */
    _PTGMD    = PIC_MODULE_DISABLE;    /* PTG Module */
    _CMP1MD   = PIC_MODULE_DISABLE;    /* Peripheral DMA Controller 1 Module */
    _CMP2MD   = PIC_MODULE_DISABLE;    /* Peripheral DMA Controller 2 Module */
    _CMP3MD   = PIC_MODULE_DISABLE;    /* Peripheral DMA Controller 3 Module */
    //_CMP4MD   = PIC_MODULE_DISABLE;    /* Peripheral DMA Controller 4 Module */
    //_CMP5MD   = PIC_MODULE_DISABLE;    /* Peripheral DMA Controller 5 Module */
   // _CMP6MD   = PIC_MODULE_DISABLE;    /* Peripheral DMA Controller 6 Module */
    
    /* PMD8 */
    _BIASMD   = PIC_MODULE_DISABLE;    /* Constant-Current Source Module */
    _CLC1MD   = PIC_MODULE_DISABLE;    /* CLC1 Module */
    _CLC2MD   = PIC_MODULE_DISABLE;    /* CLC2 Module */
    _CLC3MD   = PIC_MODULE_DISABLE;    /* CLC3 Module */
    _CLC4MD   = PIC_MODULE_DISABLE;    /* CLC4 Module */
    _DMTMD    = PIC_MODULE_DISABLE;    /* Deadman Timer Module */
    _SENT1MD  = PIC_MODULE_DISABLE;    /* SENT1 Module */
    _SENT2MD  = PIC_MODULE_DISABLE;    /* SENT2 Module */
    _OPAMPMD  = PIC_MODULE_DISABLE;    /* Op Amp Module */
#endif //#if o
}  /* End _cpu_set_pinmux() */


/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: The watchdog service function.
 * Parameters:  None.
 * Returns:     None.
 ********************************************************************************************/
void cpu_service_watchdog( void )
{
    /* Clear the watchdog timer */
    ClrWdt();

    /* Void return */
    return;
}


/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Sets the state of the system LED.
 * Parameters:  led_state - desired state of the status LED, can be OFF, GREEN, RED, or YELLOW
 * Returns:     None.
 ********************************************************************************************/
void cpu_set_led_state( INT16U led_state )
{
    switch( led_state )
    {
        case LED_STATE_OFF:
            GREEN_LED_PIN = PORT_OUT_LOW;
            RED_LED_PIN   = PORT_OUT_LOW;
            break;

        case LED_STATE_GREEN:
            GREEN_LED_PIN = PORT_OUT_HIGH;
            RED_LED_PIN   = PORT_OUT_LOW;
            break;

        case LED_STATE_RED:
            GREEN_LED_PIN = PORT_OUT_LOW;
            RED_LED_PIN   = PORT_OUT_HIGH;
            break;

        case LED_STATE_YELLOW:
        default:
            GREEN_LED_PIN = PORT_OUT_HIGH;
            RED_LED_PIN   = PORT_OUT_HIGH;
            break;
    }

    /* Void return */
    return;
}

/*********************************************************************************************
 * Author(s):       mfarver
 * Description:     Maps flash chip select to correct output
 * Parameters:      state, (in) - FLASH_SELECTED or FLASH_UNSELECTED
 * Returns:         None
 *********************************************************************************************/
void cpu_SetDataFlashCs( FLASH_CS_STATES state )
{
    DATAFLASH_SELECT = ( state == FLASH_SELECTED ) ? 0 : 1;
    return;
}


/*********************************************************************************************
 * Author(s):       mfarver
 * Description:     Maps flash reset to correct output
 * Parameters:      state, (in) - FLASH_RESET or FLASH_NORMAL_OP
 * Returns:         None
 *********************************************************************************************/
void cpu_SetDataFlashReset( FLASH_RESET_STATES state )
{
    DATAFLASH_RESET = ( state == FLASH_NORMAL_OP ) ? 1 : 0;
    return;
}


/*********************************************************************************************
 * Author(s):       mfarver
 * Description:     Maps flash write protect to correct output
 * Parameters:      state, (in) - FLASH_WRITE or FLASH_WRITE_PROTECT
 * Returns:         None
 *********************************************************************************************/
void cpu_SetDataFlashWp( FLASH_WP_STATES state )
{
    DATAFLASH_WP = ( state == FLASH_WRITE ) ? 1 : 0;
    return;
}

/*********************************************************************************************
 * Author(s):       mfarver
 * Description:     Reads ADC DMA buffer for position data
 * Parameters:      position, (out) - Data structure to store position data.
 * Returns:         None
 *********************************************************************************************/
void cpu_GetPosition(PSN_POSITION_DATA * position)
{
        /*TBD*/ 
    /*To be implemented with SPI*/
}

/*********************************************************************************************
 * Author(s):       
 * Description:     Reads ADC motor current for average
 * Parameters:      None
 * Returns:         12bit ADC average raw value for current
 *********************************************************************************************/
INT16U cpu_GetCurrent()
{
    return ADC_raw_value( ADC_CHANNEL_ISENSE );
}
/*********************************************************************************************
 * Author(s):       
 * Description:     Reads ADC motor current reference value
 * Parameters:      None
 * Returns:         12bit ADC average raw value for Isense_ref
 *********************************************************************************************/
INT16U cpu_GetCurrentref()
{
    return ADC_raw_value( ADC_CHANNEL_ISENSE_REF );
}
/*********************************************************************************************
 * Author(s):       mfarver
 * Description:     Reads ADC DMA buffer for PCB temp
 * Parameters:      None
 * Returns:         12bit ADC average raw value for current
 *********************************************************************************************/
INT16U cpu_GetPcbTemp()
{
    /*TBD*/
    INT16U temp = 0;
    temp = i2c_get_temp();
    return temp;
}

