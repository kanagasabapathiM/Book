/*
Author(s): Michael Ansolis
Status: Preliminary
Release Date:
Revision:
Description: Header for BLDC module. Contains interface for BLDC motor control.
*/

#ifndef HALL_H
#define HALL_H

/*********************************************************************************************
Includes
*********************************************************************************************/
#include "typedef.h"

/*********************************************************************************************
Preprocessor definitions
*********************************************************************************************/
/*
    Motor electromechanical config:
    Number of electrical poles and...
    number of hall transitions per rotation
*/
#define BLDC_POLES            16 /*TBD*/
#define HALL_SENSORS          3
/* Every hall sensor transition is triggered by every pole */
#define HALL_TRANS_PER_ROT    ( BLDC_POLES * HALL_SENSORS )

/*********************************************************************************************
Type Definitions
*********************************************************************************************/
/*
    Description: Tells you when the period buffer contains entries that will
    give you a valid speed and the corresponding direction
*/
typedef enum
{
    PERIOD_INVALID,
    PERIOD_POSITIVE_DIR,
    PERIOD_NEGATIVE_DIR,
}
PERIOD_STATE;

/*********************************************************************************************
Function declarations
*********************************************************************************************/

/*********************************************************************************************
 * Author(s):    Michael Ansolis
 * Description:  Initializes the Hall module.
 * Parameters:   None
 * Returns:      None
*********************************************************************************************/
void hall_init(void);

/*********************************************************************************************
 * Author(s):   Michael Ansolis
 * Description: Retrieves the state of the BLDC motor rotor.
 * Parameters:  None
 * Returns:     Direction of rotation based on the period buffer
*********************************************************************************************/
PERIOD_STATE hall_get_period_state(void);

/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Returns the sum of all the time segments of the entire hall sensor
             period ring buffer.
Parameters:  None
Returns:     See description.
*********************************************************************************************/
INT32S * hall_get_rotation_time(void);

/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Returns the the value indicating how many times the Hall sensors have reported
             a rotor position change.
Parameters:  None.
Returns:     See description.
*********************************************************************************************/
INT16U hall_get_position_change_steps(void);

/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Returns a bitfield (least significant bits 0 - 2) indicating Hall sensor
             readings from the BLDC motor.
Parameters:  None.
Returns:     See description.
*********************************************************************************************/
INT16U hall_get_position();

/*********************************************************************************************
Author(s):   Juan Kuyoc
Description: Returns the motor position.
Parameters:  None
Returns:     INT16S - The motor position.
*********************************************************************************************/
INT32S hall_get_motor_position();

#endif /* HALL_H */
