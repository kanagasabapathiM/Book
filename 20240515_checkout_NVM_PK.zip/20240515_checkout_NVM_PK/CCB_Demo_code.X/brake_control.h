/*
 Author(s): Russell Everett <reverett@righthandtech.com>
            Doug Wendt      <dwendt@omnicongroup.com>  (Stepper Feedback)
 Status: Preliminary
 Release Date:
 Revision:
 Description: Header file for the Stepper Control Module.
 History:
 06/11/2010 Clay Barber Changed Files updates
 */

#ifndef STEPCTRL_H
#define STEPCTRL_H
/*********************************************************************************************
Includes
*********************************************************************************************/
#include "typedef.h"

/*********************************************************************************************
Preprocessor definitions
*********************************************************************************************/
/* Defines for G_brake_status_flag that actually make sense in indicating the state of the brake  */
#define STOPPED     FALSE
#define STEPPING    TRUE

/*********************************************************************************************
Type Definitions
*********************************************************************************************/
/*
 Defines the different brake states of the stepper state machine (stpc_exec)
 */
typedef enum
{
    BRAKE_STATE_ENGAGED         =  0,
    BRAKE_STATE_DISENGAGED      =  1,
} SLND_BRAKE_STATE;
/*
 Defines the overall status of the stepper state machine
 */
typedef enum
{
    BRAKE_STATUS_FULLY_ENGAGED = 1,
    BRAKE_STATUS_NOT_ENGAGED   = 0
} SLND_BRAKE_STATUS;
/*
 Defines the brake command values
 */

typedef enum
{
    BRAKE_CMD_ENGAGE = 0,
    BRAKE_CMD_DISENGAGE,
} SLND_BRAKE_COMMAND;

/*********************************************************************************************
Function declarations
*********************************************************************************************/

/*********************************************************************************************
 * Author(s):   Russell Everett <reverett@righthandtech.com>
 * Description: The initialization function for the Stepper Control module.
 * Parameters:  None.
 * Returns:     NO_ERROR    - indicates success
 *              ERR_FAILURE - indicates failure
*********************************************************************************************/
ERR_RET brake_init(void);

/*********************************************************************************************
Author(s):   Russell Everett <reverett@righthandtech.com>
Description: The periodic function for control of the brake state.
Parameters:  (in) The brake command.
Returns:     The brake state of stepper control module.
*********************************************************************************************/
SLND_BRAKE_STATE brake_exec(SLND_BRAKE_COMMAND brake_cmd);

/*********************************************************************************************
Author(s):   Russell Everett <reverett@righthandtech.com>
Description: The function for returning the status of the brake state.
Parameters:  None.
Returns:     The overall brake status of stepper control module.
*********************************************************************************************/
SLND_BRAKE_STATUS slnd_get_brake_status(void);

/*********************************************************************************************
Author(s):   Russell Everett <reverett@righthandtech.com>
Description: Interrupt Service Routine for the STP_STEP output
Parameters:  None.
Returns:     None.
*********************************************************************************************/
void slnd_step_isr(void);

/*********************************************************************************************
 * Author(s):   Michael Ansolis
 * Description: Retrieves the stepper reference line duty cycle value for holding the brake
 *              disengaged.
 * Parameters:  None.
 * Returns:     See description.
 ********************************************************************************************/
INT16U slnd_get_stepper_hold_duty_cycle( void );


/*********************************************************************************************
Author(s):   Jonathan Saliers
Description: Get the state of G_brake_status_flag.
Parameters:  None.
Returns:     boolean value representing G_brake_status_flag.
*********************************************************************************************/
BOOL slnd_get_brake_status_flag( void );

#ifdef BRAKE_FEEDBACK_ENABLED


/*********************************************************************************************
Author(s):   Doug Wendt      <dwendt@omnicongroup.com>
Description: Gets the state of G_engaged_fault_flag.
Parameters:  None.
Returns:     boolean value representing an Engaged fault
History:
06/11/2010 Clay Barber Changed Files updates
*********************************************************************************************/
BOOL slnd_get_engaged_fault_flag( void );

/*********************************************************************************************
Author(s):   Doug Wendt      <dwendt@omnicongroup.com>
Description: Sets the state of G_engaged_fault_flag.
Parameters:  boolean value representing an Engaged fault
Returns:     void
History:
06/11/2010 Clay Barber Changed Files updates
*********************************************************************************************/
void slnd_set_engaged_fault_flag( BOOL value );

/*********************************************************************************************
Author(s):   Doug Wendt      <dwendt@omnicongroup.com>
Description: Gets the state of G_disengaged_fault_flag.
Parameters:  None.
Returns:     boolean value representing a Disengaged fault
History:
06/11/2010 Clay Barber Changed Files updates
*********************************************************************************************/
BOOL slnd_get_disengaged_fault_flag( void );

/*********************************************************************************************
Author(s):   Doug Wendt      <dwendt@omnicongroup.com>
Description: Retrieves the tolerance for brake engagement.
Parameters:  None.
Returns:     See description.
History:
06/11/2010 Clay Barber Changed Files updates
*********************************************************************************************/
INT16U slnd_get_brake_engage_tolerance( void );

/*********************************************************************************************
Author(s):   Doug Wendt      <dwendt@omnicongroup.com>
Description: Helper function for common things done when Stepping needs to Stop
Parameters:  None.
Returns:     None.
History:
06/11/2010 Clay Barber Changed Files updates
********************************************************************************************/
void slnd_stop_stepping (void);



/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: Retrieves the brake correct on-the-fly value.
Parameters:  None.
Returns:     INT16S - Brake_Correct_On_The_Fly value.
*********************************************************************************************/
INT16S slnd_get_brake_correct_on_the_fly( void );

/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: Retrieves the pulse count disengage value.
Parameters:  None.
Returns:     INT16U - Pulse_Count_Disengage value.
*********************************************************************************************/
INT16U slnd_get_pulse_count_disengage( void );

#endif /* BRAKE_FEEDBACK_ENABLED */

//void stpc_get_brake_debug( INT8U *data );

#endif  /*STEPCTRL_H */

