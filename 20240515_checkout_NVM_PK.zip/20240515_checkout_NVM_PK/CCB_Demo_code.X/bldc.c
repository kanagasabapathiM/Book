/*
Author(s):      Dave Zielinski <dzielinski@righthandtech.com>
                Glenn Racette <gracette
Status:         Preliminary
Release Date:
Revision:
Description:    Implementation of the BLDC_Control module.
*/

/*********************************************************************************************
Includes
*********************************************************************************************/
#include "global.h"
#include "bldc.h"
#include "timer_manager.h"
#include "current.h"
#include "pwm.h"
#include "hall.h"
//#include "communications.h"
#include "bldc_drv.h"
#ifdef UART_DEBUG
#include "uart1.h"
#endif
/*********************************************************************************************
Preprocessor definitions
*********************************************************************************************/

/*
    Interval to run the speed feedback part of the feedback loop in ms
*/
#define RPM_UPDATE_TIME_MS          1ul
#define BLDC_INITIALIZATION_TIME    100ul
#define SECONDS_PER_MINUTE          60ul
#define US_PER_SECOND               1000000ul

/*********************************************************************************************
Global Variable Definitions
*********************************************************************************************/
/* Current desired speed as set by Motion_Control. */
static INT16S G_desired_rpm;

/* Flag indicating the BLDC module is still in the initializing state. */
static BOOL G_bldc_initializing;

/* Contains the local copy of the control param table copied from the configuration module
    (Used only in ISR aside from bldc_init). */
static CFG_CONTROL_PARAM_TABLE_TYPE G_control_param_table;

/* Flag to indicate this is a new speed command.  Used to apply the linear speed ramp
    and reset some terms in the control loop. */
static BOOL G_new_speed_cmd;

static INT16S G_current_rpm;
    
/*********************************************************************************************
Function declarations
*********************************************************************************************/

static void _bldc_speed_control_loop(INT16S measured_speed);
void Bldc_print_error();
static FP32 UpdatedP;
static FP32 UpdatedI;

/*********************************************************************************************
Function defintions
*********************************************************************************************/

/*********************************************************************************************
 * Author(s):   Dave Zielinski
 * Description: Initializes the this module.
 * Parameters:  None
 * Returns:     NO_ERROR - no error occured while initializing the module.
 *              ERR_FAILURE - an error was detected while initializing the module.
*********************************************************************************************/
ERR_RET bldc_init(void)
{
    ERR_RET sys_err = NO_ERROR;

    /* Initialize global variables. */
    G_desired_rpm = 0;
    G_bldc_initializing = TRUE;
    G_new_speed_cmd = FALSE;
    G_current_rpm = 0;

    /* Copy the control parameters table from the configuration module to the local table. */
    //sys_err = cfg_load_parameters( TBL_CTRL_LOOP_PARAM, (INT16U*)&G_control_param_table); /*For DEMO Only/*
    
    G_control_param_table.p_speed = 1.1;//check and provide the default value as previous configuration
    G_control_param_table.i_speed = 0.1; //check and provide the default value as previous configuration

    UpdatedP = G_control_param_table.p_speed;
    UpdatedI = G_control_param_table.i_speed;
    
   //if(sys_err == NO_ERROR)
    {
        sys_err = pwm_init();
        
    }

  //if(sys_err == NO_ERROR)
    {
        hall_init();
    }
    spi1_init();
    //if(sys_err == NO_ERROR)
    {
        sys_err = bldc_drv_init(); 
    }

    return sys_err;
}


/*********************************************************************************************
Author(s):   Dave Zielinski
Description: Pushes desired speed to the internal drive feedback loop.
Parameters:  i16s_desired_rpm (in) - desired speed in RPMs
Returns:     None
*********************************************************************************************/
void bldc_set_desired_speed(INT16S desired_rpm)
{
    if( G_desired_rpm != desired_rpm )
    {
        G_new_speed_cmd = TRUE;

        if( desired_rpm == 0 )
        {
            pwm_set_disable_drive(TRUE);
            pwm_set_speed_demand(0);
        }
        else
        {
            pwm_set_disable_drive(FALSE);
        }
    }

    /* Save the new RPM value */
    G_desired_rpm = desired_rpm;
}


/*********************************************************************************************
Author(s):   Dave Zielinski
Description: Asks if the BLDC motor is "stopped".  "Stopped" is defined as no hall
             sensor change within 25ms.
             Note: Do not call this function until tmgr_init() is called.
Parameters:  None
Returns:     BLDC_IS_STOPPED - rotor is stopped
             BLDC_NOT_STOPPED - rotor is NOT stopped

Pseudocode:
 if tmgr_hall_delta_time_expired() returns true
     return BLDC_IS_STOPPED
 else
     return BLDC_NOT_STOPPED

*********************************************************************************************/
BLDC_STOPPED_T bldc_is_stopped(void)
{
    if( tmgr_hall_delta_time_expired() == TRUE )
    {
        return BLDC_IS_STOPPED;
    }
    else
    {
        return BLDC_NOT_STOPPED;
    }
}


/*********************************************************************************************
Author(s):   Dave Zielinski
             Glenn Racette
Description: Computes the current demand from desired speed and actual
Parameters:  current_rpm (in) - current motor speed in RPM
Returns:     None
*********************************************************************************************/
static void _bldc_speed_control_loop(INT16S measured_speed)
{
    /* Integral component of speed control loop */
    static INT32S S_speed_integral = 0;
    static INT32S S_last_speed_error = 0;

    INT32S speed_proportional=0;
    INT32S speed_error=0;
    INT32S speed_demand=0;
    /* Calculate the speed error between the desired speed and the last measurement. */
    speed_error = G_desired_rpm - measured_speed;
   //printf("\r\n G_desired_rpm / measured_speed %d / %d speed_error %ld\r\n",G_desired_rpm,measured_speed,speed_error);
    /* Calculate the proportional speed error term and apply the Kp constant. */
    speed_proportional = speed_error * UpdatedP;
    //printf("S_speed_integral %ld",speed_proportional);
    /* Calculate and sum the integral speed error term and apply the Ki constant. */
    S_speed_integral = S_speed_integral + S_last_speed_error * UpdatedI;
   // printf("speed_proportional %ld",S_speed_integral);
    /* Prevent integral term from overflowing during stall conditions. */
    if(S_speed_integral >= 31000)
        S_speed_integral = 31000;

    if(S_speed_integral <= -31000)
        S_speed_integral = -31000;

    /* Calculate the speed demand as long, to prevent overflow during stall conditions */
    speed_demand = speed_proportional + S_speed_integral;
//printf("speed_demand %ld",speed_demand);
    /* Prevent integral term from overflowing during stall conditions. */
    if(speed_demand >= MAX_INT_16S)
        speed_demand = MAX_INT_16S;

    if(speed_demand <= -MAX_INT_16S)
        speed_demand = -MAX_INT_16S;

    S_last_speed_error = speed_error;

    if( G_desired_rpm == 0 )
    {
        speed_demand = 0;
        S_speed_integral = 0;

        pwm_set_disable_drive(TRUE);
    }

    if( G_new_speed_cmd == TRUE )
    {
        G_new_speed_cmd = FALSE;
        pwm_isr_adjust_drive(hall_get_position());
    }
    /* Set speed demand in the PWM module. */
    pwm_set_speed_demand((INT16S)speed_demand);

    /* Compute PWM duty cycle and push it to the PWM hardware. */
    pwm_adjust_pwm();

    /* Void return. */
    return;
}
/*********************************************************************************************
Author(s):   Dave Zielinski
Description: Periodic execution function for BLDC module.  Checks if we've crossed a 1ms time
             boundary and update the persistent actual RPM value.
Parameters:  None
Returns:     None
 *********************************************************************************************/
void bldc_exec(void) {
    static INT32U S_next_rpm_update_time = 0;
    INT32U time_ms;
    INT32S temp_rpm,time;
    PERIOD_STATE period_state;
    INT32S* ptr_time;

    /*
        Perform initialization and then update speed control loop every millisecond
     */
    time_ms = tmgr_get_system_time();
    
    if(time_ms>S_next_rpm_update_time){
        
    period_state = hall_get_period_state();

    S_next_rpm_update_time = time_ms + RPM_UPDATE_TIME_MS;

    /* Check if BLDC is stopped or moving too slowly. */
    if ((period_state == PERIOD_INVALID) || (bldc_is_stopped() == BLDC_IS_STOPPED)) {
        G_current_rpm = 0;
        pwm_set_motor_speed(0);
    } else {
        /* Get rotation period and convert to actual RPM by dividing 1 minute in microseconds
           by rotation time. */
        ptr_time = hall_get_rotation_time();
        time = *ptr_time * 0.8;
        temp_rpm = (SECONDS_PER_MINUTE * US_PER_SECOND) / time; //CCP1TMRL every count equal to 0.8u sec

        pwm_set_motor_speed((INT16S)temp_rpm);

        G_current_rpm = (INT16S) temp_rpm;

        /* Apply direction to the sign of the RPM measurement */
        if (period_state == PERIOD_NEGATIVE_DIR) {
           G_current_rpm = -G_current_rpm;
        }
    }

    /* Update the speed control loop with the latest RPM measurement */
    _bldc_speed_control_loop(G_current_rpm);

    }
    INT32U value = 0;
    
    value = _bldc_drv_command(BLDC_OPERMODE_READ); //op mode

    //check for normal mode reg:  Operation Mode Overview
    if (value & BLDC_DRIVE_MODE) {

        static int first=true;
        if (first == true) {
            Bldc_print_error();
            first = false;
        }
    } else {
        static int first=true;
        if (first == true) {
            Bldc_print_error();
            first = false;
        }

        cpu_set_led_state(LED_STATE_RED);
    }
}

/*********************************************************************************************
Author(s):   Juan Kuyoc
Description: Returns the current RPM value.
Parameters:  None
Returns:     INT16S - The current RPM value.
*********************************************************************************************/
INT16S bldc_get_current_RPM()
{
    return G_current_rpm;
}

/*********************************************************************************************
Author(s):   Juan Kuyoc
Description: Returns the commanded RPM value.
Parameters:  None
Returns:     INT16S - The commanded RPM value.
*********************************************************************************************/
INT16S bldc_get_commanded_RPM()
{
    return G_desired_rpm;
}
void UpdateP(INT8U D[2]) {
    UpdatedP = D[0];
    UpdatedP *= 256;
    UpdatedP += D[1];
    UpdatedP /= 1000;
}

void UpdateI(INT8U D[2]) {
    UpdatedI = D[0];
    UpdatedI *= 256;
    UpdatedI += D[1];
    UpdatedI /= 1000;
}

void Bldc_print_error()
{
        INT32U error=0;
        INT32U sys_time_ms = 0;

        INT16U Lsb=0,Msb=0;
        
        sys_time_ms = tmgr_get_system_time();
        
        //--//printf("\r\n system time %ld\r\n",sys_time_ms);
        for (int i = 0; i < 12; i++) {
            error =  (INT32U)bldc_drv_read_error(i);
            //error = 0x12345678;;
            Lsb = (INT16U)error;
            Msb=(INT16U)(error>>16);
            //--//printf("\r\n Error Register 0x%02x%04x\r\n",(INT16U)Msb,(INT16U)Lsb);
        }
        error = _bldc_drv_command(BLDC_OPERMODE_READ); //op mode
        Lsb = (INT16U)error;
        Msb=(INT16U)(error>>16);
        //--//printf("\r\n Error Register 0x%02x%04x\r\n",(INT16U)Msb,(INT16U)Lsb);
        delay(5);
      
}