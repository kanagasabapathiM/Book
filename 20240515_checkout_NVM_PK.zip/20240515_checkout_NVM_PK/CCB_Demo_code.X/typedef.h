/*
 Author(s):
 Release Date:  Pre-release
 Revision:
 Description:   Type definitions as specified in the B/E Aerospace coding standards.
 */

#ifndef _TYPEDEF_H
#define	_TYPEDEF_H

/*********************************************************************************************
Includes
*********************************************************************************************/
#include <stdint.h>
#include <stdbool.h>

/*********************************************************************************************
Preprocessor definitions
*********************************************************************************************/
#define FALSE false
#define TRUE  true

#define ERR_RET     INT16U
#define NO_ERROR    0x0
#define INIT_FAILED 0x1
#define ERR_FAILURE 0x1

#define EIGHT_BYTES 8
#define FOUR_BYTES  4
//TODO: Need to correct these.

#define MAX_INT16S              32767
#define MIN_INT16S              (-32768)
#define MAX_INT16U              65535
#define MIN_INT16U              0
#define MAX_INT8S               127
#define MIN_INT8S               (-128)

/*********************************************************************************************
Type Definitions
*********************************************************************************************/
typedef bool        BOOL;
typedef uint8_t     INT8U;
typedef int8_t      INT8S;
typedef uint16_t    INT16U;
typedef int16_t     INT16S;
typedef uint32_t    INT32U;
typedef int32_t     INT32S;
typedef uint64_t    INT64U;
typedef int64_t     INT64S;
typedef float       FP32;
typedef long double FP64;
/* Define native integers where size doesn't matter but are at least 16 bits */
typedef signed int INTS;
typedef unsigned int INTU;

#define SW_PART_NUMBER_LEN 8
typedef struct
{
    INT8U software_pn[SW_PART_NUMBER_LEN];
    INT32U crc;
} SOFTWARE_DESCRIPTION;

/*********************************************************************************************
 * Recursive header block
 ********************************************************************************************/
#endif
