/*
 * File:   bldc-temp.h
 * Author: mfarver
 *
 * Created on August 12, 2015, 9:31 AM
 */

#ifndef BLDC_TEMP_H
#define	BLDC_TEMP_H

#ifdef	__cplusplus
extern "C" {
#endif

/*********************************************************************************************
Includes
*********************************************************************************************/
#include "typedef.h"

/*********************************************************************************************
 * Source file function definitions
 ********************************************************************************************/

/*********************************************************************************************
Author(s):      Michael Ansolis
Description:    The initialization function for the temperature module.
Parameters:     None
Returns:        None
*********************************************************************************************/
void bldc_temp_init( void );

/*********************************************************************************************
Author(s):      Michael Ansolis
Description:    The periodic function function for the temperature module.
Parameters:     None
Returns:        None
*********************************************************************************************/
void bldc_temp_exec(void);

/*********************************************************************************************
Author(s):      Michael Ansolis.
Description:    Returns BLDC motor temperature.
Parameters:     None.
Returns:        See description.
*********************************************************************************************/
INT16S bldc_temp_get_temp();



#ifdef	__cplusplus
}
#endif

#endif	/* BLDC_TEMP_H */

