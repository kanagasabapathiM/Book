/*
 * Author(s):    Jonathan R. Saliers
 * Status:       Incomplete
 * Release Date: 11/30/12
 * Revision:     0.1
 * Description: The Memory_Manager module is responsible for the non-volatile storage and
 * retrieval of firmware and data stored both in internal and in external flash memory.  The
 * internal and external memory data is stored when the flash memory is programmed in the
 * production environment, but may be updated or retrieved by the Maintenance software.
 * History:      06/10/2010 Clay Barber - Changed Files updates
 */

/*********************************************************************************************
 * Source file includes
 ********************************************************************************************/


#include "cpu.h"
#include "dataflash.h"
#include "memorymgr.h"
#include <xc.h>
#include "utility.h"

/*********************************************************************************************
 * Private type definitions
 ********************************************************************************************/

/*********************************************************************************************
 * Private preprocessor definitions
 ********************************************************************************************/
/* NVMCON value for erasing a 4KB block of memory. */
#define ERASE_MEM_BLOCK          0x4003  /* WREN=1 (enable write/erase op) and NVMOP=3 (erase block of memory) */
#define WRITE_MEM_BLOCK          0x4001  /* WREN=1 (enable write/erase op) and NVMOP=1 (word program op) */

/* The maximum number of initialization attempts to perform on the DataFlash chip. */
#define MAX_INIT_ATTEMPTS    5
/* An interrupt vector takes up 2 words. */
#define INT_VEC_SIZE             2
/* Number of bytes in one 16-bit word. */
#define BYTES_PER_WORD           2

/*********************************************************************************************
 * Private function declarations
 ********************************************************************************************/

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Erases and overwrites a 4Kbyte page of the internal program flash memory.
 * Parameters:  address - the address of the beginning of the 4K page of NVM to overwrite.
 * Returns:     MMGR_NO_ERROR - no write errors detected.
 *              MMGR_ERROR    - error while writing data to the memory.
 ********************************************************************************************/
ERR_RET _mmgr_write_ram_image( MEM_ADDRESS_TYPE address );

/*********************************************************************************************
 * Global variable definitions
 ********************************************************************************************/
static MEM_ADDRESS_TYPE G_start_address;
static MEM_ADDRESS_TYPE G_4k_page_start_address;
static INT16U G_4k_page_offset;
static INT16U data_page_RAM_image[FLASH_PAGE_SIZE];
static INT16U G_word_count = 0;

/*********************************************************************************************
 * Source file function definitions
 ********************************************************************************************/

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: The initialization function for the Memory_Manager module.
 * Parameters:  None.
 * Returns:     NO_ERROR    - Initialization complete, continue.
 *              INIT_FAILED - Initialization failed, cannot continue to run normal execution
 ********************************************************************************************/
ERR_RET mmgr_init( void )
{
    ERR_RET sys_err = NO_ERROR;
    INT16U  i;

    /* Initialize the DataFlash module. */
    for(i = 0; i < MAX_INIT_ATTEMPTS; i++)
    {
        sys_err = flash_init();/*TBD*/
        if (sys_err == NO_ERROR)
        {
            break;
        }
    }
    /* Return status */
    return sys_err;
}


/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Serves as a method to retrieve eight bytes of data from either internal NVM or
 *              external DataFlash chip memory.
 * Parameters:  mem_addr - address in internal/external memory to retrieve data from.
 *              Addresses between 0 and 0x2A7FF are considered internal memory addresses.
 *              p_data - pointer to an 8-byte buffer to read data into.
 * Returns:     MMGR_NO_ERROR        - retrieval successful.
 *              MMGR_INVALID_ADDRESS - returned if the specified memory is invalid.
 ********************************************************************************************/
ERR_RET mmgr_retrieve_data_from_memory( INT32U mem_addr, INT16U* p_data )
{

    ERR_RET sys_err = MMGR_NO_ERROR;
    MEM_ADDRESS_TYPE src_address;

    /* Check if we need to read from the internal program flash memory. */
    /* Check to make sure we're not crossing a 128Kbyte page boundary when reading 4 words. */
    /* Check to make sure the address is even. */
    if( ( PROG_MEM_PAGE_SIZE - ( mem_addr % PROG_MEM_PAGE_SIZE ) >= EIGHT_BYTES / BYTES_PER_WORD ) &&
        ( mem_addr % 2 == 0 ) )
    {
        /* Copy 8 bytes of data from mem_addr to p_data */
        src_address.page   = mem_addr / PROG_MEM_PAGE_SIZE;
        src_address.offset = mem_addr % PROG_MEM_PAGE_SIZE;
        mmgr_memcpy( p_data, src_address, EIGHT_BYTES / BYTES_PER_WORD );
    }
    else
    {
        sys_err = MMGR_INVALID_ADDRESS;
    }

    /* Return status */
    return sys_err;

}


/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Initializes addresses and creates an image of the 4K NVM page in RAM to be
 *              subsequently modified and written back to NVM.  Called prior to making
 *              mmgr_write_data() calls.
 * Parameters:  address - starting address in the internal program flash memory
 *              to store data to, in words.
 * Returns:     MMGR_NO_ERROR - initialization completed successfully.
 ********************************************************************************************/
ERR_RET mmgr_write_data_start( INT32U address )
{
    ERR_RET sys_err = MMGR_NO_ERROR;

    /* Compute the page and offset of the first memory location to be modified. */
    G_start_address.offset = address % PROG_MEM_PAGE_SIZE;
    G_start_address.page   = address / PROG_MEM_PAGE_SIZE;

    /* Compute the offset into the 4K NMV page where the first memory location to be modified is. */
    G_4k_page_offset = G_start_address.offset % FLASH_PAGE_SIZE;

    /* Compute the starting address of the 4K page being modified. */
    G_4k_page_start_address.offset = G_start_address.offset - G_4k_page_offset;
    G_4k_page_start_address.page   = G_start_address.page;

    /* Reset the number of data words received for the current 4K page. */
    G_word_count = 0;

    /* Create a RAM image of the 4K page being modified. */
    mmgr_memcpy( data_page_RAM_image, G_4k_page_start_address, FLASH_PAGE_SIZE );

    return sys_err;
}


/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Adds new data words to the RAM image of a 4K memory page to be overwritten.
 *              When the end of the page is reached, the page is written to the NVM.  A call
 *              to mmgr_write_data_start() should be made prior to calling this function and
 *              a call to mmgr_write_data_finalize() should be made after the last
 *              mmgr_write_data() call.
 * Parameters:  data - the address of the data buffer to get data from; the data is added
 *                     immediately after the last data word previously written.
 *              size - the number of 16-bit words that will be added to the RAM image of the
 *                     current 4K RAM image of the NVM page being overwritten.
 * Returns:     MMGR_NO_ERROR - no error were detected.
 *              MMGR_ERROR    - an error occurred when writing to the NVM.
 ********************************************************************************************/
ERR_RET mmgr_write_data( INT16U* data, INT16U size )
{
    INT16S  page_overflow_word_count;
    INT16U  i;
    INT16U  j = 0;
    INT16U  first_word;
    ERR_RET sys_err = MMGR_NO_ERROR;

    /* Compute how many words will go to the next 4K page. */
    page_overflow_word_count = G_4k_page_offset + G_word_count + size - FLASH_PAGE_SIZE;

    /* Check if a 4K page is full and can be written to NVM. */
    if( page_overflow_word_count >= 0 )
    {
        /* Add new bytes to the RAM image up to the end of the 4K page. */
        for( i = G_4k_page_offset + G_word_count; i < FLASH_PAGE_SIZE; i++ )
        {
            data_page_RAM_image[i] = data[j++];
        }

        /* Write a full 4K page. */
        sys_err = _mmgr_write_ram_image( G_4k_page_start_address );

        /* Compute the starting address of a new RAM image. */
        if( ( G_4k_page_start_address.offset + FLASH_PAGE_SIZE ) == PROG_MEM_PAGE_SIZE )
        {
            G_4k_page_start_address.offset = 0;
            G_4k_page_start_address.page++;
        }
        else
        {
            G_4k_page_start_address.offset = G_4k_page_start_address.offset + FLASH_PAGE_SIZE;
        }

        /* Create a RAM image of the new 4K page to be modified. */
        mmgr_memcpy( data_page_RAM_image, G_4k_page_start_address, FLASH_PAGE_SIZE );

        /* Set the starting offset of data being modified on the new 4K page. */
        G_4k_page_offset = 0;

        /* Check if overflow didn't occur, but the end of a 4K page was reached. */
        if( page_overflow_word_count == 0 )
        {
            /* Set the number of words written to the new page. */
            G_word_count = 0;
        }
        else /* 4K page overflow occurred. */
        {
            /* Copy the remaining page_overflow_byte_count bytes to a new RAM image. */
            G_word_count = page_overflow_word_count;

            for( i = 0; i < G_word_count; i++ )
            {
                data_page_RAM_image[i] = data[j++];
            }
        }
    }
    else
    {
        /* Compute the index of the first word in the sequence of words being added. */
        first_word = G_4k_page_offset + G_word_count;
        /* Add new words to the RAM image of the current 4K page in data_page_RAM_image. */
        for( i = first_word; i < first_word + size; i++ )
        {
            data_page_RAM_image[i] = data[j++];
        }

        /* Update the count of words written to the current 4K page. */
        G_word_count += size;
    }

    return sys_err;
}


/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Adds new data words to the RAM image of a 4K memory page to be overwritten.
 *              When the end of the page is reached, the page is written to the NVM.  A call
 *              to mmgr_write_data_start() should be made prior to calling this function and
 *              a call to mmgr_write_data_finalize() should be made after the last
 *              mmgr_write_data() call.
 * Parameters:  data - the address of the data buffer to get data from; the data is added
 *                     immediately after the last data word previously written.
 *              size - the number of 16-bit words that will be added to the RAM image of the
 *                     current 4K RAM image of the NVM page being overwritten.
 * Returns:     MMGR_NO_ERROR - no error were detected.
 *              MMGR_ERROR    - an error occurred when writing to the NVM.
 ********************************************************************************************/
ERR_RET mmgr_write_configuration_data( INT16U* data, INT16U size )
{
    INT16S  page_overflow_word_count;
    INT16U  i;
    INT16U  j = 0;
    INT16U  first_word;
    ERR_RET sys_err = MMGR_NO_ERROR;

    /* Compute how many words will go to the next 4K page. */
    page_overflow_word_count = G_4k_page_offset + G_word_count + size - FLASH_PAGE_SIZE;

    /* Check if a 4K page is full and can be written to NVM. */
    if( page_overflow_word_count >= 0 )
    {
        /* Add new bytes to the RAM image up to the end of the 4K page. */
        for( i = G_4k_page_offset + G_word_count; i < FLASH_PAGE_SIZE; i++ )
        {
            data_page_RAM_image[i] = data[j++];
            i++; /* Skip the upper word that has a single usable byte */
        }

        /* Write a full 4K page. */
        sys_err = _mmgr_write_ram_image( G_4k_page_start_address );

        /* Compute the starting address of a new RAM image. */
        if( ( G_4k_page_start_address.offset + FLASH_PAGE_SIZE ) == PROG_MEM_PAGE_SIZE )
        {
            G_4k_page_start_address.offset = 0;
            G_4k_page_start_address.page++;
        }
        else
        {
            G_4k_page_start_address.offset = G_4k_page_start_address.offset + FLASH_PAGE_SIZE;
        }

        /* Create a RAM image of the new 4K page to be modified. */
        mmgr_memcpy( data_page_RAM_image, G_4k_page_start_address, FLASH_PAGE_SIZE );

        /* Set the starting offset of data being modified on the new 4K page. */
        G_4k_page_offset = 0;

        /* Check if overflow didn't occur, but the end of a 4K page was reached. */
        if( page_overflow_word_count == 0 )
        {
            /* Set the number of words written to the new page. */
            G_word_count = 0;
        }
        else /* 4K page overflow occurred. */
        {
            /* Copy the remaining page_overflow_byte_count bytes to a new RAM image. */
            G_word_count = page_overflow_word_count;

            for( i = 0; i < G_word_count; i++ )
            {
                data_page_RAM_image[i] = data[j++];
            }
        }
    }
    else
    {
        /* Compute the index of the first word in the sequence of words being added. */
        first_word = G_4k_page_offset + G_word_count;
        /* Add new words to the RAM image of the current 4K page in data_page_RAM_image. */
        for( i = first_word; i < first_word + size; i++ )
        {
            data_page_RAM_image[i] = data[j++];
            i++; /* Skip the upper word that has a single usable byte */
        }

        /* Update the count of words written to the current 4K page. */
        G_word_count += size;
    }

    return sys_err;
}


/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Updates flash memory based on the RAM buffer contents.  Called after making
 *              mmgr_write_data() calls;
 * Parameters:  None.
 * Returns:     MMGR_NO_ERROR - no error were detected.
 *              MMGR_ERROR    - an error occurred when writing to the NVM.
 ********************************************************************************************/
ERR_RET mmgr_write_data_finalize( void )
{
    ERR_RET sys_err = MMGR_NO_ERROR;

    if( G_word_count > 0 )
    {
        /* Write a full 4K page. */
        sys_err = _mmgr_write_ram_image( G_4k_page_start_address );
    }

    return sys_err;
}


/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Erases and overwrites a 4Kbyte page of the internal program flash memory.
 * Parameters:  address - the address of the beginning of the 4K page of NVM to overwrite.
 * Returns:     MMGR_NO_ERROR - no write errors detected.
 *              MMGR_ERROR    - error while writing data to the memory.
 * History:     06/10/2010 Clay Barber - Changed Files updates
 ********************************************************************************************/
ERR_RET _mmgr_write_ram_image( MEM_ADDRESS_TYPE address )
{
    ERR_RET sys_err      = MMGR_NO_ERROR;
    INT16U  ram_offset   = 0;       /* Address offset into the RAM image data */

    /* Instruction double word count (two 24-bit instruction words programmed at a time) */
    INT16U  dword_count  = 0;

    INT16U  saved_TBLPAG = TBLPAG;  /* Save the current TBLPAG register value. */
    INT16U rowsize;
    INT8U nvmop;
    INT8U i;

    INTCON2bits.GIE = 0;

    /* Erase the flash data page from memory */
    mmgr_erase_flash( address );

    /* Set starting address to write to */
    NVMADRU = address.page;
    Nop();
    NVMADR  = address.offset;
    Nop();

    /* Rowsize is 2 instruction words (32 bytes) on dspic33EPxxxMC506 processors (LCU/UAP) and
     *   128 instruction words on dspic33EPxxxxx806/810 (SCM/PDM and SCMv2) */
#if defined(__dsPIC33EP256MC506__)
    rowsize = 2;
    nvmop = 0b001;
#elif defined(__dsPIC33EP256MU806__) || defined(__dsPIC33EP512MU810__)
    rowsize = 128;
    nvmop = 0b010;
/* added support for the '256MU810 */
#elif defined(__dsPIC33EP256MU810__)
    rowsize = 128;
    nvmop = 0b010;
#elif defined(__dsPIC33CK512MP608__)/*TBD*/
    rowsize = 128;
    nvmop = 0b010;
#elif defined(__dsPIC33CK256MP508__)/*TBD*/
    rowsize = 128;
    nvmop = 0b010;
#elif defined(__dsPIC33CK256MP606__)/*TBD*/
    rowsize = 128;
    nvmop = 0b010;
#else
#error "Unknown processor in use: Don't know what rowsize to use for Flash writes."
#endif

    NVMCONbits.NVMOP = nvmop;
    NVMCONbits.WREN = 1;

    /* Program the modified RAM data image into memory two instruction words (4 16-bit words) at a time. */
    for (dword_count = 0; dword_count < ( FLASH_PAGE_SIZE / (rowsize*2) ); dword_count++)
    {
        TBLPAG = 0xFA;   /* Write latches are 0xFA0000 - 0xFA0003 (two instruction words) */

        for(i=0; i< rowsize; ++i)
        {
            __builtin_tblwtl( i*2, data_page_RAM_image[ram_offset++] );
            __builtin_tblwth( i*2, data_page_RAM_image[ram_offset++] );
        }

        Nop();
        asm (
            "; Disable interrupts < priority 7 for next 5 instructions      \n"
            "DISI #06                                                       \n"
            "; Write the KEY sequence                                       \n"
            "MOV #0x55,W0                                                   \n"
            "MOV W0,NVMKEY                                                  \n"
            "MOV #0xAA,W0                                                   \n"
            "MOV W0,NVMKEY                                                  \n"
            "; Start the programming sequence                               \n"
            "BSET NVMCON,#15                                                \n"
            "; Insert two NOPs after programming                            \n"
            "NOP                                                            \n"
            "NOP                                                            \n"
        );
        while( NVMCONbits.WR );   /* Wait for programming to complete */
        Nop();
        Nop();

        /* Check if an error occured while programming. */
        if( NVMCONbits.WRERR )
        {
            sys_err = MMGR_ERROR;
        }

        NVMADR += rowsize*2;              /* Set next double-word to program */
        Nop();
    }

    /* Restore TBLPAG register. */
    TBLPAG = saved_TBLPAG;
    Nop();

    INTCON2bits.GIE = 1;

    /* Return status */
    return sys_err;
}


/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Copies a specified number of 16-bit words from the program memory
 *              source address to the RAM destination address.
 * Parameters:  p_dest - pointer to the destination to store the data being copied.
 *              src_addr - address (128K page number and offset) to read data from
 *              num_bytes - number of bytes that need to be read
 * Returns:     None.
 ********************************************************************************************/
void mmgr_memcpy( void* p_dest, MEM_ADDRESS_TYPE src_addr, INT16U num_words )
{
    INT16U  offset;
    INT16U  saved_TBLPAG = TBLPAG;     /* Save the current TBLPAG register value. */
    INT16U* p_buf = (INT16U*)p_dest;
    INT16U  i;

    /* Set page number and offset addresses for the read operation */
    TBLPAG = src_addr.page;
    offset = src_addr.offset;

    /* Loop through and read out the number of bytes required */
    for( i = 0; i < num_words; i++ )
    {
        if( offset % 2 == 0 )
        {
            p_buf[i] = __builtin_tblrdl( offset );
        }
        else
        {
            p_buf[i] = __builtin_tblrdh( offset );
        }

        offset++;
    }

    /* Restore TBLPAG register. */
    TBLPAG = saved_TBLPAG;

    /* Void return */
    return;
}


/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Copies a specified number of 16-bit words at even addresses from
 *              the program memory source address to the RAM destination address.
 * Parameters:  p_dest - pointer to the destination to store the data being copied.
 *              src_addr - address (128K page number and offset) to read data from
 *              num_bytes - number of bytes that need to be read
 * Returns:     None.
 ********************************************************************************************/
void mmgr_memcpy_even( void* p_dest, MEM_ADDRESS_TYPE src_addr, INT16U num_words )
{
    INT16U  offset;
    INT16U  saved_TBLPAG = TBLPAG;     /* Save the current TBLPAG register value. */
    INT16U* p_buf = (INT16U*)p_dest;
    INT16U  i;

    /* Set page number and offset addresses for the read operation */
    TBLPAG = src_addr.page;
    offset = src_addr.offset;

    /* Loop through and read out the number of bytes required */
    for( i = 0; i < num_words; i++ )
    {
        p_buf[i] = __builtin_tblrdl( offset );
        offset += 2;
    }

    /* Restore TBLPAG register. */
    TBLPAG = saved_TBLPAG;

    /* Void return */
    return;
}


/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Retrieves a word of data from the program flash memory.
 * Parameters:  address - address of data to read.
 *              p_value - pointer to the buffer to store a 16-bit word to.
 * Returns:     None.
 ********************************************************************************************/
void mmgr_get_program_word( INT32U address, INT16U* p_value )
{
    /* Save the current TBLPAG register value. */
    INT16U saved_TBLPAG = TBLPAG;
    /* Set offset of the data within the program memory page */
    INT16U data_offset = address % PROG_MEM_PAGE_SIZE;

    if( address <= PROGRAM_MEMORY_MAX_ADDR )
    {
        /* Set program memory page number */
        TBLPAG = address / PROG_MEM_PAGE_SIZE;

        if( data_offset % 2 == 0 )
        {
            *p_value = __builtin_tblrdl( data_offset );
        }
        else
        {
            *p_value = __builtin_tblrdh( data_offset );
        }

        /* Restore TBLPAG register. */
        TBLPAG = saved_TBLPAG;
    }

    /* Void return */
    return;
}


/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Writes boot mode setting to flash memory.
 * Parameters:  boot_mode - either application or maintenance mode can be selected.
 * Returns:     MMGR_NO_ERROR - no error has occurred.
 *              MMGR_ERROR    - an error has occurred.
 ********************************************************************************************/
ERR_RET mmgr_set_boot_mode( BOOT_MODE_TYPE boot_mode )
{
    INT16U  boot_code = (INT16U)boot_mode;
    INT16U  current_boot_mode;
    ERR_RET sys_err = NO_ERROR;
    MEM_ADDRESS_TYPE boot_mode_address;

    /* Compute address offset into the block of flash memory being modified. */
    boot_mode_address.page   =  (INT8U)( FW_BOOT_TABLE_ADDR / PROG_MEM_PAGE_SIZE );
    boot_mode_address.offset = (INT16U)( FW_BOOT_TABLE_ADDR % PROG_MEM_PAGE_SIZE );

    /* Do NOT overwrite the boot mode field if the boot mode is already set to the commanded mode. */
    mmgr_get_program_word(FW_BOOT_TABLE_ADDR, &current_boot_mode);
    if( current_boot_mode == (INT16U)boot_mode )
    {
        sys_err = MMGR_NO_ERROR;
    }
    else
    {
        /* Initialize writing operation. */
        sys_err = mmgr_write_data_start( FW_BOOT_TABLE_ADDR );

        /* Continue if writing at the specified address is allowed. */
        if( sys_err == MMGR_NO_ERROR )
        {
            /* Write data to the temporary buffer. */
            sys_err = mmgr_write_data( &boot_code, BOOT_MODE_SIZE );
            /* Commit changes to the flash memory. */
            sys_err += mmgr_write_data_finalize();
        }
    }

    /* Return status */
    return ( (sys_err == MMGR_NO_ERROR) ? MMGR_NO_ERROR : MMGR_ERROR );
}

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Utility function to erase a 4K page of program flash memory.
 * Parameters:  mem_addr - 128K page number and offset into the page to address the 4K page
 *              to be erased.
 * Returns:     None.
 ********************************************************************************************/
void mmgr_erase_flash( MEM_ADDRESS_TYPE mem_addr )
{
    /* Set the page and offset addresses for the erase operation, and enable erase operations */
    NVMADR  = mem_addr.offset;  /* Offset into the 128K page to the 4K page to be erased. */
    NVMADRU = mem_addr.page;    /* 128K page number. */
    NVMCON  = ERASE_MEM_BLOCK;

    /* Disable interrupts. */
    DISABLE_INTERRUPTS();

    /* Issue the unlock sequence and enable the Write bit followed by two nop's. */
    __builtin_write_NVM();
    __builtin_nop(); /* per datasheet we must have two nops after NV RAM command */
    __builtin_nop(); /* per datasheet we must have two nops after NV RAM command */

    /* Re-enable interrupts. */
    ENABLE_INTERRUPTS();

    /* Wait for programming to complete */
    while( NVMCONbits.WR )
    {
        ClrWdt();
    }

    /* Void return */
    return;
}
