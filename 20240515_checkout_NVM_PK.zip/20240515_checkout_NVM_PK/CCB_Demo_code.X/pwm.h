/*
Author(s): Michael Ansolis <dzielinski@righthandtech.com>
Status: Preliminary
Release Date:
Revision:
Description: Header for PWM_Control module.
*/

#ifndef PWM_H
#define PWM_H

/*********************************************************************************************
Includes
*********************************************************************************************/
#include "typedef.h"

/*********************************************************************************************
Preprocessor definitions
*********************************************************************************************/
/* Maximum signed 16-bit integer. */
#define MAX_INT_16S        32767

typedef enum
{
    BLDC_DRIVE_NEGATIVE = 0,
    BLDC_DRIVE_POSITIVE = 1
} BLDC_DRIVE_DIRECTION;


/*********************************************************************************************
Function declarations
*********************************************************************************************/

/*********************************************************************************************
 * Author(s):    Michael Ansolis
 * Description:  Initialization of the PWM_Control module, including initialization of PWM
 *               hardware module and special even interrupt that triggers at a certain phase of
 *               PWM duty cycle.
 * Parameters:   None
 * Returns:      NO_ERROR    - indicates success
 *               ERR_FAILURE - indicates failure
*********************************************************************************************/
ERR_RET pwm_init(void);
void pwm_ADCtrig_init( void );
void pwm_slnd_init( void );
void pwm_change_drive_direction(BLDC_DRIVE_DIRECTION drive_direction);
/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Computes the PWM duty cycle based on the speed demand and limits the PWM value
             based on the current motor speed.  The computed value is pushed to the hardware
             PWM module.
Parameters:  None
Returns:     None
*********************************************************************************************/
void pwm_adjust_pwm(void);


/*********************************************************************************************
Author(s):      Jonathan R. Saliers
Description:    Changes which drive transitors are active/inactive
Parameters:     current_hall - bitfield representing the current Hall sensor readings.
Returns:        None
*********************************************************************************************/
void pwm_isr_adjust_drive(INT16U current_hall);


/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Safely sets the new value of the global variable G_disable_drive.
Parameters:  disable_drive - indicates whether BLDC motor needs to be stopped.
Returns:     None
*********************************************************************************************/
void pwm_set_disable_drive(BOOL disable_drive);


/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Sets the new value of the global variable G_speed_demand.
Parameters:  speed_demand - speed demand in RPM calculated by the speed control loop.
Returns:     None
*********************************************************************************************/
void pwm_set_speed_demand(INT16S speed_demand);


/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Sets the new value of the global variable G_motor_speed.
Parameters:  motor_speed - new actual motor speed in RPM.
Returns:     None
*********************************************************************************************/
void pwm_set_motor_speed(INT16S motor_speed);

INT16S pwm_get_motor_speed();
/*********************************************************************************************
Author(s):   Michael Ansolis
Description: Return the currently assigned motor PWM value.
Parameters:  None.
Returns:     The currently assigned motor PWM value.
*********************************************************************************************/
INT16S pwm_get_current_pwm(void);

/*********************************************************************************************
Author(s):   Juan Kuyoc
Description: Returns the voltage applied to the PWM by multiplying the duty
             percentage and the PWM voltage.
Parameters:  None
Returns:     float - The voltage applied to the PWM.
*********************************************************************************************/
float pwm_get_command_voltage();
#endif /* PWM_H */
