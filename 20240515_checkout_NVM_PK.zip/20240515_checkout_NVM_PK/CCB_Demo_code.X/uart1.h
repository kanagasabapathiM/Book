#ifndef UART1_H
#define UART1_H
/*********************************************************************************************
Included files
 *********************************************************************************************/
#define UART_DEBUG 1
#ifdef UART_DEBUG
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
/*********************************************************************************************
 * Function declarations
 ********************************************************************************************/
void UART1_Initialize(void);

void UART1_Write(uint8_t data);

void UART1_test(void);

int32_t UART1_Get_cmd();

#endif
#endif  // UART1_H
