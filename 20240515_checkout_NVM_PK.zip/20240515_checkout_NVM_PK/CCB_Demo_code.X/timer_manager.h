/*
 * Author(s):    Jonathan R. Saliers
 * Status:       Incomplete
 * Release Date: 11/30/12
 * Revision:     0.1
 * Description:  Header file for the Timer_Manager module.
 */

/*********************************************************************************************
 * Recursive header block
 ********************************************************************************************/
#ifndef TIMER_MANAGER_H
#define TIMER_MANAGER_H

/*********************************************************************************************
 * Includes
 ********************************************************************************************/
#include "typedef.h"
#include "position.h"

/*********************************************************************************************
 * Any type definitions defined by the header file
 ********************************************************************************************/
/*
 Defines the different PWM duty cycles for the PWM ref signal STP_REF
 */
typedef enum
{
    TMGR_PWM_ENGAGED = 0,
    TMGR_PWM_STEPPING,
    TMGR_PWM_HOLDING
} TMGR_PWM_TYPE;

/*********************************************************************************************
 * Preprocessor definitions
 ********************************************************************************************/
#define HEF_STOP_TIMEOUT_MIN        6000ul
#define HEF_STOP_TIMEOUT_DEFAULT    30000ul /* 15625?*0.8= 12500usec = 12500 * 48 = 600msec for 1 rotation minimum*/
#define HEF_STOP_TIMEOUT_MAX        30000ul

/*********************************************************************************************
 * Function declarations
 ********************************************************************************************/

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: The initialization function for the Timer_Manager module.
 * Parameters:  None.
 * Returns:     None.
 ********************************************************************************************/
void tmgr_init( void );

/*********************************************************************************************
Author(s):   James Pieterick
Description: returns the time in microseconds since the last time that this function
             was called in *P_hall_delta_time. The is reset and restarted by this function.
             Note that the largest value that this function will return is
             hef_stop_timeout.
Parameters:  P_hall_delta_time - A pointer to the time delta since the last time
                                this function was called with the reset flag set.
Returns:     None.
 *********************************************************************************************/
void tmgr_isr_get_hall_delta_time(INT16U* p_hall_delta_time);

/*********************************************************************************************
Author(s):   James Pieterick
Description: returns a flag that indicates whether or not the hall delta timer has
             expired (exceeded hef_stop_timeout).
Parameters:  None.
Returns:     A boolean flag that if TRUE indicates that the hall delta timer has expired.
             FALSE indicates that the timer has not yet expired.
 *********************************************************************************************/
BOOL tmgr_hall_delta_time_expired(void);

/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: Returns the number of milliseconds since unit power up.
Parameters:  None.
Returns:     The number of milliseconds since power up.
 *********************************************************************************************/
INT32U tmgr_get_system_time( void );

#ifndef PRIVACY_DIVIDER
/*********************************************************************************************
Author(s):   Russell Everett <reverett@righthandtech.com>
Description: Timer Manager function to set the PWM reference duty cycle.
Parameters:  (in) requested PWM
Returns:     None.
*********************************************************************************************/
void tmgr_set_stepper_ref_pwm(TMGR_PWM_TYPE pwm_request);

/*********************************************************************************************
Author(s):   Russell Everett <reverett@righthandtech.com>
Description: Timer Manager function to start timer 4.
              - clears timer 4 then enables timer 4 interrupts
Parameters:  None.
Returns:     None.
*********************************************************************************************/
void tmgr_enable_timer4(void);

/*********************************************************************************************
Author(s):   Russell Everett <reverett@righthandtech.com>
Description: Timer Manager funtion to Stop timer 4.
              - disables timer 4 interrupts
Parameters:  None.
Returns:     None.
*********************************************************************************************/
void tmgr_disable_timer4(void);
#endif

/*********************************************************************************************
 * Recursive header block
 ********************************************************************************************/
#endif	/* TIMER_MANAGER_H */

