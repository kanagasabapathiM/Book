/*
 Author(s):    Pratheep Kumar
 Status:       Draft
 Release Date:
 Revision:
 Description:  Definitions for the Actuator Communications Module.
 Note:         
 */
/****NAMING CONVENTION IS NOT FOLLWED AS IT WILL REQUIRE LOT OF PLACES TO BE CHANGED ECAN TO CAN
 AS IT IS ONLY FOR DEMO NOT NECESSARY*/
/*********************************************************************************************
Included Files
*********************************************************************************************/
#include "can.h"
#ifndef BOOTLOADER
#include "Event_Manager.h"
#endif
#include "global.h"
#include "utility.h"
#include <xc.h>
#include <stdint.h>
/*********************************************************************************************
Private Preprocessor definitions
*********************************************************************************************/

/* CAN interface configuration register initialization values */

#define INIT_CAN_MODE_CFG  4

#define INIT_CAN_SYNC_JUMP_WIDTH 0x3
#define INIT_CAN_BAUD_RATE_PRESCALER 0x1
#define INIT_CAN_WAKEUP_LINEFILTER 0x0
#define INIT_CAN_PHASE2_LENGTH 0x4
#define INIT_CAN_PHASE1_LENGTH 6
#define INIT_FILTER_ENABLE_MASK 0x0101   /* Enable filters 0 and 8 */
#define INIT_FILTER_MASK_SELECT0     0
#define INIT_FILTER_MASK_SELECT1     1
#define INIT_FILTER_MASK_SELECT2     2
#define INIT_FILTER_BUF_PNTR1234 0xFFFF

#define FILTER_CANID       0x7F
#define ANY_CANID       0x00
#define FILTER_SID         0x1FF
#define ANY_SID         0x00
#define FILTER_STD_OR_EXT  TRUE
#define FILTER_STD_AND_EXT FALSE


#define INIT_TX_BUF_EN 0x1
#define INIT_TX_BUF_PRI 0x1

/* CAN message field constant values */
#define INIT_TXMSG_LCC  0x2
#define INIT_TXMSG_RSD  0x0
#define INIT_TXMSG_RTR  0x0
#define INIT_TXMSG_IDE  0x1
#define INIT_TXMSG_LCL  0x1
#define INIT_TXMSG_PVT  0x0
#define INIT_TXMSG_SIDH 0x0
#define INIT_TXMSG_BRS  0x0

#define INIT_SIDL_MASK  0b00011111
#define INIT_SIDH_SHIFT 5
#define INIT_SIDH_MASK  0b011100000
#define INIT_SID_BIT_9_SHIFT   8
#define INIT_SID_BIT_9_MASK    0b100000000

// CAN Message object arbitration field information

// CAN Bus FIFO Memory information
#define CAN1_FIFO_ALLOCATE_RAM_SIZE    2048U // CAN FIFO allocated ram size based on (number of FIFO x FIFO message Payload size x Message object DLC size)

// CAN Bus receive FIFO Memory information
#define CAN1_NUM_OF_RX_FIFO            2U    // No of RX FIFO's configured
#define CAN1_RX_FIFO_MSG_DATA          8U   // CAN RX FIFO Message object data field size
#define CAN_RX_FIFO_WORD_0      0
#define CAN_RX_FIFO_WORD_1      1
#define CAN_RX_FIFO_WORD_2      2
#define CAN_RX_FIFO_WORD_4      4

// CAN Bus Transmit FIFO Memory information
#define CAN1_TX_MSG_SEND_REQ_BIT_POS   0x200U // CAN FIFO TX Message Send Request bit 
#define CAN1_TX_INC_FIFO_PTR_BIT_POS   0x100U // CAN FIFO Increment Head/Tail bit
#define CAN_TX_FIFO_WORD_0      0
#define CAN_TX_FIFO_WORD_1      1
#define CAN_TX_FIFO_WORD_2      2
#define CAN_TX_FIFO_WORD_4      4

#define CAN1_NUM_OF_RX_FIFO            2U    // No of RX FIFO's configured

// Section: Private Variable Definitions
// Start CAN Message Memory Base Address
static INT8U __attribute__((aligned(4)))can1FifoMsg[CAN1_FIFO_ALLOCATE_RAM_SIZE];

static INT8U rxFIFOMsg[CAN1_NUM_OF_RX_FIFO] = {CAN1_FIFO_2,CAN1_FIFO_3}; 

static uint16_t *txFifoObj;

/*********************************************************************************************
 * Private type definitions
 ********************************************************************************************/
typedef struct {
    union {
        struct {
            unsigned         :3;
            unsigned flag    :1; /* MIDE for masks, EXIDE for filters */
            unsigned         :2;
            unsigned source  :7;
            unsigned         :3;
        };
        struct {
            unsigned int value;
        };
    };
} ECAN_SID_TYPE;

typedef struct {
    union {
        struct {
            unsigned sid     :9;
            unsigned dest    :7;
        };
        struct {
            unsigned int value;
        };
    };
} ECAN_EID_TYPE;


typedef struct {
    ECAN_SID_TYPE sid;
    ECAN_EID_TYPE eid;
} ECAN_SID_EID_TYPE;

struct CAN1_FIFO_INFO
{
    uint8_t payloadSize;
    uint8_t msgDeepSize;
    uint16_t *address;
};

/*********************************************************************************************
Private Function declarations
 *********************************************************************************************/
static void _ecan_init_filters(INT8U source_canid, INT8U dest_canid, INT8U dest_pwrid);
static void CAN1_RX_FIFO_IncrementMsgPtr(const uint8_t fifoNum);
static void CAN1_MessageReadFromFifo(uint16_t *rxFifoObj, ECAN_HW_MESSAGE *rxCanMsg);
uint8_t CAN1_RX_FIFO_StatusGet(const enum CAN1_RX_FIFO_CHANNELS fifoNum);
static void CAN1_FIFO_InfoGet(const uint8_t fifoNum, volatile struct CAN1_FIFO_INFO *fifoInfo);

static void CAN1_TX_FIFO_MessageSendRequest(const enum CAN1_TX_FIFO_CHANNELS fifoChannel);

static void CAN1_RX_FIFO_OverflowStatusFlagClear(const enum CAN1_RX_FIFO_CHANNELS fifoNum);
enum CAN_TX_FIFO_STATUS CAN1_TransmitFIFOStatusGet(const enum CAN1_TX_FIFO_CHANNELS fifoChannel);
/*********************************************************************************************
Global Variable definitions
 *********************************************************************************************/

/*********************************************************************************************
Function definitions
 *********************************************************************************************/
/*********************************************************************************************
 * Author(s):   
 * Description: The initialization function for the CAN module.
 * Parameters:  scm_id - CAN ID of the SCM controlling this actuator.
 *              can_id - CAN ID of this actuator.
 *              pwr_id - destination CAN ID for the "broadcast" message announcing
 *                       power shutdown is imminent for this actuator.
 * Returns:     None.
 * History:
 *********************************************************************************************/
void ecan_init(INT8U scm_id, INT8U can_id, INT8U pwr_id) {

    /* Enable the CAN1 module */
    C1CONLbits.CON = 1;

    C1CONHbits.REQOP = INIT_CAN_MODE_CFG; //Sets Configuration mode
    while (C1CONHbits.OPMOD != INIT_CAN_MODE_CFG); //Wait for configuration mode

    C1CONHbits.TXQEN = 0x1; //Enable Transmit Queue bit

    /* Initialize the C1FIFOBAL with the start address of the CAN1 FIFO message object area. */
    C1FIFOBAL = (uint16_t) & can1FifoMsg[0];

    /* CAN clock configuration for 1Mbps. */
    C1NBTCFGLbits.SJW = INIT_CAN_SYNC_JUMP_WIDTH;
    C1NBTCFGLbits.TSEG2 = INIT_CAN_PHASE2_LENGTH;

    C1NBTCFGHbits.BRP = INIT_CAN_BAUD_RATE_PRESCALER;
    C1NBTCFGHbits.TSEG1 = INIT_CAN_PHASE1_LENGTH;

    //C1DBTCFGH C1DBTCFGL required to set??
    C1CONLbits.BRSDIS = 1; //Bit Rate Switching is disabled, regardless of BRS in the transmit message object
    C1CONLbits.WAKFIL = INIT_CAN_WAKEUP_LINEFILTER; //CAN bus line filter is not used for wake-up
    C1CONLbits.PXEDIS = 1; //Protocol Exception is treated as a form error
    //TBD check if required to enable..?
    C1CONLbits.ISOCRCEN = 0; //Does not include stuff bit count in CRC field and uses CRC initialization vector with all zeros

    // Disabled CAN1 Store in Transmit Event FIFO bit
    C1CONHbits.STEF = 0;
    // Enabled CAN1 Transmit Queue bit
    C1CONHbits.TXQEN = 1;

    /* configure CAN1 Bit rate settings */
    // BRP 0; TSEG1 14; 
    C1NBTCFGH = 0xE;
    // SJW 3; TSEG2 3; 
    C1NBTCFGL = 0x303;

    /* configure CAN1 transmit FIFO settings */
    C1TXQCONHbits.PLSIZE = 0; //Payload Size 8 data bytes
    C1TXQCONHbits.FSIZE = 0x1F; //FIFO is 32 messages deep
    C1TXQCONHbits.TXAT = 2; //Unlimited number of retransmission attempts

    C1TXQCONLbits.FRESET = 1; //FIFO Reset bit
    C1TXQCONLbits.TXEN = INIT_TX_BUF_EN; //TX Enable bit  
    // C1TXQCONLbits.TXATIE = 1;

    C1FIFOCON1Hbits.PLSIZE = 0; //Payload Size 8 data bytes
    C1FIFOCON1Hbits.FSIZE = 0x1F; //FIFO is 32 messages deep
    C1FIFOCON1Hbits.TXAT = 2; //Unlimited number of retransmission attempts

    C1FIFOCON1Lbits.FRESET = 1; //FIFO Reset bit
    C1FIFOCON1Lbits.TXEN = INIT_TX_BUF_EN; //TX Enable bit  

    /*Configure the CAN1 receive FIFO settings*/
    C1FIFOCON2Hbits.PLSIZE = 0; //Payload Size 8 data bytes
    C1FIFOCON2Hbits.FSIZE = 0x1F; //FIFO is 32 messages deep
    C1FIFOCON2Lbits.FRESET = 1; //FIFO Reset bit
    C1FIFOCON2Lbits.TXEN = 0;
    C1FIFOCON2Lbits.RXOVIE = 1; //FIFO Reset bit   

    C1FIFOCON3Hbits.PLSIZE = 0; //Payload Size 8 data bytes
    C1FIFOCON3Hbits.FSIZE = 0x1F; //FIFO is 32 messages deep
    C1FIFOCON3Lbits.FRESET = 1; //FIFO Reset bit
    C1FIFOCON3Lbits.TXEN = 0;
    C1FIFOCON3Lbits.RXOVIE = 1; //FIFO Reset bit  
    //
    _ecan_init_filters(1, 1, 1);


    C1CONHbits.REQOP = 0x6; //Sets Normal CAN 2.0 mode;;
    while (C1CONHbits.OPMOD != 0x6);

    return;

}

/*********************************************************************************************
 * Author(s):   E. Miller
 * Description: Change CAN Source, Destination, SID and MIDE/EXIDE flag into processor SID/EID register format
 * Parameters:  source -_the source mask or filter
 *              dest   - the destination mask or filter
 *              sid    - the sid mask or filter
 *              flag   - the MIDE flag for mask, or the EXIDE flag for the filter
 * Returns:     SID/EID in register formates
 *********************************************************************************************/
static ECAN_SID_EID_TYPE _ecan_sid_eid_format ( INT16U source, INT16U dest, INT16U sid, BOOL flag )
{

    ECAN_SID_EID_TYPE result;

    result.sid.value   = 0;
    result.sid.source  = source;
    result.sid.flag    = flag;

    result.eid.value   = 0;
    result.eid.dest    = dest;
    result.eid.sid     = sid;

    return result;

}

/*********************************************************************************************
Author(s):  
Description: The initialization function for the CAN filter configuration), 
Parameters:  source_canid - the canid (send id) to fill in to match the Send message field
 *           dest_canid - the canid (receiver id) to fill in to match the Dest message field
Returns:     None
 *********************************************************************************************/
static void _ecan_init_filters(INT8U source_canid, INT8U dest_canid, INT8U dest_pwrid) {
    //filter setting to be updated TBD

    //FOR THE DEMO REMOVED ALL THE FILTER CONFIGURATIONS ACCEPTS ALL THE MESSAGES(FILTERS TO BE UPDATED))
    /* Configure RX FIFO Filter control settings*/

    // message stored in FIFO2
    C1FLTCON0Lbits.F0BP = 2;
    // EID 0x0; SID 0x0; 
    C1FLTOBJ0L = 0x0;
    // EID 0x0; EXIDE disabled; SID11 disabled; 
    C1FLTOBJ0H = 0x0;
    // MSID 0x0; MEID 0x0; 
    C1MASK0L = 0x0;
    // MEID 0x0; MSID11 disabled; MIDE disabled; 
    C1MASK0H = 0x0;
    // Enable the filter 0
    C1FLTCON0Lbits.FLTEN0 = 1;

    // message stored in FIFO3
    C1FLTCON0Lbits.F1BP = 3;
    // EID 0x0; SID 0x0; 
    C1FLTOBJ1L = 0x0;
    // EID 0x0; EXIDE disabled; SID11 disabled; 
    C1FLTOBJ1H = 0x0;
    // MSID 0x0; MEID 0x0; 
    C1MASK1L = 0x0;
    // MEID 0x0; MSID11 disabled; MIDE disabled; 
    C1MASK1H = 0x0;
    // Enable the filter 1
    C1FLTCON0Lbits.FLTEN1 = 1;

    return;

}
/*********************************************************************************************
 * Author(s):   
 * Description: This function checks for receipt of messages and returns the first
 *              received message on FIFO basis.
 * Parameters:  p_msg - pointer to a message input buffer to store a received message.
 * Returns:     false - no message was received.
 *              true    - message received.
 *********************************************************************************************/
bool ecan_rx_message(ECAN_HW_MESSAGE *rxCanMsg) {
    uint8_t fifoChannel;
    uint8_t count;
    uint8_t rxMsgStatus;
    volatile struct CAN1_FIFO_INFO fifoInfo;
    bool status = false;

    // Iterate all receive FIFO's and read the message object
    for (count = 0; count < CAN1_NUM_OF_RX_FIFO; count++) {
        fifoChannel = rxFIFOMsg[count];
        CAN1_FIFO_InfoGet(fifoChannel, &fifoInfo);
        rxMsgStatus = CAN1_RX_FIFO_StatusGet(fifoChannel);

        // If message object is available
        if ((uint8_t) CAN_RX_MSG_AVAILABLE == (rxMsgStatus & (uint8_t) CAN_RX_MSG_AVAILABLE)) {
            if ((uint16_t *) (*(fifoInfo.address)) != 0) {
                CAN1_MessageReadFromFifo((uint16_t *) * fifoInfo.address, rxCanMsg);
                CAN1_RX_FIFO_IncrementMsgPtr(fifoChannel);

                // User have to clear manually RX Overflow status
                if ((uint8_t) CAN_RX_MSG_OVERFLOW == (rxMsgStatus & (uint8_t) CAN_RX_MSG_OVERFLOW)) {
                    CAN1_RX_FIFO_OverflowStatusFlagClear(fifoChannel);
                }

                status = true;
            }

            break;
        }
    }

    return status;

}
//This function Update the receive FIFO message increment tail position
static void CAN1_RX_FIFO_IncrementMsgPtr(const uint8_t fifoNum) 
{
    switch (fifoNum) 
    {   
        case CAN1_FIFO_2:
            C1FIFOCON2Lbits.UINC = 1; // Update the CAN1_FIFO_2 message pointer.
            break;
        
        case CAN1_FIFO_3:
            C1FIFOCON3Lbits.UINC = 1; // Update the CAN1_FIFO_3 message pointer.
            break;
        
        default:
            break;
    }    
}
//This function is used to clear the CAN1 receive FIFO overflow status bit
static void CAN1_RX_FIFO_OverflowStatusFlagClear(const enum CAN1_RX_FIFO_CHANNELS fifoNum)
{   
    switch (fifoNum) 
    {
        case CAN1_FIFO_2:
            C1FIFOSTA2bits.RXOVIF = false;
            break;
            
        case CAN1_FIFO_3:
            C1FIFOSTA3bits.RXOVIF = false;
            break;
            
        default:
            break;
    }
}
/*This function read the message object from receive FIFO*/
static void CAN1_MessageReadFromFifo(uint16_t *rxFifoObj, ECAN_HW_MESSAGE *rxCanMsg) {

    uint8_t dlcByteSize = 0;

    
    util_memcpy((uint16_t*) rxCanMsg, (uint16_t*) (&rxFifoObj[0]), 8);
    dlcByteSize = rxCanMsg->DLC;
    util_memcpy((uint8_t*) rxCanMsg->D, (uint8_t*) (&rxFifoObj[CAN_RX_FIFO_WORD_4]), dlcByteSize);

}

/*********************************************************************************************
 * Author(s):   
 * Description: This function transmits outgoing messages.
 * Parameters:  p_msg       - pointer to the message that needs to be transmitted.
 * Returns:     ERR_FAILURE - message could not be transmitted (Tx buffers full).
 *              NO_ERROR    - no error was detected.
 *********************************************************************************************/
ERR_RET ecan_tx_message(ECAN_HW_MESSAGE* p_msg) {

    ERR_RET sys_err = NO_ERROR;
    enum CAN1_TX_FIFO_CHANNELS fifoChannel;
    
    /* Fill in common fields */
    p_msg->LCC = INIT_TXMSG_LCC;
    p_msg->RSD = INIT_TXMSG_RSD;
    p_msg->RTR = INIT_TXMSG_RTR;
    p_msg->IDE = INIT_TXMSG_IDE;
    p_msg->LCL = INIT_TXMSG_LCL;
    p_msg->PVT = INIT_TXMSG_PVT;
    p_msg->BRS = INIT_TXMSG_BRS;

    if (CAN1_TransmitFIFOStatusGet(CAN1_TXQ) == CAN_TX_FIFO_AVAILABLE) {
        txFifoObj = (uint16_t *) C1TXQUAL;
        fifoChannel = CAN1_TXQ;
    } else if (CAN1_TransmitFIFOStatusGet(CAN1_FIFO_1) == CAN_TX_FIFO_AVAILABLE) {
        txFifoObj = (uint16_t *) C1FIFOUA1L;
        fifoChannel = CAN1_FIFO_1;
    } else {
        return ERR_FAILURE;
    }

    util_memcpy((uint16_t*) (&txFifoObj[0]), (uint16_t*) p_msg->value, 8);
    util_memcpy((uint8_t*) (&txFifoObj[4]), (uint16_t *) p_msg->D, 8);

    CAN1_TX_FIFO_MessageSendRequest(fifoChannel);
    return sys_err;

}

/*********************************************************************************************
 * Author(s):   Mark Farver
 * Description: Breaks the SID up into three parts and puts them into the CAN frame
 * Parameters:  msg - the CAN frame to add the SID to
 *              sid - 9 bit SID value.
 * Returns:     None
 ********************************************************************************************/
void ecan_fill_sid(ECAN_HW_MESSAGE* msg, const INT16U sid)
{
    msg->SIDL      = (INT8U)(sid & INIT_SIDL_MASK);
    msg->SIDH      = (INT8U)((sid & INIT_SIDH_MASK ) >> INIT_SIDH_SHIFT);
    msg->SID_Bit_9 = (INT8U)((sid & INIT_SID_BIT_9_MASK) >> INIT_SID_BIT_9_SHIFT);
}


/*********************************************************************************************
 * Author(s):   Mark Farver
 * Description: Extracts the SID from a CAN frame and into a single value.
 * Parameters:  msg - the CAN frame to add the SID to
 * Returns:     9 bit SID value.
 ********************************************************************************************/
INT16U ecan_extract_sid(const ECAN_HW_MESSAGE* msg)
{
    INT16U sid = 0;
    sid |= ((INT16U)msg->SIDL) & INIT_SIDL_MASK;
    sid |= (((INT16U)msg->SIDH) << INIT_SIDH_SHIFT) & INIT_SIDH_MASK;
    sid |= (((INT16U)msg->SID_Bit_9) << INIT_SID_BIT_9_SHIFT)
           & INIT_SID_BIT_9_MASK;

    return sid;
}
// This function get the TX FIFO Availability
enum CAN_TX_FIFO_STATUS CAN1_TransmitFIFOStatusGet(const enum CAN1_TX_FIFO_CHANNELS fifoChannel)
{
    enum CAN_TX_FIFO_STATUS fifoStatus;
    
    switch (fifoChannel) 
    {
        case CAN1_TXQ:
            fifoStatus = ((C1TXQSTA & 0x1) ? CAN_TX_FIFO_AVAILABLE:CAN_TX_FIFO_FULL);
            break;
            
        case CAN1_FIFO_1:
            fifoStatus = ((C1FIFOSTA1 & 0x1) ? CAN_TX_FIFO_AVAILABLE:CAN_TX_FIFO_FULL);
            break;
            
        default:
            fifoStatus = CAN_TX_FIFO_FULL;
            break;
    }
    
    return fifoStatus;
}
//This function get the FIFO user address, message depth and payload size information.
static void CAN1_FIFO_InfoGet(const uint8_t fifoNum, volatile struct CAN1_FIFO_INFO *fifoInfo)
{   
    switch (fifoNum) 
    {
        case CAN1_TXQ:
            fifoInfo->address = (uint16_t *) &C1TXQUAL;
            fifoInfo->payloadSize = 8U;
            fifoInfo->msgDeepSize = 32U;
            break;
     
        case CAN1_FIFO_1:
            fifoInfo->address = (uint16_t *) &C1FIFOUA1L;
            fifoInfo->payloadSize = 8U;
            fifoInfo->msgDeepSize = 32U;
            break;
     
        case CAN1_FIFO_2:
            fifoInfo->address = (uint16_t *) &C1FIFOUA2L;
            fifoInfo->payloadSize = 8U;
            fifoInfo->msgDeepSize = 32U;
            break;
     
        case CAN1_FIFO_3:
            fifoInfo->address = (uint16_t *) &C1FIFOUA3L;
            fifoInfo->payloadSize = 8U;
            fifoInfo->msgDeepSize = 32U;
            break;
     
        default:
            fifoInfo->address = 0;
            fifoInfo->payloadSize = 0U;
            fifoInfo->msgDeepSize = 0U;
            break;
    }
}
//check the RX FIFO status for message reception
uint8_t CAN1_RX_FIFO_StatusGet(const enum CAN1_RX_FIFO_CHANNELS fifoNum)
{
    uint8_t rxFifoStatus;
    
    switch (fifoNum) 
    {
        case CAN1_FIFO_2:
            rxFifoStatus = (uint8_t)(C1FIFOSTA2 & (CAN_RX_MSG_AVAILABLE | CAN_RX_MSG_OVERFLOW));
            break;

        case CAN1_FIFO_3:
            rxFifoStatus = (uint8_t)(C1FIFOSTA3 & (CAN_RX_MSG_AVAILABLE | CAN_RX_MSG_OVERFLOW));
            break;

        default:
            rxFifoStatus = (uint8_t)CAN_RX_MSG_NOT_AVAILABLE;
            break;
    }
    
    return rxFifoStatus;
}

static void CAN1_TX_FIFO_MessageSendRequest(const enum CAN1_TX_FIFO_CHANNELS fifoChannel)
{   
    switch (fifoChannel) 
    {           
        case CAN1_TXQ:
            // Update the CAN1_TXQ message pointer; Set TXREQ bit
            C1TXQCONL = (C1TXQCONL | (CAN1_TX_MSG_SEND_REQ_BIT_POS | CAN1_TX_INC_FIFO_PTR_BIT_POS));
            break;

        case CAN1_FIFO_1:
            // Update the CAN1_FIFO_1 message pointer; Set TXREQ bit
            C1FIFOCON1L = (C1FIFOCON1L | (CAN1_TX_MSG_SEND_REQ_BIT_POS | CAN1_TX_INC_FIFO_PTR_BIT_POS));
            break;

        default:
            break;
    }      
}