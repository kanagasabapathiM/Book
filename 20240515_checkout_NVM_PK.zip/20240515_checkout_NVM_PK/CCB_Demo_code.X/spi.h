#ifndef _SPI_H
#define _SPI_H

/*********************************************************************************************
 * Includes
 ********************************************************************************************/
#include "typedef.h"
#include <stddef.h>


void spi1_init(void);

INT32U spi1_read(void);

INT32U spi1_exchange24bit( INT32U data );

INT32U spi3_exchange16bit(INT16U data);

INT16U spi3_read(void);

INT8U SPI2_ByteExchange(INT8U byteData);
void spi2_Init(void);

#endif /* _SPI_H */