/*
Author(s):      
Status:         
Release Date:
Revision:       
Description:    
*/

/*********************************************************************************************
Includes
*********************************************************************************************/
#include "angle_sensor.h"
#include "can.h"

/*********************************************************************************************
Private Type Definitions
 *********************************************************************************************/


/*********************************************************************************************
Private Preprocessor definitions
*********************************************************************************************/

#define TWR_DELAY          6                 /* After changing the data direction, a delay twr_delay Tcy=1.5us*/
#define SPI_TRY_COUNT      200               /* Iterate 200 times attempting to read SPI buffer. */
#define DATA_READ          1
#define DATA_WRITE         0

#define ANGLE_VALUE            0x7FFF

#define sensorX_CS_ON      switch(sensorX)\
                           {\
                            case ANGLESENSOR_01:\
                                _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */\
                                break;\
                            case ANGLESENSOR_02:\
                                _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */\
                                break;\
                            default:\
                                return;\
                            }
#define sensorX_CS_OFF      switch(sensorX)\
                            {\
                             case ANGLESENSOR_01:\
                                 _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */\
                                 break;\
                             case ANGLESENSOR_02:\
                                 _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */\
                                 break;\
                            }

/*********************************************************************************************
Global Variable definitions
*********************************************************************************************/
/* Scale and offset to compute current based on the voltage measured by ADC. */
typedef enum
{
    ANGLESENSOR_SELECTED,
    ANGLESENSOR_UNSELECTED
} ANGLESENSOR_CS_STATES;

static INT16U angle_data[2];
static SAFTY_WORD safety_data[2];
static bool flag_zero_config;


/*********************************************************************************************
Function declarations
*********************************************************************************************/
/*********************************************************************************************/

static void zero_pos_config_compute_store_nvm(ANGLESENSOR_NUM, INT16U);
static INT16U zero_pos_config_nvm_read_use(ANGLESENSOR_NUM);
INT16U flash_main_demo();
INT16U flash_main_demo_bkp();
INT16U flash_main_demo_short();
INT16U flash_main_demo_short_1byte();
void angleSens(void);
BOOL safetyword_analyze_print(SAFTY_WORD sft_word);
unsigned char CRC8(unsigned char *message, unsigned char Bytelength);

/*********************************************************************************************
Function definitions
*********************************************************************************************/
/*********************************************************************************************/
void cpu_SetAngleSensorCs(ANGLESENSOR_CS_STATES state, ANGLESENSOR_NUM sensor) 
{
    switch (sensor) 
    {
        case ANGLESENSOR_01:
            ANGLESENSOR1_SELECT = (state == ANGLESENSOR_SELECTED) ? 0 : 1;
            break;
        case ANGLESENSOR_02:
            ANGLESENSOR2_SELECT = (state == ANGLESENSOR_SELECTED) ? 0 : 1;
            break;
        default:
            /*do nothing*/
            break;
    }
    return;
}

void deactivate_AS_FUSE_CRC(ANGLESENSOR_NUM sensorX)
{
    INT16U safety_word;
    INT16U ACSTAT_reg;

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
            break;
        default:
            return;
    }
    
    spi3_exchange16bit(0x8011);
    delay(10);
    ACSTAT_reg = spi3_exchange16bit(0xFFFF);
    delay(10);
    safety_word = spi3_exchange16bit(0xFFFF);

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
            break;
    }

#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_SAFETY_WORD_ANALYZE
    {
        SAFTY_WORD sft_word;
        sft_word.safety_word = safety_word;
        
        printf("\r\ninside %s() func for %s\r\n", __func__, (sensorX == ANGLESENSOR_01)? "ANGLESENSOR_01": "ANGLESENSOR_02");
        safetyword_analyze_print(sft_word);
    }
#endif

#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_STATUS_ANALYZE
    statusreg_read_analyze_print(sensorX);
#endif
    
    printf("\r\nBefore writing ACSTAT_reg = 0x%X\r\n", ACSTAT_reg);
    
    //ACSTAT_reg &= 0xFFF7; // bit 3 is AS_FUSE
    ACSTAT_reg &= 0xFF11; // bits 7-5, 3-1 are made zero
    
    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
            break;
        default:
            return;
    }
    
    spi3_exchange16bit(0x0011);
    delay(10);
    spi3_exchange16bit(ACSTAT_reg);
    delay(10);
    safety_word = spi3_exchange16bit(0xFFFF);

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
            break;
    }

#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_SAFETY_WORD_ANALYZE
    {
        SAFTY_WORD sft_word;
        sft_word.safety_word = safety_word;
        
        printf("\r\ninside %s() func for %s\r\n", __func__, (sensorX == ANGLESENSOR_01)? "ANGLESENSOR_01": "ANGLESENSOR_02");
        safetyword_analyze_print(sft_word);
    }
#endif

#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_STATUS_ANALYZE
    statusreg_read_analyze_print(sensorX);
#endif


    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
            break;
        default:
            return;
    }
    
    spi3_exchange16bit(0x8011);
    delay(10);
    ACSTAT_reg = spi3_exchange16bit(0xFFFF);
    delay(10);
    safety_word = spi3_exchange16bit(0xFFFF);

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
            break;
    }

    printf("\r\nAfter writing ACSTAT_reg = 0x%X\r\n", ACSTAT_reg);
    
}

#if 1
void read_config_reg_08h_0Fh(ANGLESENSOR_NUM sensorX) // working as expected; 20240604
{
    INT16U safety_word;
    INT16U MOD_2_08h, MOD_3_09h, OFFX_0Ah, OFFY_0Bh;
    INT16U SYNCH_0Ch, IFAB_0Dh, MOD_4_0Eh, TCO_Y_0Fh;
#if 0
    sensorX_CS_ON

    spi3_exchange16bit(0xD081);
    delay(10);
    MOD_2_08h = spi3_exchange16bit(0xFFFF);
    delay(10);
    safety_word = spi3_exchange16bit(0xFFFF);
    
    sensorX_CS_OFF
    
    sensorX_CS_ON

    spi3_exchange16bit(0xD091);
    delay(10);
    MOD_3_09h = spi3_exchange16bit(0xFFFF);
    delay(10);
    safety_word = spi3_exchange16bit(0xFFFF);

    sensorX_CS_OFF
    
    sensorX_CS_ON

    spi3_exchange16bit(0xD0A1);
    delay(10);
    OFFX_0Ah = spi3_exchange16bit(0xFFFF);
    delay(10);
    safety_word = spi3_exchange16bit(0xFFFF);

    sensorX_CS_OFF
    
    sensorX_CS_ON

    spi3_exchange16bit(0xD0B1);
    delay(10);
    OFFY_0Bh = spi3_exchange16bit(0xFFFF);
    delay(10);
    safety_word = spi3_exchange16bit(0xFFFF);

    sensorX_CS_OFF
    
    sensorX_CS_ON


    spi3_exchange16bit(0xD0C1);
    delay(10);
    SYNCH_0Ch = spi3_exchange16bit(0xFFFF);
    delay(10);
    safety_word = spi3_exchange16bit(0xFFFF);
    
    sensorX_CS_OFF
    
    sensorX_CS_ON

    spi3_exchange16bit(0xD0D1);
    delay(10);
    IFAB_0Dh = spi3_exchange16bit(0xFFFF);
    delay(10);
    safety_word = spi3_exchange16bit(0xFFFF);

    sensorX_CS_OFF
    
    sensorX_CS_ON

    spi3_exchange16bit(0xD0E1);
    delay(10);
    MOD_4_0Eh = spi3_exchange16bit(0xFFFF);
    delay(10);
    safety_word = spi3_exchange16bit(0xFFFF);

    sensorX_CS_OFF
    
    sensorX_CS_ON

    spi3_exchange16bit(0xD0F1);
    delay(10);
    TCO_Y_0Fh = spi3_exchange16bit(0xFFFF);
    delay(10);
    safety_word = spi3_exchange16bit(0xFFFF);

    sensorX_CS_OFF
    
    printf("\r\nMOD_2_08h = 0x%04X\r\n", MOD_2_08h);
    printf("\r\nMOD_3_09h = 0x%04X\r\n", MOD_3_09h);
    printf("\r\nOFFX_0Ah  = 0x%04X\r\n", OFFX_0Ah);
    printf("\r\nOFFY_0Bh  = 0x%04X\r\n", OFFY_0Bh);
    printf("\r\nSYNCH_0Ch = 0x%04X\r\n", SYNCH_0Ch);
    printf("\r\nIFAB_0Dh  = 0x%04X\r\n", IFAB_0Dh);
    printf("\r\nMOD_4_0Eh = 0x%04X\r\n", MOD_4_0Eh);
    printf("\r\nTCO_Y_0Fh = 0x%04X\r\n", TCO_Y_0Fh);
#else
    sensorX_CS_ON

    spi3_exchange16bit(0xD088);
    delay(10);
    MOD_2_08h = spi3_exchange16bit(0xFFFF);
    delay(10);
    MOD_3_09h = spi3_exchange16bit(0xFFFF);
    delay(10);
    OFFX_0Ah = spi3_exchange16bit(0xFFFF);
    delay(10);
    OFFY_0Bh = spi3_exchange16bit(0xFFFF);
    delay(10);
    SYNCH_0Ch = spi3_exchange16bit(0xFFFF);
    delay(10);
    IFAB_0Dh = spi3_exchange16bit(0xFFFF);
    delay(10);
    MOD_4_0Eh = spi3_exchange16bit(0xFFFF);
    delay(10);
    TCO_Y_0Fh = spi3_exchange16bit(0xFFFF);
    delay(10);
    safety_word = spi3_exchange16bit(0xFFFF);

    sensorX_CS_OFF
    
    printf("\r\nMOD_2_08h = 0x%04X\r\n", MOD_2_08h);
    printf("\r\nMOD_3_09h = 0x%04X\r\n", MOD_3_09h);
    printf("\r\nOFFX_0Ah  = 0x%04X\r\n", OFFX_0Ah);
    printf("\r\nOFFY_0Bh  = 0x%04X\r\n", OFFY_0Bh);
    printf("\r\nSYNCH_0Ch = 0x%04X\r\n", SYNCH_0Ch);
    printf("\r\nIFAB_0Dh  = 0x%04X\r\n", IFAB_0Dh);
    printf("\r\nMOD_4_0Eh = 0x%04X\r\n", MOD_4_0Eh);
    printf("\r\nTCO_Y_0Fh = 0x%04X\r\n", TCO_Y_0Fh);
    
#endif
}
#endif

void write_config_reg_0Fh_LSByte(ANGLESENSOR_NUM sensorX, INT8U CRCByte)
{
    INT16U TCO_Y_0Fh;
    INT16U safety_word;

    sensorX_CS_ON
    
    spi3_exchange16bit(0xD0F1);
    delay(10);
    TCO_Y_0Fh = spi3_exchange16bit(0xFFFF);
    delay(10);
    safety_word = spi3_exchange16bit(0xFFFF);
    delay(10);
    
    sensorX_CS_OFF
            
    TCO_Y_0Fh &= 0xFF00; //clear LSByte
    TCO_Y_0Fh |= (INT16U)CRCByte;

    sensorX_CS_ON
    spi3_exchange16bit(0x50F1);
    delay(10);
    spi3_exchange16bit(TCO_Y_0Fh);
    delay(10);
    safety_word = spi3_exchange16bit(0xFFFF);
    delay(10);
    sensorX_CS_OFF
}

void read_config_reg_08h_0Fh_return_15bytes(ANGLESENSOR_NUM sensorX, INT8U *message) // working as expected; 20240604
{
    INT16U safety_word;
    INT16U MOD_2_08h, MOD_3_09h, OFFX_0Ah, OFFY_0Bh;
    INT16U SYNCH_0Ch, IFAB_0Dh, MOD_4_0Eh, TCO_Y_0Fh;
    INT16U ReceiveData[8];

    sensorX_CS_ON

    spi3_exchange16bit(0xD088);
    delay(10);
    for(int i = 0; i < 8; i++)
    {
        ReceiveData[i] = spi3_exchange16bit(0xFFFF);
        delay(10);
    }
    
    safety_word = spi3_exchange16bit(0xFFFF);
    delay(10);

    sensorX_CS_OFF
    
    for(int i = 0; i < 7; i++)
    {
        message [2*i]   = (INT8U) (ReceiveData[i] >> 8);
        message [2*i+1] = (INT8U) ReceiveData[i];
    }
    
    message [14] = (INT8U) (ReceiveData[7] >> 8);
}

void angleSens_init(void)
{
    ANGLESENSOR_NUM sensorX;
    INT8U message[15];
    
    sensorX = ANGLESENSOR_01;
    //deactivate_AS_FUSE_CRC(sensorX);
    //read_config_reg_08h_0Fh(sensorX);
    //read_config_reg_08h_0Fh_return_15bytes(sensorX, message);
    //printf("\r\nbyte1 = 0x%04X", (INT8U)CRC8(message, 15));
    
    sensorX = ANGLESENSOR_02;
    //deactivate_AS_FUSE_CRC(sensorX);
    //read_config_reg_08h_0Fh(sensorX);
    //read_config_reg_08h_0Fh_return_15bytes(sensorX, message);
    //printf("\r\nbyte2 = 0x%04X", (INT8U)CRC8(message, 15));
    //printf("\r\n");
}
    
#if 0
void CRC8_cross_check(void)
{
    unsigned char message1[] = { 0x08, 0x00,
                                 0xFF, 0xCA,
                                 0xFF, 0x90,
                                 0x0B, 0xB0,
                                 0x06, 0x50,
                                 0xE3, 0x80,
                                 0xFE, 0x01,
                                 0xF3 };
    unsigned char message2[] = { 0x08, 0x00,
                                 0x00, 0xDA,
                                 0xE5, 0x10,
                                 0xED, 0xA0,
                                 0xFB, 0x60,
                                 0x05, 0x20,
                                 0x16, 0x01,
                                 0x09 };
    
    unsigned char crc_byte1 = CRC8(message1, 15);
    unsigned char crc_byte2 = CRC8(message2, 15);
    
    printf("\r\ncrc_byte1 = 0x%X", crc_byte1); // expected val = 0x6D
    printf("\r\ncrc_byte2 = 0x%X", crc_byte2); // expected val = 0xDA
    printf("\r\n");
}
#endif

void angle_readvalue(ANGLESENSOR_NUM sensor)
{
    CMD_WORD cmd;

    cmd.command = 0;
    safety_data[sensor].safety_word  = 0;   
    cmd.RW = DATA_READ;
    cmd.Lock = 0;
    cmd.UPD  = 1; //Access to values in update buffer
    cmd.ADDR = AVAL_REG_ADDR;
    cmd.ND = 1; // angle value + safety word
    
    cpu_SetAngleSensorCs(ANGLESENSOR_SELECTED, sensor);
    
    cmd.command = 0x1234;
    (void)spi3_exchange16bit(cmd.command);
    
    angle_data[sensor] = spi3_read(); // angle data
    
    safety_data[sensor].safety_word = spi3_read(); // angle data
    
    cpu_SetAngleSensorCs(ANGLESENSOR_SELECTED, sensor);
}
//Angle Value Register bit 0-14 data, bit 15 read status
INT16U angle_getvalue(ANGLESENSOR_NUM sensor)
{
    return (angle_data[sensor] & ANGLE_VALUE);
}


/*********************************************/
/* Code from 20240326 onwards is added below */
/*********************************************/

BOOL safetyword_analyze_print(SAFTY_WORD sft_word)
{
    printf("\r\nSafety Word: 0x%X\r\n", sft_word.safety_word);
    if(sft_word.Sys_err == 0 || sft_word.Intf_err == 0 || sft_word.Validity == 0)
    {
        printf("\r\nSafety Word: has error/s");
        if(sft_word.Sys_err == 0)
            printf("\r\n\t-> System error");
        if(sft_word.Intf_err == 0)
            printf("\r\n\t-> Interface access error");
        if(sft_word.Validity == 0)
            printf("\r\n\t-> Valid angle value");
        
        printf("\r\n");
        
        return 1;
    }
    else
    {
        printf("\r\nSafety Word: OK");

        return 0;
    }
    
}

void deactivate_magnitude_check(ANGLESENSOR_NUM sensorX)
{
    INT16U ReceiveData;

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
            break;
        default:
            return;
    }
    
    spi3_exchange16bit(0x0011);
    delay(10);
    spi3_exchange16bit(0x1AFE);
    delay(10);
    ReceiveData = spi3_exchange16bit(0xFFFF);

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
            break;
    }

#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_SAFETY_WORD_ANALYZE
    {
        SAFTY_WORD sft_word;
        sft_word.safety_word = ReceiveData;
        
        printf("\r\ninside %s() func for %s\r\n", __func__, (sensorX == ANGLESENSOR_01)? "ANGLESENSOR_01": "ANGLESENSOR_02");
        safetyword_analyze_print(sft_word);
    }
#endif

#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_STATUS_ANALYZE
    statusreg_read_analyze_print(sensorX);
#endif
}

void statusreg_read_analyze_print(ANGLESENSOR_NUM sensorX)
{
    INT16U ReceiveData;
    INT16U statusreg;

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
            break;
        default:
            return;
    }
    
    spi3_exchange16bit(0x8001);
    delay(10);
    statusreg = spi3_exchange16bit(0xFFFF);
    delay(10);
    ReceiveData = spi3_exchange16bit(0xFFFF);

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
            break;
    }
    
    printf("\r\nstatusreg = 0x%X", statusreg);
    
    if(statusreg & 0x8000) // bit 15
        printf("\r\n(it is a new Status)");
    else
        printf("\r\n(it is a old Status)");
    if(statusreg & STATUS_REG_PARTIAL_MASK)
    {
        printf("\r\nStatus Reg: has error/s");
        if(statusreg & 0x1000) // bit 12
            printf("\r\n\t-> no valid GMR angle value on the interface");
        if(statusreg & 0x800) // bit 11
            printf("\r\n\t-> no valid GMR_XY values on the ADC input");
        if(statusreg & 0x400) // bit 10
            printf("\r\n\t-> CRC fail or running");
        if(statusreg & 0x200) // bit 9
            printf("\r\n\t-> Test vectors out of limit");
        
        if(statusreg & 0x80) // bit 7
            printf("\r\n\t-> GMR-magnitude out of limit");
        if(statusreg & 0x40) // bit 6
            printf("\r\n\t-> X,Y data out of limit");
        if(statusreg & 0x20) // bit 5
            printf("\r\n\t-> DSPU overflow occurred");
        if(statusreg & 0x10) // bit 4
            printf("\r\n\t-> DSPU self test not ok, or self test is running");
        if(statusreg & 0x8) // bit 3
            printf("\r\n\t-> CRC fail");
        if(statusreg & 0x4) // bit 2
            printf("\r\n\t-> VDD over voltage; VDD-off; GND-off; or V-OVG; V-OVA; V-OVD too high");
        if(statusreg & 0x2) // bit 1
            printf("\r\n\t-> watchdog counter expired (DSPU stop), AS_RST must be activated. Outputs deactivated, pull up/down active.");
        if(statusreg & 0x1) // bit 0
            printf("\r\n\t-> indication of power-up, short power-break, firmware or active reset.");
        
        printf("\r\n");
    }
    else
    {
        printf("\r\nStatus Reg: OK");
    }

#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_SAFETY_WORD_ANALYZE
    {
        SAFTY_WORD sft_word;
        sft_word.safety_word = ReceiveData;
        
        printf("\r\ninside %s() func for %s\r\n", __func__, (sensorX == ANGLESENSOR_01)? "ANGLESENSOR_01": "ANGLESENSOR_02");
        safetyword_analyze_print(sft_word);
    }
#endif
    printf("\r\n#############\r\n");
}

INT16S angle_sensor_current_angle(ANGLESENSOR_NUM sensorX)
{
    INT16U ReceiveData;
    INT16S AVAL;
    INT16S angle_degrees = 0;
    static first_time = 1;

    INT16U ReceiveData2, ReceiveData3;
    INT16S AVAL2, AVAL3;

    
    if(first_time)
    {
        zero_config_from_NVM();
        
        if(1){
            INT8U message[15];
            INT8U CRCbyte;

            read_config_reg_08h_0Fh_return_15bytes(ANGLESENSOR_01, message);
            CRCbyte = CRC8(message, 15);
            //printf("\r\nCRCbyte1 = 0x%X", CRCbyte);
            write_config_reg_0Fh_LSByte(ANGLESENSOR_01, CRCbyte);

            read_config_reg_08h_0Fh_return_15bytes(ANGLESENSOR_02, message);
            CRCbyte = CRC8(message, 15);
            //printf("\r\nCRCbyte1 = 0x%X", CRCbyte);
            //printf("\r\n");
            write_config_reg_0Fh_LSByte(ANGLESENSOR_02, CRCbyte);
            
            //read Status Register once, after CRC is written
            statusreg_read_analyze_print(ANGLESENSOR_01);
            statusreg_read_analyze_print(ANGLESENSOR_02);
        }

        for (int i = 0; i < 0; i++) {
            delay(60000);
            delay(60000);
            delay(60000);
            delay(60000);
            delay(60000);
        }
        
        first_time = 0;
    }

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
            break;
        default:
            return angle_degrees;
    }
    
    /* command word */
    //spi3_exchange16bit(0x8421);
    spi3_exchange16bit(0x8021);
    delay(10);
    /* read Angle Value */
    AVAL = spi3_exchange16bit(0xFFFF);
    delay(10);
    /* read Safety Word */
    ReceiveData = spi3_exchange16bit(0xFFFF);

    if(0)
    {
        spi3_exchange16bit(0x8021);
        delay(10);
        /* read Angle Value */
        AVAL2 = spi3_exchange16bit(0xFFFF);
        delay(10);
        /* read Safety Word */
        ReceiveData3 = spi3_exchange16bit(0xFFFF);

        spi3_exchange16bit(0x8021);
        delay(10);
        /* read Angle Value */
        AVAL3 = spi3_exchange16bit(0xFFFF);
        delay(10);
        /* read Safety Word */
        ReceiveData3 = spi3_exchange16bit(0xFFFF);
    }

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
            break;
    }

    angle_degrees = CONVERT2DEGREE(AVAL);
    if(angle_degrees < 0) angle_degrees += 360;
    
    if(0)
    {
        printf("\r\nReceiveData = 0x%X", ReceiveData);
        printf("\r\nReceiveData2 = 0x%X", ReceiveData2);
        printf("\r\nReceiveData3 = 0x%X\r\n", ReceiveData3);
    }
    
#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_SAFETY_WORD_ANALYZE
    {
        SAFTY_WORD sft_word;
        sft_word.safety_word = ReceiveData;
        
        printf("\r\ninside %s() func for %s\r\n", __func__, (sensorX == ANGLESENSOR_01)? "ANGLESENSOR_01": "ANGLESENSOR_02");
        safetyword_analyze_print(sft_word);
        //printf("\r\nCommand word: 0x8021");
        //printf("\r\nAVAL read: 0x%X", AVAL);
        //printf("\r\nReceiveData: 0x%X", ReceiveData);
        //printf("\r\n print done\r\n");
        //printf("\r\n\r\n");
    }
    
    if(0)
    {
        SAFTY_WORD sft_word;
        sft_word.safety_word = ReceiveData2;
        
        printf("\r\ninside %s() func for %s\r\n", __func__, (sensorX == ANGLESENSOR_01)? "ANGLESENSOR_01": "ANGLESENSOR_02");
        safetyword_analyze_print(sft_word);

        sft_word.safety_word = ReceiveData3;
        
        printf("\r\ninside %s() func for %s\r\n", __func__, (sensorX == ANGLESENSOR_01)? "ANGLESENSOR_01": "ANGLESENSOR_02");
        safetyword_analyze_print(sft_word);
    }
#endif

#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_STATUS_ANALYZE
    statusreg_read_analyze_print(sensorX);
#endif
    
    return angle_degrees;
}

INT16S angle_sensor_current_revolutions(ANGLESENSOR_NUM sensorX)
{
    INT16S ReceiveData;
    INT16S AREV_value;
    INT16S REVOL_value = 0;

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
            break;
        default:
            return REVOL_value;
    }
    
    /* command word */
    //spi3_exchange16bit(0x8441);
    spi3_exchange16bit(0x8041);
    delay(10);
    /* read Angle Revolution */
    AREV_value = spi3_exchange16bit(0xFFFF);
    REVOL_value = ((AREV_value & 0x1FF) << 7) >> 7;
    delay(10);
    /* read Safety Word */
    ReceiveData = spi3_exchange16bit(0xFFFF);
#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_SAFETY_WORD_ANALYZE
    {
        SAFTY_WORD sft_word;
        sft_word.safety_word = ReceiveData;
        
        printf("\r\ninside %s() func for %s\r\n", __func__, (sensorX == ANGLESENSOR_01)? "ANGLESENSOR_01": "ANGLESENSOR_02");
        safetyword_analyze_print(sft_word);
    }
#endif

#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_STATUS_ANALYZE
    statusreg_read_analyze_print(sensorX);
#endif

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
            break;
    }

    return REVOL_value;
}

/* this function is not required, since other function returns the value from which displacement can be derived */
BOOL angle_sensor_current_displacement(BOOL sensorX)
{
    INT16S REVOL_value;
    
    REVOL_value = angle_sensor_current_revolutions(sensorX);
    
    return (BOOL) (REVOL_value >> 15);
}

void write_ANGLE_BASE_value(ANGLESENSOR_NUM sensorX, INT16U data)
{
    /* step 1: Move the mechanical assembly to the desired 0�-position.           */
    /* step 2: Read ANG_BASE in the MOD_3 register (address 09H).                 */
    /* step 3: Read the content of the AVAL register (address 02H) and process it */
    /* step 4: Disable Auto-calibration in MOD_2 register (address 08H).           */
    /* step 5: write the stored value into the ANG_BASE register.                 */
    
    /* Q: ANG_DIR also has to be written? */
    
    /* "and process it" */
    /* read MOD_3 (address 09H) */
    /* extract ANG_BASE */
    /* read AVAL register (address 02H) */
    /* remove its MSB */
    /* add 0x0008 */
    /* right shift >> 3 */
    /* read ANG_DIR from MOD_2 register (address 08H) */
    /* add/subtract processes AVAL from ANG_BASE */
    
    INT16U mod2_value;
    INT16U mod3_value;
    INT16U ANG_BASE_value;
    INT16U AVAL_value;
    INT16U ANG_VAL_value;
    INT16U other_bits;
    INT16U ReceiveData;
    INT16U autocal_mode;

    
    /* READ STAGE 1*/
    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
            break;
    }
    
    spi3_exchange16bit(0xD091);
    delay(10);
    mod3_value = spi3_exchange16bit(0xFFFF);
    delay(10);
    ReceiveData = spi3_exchange16bit(0xFFFF);

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
            break;
    }
    
#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_SAFETY_WORD_ANALYZE
    {
        SAFTY_WORD sft_word;
        sft_word.safety_word = ReceiveData;
        
        printf("\r\ninside %s() func for %s\r\n", __func__, (sensorX == ANGLESENSOR_01)? "ANGLESENSOR_01": "ANGLESENSOR_02");
        safetyword_analyze_print(sft_word);
    }
#endif

#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_STATUS_ANALYZE
    statusreg_read_analyze_print(sensorX);
#endif

    other_bits = mod3_value & 0xF;
    ANG_BASE_value = data;
    
    mod3_value = (ANG_BASE_value << 4) | other_bits;

    
    /* WRITE STAGE 5*/
    autocal_mode = mod2_value & 0x3;
    if(autocal_mode) /* if autocalibration is enabled..*/
    {
        mod2_value = mod2_value & 0xFFFC;/* disable autocalibration*/

        switch(sensorX)
        {
            case ANGLESENSOR_01:
                _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
                break;
            case ANGLESENSOR_02:
                _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
                break;
        }

        /* command word */
        spi3_exchange16bit(0x5081);
        delay(10);
        /* read MOD_2 Value */
        spi3_exchange16bit(mod2_value);
        delay(10);
        /* read Safety Word */
        ReceiveData = spi3_exchange16bit(0xFFFF);

        switch(sensorX)
        {
            case ANGLESENSOR_01:
                _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
                break;
            case ANGLESENSOR_02:
                _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
                break;
        }
    }

    /* WRITE STAGE 6*/
    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
            break;
        default:
            return;
    }
    
    spi3_exchange16bit(0x5091);
    delay(10);
    spi3_exchange16bit(mod3_value);
    delay(10);
    ReceiveData = spi3_exchange16bit(0xFFFF);

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
            break;
    }
    
#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_SAFETY_WORD_ANALYZE
    {
        SAFTY_WORD sft_word;
        sft_word.safety_word = ReceiveData;
        
        printf("\r\ninside %s() func for %s\r\n", __func__, (sensorX == ANGLESENSOR_01)? "ANGLESENSOR_01": "ANGLESENSOR_02");
        safetyword_analyze_print(sft_word);
    }
#endif

#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_STATUS_ANALYZE
    statusreg_read_analyze_print(sensorX);
#endif

    /* WRITE STAGE 7*/
    if(autocal_mode) /* if autocalibration was enabled..*/
    {
        mod2_value = mod2_value | autocal_mode; /* restore autocalibration mode */

        switch(sensorX)
        {
            case ANGLESENSOR_01:
                _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
                break;
            case ANGLESENSOR_02:
                _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
                break;
        }

        /* command word */
        spi3_exchange16bit(0x5081);
        delay(10);
        /* read MOD_2 Value */
        spi3_exchange16bit(mod2_value);
        delay(10);
        /* read Safety Word */
        ReceiveData = spi3_exchange16bit(0xFFFF);

        switch(sensorX)
        {
            case ANGLESENSOR_01:
                _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
                break;
            case ANGLESENSOR_02:
                _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
                break;
        }
    }
}

INT16U read_ANGLE_BASE_value(ANGLESENSOR_NUM sensorX)
{
    /* step 1: Move the mechanical assembly to the desired 0�-position.           */
    /* step 2: Read ANG_BASE in the MOD_3 register (address 09H).                 */
    /* step 3: Read the content of the AVAL register (address 02H) and process it */
    /* step 4: Disable Auto-calibration in MOD_2 register (address 08H).           */
    /* step 5: write the stored value into the ANG_BASE register.                 */
    
    /* Q: ANG_DIR also has to be written? */
    
    /* "and process it" */
    /* read MOD_3 (address 09H) */
    /* extract ANG_BASE */
    /* read AVAL register (address 02H) */
    /* remove its MSB */
    /* add 0x0008 */
    /* right shift >> 3 */
    /* read ANG_DIR from MOD_2 register (address 08H) */
    /* add/subtract processes AVAL from ANG_BASE */
    
    INT16U mod2_value;
    INT16U mod3_value;
    INT16U ANG_BASE_value;
    INT16U AVAL_value;
    INT16U ANG_VAL_value;
    INT16U other_bits;
    INT16U ReceiveData;
    INT16U autocal_mode;

    
    /* READ STAGE 1*/
    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
            break;
    }
    
    spi3_exchange16bit(0xD091);
    delay(10);
    mod3_value = spi3_exchange16bit(0xFFFF);
    delay(10);
    ReceiveData = spi3_exchange16bit(0xFFFF);

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
            break;
    }
    
#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_SAFETY_WORD_ANALYZE
    {
        SAFTY_WORD sft_word;
        sft_word.safety_word = ReceiveData;
        
        printf("\r\ninside %s() func for %s\r\n", __func__, (sensorX == ANGLESENSOR_01)? "ANGLESENSOR_01": "ANGLESENSOR_02");
        safetyword_analyze_print(sft_word);
    }
#endif

#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_STATUS_ANALYZE
    statusreg_read_analyze_print(sensorX);
#endif

    other_bits = mod3_value & 0xF;
    ANG_BASE_value = mod3_value >> 4;
    
    /* READ STAGE 2*/
    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
            break;
    }
    
    /* command word */
    spi3_exchange16bit(0x8021);
    delay(10);
    /* read Angle Value */
    AVAL_value = spi3_exchange16bit(0xFFFF);
    delay(10);
    /* read Safety Word */
    ReceiveData = spi3_exchange16bit(0xFFFF);

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
            break;
    }
    
    ANG_VAL_value = ((AVAL_value << 1) >> 1);
    ANG_VAL_value = ANG_VAL_value + 0x8; /*refer step 3 under 6.1.4 of Infineon-Angle_Sensor_TLE5012B-UM-v01_02-en-UM-v01_02-EN.pdf*/
    ANG_VAL_value = ANG_VAL_value >> 3;/*refer same step 3 as mentioned above */
    

    /* READ STAGE 3*/
    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
            break;
    }
    
    /* command word */
    spi3_exchange16bit(0xD081);
    delay(10);
    /* read MOD_2 Value */
    mod2_value = spi3_exchange16bit(0xFFFF);
    delay(10);
    /* read Safety Word */
    ReceiveData = spi3_exchange16bit(0xFFFF);

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
            break;
    }
    
    if(mod2_value & 0x8) /* ANG_DIR == 1 */
    {
        ANG_BASE_value = ANG_BASE_value + ANG_VAL_value; 
    }
    else
    {
        ANG_BASE_value = ANG_BASE_value - ANG_VAL_value;
    }
    
    return ANG_BASE_value;
}

void zero_position_configuration(ANGLESENSOR_NUM sensorX)
{
    /* step 1: Move the mechanical assembly to the desired 0�-position.           */
    /* step 2: Read ANG_BASE in the MOD_3 register (address 09H).                 */
    /* step 3: Read the content of the AVAL register (address 02H) and process it */
    /* step 4: Disable Auto-calibration in MOD_2 register (address 08H).           */
    /* step 5: write the stored value into the ANG_BASE register.                 */
    
    /* Q: ANG_DIR also has to be written? */
    
    /* "and process it" */
    /* read MOD_3 (address 09H) */
    /* extract ANG_BASE */
    /* read AVAL register (address 02H) */
    /* remove its MSB */
    /* add 0x0008 */
    /* right shift >> 3 */
    /* read ANG_DIR from MOD_2 register (address 08H) */
    /* add/subtract processes AVAL from ANG_BASE */
    
    INT16U mod2_value;
    INT16U mod3_value;
    INT16U ANG_BASE_value;
    INT16U AVAL_value;
    INT16U ANG_VAL_value;
    INT16U other_bits;
    INT16U ReceiveData;
    INT16U autocal_mode;

    
    /* READ STAGE 1*/
    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
            break;
    }
    
    spi3_exchange16bit(0xD091);
    delay(10);
    mod3_value = spi3_exchange16bit(0xFFFF);
    delay(10);
    ReceiveData = spi3_exchange16bit(0xFFFF);

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
            break;
    }
    
#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_SAFETY_WORD_ANALYZE
    {
        SAFTY_WORD sft_word;
        sft_word.safety_word = ReceiveData;
        
        printf("\r\ninside %s() func for %s\r\n", __func__, (sensorX == ANGLESENSOR_01)? "ANGLESENSOR_01": "ANGLESENSOR_02");
        safetyword_analyze_print(sft_word);
    }
#endif

#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_STATUS_ANALYZE
    statusreg_read_analyze_print(sensorX);
#endif

    other_bits = mod3_value & 0xF;
    ANG_BASE_value = mod3_value >> 4;
    
    /* READ STAGE 2*/
    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
            break;
    }
    
    /* command word */
    spi3_exchange16bit(0x8021);
    delay(10);
    /* read Angle Value */
    AVAL_value = spi3_exchange16bit(0xFFFF);
    delay(10);
    /* read Safety Word */
    ReceiveData = spi3_exchange16bit(0xFFFF);

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
            break;
    }
    
    ANG_VAL_value = ((AVAL_value << 1) >> 1);
    ANG_VAL_value = ANG_VAL_value + 0x8; /*refer step 3 under 6.1.4 of Infineon-Angle_Sensor_TLE5012B-UM-v01_02-en-UM-v01_02-EN.pdf*/
    ANG_VAL_value = ANG_VAL_value >> 3;/*refer same step 3 as mentioned above */
    

    /* READ STAGE 3*/
    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
            break;
    }
    
    /* command word */
    spi3_exchange16bit(0xD081);
    delay(10);
    /* read MOD_2 Value */
    mod2_value = spi3_exchange16bit(0xFFFF);
    delay(10);
    /* read Safety Word */
    ReceiveData = spi3_exchange16bit(0xFFFF);

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
            break;
    }
    
    if(mod2_value & 0x8) /* ANG_DIR == 1 */
    {
        ANG_BASE_value = ANG_BASE_value + ANG_VAL_value; 
    }
    else
    {
        ANG_BASE_value = ANG_BASE_value - ANG_VAL_value;
    }
    
    mod3_value = (ANG_BASE_value << 4) | other_bits;

#if (0 && ZERO_POS_CONFIG_COMPUTE_STORE_NVM)
    {
        Portassign();
        CE_High();
        WP_High();
        init();
    }
    {
        SPI_WREN();
        SPI_Write_Byte(0x001122, mod3_value);
        SPI_Wait_Busy();
    }
#else
    //zero_pos_config_compute_store_nvm(sensorX, ANG_BASE_value);
//#endif
    
//#if (1 || ZERO_POS_CONFIG_NVM_READ_USE)
    //zero_pos_config_nvm_read_use(sensorX);
    //flash_main_demo();
    //flash_main_demo_short();
    //flash_main_demo_bkp();
    //flash_main_demo_short_1byte();
#endif
    
    /* WRITE STAGE 5*/
    autocal_mode = mod2_value & 0x3;
    if(autocal_mode) /* if autocalibration is enabled..*/
    {
        mod2_value = mod2_value & 0xFFFC;/* disable autocalibration*/

        switch(sensorX)
        {
            case ANGLESENSOR_01:
                _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
                break;
            case ANGLESENSOR_02:
                _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
                break;
        }

        /* command word */
        spi3_exchange16bit(0x5081);
        delay(10);
        /* read MOD_2 Value */
        spi3_exchange16bit(mod2_value);
        delay(10);
        /* read Safety Word */
        ReceiveData = spi3_exchange16bit(0xFFFF);

        switch(sensorX)
        {
            case ANGLESENSOR_01:
                _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
                break;
            case ANGLESENSOR_02:
                _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
                break;
        }
    }

    /* WRITE STAGE 6*/
    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
            break;
        default:
            return;
    }
    
    spi3_exchange16bit(0x5091);
    delay(10);
    spi3_exchange16bit(mod3_value);
    delay(10);
    ReceiveData = spi3_exchange16bit(0xFFFF);

    switch(sensorX)
    {
        case ANGLESENSOR_01:
            _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
            break;
        case ANGLESENSOR_02:
            _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
            break;
    }
    
#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_SAFETY_WORD_ANALYZE
    {
        SAFTY_WORD sft_word;
        sft_word.safety_word = ReceiveData;
        
        printf("\r\ninside %s() func for %s\r\n", __func__, (sensorX == ANGLESENSOR_01)? "ANGLESENSOR_01": "ANGLESENSOR_02");
        safetyword_analyze_print(sft_word);
    }
#endif

#if ANGLE_SENSOR_ANALYZE || ANGLE_SENSOR_STATUS_ANALYZE
    statusreg_read_analyze_print(sensorX);
#endif

    /* WRITE STAGE 7*/
    if(autocal_mode) /* if autocalibration was enabled..*/
    {
        mod2_value = mod2_value | autocal_mode; /* restore autocalibration mode */

        switch(sensorX)
        {
            case ANGLESENSOR_01:
                _LATD15 = PORT_OUT_LOW; /* U2 chip on CCB */
                break;
            case ANGLESENSOR_02:
                _LATB0 = PORT_OUT_LOW; /* U3 chip on CCB */
                break;
        }

        /* command word */
        spi3_exchange16bit(0x5081);
        delay(10);
        /* read MOD_2 Value */
        spi3_exchange16bit(mod2_value);
        delay(10);
        /* read Safety Word */
        ReceiveData = spi3_exchange16bit(0xFFFF);

        switch(sensorX)
        {
            case ANGLESENSOR_01:
                _LATD15 = PORT_OUT_HIGH; /* U2 chip on CCB */
                break;
            case ANGLESENSOR_02:
                _LATB0 = PORT_OUT_HIGH; /* U3 chip on CCB */
                break;
        }
    }
}

static void zero_pos_config_compute_store_nvm(ANGLESENSOR_NUM sensorX, INT16U ANG_BASE_value)
{
    INT16U ANG_BASE_value_dup;
    INT8U  ANG_BASE_value_dup_L;
    INT8U  status_reg = 1;
    INT8U  read_byte[10];

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x06); //write enable
    _LATD8 = TRUE;

    _LATD8 = FALSE;
    SPI2_ByteExchange(0xC7); //Chip Erase
    _LATD8 = TRUE;

    while ((status_reg & 1 == 1) /*BUSY*/ || (status_reg & 0b10 == 0)/*WREN*/) {
        _LATD8 = FALSE;
        SPI2_ByteExchange(0x05); //read status reg
        status_reg = SPI2_ByteExchange(0xFF); // dummy command for status reg read
        _LATD8 = TRUE;
        delay(10);
        
        { /* junk statements; only for putting breakpoints */ 
            int i = 0;
            int j = 0;
            int status = 1; //1 means memory/code works and 0 means fault has occured.
            int check = 0; //keeps track of code progress.
            int tempcheck = 1;
            int highest_address = 0xfffff; //8Mb   //highest_address=256;
        }
        
    }

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x06); //write enable
    _LATD8 = TRUE;

    {
        INT32U NVM_addr;

        switch(sensorX)
        {
            case ANGLESENSOR_01:
                //NVM_addr = 0x800;
                NVM_addr = 0x10000;
                break;
            case ANGLESENSOR_02:
                //NVM_addr = 0x802;
                NVM_addr = 0x10002;
                break;
        }


        _LATD8 = FALSE; /* enable device */
        SPI2_ByteExchange(0x02); /* send Byte Program command */
        SPI2_ByteExchange(((NVM_addr & 0xFFFFFF) >> 16)); /* send 3 address bytes */
        SPI2_ByteExchange(((NVM_addr & 0xFFFF) >> 8));
        SPI2_ByteExchange(NVM_addr & 0xFF);
        SPI2_ByteExchange(ANG_BASE_value >> 8);
        SPI2_ByteExchange(ANG_BASE_value & 0xFF);
        _LATD8 = TRUE;
        
        delay(30000);
    }
}

static INT16U zero_pos_config_nvm_read_use(ANGLESENSOR_NUM sensorX) {
    INT16U ANG_BASE_value_dup;
    INT8U  ANG_BASE_value_dup_L;
    INT8U  status_reg = 1;
    INT8U  read_byte[10];

    INT32U NVM_addr;

    switch (sensorX) {
        case ANGLESENSOR_01:
            //NVM_addr = 0x800;
            NVM_addr = 0x10000;
            break;
        case ANGLESENSOR_02:
            //NVM_addr = 0x802;
            NVM_addr = 0x10002;
            break;
    }

    while ((status_reg & 1 == 1) /*BUSY*/ || (status_reg & 0b10 == 0)/*WREN*/) {
        _LATD8 = FALSE;
        SPI2_ByteExchange(0x05); //read status reg
        status_reg = SPI2_ByteExchange(0xFF); // dummy command for status reg read
        _LATD8 = TRUE;
        delay(10);
    }

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x06); //write enable
    _LATD8 = TRUE;

    _LATD8 = FALSE; /* enable device */
#if 0
    SPI2_ByteExchange(0x0B); /* read command */
    SPI2_ByteExchange((NVM_addr & 0xFFFFFF) >> 16); /* send 3 address bytes */
    SPI2_ByteExchange((NVM_addr & 0xFFFF) >> 8);
    SPI2_ByteExchange(NVM_addr & 0xFF);
    SPI2_ByteExchange(0xFF); /*dummy byte*/

    ANG_BASE_value_dup = (INT16U) SPI2_ByteExchange(0xFF); /* MSByte */
    ANG_BASE_value_dup_L = SPI2_ByteExchange(0xFF); /* LSByte */
#else
    SPI2_ByteExchange(0x03); /* read command */
    SPI2_ByteExchange((NVM_addr & 0xFFFFFF) >> 16); /* send 3 address bytes */
    SPI2_ByteExchange((NVM_addr & 0xFFFF) >> 8);
    SPI2_ByteExchange(NVM_addr & 0xFF);

    ANG_BASE_value_dup = (INT16U) SPI2_ByteExchange(0xFF); /* MSByte */
    ANG_BASE_value_dup_L = SPI2_ByteExchange(0xFF); /* LSByte */

    //read_byte[0] = SPI2_ByteExchange(0xFF);
    //read_byte[1] = SPI2_ByteExchange(0xFF);
    //read_byte[2] = SPI2_ByteExchange(0xFF);
    //read_byte[3] = SPI2_ByteExchange(0xFF);
    //read_byte[4] = SPI2_ByteExchange(0xFF);
    //read_byte[5] = SPI2_ByteExchange(0xFF);
    //read_byte[6] = SPI2_ByteExchange(0xFF);
    //read_byte[7] = SPI2_ByteExchange(0xFF);
    //read_byte[8] = SPI2_ByteExchange(0xFF);
    //read_byte[9] = SPI2_ByteExchange(0xFF);
#endif
    _LATD8 = TRUE; /* disable device */

    ANG_BASE_value_dup = (ANG_BASE_value_dup << 8) | ANG_BASE_value_dup_L;

    delay(100);

    //NVM_addr = 0x802;
    NVM_addr = 0x10002;
    
    return ANG_BASE_value_dup;
}

typedef enum 
{
    TEST_FAIL = 0,
    TEST_PASS
}testResult;

extern unsigned int data_256[256];

INT16U flash_main_demo() {
    INT16U testRslt = TEST_FAIL;
    INT8U status_reg = 0x1; // initial value is fake busy

    unsigned long i, j, highest_address, tempdatalong; //m,k
    int check, tempcheck, status;
    int tempdata;
    unsigned char Read_Stat_Reg; //devicedata
    unsigned int loop_var;

    cpu_set_led_state( LED_STATE_RED );
    
    i = 0;
    j = 0;
    status = 1; //1 means memory/code works and 0 means fault has occured.
    check = 0; //keeps track of code progress.
    tempcheck = 1;
    highest_address = 0xfffff; //8Mb   //highest_address=256;
    
/**/
    _LATD8 = TRUE;
    _LATB8 = TRUE;

/**/    

    /************* Page program whole chip using SPI protocol and verify its OK. *********/

    i = 0;
    while (i <= 255) {
        data_256[i] = i; // filling data in buffer
        i++;
    }

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x06); //write enable
    _LATD8 = TRUE;

    _LATD8 = FALSE;
    SPI2_ByteExchange(0xC7); //Chip Erase
    _LATD8 = TRUE;

    while ((status_reg & 1 == 1) /*BUSY*/ || (status_reg & 0b10 == 0)/*WREN*/) {
        _LATD8 = FALSE;
        SPI2_ByteExchange(0x05); //read status reg
        status_reg = SPI2_ByteExchange(0xFF); // dummy command for status reg read
        _LATD8 = TRUE;
        delay(10);
        
        { /* junk statements; only for putting breakpoints */ 
            i = 0;
            j = 0;
            status = 1; //1 means memory/code works and 0 means fault has occured.
            check = 0; //keeps track of code progress.
            tempcheck = 1;
            highest_address = 0xfffff; //8Mb   //highest_address=256;
        }

    }

    i = 0;

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x06); //write enable
    _LATD8 = TRUE;

    //while(i < highest_address)
    {
        _LATD8 = FALSE;
        SPI2_ByteExchange(0x06); //write enable
        _LATD8 = TRUE;

        {
            unsigned int k;
            k = 0;

            _LATD8 = FALSE; /* enable device */
            SPI2_ByteExchange(0x02); /* send Byte Program command */
            SPI2_ByteExchange(((i & 0xFFFFFF) >> 16)); /* send 3 address bytes */
            SPI2_ByteExchange(((i & 0xFFFF) >> 8));
            SPI2_ByteExchange(i & 0xFF);
            for (k = 0; k < 256; k++) {
                SPI2_ByteExchange(data_256[k]); /* send byte to be programmed */
            }
            _LATD8 = TRUE; /* disable device */
        }

        while ((status_reg & 1 == 1) /*BUSY*/ || (status_reg & 0b10 == 0)/*WREN*/) {
            _LATD8 = FALSE;
            SPI2_ByteExchange(0x05); //read status reg
            status_reg = SPI2_ByteExchange(0xFF); // dummy command for status reg read
            _LATD8 = TRUE;
            delay(10);
        }

        i = i + 256;
    }

    delay(50000);

    i = 0;
    while (i <= 255) {
        data_256[i] = 255 - i; // filling data in buffer
        i++;
    }

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x06); //write enable
    _LATD8 = TRUE;

    j = 0;
    //while(j < highest_address)
    {
        {
            unsigned long k = 0;
            _LATD8 = FALSE; /* enable device */
            SPI2_ByteExchange(0x0B); /* read command */
            SPI2_ByteExchange(((j & 0xFFFFFF) >> 16)); /* send 3 address bytes */
            SPI2_ByteExchange(((j & 0xFFFF) >> 8));
            SPI2_ByteExchange(j & 0xFF);
            SPI2_ByteExchange(0xFF); /*dummy byte*/

            for (k = 0; k < 256; k++) /* read until no_bytes is reached */ {
                data_256[k] = SPI2_ByteExchange(0xFF);
            }
            _LATD8 = TRUE; /* disable device */
        }

        for (loop_var = 0; loop_var < 256; loop_var++) {
            if (data_256[loop_var] == loop_var) {
                tempcheck &= 1;
            } else {
                tempcheck = 0;
            }
        }
        j = j + 256;
    }

    if ((tempcheck == 1)&&(status == 1)) {
        check = (check + 1);
        status = status & 1;
        printf("\r\n !!!! Page read and write is Pass !!!! \r\n");
        testRslt = TEST_PASS;
        
        cpu_set_led_state( LED_STATE_GREEN );
    } else {
        status = 0;
        printf("\r\n !!!! Page read and write is Failed !!!! \r\n");
        testRslt = TEST_FAIL;
    }

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x66); //ResetEn
    _LATD8 = TRUE;

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x99); //Reset
    _LATD8 = TRUE;

    /***************** End of checking *****************/
    return testRslt;
}

INT16U flash_main_demo_short_1byte() {
    INT16U testRslt = TEST_FAIL;
    INT8U status_reg = 0x1; // initial value is fake busy

    unsigned long i, j, highest_address, tempdatalong; //m,k
    int check, tempcheck, status;
    int tempdata;
    unsigned char Read_Stat_Reg; //devicedata
    unsigned int loop_var;

    cpu_set_led_state( LED_STATE_RED );
    
    i = 0;
    j = 0;
    status = 1; //1 means memory/code works and 0 means fault has occured.
    check = 0; //keeps track of code progress.
    tempcheck = 1;
    highest_address = 0xfffff; //8Mb   //highest_address=256;
    
/**/
    _LATD8 = TRUE;
    _LATB8 = TRUE;

/**/    

    /************* Page program whole chip using SPI protocol and verify its OK. *********/

    i = 0;
    while (i <= 255) {
        data_256[i] = i; // filling data in buffer
        i++;
    }

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x06); //write enable
    _LATD8 = TRUE;

    _LATD8 = FALSE;
    SPI2_ByteExchange(0xC7); //Chip Erase
    _LATD8 = TRUE;

    while ((status_reg & 1 == 1) /*BUSY*/ || (status_reg & 0b10 == 0)/*WREN*/) {
        _LATD8 = FALSE;
        SPI2_ByteExchange(0x05); //read status reg
        status_reg = SPI2_ByteExchange(0xFF); // dummy command for status reg read
        _LATD8 = TRUE;
        delay(10);
        
        { /* junk statements; only for putting breakpoints */ 
            i = 0;
            j = 0;
            status = 1; //1 means memory/code works and 0 means fault has occured.
            check = 0; //keeps track of code progress.
            tempcheck = 1;
            highest_address = 0xfffff; //8Mb   //highest_address=256;
        }

    }

    i = 0;

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x06); //write enable
    _LATD8 = TRUE;

    //while(i < highest_address)
    {
        _LATD8 = FALSE;
        SPI2_ByteExchange(0x06); //write enable
        _LATD8 = TRUE;

        {
            unsigned int k;
            k = 0;

#if 0
            _LATD8 = FALSE; /* enable device */
            SPI2_ByteExchange(0x02); /* send Byte Program command */
            SPI2_ByteExchange(((i & 0xFFFFFF) >> 16)); /* send 3 address bytes */
            SPI2_ByteExchange(((i & 0xFFFF) >> 8));
            SPI2_ByteExchange(i & 0xFF);
            for (k = 0; k < 256; k++) {
                SPI2_ByteExchange(data_256[k]); /* send byte to be programmed */
            }
            _LATD8 = TRUE; /* disable device */
#else
            _LATD8 = FALSE; /* enable device */
            SPI2_ByteExchange(0x02); /* send Byte Program command */
            SPI2_ByteExchange(((0x400 & 0xFFFFFF) >> 16)); /* send 3 address bytes */
            SPI2_ByteExchange(((0x400 & 0xFFFF) >> 8));
            SPI2_ByteExchange(0x400 & 0xFF);
            SPI2_ByteExchange(0xB9); /* send byte to be programmed */
            _LATD8 = TRUE; /* disable device */
#endif
        }

        while ((status_reg & 1 == 1) /*BUSY*/ || (status_reg & 0b10 == 0)/*WREN*/) {
            _LATD8 = FALSE;
            SPI2_ByteExchange(0x05); //read status reg
            status_reg = SPI2_ByteExchange(0xFF); // dummy command for status reg read
            _LATD8 = TRUE;
            delay(10);
        }

        i = i + 256;
    }

    delay(50000);

    i = 0;
    while (i <= 255) {
        data_256[i] = 255 - i; // filling data in buffer
        i++;
    }

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x06); //write enable
    _LATD8 = TRUE;

    j = 0;
    //while(j < highest_address)
    {
        {
            unsigned long k = 0;
            _LATD8 = FALSE; /* enable device */
            SPI2_ByteExchange(0x0B); /* read command */
            SPI2_ByteExchange(((j & 0xFFFFFF) >> 16)); /* send 3 address bytes */
            SPI2_ByteExchange(((j & 0xFFFF) >> 8));
            SPI2_ByteExchange(j & 0xFF);
            SPI2_ByteExchange(0xFF); /*dummy byte*/

            for (k = 0; k < 256; k++) /* read until no_bytes is reached */ {
                data_256[k] = SPI2_ByteExchange(0xFF);
            }
            _LATD8 = TRUE; /* disable device */
        }

        for (loop_var = 0; loop_var < 256; loop_var++) {
            if (data_256[loop_var] == loop_var) {
                tempcheck &= 1;
            } else {
                tempcheck = 0;
            }
        }
        j = j + 256;
    }

    if ((tempcheck == 1)&&(status == 1)) {
        check = (check + 1);
        status = status & 1;
        printf("\r\n !!!! Page read and write is Pass !!!! \r\n");
        testRslt = TEST_PASS;
        
        cpu_set_led_state( LED_STATE_GREEN );
    } else {
        status = 0;
        printf("\r\n !!!! Page read and write is Failed !!!! \r\n");
        testRslt = TEST_FAIL;
    }

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x66); //ResetEn
    _LATD8 = TRUE;

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x99); //Reset
    _LATD8 = TRUE;

    /***************** End of checking *****************/
    return testRslt;
}


INT16U flash_main_demo_bkp() {
    INT16U testRslt = TEST_FAIL;
    INT8U status_reg = 0x1; // initial value is fake busy
    INT8U config_reg = 0x1; // initial random value

    unsigned long i, j, highest_address, tempdatalong; //m,k
    int check, tempcheck, status;
    int tempdata;
    unsigned char Read_Stat_Reg; //devicedata
    unsigned int loop_var;

    cpu_set_led_state( LED_STATE_RED );
    
    i = 0;
    j = 0;
    status = 1; //1 means memory/code works and 0 means fault has occured.
    check = 0; //keeps track of code progress.
    tempcheck = 1;
    highest_address = 0xfffff; //8Mb   //highest_address=256;
    
    
    /**/
    _LATD8 = FALSE;
    SPI2_ByteExchange(0x05); //read status reg
    status_reg = SPI2_ByteExchange(0xFF); // dummy command for status reg read
    _LATD8 = TRUE;

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x35); //read status reg
    config_reg = SPI2_ByteExchange(0xFF); // dummy command for config reg read
    _LATD8 = TRUE;
    /**/

    /************* Page program whole chip using SPI protocol and verify its OK. *********/

    i = 0;
    while (i <= 255) {
        data_256[i] = i; // filling data in buffer
        i++;
    }
    
    data_256[0] = 0xB9;

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x06); //write enable
    _LATD8 = TRUE;

    _LATD8 = FALSE;
    SPI2_ByteExchange(0xC7); //Chip Erase
    _LATD8 = TRUE;

    while ((status_reg & 1 == 1) /*BUSY*/ || (status_reg & 0b10 == 0)/*WREN*/) {
        _LATD8 = FALSE;
        SPI2_ByteExchange(0x05); //read status reg
        status_reg = SPI2_ByteExchange(0xFF); // dummy command for status reg read
        _LATD8 = TRUE;
        delay(10);
        
        { /* junk statements; only for putting breakpoints */ 
            i = 0;
            j = 0;
            status = 1; //1 means memory/code works and 0 means fault has occured.
            check = 0; //keeps track of code progress.
            tempcheck = 1;
            highest_address = 0xfffff; //8Mb   //highest_address=256;
        }

    }

    /**/
    _LATD8 = FALSE;
    SPI2_ByteExchange(0x35); //read status reg
    config_reg = SPI2_ByteExchange(0xFF); // dummy command for config reg read
    _LATD8 = TRUE;
    /**/

    i = 0;

#if 0
    _LATD8 = FALSE;
    SPI2_ByteExchange(0x06); //write enable
    _LATD8 = TRUE;
#endif

    //while(i < highest_address)
    {
        _LATD8 = FALSE;
        SPI2_ByteExchange(0x06); //write enable
        _LATD8 = TRUE;

        {
            unsigned int k;
            k = 0;

            _LATD8 = FALSE; /* enable device */
            SPI2_ByteExchange(0x02); /* send Byte Program command */
            SPI2_ByteExchange(((i & 0xFFFFFF) >> 16)); /* send 3 address bytes */
            SPI2_ByteExchange(((i & 0xFFFF) >> 8));
            SPI2_ByteExchange(i & 0xFF);
            for (k = 0; k < 256; k++) {
                SPI2_ByteExchange(data_256[k]); /* send byte to be programmed */
            }
            _LATD8 = TRUE; /* disable device */
        }

        while ((status_reg & 1 == 1) /*BUSY*/ || (status_reg & 0b10 == 0)/*WREN*/) {
            _LATD8 = FALSE;
            SPI2_ByteExchange(0x05); //read status reg
            status_reg = SPI2_ByteExchange(0xFF); // dummy command for status reg read
            _LATD8 = TRUE;
            delay(10);
        }

    /**/
    _LATD8 = FALSE;
    SPI2_ByteExchange(0x35); //read status reg
    config_reg = SPI2_ByteExchange(0xFF); // dummy command for config reg read
    _LATD8 = TRUE;
    /**/

        i = i + 256;
    }

    delay(50000);

    i = 0;
    while (i <= 255) {
        data_256[i] = 255 - i; // filling data in buffer
        i++;
    }

    //_LATD8 = FALSE; // check if this is the culprit
    //SPI2_ByteExchange(0x06); //write enable // check if this is the culprit
    //_LATD8 = TRUE; // check if this is the culprit

    j = 0;
    //while(j < highest_address)
    {
        {
            unsigned long k = 0;
            _LATD8 = FALSE; /* enable device */
            SPI2_ByteExchange(0x0B); /* read command */
            SPI2_ByteExchange(((j & 0xFFFFFF) >> 16)); /* send 3 address bytes */
            SPI2_ByteExchange(((j & 0xFFFF) >> 8));
            SPI2_ByteExchange(j & 0xFF);
            SPI2_ByteExchange(0xFF); /*dummy byte*/

            for (k = 0; k < 256; k++) /* read until no_bytes is reached */ {
                data_256[k] = SPI2_ByteExchange(0xFF);
            }
            _LATD8 = TRUE; /* disable device */
        }

        for (loop_var = 0; loop_var < 256; loop_var++) {
            if (data_256[loop_var] == loop_var) {
                tempcheck &= 1;
            } else {
                tempcheck = 0;
            }
        }

    /**/
    _LATD8 = FALSE;
    SPI2_ByteExchange(0x05); //read status reg
    status_reg = SPI2_ByteExchange(0xFF); // dummy command for status reg read
    _LATD8 = TRUE;

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x35); //read status reg
    config_reg = SPI2_ByteExchange(0xFF); // dummy command for config reg read
    _LATD8 = TRUE;
    /**/


        j = j + 256;
    }

    if ((tempcheck == 1)&&(status == 1)) {
        check = (check + 1);
        status = status & 1;
        printf("\r\n !!!! Page read and write is Pass !!!! \r\n");
        testRslt = TEST_PASS;
        
        cpu_set_led_state( LED_STATE_GREEN );
    } else {
        status = 0;
        printf("\r\n !!!! Page read and write is Failed !!!! \r\n");
        testRslt = TEST_FAIL;
    }

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x66); //ResetEn
    _LATD8 = TRUE;

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x99); //Reset
    _LATD8 = TRUE;

    /***************** End of checking *****************/
    return testRslt;
}

INT16U flash_main_demo_short() {
    INT16U testRslt = TEST_FAIL;
    INT8U status_reg = 0x1; // initial value is fake busy

    unsigned long i, j, highest_address, tempdatalong; //m,k
    int check, tempcheck, status;
    int tempdata;
    unsigned char Read_Stat_Reg; //devicedata
    unsigned int loop_var;

    cpu_set_led_state( LED_STATE_RED );
    
    i = 0;
    j = 0;
    status = 1; //1 means memory/code works and 0 means fault has occured.
    check = 0; //keeps track of code progress.
    tempcheck = 1;
    highest_address = 0xfffff; //8Mb   //highest_address=256;

    /************* Page program whole chip using SPI protocol and verify its OK. *********/

    i = 0;
    while (i <= 255) {
        data_256[i] = i; // filling data in buffer
        i++;
    }
    
    data_256[0] = 0xB9;
    data_256[1] = 0xAA;
    data_256[2] = 0x12;
    data_256[3] = 0x45;

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x06); //write enable
    _LATD8 = TRUE;

    _LATD8 = FALSE;
    SPI2_ByteExchange(0xC7); //Chip Erase
    _LATD8 = TRUE;

    while ((status_reg & 1 == 1) /*BUSY*/ || (status_reg & 0b10 == 0)/*WREN*/) {
        _LATD8 = FALSE;
        SPI2_ByteExchange(0x05); //read status reg
        status_reg = SPI2_ByteExchange(0xFF); // dummy command for status reg read
        _LATD8 = TRUE;
        delay(10);
        
        { /* junk statements; only for putting breakpoints */ 
            i = 0;
            j = 0;
            status = 1; //1 means memory/code works and 0 means fault has occured.
            check = 0; //keeps track of code progress.
            tempcheck = 1;
            highest_address = 0xfffff; //8Mb   //highest_address=256;
        }

    }

    /*#*/
    _LATD8 = FALSE;
    SPI2_ByteExchange(0x06); //write enable
    _LATD8 = TRUE;

    j = 0;

    {
        unsigned long k = 0;
        _LATD8 = FALSE; /* enable device */
        SPI2_ByteExchange(0x0B); /* read command */
        SPI2_ByteExchange(((j & 0xFFFFFF) >> 16)); /* send 3 address bytes */
        SPI2_ByteExchange(((j & 0xFFFF) >> 8));
        SPI2_ByteExchange(j & 0xFF);
        SPI2_ByteExchange(0xFF); /*dummy byte*/

        for (k = 0; k < 256; k++) /* read until no_bytes is reached */ {
            data_256[k] = SPI2_ByteExchange(0xFF);
        }
        _LATD8 = TRUE; /* disable device */
    }    

    i = 0;
    while (i <= 255) {
        data_256[i] = i; // filling data in buffer
        i++;
    }
    
    data_256[0] = 0xB9;
    data_256[1] = 0xAA;
    data_256[2] = 0x12;
    data_256[3] = 0x45;

    /*#*/
    
    i = 0;

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x06); //write enable
    _LATD8 = TRUE;

    //while(i < highest_address)
    {
        _LATD8 = FALSE;
        SPI2_ByteExchange(0x06); //write enable
        _LATD8 = TRUE;

        {
            unsigned int k;
            k = 0;

            _LATD8 = FALSE; /* enable device */
            SPI2_ByteExchange(0x02); /* send Byte Program command */
            SPI2_ByteExchange(((i & 0xFFFFFF) >> 16)); /* send 3 address bytes */
            SPI2_ByteExchange(((i & 0xFFFF) >> 8));
            SPI2_ByteExchange(i & 0xFF);
            for (k = 0; k < 256; k++) {
                SPI2_ByteExchange(data_256[k]); /* send byte to be programmed */
            }
            _LATD8 = TRUE; /* disable device */
        }

        while ((status_reg & 1 == 1) /*BUSY*/ || (status_reg & 0b10 == 0)/*WREN*/) {
            _LATD8 = FALSE;
            SPI2_ByteExchange(0x05); //read status reg
            status_reg = SPI2_ByteExchange(0xFF); // dummy command for status reg read
            _LATD8 = TRUE;
            delay(10);
        }

        i = i + 256;
    }

    delay(50000);

    i = 0;
    while (i <= 255) {
        data_256[i] = 255 - i; // filling data in buffer
        i++;
    }

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x06); //write enable
    _LATD8 = TRUE;

    j = 0;
    //while(j < highest_address)
    {
        {
            unsigned long k = 0;
            _LATD8 = FALSE; /* enable device */
            SPI2_ByteExchange(0x0B); /* read command */
            SPI2_ByteExchange(((j & 0xFFFFFF) >> 16)); /* send 3 address bytes */
            SPI2_ByteExchange(((j & 0xFFFF) >> 8));
            SPI2_ByteExchange(j & 0xFF);
            SPI2_ByteExchange(0xFF); /*dummy byte*/

            for (k = 0; k < 256; k++) /* read until no_bytes is reached */ {
                data_256[k] = SPI2_ByteExchange(0xFF);
            }
            _LATD8 = TRUE; /* disable device */
        }

        for (loop_var = 0; loop_var < 256; loop_var++) {
            if (data_256[loop_var] == loop_var) {
                tempcheck &= 1;
            } else {
                tempcheck = 0;
            }
        }
        j = j + 256;
    }

    if ((tempcheck == 1)&&(status == 1)) {
        check = (check + 1);
        status = status & 1;
        printf("\r\n !!!! Page read and write is Pass !!!! \r\n");
        testRslt = TEST_PASS;
        
        cpu_set_led_state( LED_STATE_GREEN );
    } else {
        status = 0;
        printf("\r\n !!!! Page read and write is Failed !!!! \r\n");
        testRslt = TEST_FAIL;
    }

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x66); //ResetEn
    _LATD8 = TRUE;

    _LATD8 = FALSE;
    SPI2_ByteExchange(0x99); //Reset
    _LATD8 = TRUE;

    /***************** End of checking *****************/
    return testRslt;
}

#define NVM_CS_PIN _LATD8
typedef  INT16U UINT16;
typedef  INT8U UINT8;
#define NVM_JEDACID_CMD                 (UINT16) 0x9F00

#if 0
INT16U flash_test()
{
    _LATB8 = 1;
    UINT16 testRslt  = TEST_FAIL;
    UINT8  status_reg = 0x1; // initial value is fake busy

    unsigned long i, j, highest_address, tempdatalong; //m,k
    int check, tempcheck, status;
    int tempdata;
    unsigned char Read_Stat_Reg; //devicedata
    unsigned int loop_var;

i=0;
j=0;
status=1;  //1 means memory/code works and 0 means fault has occured.
check=0;  //keeps track of code progress.
tempcheck=1;
highest_address=0xfffff;    //8Mb   //highest_address=256;

/************* Page program whole chip using SPI protocol and verify its OK. *********/

i=0;

Jedec_ID_Read();

nvm_testNVM();

while (i<=255)
{
 data_256[i]= i; // filling data in buffer
	i++;
}
 	
    NVM_CS_PIN = FALSE;
    SPI2_ByteExchange(0x06); //write enable
    NVM_CS_PIN = TRUE;

    NVM_CS_PIN = FALSE;
    SPI2_ByteExchange(0xC7); //Chip Erase
    NVM_CS_PIN = TRUE;

    while((status_reg & 1 == 1) /*BUSY*/  || (status_reg & 0b10 == 0)/*WREN*/)
    {
        NVM_CS_PIN = FALSE;
        SPI2_ByteExchange(0x05); //read status reg
        status_reg = SPI2_ByteExchange(0xFF); // dummy command for status reg read
        NVM_CS_PIN = TRUE;
        delay(10);
    }

    i=0;

    NVM_CS_PIN = FALSE;
    SPI2_ByteExchange(0x06); //write enable
    NVM_CS_PIN = TRUE;

//while(i < highest_address)
{	
    NVM_CS_PIN = FALSE;
    SPI2_ByteExchange(0x06); //write enable
    NVM_CS_PIN = TRUE;

    {
        unsigned int k;
        k=0;

        NVM_CS_PIN = FALSE;				/* enable device */
        SPI2_ByteExchange(0x02); 			/* send Byte Program command */
        SPI2_ByteExchange(((i & 0xFFFFFF) >> 16));	/* send 3 address bytes */
        SPI2_ByteExchange(((i & 0xFFFF) >> 8));
        SPI2_ByteExchange(i & 0xFF);
        for (k=0;k<256;k++)
        {	
            SPI2_ByteExchange(data_256[k]);		/* send byte to be programmed */
        }
        NVM_CS_PIN = TRUE;				/* disable device */
    }

    while((status_reg & 1 == 1) /*BUSY*/  || (status_reg & 0b10 == 0)/*WREN*/)
    {
        NVM_CS_PIN = FALSE;
        SPI2_ByteExchange(0x05); //read status reg
        status_reg = SPI2_ByteExchange(0xFF); // dummy command for status reg read
        NVM_CS_PIN = TRUE;
        delay(10);
    }

	i=i+256;
}

delay(50000);    
    
i=0;
while (i<=255)
{
 data_256[i]= 255 - i; // filling data in buffer
	i++;
}
    
    NVM_CS_PIN = FALSE;
    SPI2_ByteExchange(0x06); //write enable
    NVM_CS_PIN = TRUE;

    j=0;
//while(j < highest_address)
{
{    
	unsigned long k = 0;
	NVM_CS_PIN = FALSE;				/* enable device */
	SPI2_ByteExchange(0x0B); 			/* read command */
	SPI2_ByteExchange(((j & 0xFFFFFF) >> 16)); 	/* send 3 address bytes */
	SPI2_ByteExchange(((j & 0xFFFF) >> 8));
	SPI2_ByteExchange(j & 0xFF);
	SPI2_ByteExchange(0xFF);                	/*dummy byte*/

	for (k = 0; k < 256; k++)		/* read until no_bytes is reached */
	{
		data_256[k] = SPI2_ByteExchange(0xFF);
	}
	NVM_CS_PIN = TRUE;				/* disable device */
}

    for (loop_var=0;loop_var<256;loop_var++)
		{
            if(data_256[loop_var]== loop_var)
			{
                tempcheck&=1;
			}
			  else
			{ 
                tempcheck=0;
			}
		}
	j=j+256;
}

if ((tempcheck == 1)&&(status==1))
{
    check=(check+1);
	status=status&1;
	printf("\r\n !!!! Page read and write is Pass !!!! \r\n");
    testRslt = TEST_PASS;
}
else
{
    status=0;
	printf("\r\n !!!! Page read and write is Failed !!!! \r\n");
    testRslt = TEST_FAIL;
}

    NVM_CS_PIN = FALSE;
    SPI2_ByteExchange(0x66); //ResetEn
    NVM_CS_PIN = TRUE;

    NVM_CS_PIN = FALSE;
    SPI2_ByteExchange(0x99); //Reset
    NVM_CS_PIN = TRUE;

 /***************** End of checking *****************/
return testRslt;
}

void nvm_testNVM(void)
{
    UINT16 mfrId     = 0;
    UINT16 devId     = 0;
    UINT16 dummyWord = 0x0000;
    //UINT16 testRslt  = TEST_FAIL;
    
    NVM_CS_PIN = FALSE;
    mfrId = spi_sendReceiveWordNVM(NVM_JEDACID_CMD);
    devId = spi_sendReceiveWordNVM(dummyWord);
    NVM_CS_PIN = TRUE;
    if(mfrId == 0xFFBF && devId == 0x2618)
    {
       // testRslt = TEST_PASS;
        printf("\n\r nvm_testNVM PASS \r\n");
    }
    else
    {
      //  testRslt = TEST_FAIL;
        printf("\n\r nvm_testNVM FAIL \r\n");
    }
    //return testRslt;
}
#endif

#if 0
INT8U Manufacturer_Id, Device_Type, Device_Id;

void xJedec_ID_Readx()
{
#if 0
	CE_Low();                            /* enable device */
	Send_Byte(0x9F);                    /* send JEDEC ID command (9Fh) */
   	Manufacturer_Id = Get_Byte();       /* receive byte */
  	Device_Type = Get_Byte();           /* receive byte */
  	Device_Id = Get_Byte();             /* receive byte */
	CE_High();                          /* disable device */
#endif
    
    NVM_CS_PIN = FALSE;
    SPI2_ByteExchange(0x9F);
    Manufacturer_Id = SPI2_ByteExchange(0xFF);
    Device_Type = SPI2_ByteExchange(0xFF);
    Device_Id = SPI2_ByteExchange(0xFF);
    NVM_CS_PIN = TRUE;
    
    printf("\r\n Jedec_ID_Read Manufacturer_Id = 0x%X\r\n", Manufacturer_Id);
    printf("\r\n Jedec_ID_Read Device_Type = 0x%X\r\n", Device_Type);
    printf("\r\n Jedec_ID_Read Device_Id = 0x%X\r\n", Device_Id);
    
}
#endif

void angle_sensor_exec(void) {
    ECAN_HW_MESSAGE rxCanMsg;
    INT16U data1, data2;
    INT32U addr = 0x0001000; // start address of 4KByte Sector
    INT16S angle1, angle2;
    static one_time = 0;

    //if (0 && ecan_rx_message(&rxCanMsg) == true) {
        //if (rxCanMsg.D[5] == 0xE3) { //Zero position configuration @ 0xE3
    if(flag_zero_config)
    {
            data1 = read_ANGLE_BASE_value(ANGLESENSOR_01);
            data2 = read_ANGLE_BASE_value(ANGLESENSOR_02);
            NVM_Erase_4K_Sector_store_2_words(addr, data1, data2);

        zero_config_from_NVM();
        
        if(1){
            INT8U message[15];
            INT8U CRCbyte;

            read_config_reg_08h_0Fh_return_15bytes(ANGLESENSOR_01, message);
            CRCbyte = CRC8(message, 15);
            write_config_reg_0Fh_LSByte(ANGLESENSOR_01, CRCbyte);

            read_config_reg_08h_0Fh_return_15bytes(ANGLESENSOR_02, message);
            CRCbyte = CRC8(message, 15);
            write_config_reg_0Fh_LSByte(ANGLESENSOR_02, CRCbyte);
            
            //read Status Register once, after CRC is written
            statusreg_read_analyze_print(ANGLESENSOR_01);
            statusreg_read_analyze_print(ANGLESENSOR_02);
        }
        
        reset_flag_angle_sensor_zero_config();
        return;
    }
        //}
    //}
        
#if 0 /* not needed anymore, because zero_config_from_NVM() is called within
         angle_sensor_current_angle() */
    if (one_time == 0) {
        NVM_read_2_words(addr, &data1, &data2);
        write_ANGLE_BASE_value(ANGLESENSOR_01, data1);
        write_ANGLE_BASE_value(ANGLESENSOR_02, data2);
        one_time = 1;
    }

    angle1 = angle_sensor_current_angle(ANGLESENSOR_01);
    angle2 = angle_sensor_current_angle(ANGLESENSOR_02);
    angle1 = angle_sensor_current_angle(ANGLESENSOR_01);
    angle2 = angle_sensor_current_angle(ANGLESENSOR_02);
#endif
}


void zero_config_from_NVM(void)
{
    INT16U data1, data2;
    INT32U addr = 0x0001000; // start address of 4KByte Sector

    NVM_read_2_words(addr, &data1, &data2);
    write_ANGLE_BASE_value(ANGLESENSOR_01, data1);
    write_ANGLE_BASE_value(ANGLESENSOR_02, data2);
}

void set_flag_angle_sensor_zero_config()
{
    flag_zero_config = 1;
}

void reset_flag_angle_sensor_zero_config()
{
    flag_zero_config = 0;
}


//?message? is the data transfer for which a CRC has to be calculated.
//A typical ?message? consists of 2 bytes for the command word plus 2 bytes for the
//data word plus 2 bytes for the safety word.
//?Bytelength? is the number of bytes in the ?message?. A typical ?message? has 6
//bytes.
unsigned char CRC8(unsigned char *message, unsigned char Bytelength) {
    //?crc? defined as the 8-bits that will be generated through the message till the
    //final crc is generated. In the example above this are the blue lines out of the
    //XOR operation.
    unsigned char crc;
    //?Byteidx? is a counter to compare the bytes used for the CRC calculation
    unsigned char Byteidx, Bitidx;
    //Initially the CRC remainder has to be set with the original seed (0xFF for the
    //TLE5012B).
    crc = 0xFF;
    //For all the bytes of the message.
    for (Byteidx = 0; Byteidx < Bytelength; Byteidx++) {
        //?crc? is calculated as the XOR operation from the previous ?crc? and the ?message?.
        //?^? is the XOR operator.
        crc ^= message[Byteidx];
        //For each bit position in a 8-bit word
        for (Bitidx = 0; Bitidx < 8; Bitidx++) {
            //If the MSB of the ?crc? is 1(with the &0x80 mask we get the MSB of the crc).
            if ((crc & 0x80) != 0) {
                //?crc? advances on position (?crc? is moved left 1 bit: the MSB is deleted since it
                //will be cancelled out with the first one of the generator polynomial and a new bit
                //from the ?message? is taken as LSB.)
                crc <<= 1;
                //?crc? is calculated as the XOR operation from the previous ?crc? and the generator
                //polynomial (0x1D for TLE5012B). Be aware that here the x8 bit is not taken since
                //the MSB of the ?crc? already has been deleted in the previous step.
                crc ^= 0x1D;
            }
                //In case the crc MSB is 0.
            else
                //?crc? advances one position (this step is to ensure that the XOR operation is only
                //done when the generator polynomial is aligned with a MSB of the message that is ?1?.
                crc <<= 1;
        }
    }
    //Return the inverted ?crc? remainder(?~? is the invertion operator). An alternative
    //to the ?~? operator would be a XOR operation between ?crc? and a 0xFF polynomial.
    return (~crc);
}

// End of File
