/*
 * Author(s):    Michael Ansolis
 * Status:       Incomplete
 * Release Date: 11/30/12
 * Revision:     0.1
 * Description:  The DataFlash module is responsible for managing the low-level read and
 *               write operations to the external flash memory IC.  The external flash IC
 *               is accessed via a SPI data bus.
 *               See:  http://www.mouser.com/ds/2/590/DS-45DB081E_028-534018.pdf
 * Note:         Compile with compiler option -mno-eds-warn to disable EDS compiler warnings.
 */

/*********************************************************************************************
 * Source file includes
 ********************************************************************************************/
#include "cpu.h"
#include <xc.h>
#define FOR_CCB_DEMO         1         //added for only DEMO to disable flash functionality
#ifndef FOR_CCB_DEMO
/*********************************************************************************************
 * Private preprocessor definitions
 ********************************************************************************************/
#define DEV_ID_OP_CODE     0x9F              /* Manufacturer and Device ID Read opcode */
#define ARRAY_READ_OPCODE  0x03              /* Continuous Array Read (Low Frequency) opcode */
#define MEM_TO_BUF_OPCODE  0x53              /* Main Memory Page to Buffer 1 Transfer opcode */
#define BUF_WRITE_OPCODE   0x84              /* Buffer 1 Write opcode */
#define PROG_BUF_OPCODE    0x83              /* Buffer 1 to Main Memory Page Program with Built-in Erase opcode */
#define GET_STATUS_OPCODE  0xD7              /* Status Register Read */
#define PAGE_SIZE_1_OPCODE 0x3D
#define PAGE_SIZE_2_OPCODE 0x2A
#define PAGE_SIZE_3_OPCODE 0x80
#define PAGE_SIZE_256_OPCODE 0xA6
#define MANUFACTURER_ID    0x1F
#define DEVICE_ID          0x25
#define READY_BIT_MASK     0x80              /* Ready bit and ready bit mask in the status byte. */
#define SPI_TRY_COUNT      200               /* Iterate 200 times attempting to read SPI buffer. */
#define WAIT_FOR_NOT_BUSY_COUNT      500000  /* How long to wait for EEPROM operations to complete */
#define ADDRESS_SHIFT_8    8                 /* Value for shifting addresses left or right */
#define ADDRESS_SHIFT_9    9                 /* Value for shifting addresses left or right */
#define ADDRESS_SHIFT_16   16                /* Value for shifting addresses left or right */

/*********************************************************************************************
 * Private type definitions
 ********************************************************************************************/
typedef struct
{
    INT8U command;
    INT8U manufacturer;
    INT16U deviceid;
} Flash_Device_Id;

typedef struct
{
    INT8U opCode1;
    INT8U opCode2;
    INT8U opCode3;
    INT8U flashSize;
} Page_Size_Reconfigure;

/* mfarver-Bit order when packing into bytes is implementation specific.
 * It works here, LSB to MSB but use caution if porting this code to another
 * line of processors.  */
typedef struct
{
    INT8U command; /* */
    /* Byte 1 LSB */
    INT8U page_size : 1; /* 0: 264bytes per page, 1: 256 bytes per page. */
    INT8U sector_protect : 1; /* Sector Protection 0: disabled, 1: enabled */
    INT8U density : 4; /* Always 1001 for 8mbit chip */
    INT8U comp : 1; /* Main Memory Page matches buffer: 0:yes 1:no */
    INT8U ready1 : 1; /* 0: Device is busy, 1: Device Ready */
    /* Byte 1 MSB */

    /* Byte 2 LSB */
    INT8U erase_suspend1 : 1; /* 1:A sector is erase suspended */
    INT8U prog_suspend1 : 1; /* 1:A sector is program suspended Buffer 1. */
    INT8U prog_suspend2 : 1; /* 1:A sector is program suspended Buffer 2. */
    INT8U sector_lockout : 1; /* Sector Lockdown command 0: disabled, 1: enabled */
    INT8U reserved2 : 1; /* Reserved */
    INT8U epe : 1; /* 0: Erase or program was successful, 1: error */
    INT8U reserved1 : 1; /* Reserved */
    INT8U ready2 : 1; /* 0: Device is busy, 1: Device Ready */
} Flash_Status_Reg;

/*********************************************************************************************
 * Private function declarations
 ********************************************************************************************/
/*********************************************************************************************
 * Author(s):   Michael Ansolis
 * Description: Function for reading a single byte from SPI bus.
 * Parameters:  None.
 * Returns:     Byte of data read from the SPI bus.
 ********************************************************************************************/
static INT8U _flash_read_spi(void);

/*********************************************************************************************
 * Author(s):   Michael Ansolis
 * Description: Function for writing a single byte to the SPI bus.
 * Parameters:  data_out - byte of data to write to the SPI bus.
 * Returns:     None.
 ********************************************************************************************/
static void _flash_write_spi(INT8U data_out);

/*********************************************************************************************
 * Author(s):   mfarver
 * Description: Does a simultaneous read/write of up to 8 bytes of data. to the SPI bus
 *  Data read replaces the data sent
 * Parameters:  data_inout - buffer of data to write to the SPI bus, and the buffer of data
 *                           read from the SPI bus.
 *              length     - number of bytes to read from SPI bus.
 * Returns:     None.
 ********************************************************************************************/
static BOOL _flash_rw_spi_bytes(INT8U * data_inout, INT8U length);

/*********************************************************************************************
 * Author(s):   Mark Farver
 * Description: Function for checking the if the DataFlash chip is busy.
 * Parameters:  None.
 * Returns:     TRUE - if the DataFlash chip is busy; FALSE otherwise.
 ********************************************************************************************/
static BOOL _flash_is_busy(void);
static ERR_RET _wait_for_not_busy();

/*********************************************************************************************
 * Author(s):   Mark Farver
 * Description: Reads if flash chip is in 264 or 256byte page mode, and updates page size
 *              to 256 bytes-per-page if necessary.
 * Parameters:  None
 * Returns:     None
 ********************************************************************************************/
static void _flash_update_page_size();

/*********************************************************************************************
 * Global variable definitions
 ********************************************************************************************/
static INT32U G_fd_page_size;
static BOOL G_flash_valid = FALSE;
#endif
/*********************************************************************************************
 * Source file function definitions
 ********************************************************************************************/

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: The initialization function for the DataFlash module.
 * Parameters:  None.
 * Returns:     NO_ERROR    - no error has been detected while initializing the Dataflash module.
 *              INIT_FAILED - an error was detected while initializing the Dataflash module.
 ********************************************************************************************/
ERR_RET flash_init(void)
{
#ifndef   FOR_CCB_DEMO
    ERR_RET sys_err = INIT_FAILED;
    Flash_Device_Id device_id_buf;

    cpu_SetDataFlashReset(FLASH_NORMAL_OP);
    cpu_SetDataFlashCs(FLASH_UNSELECTED); /* Set Chip Select pin high - deselect the memory chip */
    cpu_SetDataFlashWp(FLASH_WRITE); /* Set nWriteProtect pin high - disable write protect */

    /* Configure SPI */
    _FLASH_SPICON1bits.DISSCK = 0; /* Internal serial clock is enabled */
    _FLASH_SPICON1bits.DISSDO = 0; /* SDO1 pin is controlled by the module */
    _FLASH_SPICON1bits.MODE16 = 0; /* Communication is byte-wide (8 bits) */

    /* Input data is sampled at the middle of data output time */
    _FLASH_SPICON1bits.SMP = 0;

    /* Serial output data changes on transition from active clock state to idle clock state */
    _FLASH_SPICON1bits.CKE = 1;

    /* Idle state for clock is a low-level; active state is a high-level */
    _FLASH_SPICON1bits.CKP = 0;

    _FLASH_SPICON1bits.MSTEN = 1; /* Master mode enabled */
    SPI2BRGLbits.BRG = 0x1F; //Fp=64 Sck = fp/(2(31+1)))
    //_FLASH_SPICON1bits.PPRE = 0b00; /* Primary Prescale 64:1 (1mhz SPI clock) */
    //_FLASH_SPICON1bits.SPRE = 0b111; /* Secondary Prescale 1:1 */
    _FLASH_SPICON1bits.ENHBUF = 1; /* Enhanced buffer enabled */
    _FLASH_SPICON1bits.SPIEN = 1; /* Enable SPI module */

    /* Verify Manufacturer and Device ID Information */
    device_id_buf.command = DEV_ID_OP_CODE;
    device_id_buf.manufacturer = 0x0;
    device_id_buf.deviceid = 0x0000;

    /* Write 1 byte command, read 3 bytes. */
    _flash_rw_spi_bytes((INT8U *) & device_id_buf, sizeof (Flash_Device_Id));

    if (device_id_buf.manufacturer == MANUFACTURER_ID &&
        device_id_buf.deviceid == DEVICE_ID)
    {
        G_flash_valid = TRUE;
        sys_err = NO_ERROR;
    }

    _flash_update_page_size();

    /* Return status */
    return sys_err;
#else
    return NO_ERROR;
#endif
}


/*********************************************************************************************
 * Author(s):   Michael Ansolis
 * Description: Function for reading Dataflash memory.
 * Parameters:  p_data      - buffer to put read data into.
 *              flash_addr  - address in DataFlash memory to start reading data from.
 *              data_length - number of bytes to read from DataFlash memory.
 * Returns:     NO_ERROR    - no error has been detected while reading from DataFlash memory.
 *              ERR_FAILURE - an error was detected while attempting to read from Dataflash memory.
 ********************************************************************************************/
ERR_RET flash_read( INT8U* p_data, const INT32U flash_addr, const INT16U data_length)
{
#ifndef   FOR_CCB_DEMO
    INT32U idx;
    INT32U address = 0;
    INT32U byte_addr = 0;
    INT32U page_num = 0;
    ERR_RET sys_err = ERR_FAILURE;

    if (!G_flash_valid || flash_addr >= (G_fd_page_size * FD_NUM_PAGES))
    {
        return ERR_FAILURE;
    }

    sys_err = _wait_for_not_busy();

    if (sys_err == NO_ERROR)
    {
        page_num = flash_addr / G_fd_page_size;
        byte_addr = flash_addr - (page_num * G_fd_page_size);
        if ( G_fd_page_size == 264ul)
        {
            address = (page_num << 9) | byte_addr;
        }
        else
        {
            address = (page_num << 8) | byte_addr;
        }
        cpu_SetDataFlashCs(FLASH_SELECTED); /* Set Chip Select pin low - select the memory chip */

        /* Send an Array Read opcode followed by 3 address bytes:  xxxPPPPP PPPPPPPB BBBBBBBB, */
        /* where x is don't care bit, P is page number bit, B is byte address bit. */
        _flash_write_spi(ARRAY_READ_OPCODE);
        _flash_write_spi((INT8U) (address >> ADDRESS_SHIFT_16));
        _flash_write_spi((INT8U) (address >> ADDRESS_SHIFT_8));
        _flash_write_spi((INT8U) (address));

        for (idx = 0; idx < data_length; idx++) /* Read data in */
        {
            p_data[idx] = _flash_read_spi();
        }
    }

    cpu_SetDataFlashCs(FLASH_UNSELECTED); /* Set Chip Select pin high - deselect the memory chip */
#endif
    return NO_ERROR;
}

/*********************************************************************************************
 * Author(s):   Michael Ansolis
 * Description: Function for writing into Dataflash memory.
 * Parameters:  p_data      - buffer containing data to be written to the DataFlash memory.
 *              flash_addr  - address in DataFlash memory to start writing data at.
 *              data_length - number of bytes to be written to the DataFlash memory.
 * Returns:     NO_ERROR    - no error was detected while writing to the DataFlash memory.
 *              ERR_FAILURE - an error was detected when attempting to write to DataFlash memory.
 ********************************************************************************************/
ERR_RET flash_write(INT8U* p_data, INT32U flash_addr, INT16U data_length)
{
#ifndef   FOR_CCB_DEMO
    INT32U page_num;
    INT16U byte_addr;
    INT32U address;
    INT32U idx;
    ERR_RET sys_err = ERR_FAILURE;

    if (!G_flash_valid || flash_addr >= G_fd_page_size * FD_NUM_PAGES)
    {
        return ERR_FAILURE;
    }

    sys_err = _wait_for_not_busy();

    if (sys_err != NO_ERROR)
    {
        return ERR_FAILURE;
    }

    page_num = flash_addr / G_fd_page_size;
    byte_addr = flash_addr - (page_num * G_fd_page_size);
    if ( G_fd_page_size == 264ul)
    {
        address = (page_num << 9) | byte_addr;
    }
    else
    {
        address = (page_num << 8) | byte_addr;
    }

    /* Set Chip Select pin low - select the memory chip */
    cpu_SetDataFlashCs(FLASH_SELECTED);

    /* Transfer main memory page to buffer 1 opcode */
    _flash_write_spi(MEM_TO_BUF_OPCODE);

    /* 3 don't care bits and 5 MSb of page address */
    _flash_write_spi((INT8U) (address >> ADDRESS_SHIFT_16));

    /* 7 LSb of page address and 1 don't care bit */
    _flash_write_spi((INT8U) (address >> ADDRESS_SHIFT_8));

    /* 8 don't care bits */
    _flash_write_spi(0);

    /* Set Chip Select pin high - deselect the memory chip */
    cpu_SetDataFlashCs(FLASH_UNSELECTED);

    sys_err = _wait_for_not_busy();

    if (sys_err != NO_ERROR)
    {
        return ERR_FAILURE;
    }

    /* Set Chip Select pin low - select the memory chip */
    cpu_SetDataFlashCs(FLASH_SELECTED);

    /* Buffer 1 Write opcode */
    _flash_write_spi(BUF_WRITE_OPCODE);

    /* Don't care bits */
    _flash_write_spi(0);

    /* 7 don't care bits and 1 MSb of buffer address */
    _flash_write_spi((INT8U) (byte_addr >> ADDRESS_SHIFT_8));

    /* 8 LSb of byte address within the buffer */
    _flash_write_spi((INT8U) (byte_addr));

    /* Send new data bytes to overwrite buffer contents */
    for (idx = 0; idx < data_length; idx++)
    {
        _flash_write_spi(p_data[idx]);
    }

    /* Set Chip Select pin high - deselect the memory chip */
    cpu_SetDataFlashCs(FLASH_UNSELECTED);
    for (idx = 0; idx < 1000; ++idx)
    {
        Nop();
    }

    /* Set Chip Select pin low - select the memory chip */
    cpu_SetDataFlashCs(FLASH_SELECTED);

    /* Program buffer 1 to main memory opcode */
    _flash_write_spi(PROG_BUF_OPCODE);

    /* 3 don't care bits and 5 MSB of page address bits */
    _flash_write_spi((INT8U) (address >> ADDRESS_SHIFT_16));

    /* 7 LSB of page address bits and 1 don't care bit */
    _flash_write_spi((INT8U) (address >> ADDRESS_SHIFT_8));

    /* 8 don't care bits */
    _flash_write_spi(0);

    /* Deselect the memory chip and start erasing and programming operations */
    cpu_SetDataFlashCs(FLASH_UNSELECTED);
#endif
    return NO_ERROR;
}
#ifndef   FOR_CCB_DEMO
static ERR_RET _wait_for_not_busy()
{

    INT32U idx;
    ERR_RET sys_err = ERR_FAILURE;

    for (idx = 0; idx < WAIT_FOR_NOT_BUSY_COUNT; idx++)
    {
        if (_flash_is_busy()) /* Wait while the DataFlash chip is busy */
        {
            Nop();
        }
        else
        {
            sys_err = NO_ERROR;
            break;
        }
    }
    return sys_err;
}

/*********************************************************************************************
 * Author(s):   Mark Farver
 * Description: Reads if flash chip is in 264 or 256byte page mode, and updates page size
 *              to 256 bytes-per-page if necessary.
 * Parameters:  None
 * Returns:     None
 ********************************************************************************************/
static void _flash_update_page_size()
{
    ERR_RET sys_err = ERR_FAILURE;
    Flash_Status_Reg status_buf;
    Page_Size_Reconfigure reconfig_buf;

    status_buf.command = GET_STATUS_OPCODE;
    /* Write 1 byte command, read 4 bytes. */
    _flash_rw_spi_bytes((INT8U *) & status_buf, sizeof (Flash_Status_Reg));
    if ( status_buf.page_size == 1 )
    {
        G_fd_page_size = 256ul;
    }
    else
    {
        reconfig_buf.opCode1 = PAGE_SIZE_1_OPCODE;
        reconfig_buf.opCode2 = PAGE_SIZE_2_OPCODE;
        reconfig_buf.opCode3 = PAGE_SIZE_3_OPCODE;
        reconfig_buf.flashSize = PAGE_SIZE_256_OPCODE;
        /* Write page size config command. */
        _flash_rw_spi_bytes((INT8U *) & reconfig_buf, sizeof (Page_Size_Reconfigure));

        /* Wait for the chip to be ready */
        sys_err = _wait_for_not_busy();
        if (sys_err != NO_ERROR)
        {
            G_flash_valid = FALSE;
        }

        /* Verify the page size was updated. */
        status_buf.command = GET_STATUS_OPCODE;
        _flash_rw_spi_bytes((INT8U *) & status_buf, sizeof (Flash_Status_Reg));
        if ( status_buf.page_size == 1 )
        {
            G_fd_page_size = 256ul;
        }
        else
        {
            G_fd_page_size = 264ul;
            G_flash_valid = FALSE;
        }
    }
    /* Void return */
    return;
}
#endif
/*********************************************************************************************
 * Author(s):   Mark Farver
 * Description: Returns cached page size of dataflash
 * Parameters:  None
 * Returns:     Page size (256 or 264 bytes)
 ********************************************************************************************/
INT32U flash_get_page_size()
{
#ifndef   FOR_CCB_DEMO
    return G_fd_page_size;
#endif
    return 0;
}
#ifndef   FOR_CCB_DEMO
/*********************************************************************************************
 * Author(s):   Michael Ansolis
 * Description: Function for writing a single byte to the SPI bus.
 * Parameters:  data_out - byte of data to write to the SPI bus.
 * Returns:     None.
 ********************************************************************************************/
static void _flash_write_spi(INT8U data_out)
{

    INT16U idx = 0;

    /* Write the byte to the SPI buffer, and wait for the buffer to report empty */
    _FLASH_SPIBUF = data_out; /*  byte write  */
    for (idx = 0; idx < SPI_TRY_COUNT; idx++)
    {
        /* Check the status bit of status register */
        if (_FLASH_SPISTATbits.SRMT)
        {
            data_out = _FLASH_SPIBUF; /* Avoiding overflow when reading */
            break;
        }
    }
    return;
}
/*********************************************************************************************
 * Author(s):   mfarver
 * Description: Does a simultaneous read/write of up to 8 bytes of data. to the SPI bus
 *  Data read replaces the data sent
 * Parameters:  data_inout - buffer of data to write to the SPI bus, and the buffer of data
 *                           read from the SPI bus.
 *              length     - number of bytes to read from SPI bus.
 * Returns:     None.
 ********************************************************************************************/
static BOOL _flash_rw_spi_bytes(INT8U data_inout[], INT8U length)
{
    INT32U idx;
    INT32U to_idx;

    cpu_SetDataFlashCs(FLASH_SELECTED);
    for (idx = 0; idx < length; ++idx)
    {
        _FLASH_SPIBUF = data_inout[idx]; /*  byte write  */

        for (to_idx = 0; to_idx < SPI_TRY_COUNT; to_idx++)
        {
            /* Check the status bit of status register */
            if (_FLASH_SPISTATbits.SRMT)
            {
                data_inout[idx] = _FLASH_SPIBUF; /*  byte read  */
                break;
            }
        }
    }
    cpu_SetDataFlashCs(FLASH_UNSELECTED);
    return TRUE;
}

/*********************************************************************************************
 * Author(s):   Michael Ansolis
 * Description: Function for reading a single byte from SPI bus.
 * Parameters:  None.
 * Returns:     Byte of data read from the SPI bus.
 ********************************************************************************************/
static INT8U _flash_read_spi(void)
{
    INT16U idx = 0;

    /* Initiate bus cycle */
    _FLASH_SPIBUF = 0x00;

    for (idx = 0; idx < SPI_TRY_COUNT; idx++)
    {
        /* Check the Receive Buffer Full status bit of status register */
        if (!_FLASH_SPISTATbits.SPIRBE)
        {
            return _FLASH_SPIBUF;
        }
    }

    /* Return data byte */
    return -1;
}

/*********************************************************************************************
 * Author(s):   Mark Farver
 * Description: Function for checking the if the DataFlash chip is busy.
 * Parameters:  None.
 * Returns:     TRUE - if the DataFlash chip is busy; FALSE otherwise.
 ********************************************************************************************/
static BOOL _flash_is_busy(void)
{
    Flash_Status_Reg status_buf;

    status_buf.command = GET_STATUS_OPCODE;
    /* Write 1 byte command, read 4 bytes. */
    _flash_rw_spi_bytes((INT8U *) & status_buf, sizeof (Flash_Status_Reg));
    return !status_buf.ready1;

}
#endif

/*********************************************************************************************
 * Author(s):   Mark Farver
 * Description: Initializes chip to factory blank state erasing all pages and lifetime
 * Parameters:  None
 * Returns:     Indicates whether the operation completed successfully (NO_ERROR)
 *              or not (ERR_FAILURE).
 ********************************************************************************************/
ERR_RET flash_erase_chip( void )
{
#ifndef   FOR_CCB_DEMO
    ERR_RET sys_err = NO_ERROR;
    INT8U erasecmd[] = {0xC7, 0x94, 0x80, 0x9A};

    if (!G_flash_valid || _flash_is_busy())
    {
        sys_err = ERR_FAILURE;
    }
    else
    {
        _flash_rw_spi_bytes(erasecmd, sizeof (erasecmd));
    }
    return sys_err;
#else
    return NO_ERROR;
#endif
}
#ifndef   FOR_CCB_DEMO
/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Retrieves the maximum address for the DataFlash chip.
 * Parameters:  None.
 * Returns:     INT32U - max address for the chip.
 ********************************************************************************************/
INT32U flash_get_max_addr( void )
{
    return ( DATAFLASH_START_ADDR + ( G_fd_page_size * FD_NUM_PAGES ) );
}
#endif
