/*
Author(s):      mfarver
                Doug Wendt      <dwendt@omnicongroup.com>
Release Date:   Pre-release
Revision:
Description:    Header file for the ADC Mnager.
History:        06/10/2016 Clay Barber
 */

#ifndef ADC_MANAGER_H
#define	ADC_MANAGER_H
/*********************************************************************************************
Includes
 *********************************************************************************************/
#ifndef PRIVACY_DIVIDER
#include "brake_control.h"
#endif
#include "typedef.h"

/*********************************************************************************************
Preprocessor definitions
 *********************************************************************************************/
/* ADC readings are converted to mv by multiplying by .806 */
#define ADC_CONVERSION_FACTOR 0.806 /* 3300mv vref / 4096 steps */

/*********************************************************************************************
Function declarations
 *********************************************************************************************/

/*********************************************************************************************
Author(s):   mfarver
Description: The initialization function for the adc manager
Parameters:  None.
Returns:     None.
 *********************************************************************************************/
void adcm_init();
void ADC_Isense_RawAvg();
/*********************************************************************************************
 * Author(s):   mfarver
 * Description: returns true after ever cell in the ADC ring buffer has
 *  stored a sample.  (Used to prevent averaging against uninitized memory
 *  during initial startup.)
 * Parameters:  None.
 * Returns:     true if buffer is full of samples.
 *********************************************************************************************/
bool adcm_is_buffer_initialized( void );

/*********************************************************************************************
 * Author(s):   mfarver
 * Description: Returns the average of all of the samples in the DMA buffer for the specified
 *  channel
 * Parameters:  None.
 * Returns:     None.
 *********************************************************************************************/
INT16U adcm_get_average( INT8U channel );

/*********************************************************************************************
 * Author(s):   mfarver
 * Description: Returns the average of all of the samples in the DMA buffer for the specified
 *  channel
 * Parameters:  channel (in) - Channel number to average
 * Returns:     Average value of that ADC channel.
 *********************************************************************************************/
INT16U adcm_get_raw_average( INT8U channel );

#ifdef BRAKE_FEEDBACK_ENABLED
/*********************************************************************************************
 * Author:      Doug Wendt      <dwendt@omnicongroup.com>
 * Description: Reads current ADC DMA buffer slot for brake position data
 * Parameters:  position, (out) - Datastructure to store position data.
 * Returns:     None
 * History:     06/10/2010 Clay Barber
 *                  Changed Files updates
*********************************************************************************************/
//void adcm_get_brake_data( SLND_POSITION_DATA * position );
#endif

#endif	/* ADC_MANAGER_H */

void ADC1_Initialize (void);
INT16U ADC_raw_value(INT8U channel);