/*
 Author(s): Russell Everett <reverett@righthandtech.com>
 Status: Preliminary
 Release Date:
 Revision:
 Description: Definitions for the Stepper Control Module.
 History:
 06/11/2010 Clay Barber Changed Files updates
 06/24/2016 Clay Barber Updates of Juan Kuyoc
*/
// FIle name need to be updated to brake_control.c
/*********************************************************************************************
Includes
*********************************************************************************************/
#include "adc_manager.h"
#include "communications.h"
#include "cpu.h"
#include "global.h"
#include "brake_control.h"
#include "timer_manager.h"
#include "pwm.h"
/*********************************************************************************************
Private Type Definitions
*********************************************************************************************/

/*********************************************************************************************
Private Preprocessor definitions
*********************************************************************************************/
#define SOL_PERIOD_TICKS      9999//for 200Hz    //((FPGx_clk/FPWM) - 1) FPWM= 16KHz required, FPGx_clk = 80MHz

#define SLND_ENGAGED     TRUE
#define SLND_DISENGAGED  FALSE

/*********************************************************************************************
Private Function declarations
*********************************************************************************************/
static void _brake_control(SLND_BRAKE_COMMAND brake_cmd);

/*********************************************************************************************
Global Variable definitions
*********************************************************************************************/

/* holds the overall state of the brake state machine */
static SLND_BRAKE_STATUS G_brake_status;

/*********************************************************************************************
Function definitions
*********************************************************************************************/

/*********************************************************************************************
Author(s):   Russell Everett <reverett@righthandtech.com>
Description: The function for returning the status of the brake state.
Parameters:  None.
Returns:     The overall brake status of stepper control module.
*********************************************************************************************/
SLND_BRAKE_STATUS slnd_get_brake_status( void )
{
    return G_brake_status;
}

/*********************************************************************************************
 * Author(s):   Russell Everett <reverett@righthandtech.com>
 *              Doug Wendt      <dwendt@omnicongroup.com> (Stepper Feedback)
 * Description: The initialization function for the Stepper Control module.
 * Parameters:  None.
 * Returns:     NO_ERROR    - indicates success
 *              ERR_FAILURE - indicates failure
 * History:
 * 06/11/2010 Clay Barber Changed Files updates
 *********************************************************************************************/
ERR_RET brake_init( void )
{
    ERR_RET sys_err = NO_ERROR;
    
    pwm_slnd_init();

    return sys_err;
}

//duty cycle = 0 : brake engaged
//duty cycle = 50% OR 100% : brake Disengaged
static void _brake_control(SLND_BRAKE_COMMAND brake_cmd) {

    if (brake_cmd == BRAKE_CMD_DISENGAGE) {
        while (PG1STATbits.UPDATE);
        PG1DC = (INT16U)(SOL_PERIOD_TICKS * 0.5); //calculate value for 100%duty cycle
    } else {//ensure the command speed as 0
        while (PG1STATbits.UPDATE);
        PG1DC = 0; //calculate value for 100%duty cycle  
    }
}
/*********************************************************************************************
Author(s):   
Description: The periodic function for control of the brake state.
Parameters:  (in) The brake command.
Returns:     The brake state of stepper control module.
History:
*********************************************************************************************/
SLND_BRAKE_STATE brake_exec( SLND_BRAKE_COMMAND brake_cmd )
{
    /* Current brake state of the brake state machine  */
    static SLND_BRAKE_STATE current_brake_state = 0;
 //   if(current_brake_state!=brake_cmd){
             _brake_control(brake_cmd);
  //  }
    current_brake_state = brake_cmd;
     return current_brake_state;
}
