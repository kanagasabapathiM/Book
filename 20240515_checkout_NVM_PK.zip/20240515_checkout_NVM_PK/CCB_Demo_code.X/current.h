/*
Author(s):      David Yuen <dyuen@righthandtech.com>
Status:         Preliminary
Release Date:
Revision:
Description:    Interface definition for the Current module.   This module caches
                current readings for distribution to other software modules.
                This module is also responsible for providing periodic monitoring of the
                current consumption.
 */

#ifndef CURRENT_H
#define CURRENT_H

/*********************************************************************************************
Includes
*********************************************************************************************/
#include "typedef.h"

/*********************************************************************************************
Preprocessor definitions
*********************************************************************************************/
/*
 Number of 1ms current samples to save for obstacle detection. Note that this number must
 be a power of 2 for the wrap operation to work properly.
 */
#define NUM_CURRENT_SAMPLES         512

/*
 The wrap mask is used to correct for wrapping around the end of the array used for the
 circular buffer. When a new index is computed, the result is simply and'ed with the wrap mask
 to correct for passing zero. The fact that the length of the buffer is a power of 2 is what
 makes this work.
 */
#define WRAP_MASK                   (NUM_CURRENT_SAMPLES - 1)

/*********************************************************************************************
Function declarations
*********************************************************************************************/


/*********************************************************************************************
Author(s):   James Pieterick <jpieterick@righthandtech.com>
Description: Computes and returns the average of the NUM_STATUS_SAMPLES most recently cached
             BLDC motor drive current measurments by summing the samples and then dividing by
             NUM_STATUS_SAMPLES.
Parameters:  None.
Returns:     See description.
*********************************************************************************************/
INT16S crnt_get_current_average();
#endif /* CURRENT_H */
