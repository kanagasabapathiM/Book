/*
 * Author(s):    Jonathan R. Saliers
 * Status:       Incomplete
 * Release Date: 11/30/12
 * Revision:     0.1
 * Description:  Header file for the Memory_Manager module.
 * History:      06/10/2016 Clay Barber - Compare Files changes
 */

/*********************************************************************************************
 * Recursive header block
 ********************************************************************************************/
#ifndef MEMORYMGR_H
#define MEMORYMGR_H

/*********************************************************************************************
 * Includes
 ********************************************************************************************/
#include "global.h"
#include "typedef.h"

/*********************************************************************************************
 * Any type definitions defined by the header file
 ********************************************************************************************/
typedef struct mem_addr
{
    INT16U page;    /* 128Kbyte page number */
    INT16U offset;  /* Offset into the 128Kbyte page. */
} MEM_ADDRESS_TYPE;

/*********************************************************************************************
 * Global variable definitions
 ********************************************************************************************/

/*********************************************************************************************
 * Preprocessor definitions
 ********************************************************************************************/
#define MMGR_NO_ERROR            0x0
#define MMGR_ERROR               0x1
#define MMGR_READ_ERROR          0x2
#define MMGR_INVALID_ADDRESS     0x4

#ifdef PRIVACY_DIVIDER
#define PROGRAM_MEMORY_START_ADDR  0x00000000ul
#define PROGRAM_MEMORY_MAX_ADDR  0x0002AFEBul  /* Excludes the page containing config bytes */
#define CFG_BITS_START_ADDR      0x0002AFECul
#define CFG_BITS_MAX_ADDR        0x0002AFFFul
#else
#define PROGRAM_MEMORY_START_ADDR  0x00000000ul
#define PROGRAM_MEMORY_MAX_ADDR  0x0002ABFFul
#define AUX_FLASH_START_ADDR     0x007FC000ul
#define AUX_FLASH_MAX_ADDR       0x007FFFF9ul
#define CFG_BITS_START_ADDR      0x00F80000ul
#define CFG_BITS_MAX_ADDR        0x00F80013ul
#endif

#define FLASH_PAGE_SIZE     ( 1024ul * 2ul )   /* In 16-bit words; 1024 instruction words, two 16-bit words each. */ /*TBD*/

#define BOOT_MODE_SIZE      1       /* Number of words to program for Boot Mode. */

/*********************************************************************************************
 * Function declarations
 ********************************************************************************************/
/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: The initialization function for the Memory_Manager module.
 * Parameters:  None.
 * Returns:     NO_ERROR    - Initialization complete, continue.
 *              INIT_FAILED - Initialization failed, cannot continue to run normal execution
 ********************************************************************************************/
ERR_RET mmgr_init( void );

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Serves as a method to retrieve eight bytes of data from either internal NVM or
 *              external DataFlash memory chip.
 * Parameters:  mem_addr - address in internal memory to retrieve data from.
 *              p_data - pointer to location for storage of retrieved data.
 * Returns:     MMGR_NO_ERROR - Retrieval successful.
 *              MMGR_INVALID_ADDRESS - Returned if the specified memory is invalid.
 ********************************************************************************************/
ERR_RET mmgr_retrieve_data_from_memory( INT32U mem_addr, INT16U* p_data );

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Initializes addresses and creates an image of the 4K NVM page in RAM to be
 *              subsequently modified and written back to NVM.  Called prior to making
 *              mmgr_write_data() calls.
 * Parameters:  address - starting address in the internal prgram flash memory
 *              to store data to, in words.
 * Returns:     MMGR_NO_ERROR - initialization completed successfully.
 ********************************************************************************************/
ERR_RET mmgr_write_data_start( INT32U address );

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Adds new data words to the RAM image of a 4K memory page to be overwritten.
 *              When the end of the page is reached, the page is written to the NVM.  A call
 *              to mmgr_write_data_start() should be made prior to calling this function and
 *              a call to mmgr_write_data_finalize() should be made after the last
 *              mmgr_write_data() call.
 * Parameters:  data - the address of the data buffer to get data from; the data is added
 *                     immediately after the last data word previously written.
 *              size - the number of 16-bit words that will be added to the RAM image of the
 *                     current 4K RAM image of the NVM page being overwritten.
 * Returns:     MMGR_NO_ERROR - no error were detected.
 *              MMGR_ERROR    - an error occured when writing to the NVM.
 ********************************************************************************************/
ERR_RET mmgr_write_data( INT16U* data, INT16U size );


/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Adds new data words to the RAM image of a 4K memory page to be overwritten.
 *              When the end of the page is reached, the page is written to the NVM.  A call
 *              to mmgr_write_data_start() should be made prior to calling this function and
 *              a call to mmgr_write_data_finalize() should be made after the last
 *              mmgr_write_data() call.
 * Parameters:  data - the address of the data buffer to get data from; the data is added
 *                     immediately after the last data word previously written.
 *              size - the number of 16-bit words that will be added to the RAM image of the
 *                     current 4K RAM image of the NVM page being overwritten.
 * Returns:     MMGR_NO_ERROR - no error were detected.
 *              MMGR_ERROR    - an error occurred when writing to the NVM.
 ********************************************************************************************/
ERR_RET mmgr_write_configuration_data( INT16U* data, INT16U size );

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Updates flash memory based on the RAM buffer contents.  Called after making
 *              mmgr_write_data() calls;
 * Parameters:  None.
 * Returns:     MMGR_NO_ERROR - no error were detected.
 *              MMGR_ERROR    - an error occured when writing to the NVM.
 ********************************************************************************************/
ERR_RET mmgr_write_data_finalize( void );

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Copies a specified number of 16-bit words from the source address to the
 *              destination address.
 * Parameters:  p_dest - pointer to the destination to store the data being copied.
 *              src_addr - address (128K page number and offset) to read data from
 *              num_bytes - number of bytes that need to be read
 * Returns:     None.
 ********************************************************************************************/
void mmgr_memcpy( void* p_dest, MEM_ADDRESS_TYPE src_addr, INT16U num_words );

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Copies a specified number of 16-bit words at even addresses from the source
 *              address to the destination address.
 * Parameters:  p_dest - pointer to the destination to store the data being copied.
 *              src_addr - address (128K page number and offset) to read data from
 *              num_bytes - number of bytes that need to be read
 * Returns:     None.
 ********************************************************************************************/
void mmgr_memcpy_even( void* p_dest, MEM_ADDRESS_TYPE src_addr, INT16U num_words );

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Retrieves a word of data from the program flash memory.
 * Parameters:  address - address of data to read.
 *              p_value - pointer to the buffer to store a 16-bit word to.
 * Returns:     None.
 ********************************************************************************************/
void mmgr_get_program_word( INT32U address, INT16U* p_value );

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Writes boot mode setting to flash memory.
 * Parameters:  boot_mode - either application or maintenance mode can be selected.
 * Returns:     MMGR_NO_ERROR - no error has occured.
 *              MMGR_ERROR    - an error has occured.
 ********************************************************************************************/
ERR_RET mmgr_set_boot_mode( BOOT_MODE_TYPE boot_mode );

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Utility function to erase a 4K page of program flash memory.
 * Parameters:  mem_addr - 128K page number and offset into the page to address the 4K page
 *              to be erased.
 * Returns:     None.
 ********************************************************************************************/
void mmgr_erase_flash( MEM_ADDRESS_TYPE mem_addr );

/*********************************************************************************************
 * Recursive header block
 ********************************************************************************************/
#endif
