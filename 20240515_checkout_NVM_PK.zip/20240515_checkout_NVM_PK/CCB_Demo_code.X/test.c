/*
 * File:   test.c
 * Author: e40063636
 *
 * Created on January 31, 2024, 4:00 PM
 */
#include "test.h"
#define ADC_TEST 0

/* Duty cycle values for PWM in BLDC. */
#define MDC_0   9999 /* 0% duty cycle */

#define BRAKE_DISENGAGED    1
#define SOL_DUTY_CYCLE    (INT16U)(49999/2)

/* Port state driven to digital output pins */
#define PORT_OUT_LOW        0
#define PORT_OUT_HIGH       1

#define ADC_CONVERSION_FACTOR 0.806 /* 3300mv vref / 4096 steps */
#define SECONDS_PER_MINUTE          60ul
#define US_PER_SECOND               1000000ul
ECAN_HW_MESSAGE canMsg;

INT16U array[12];
volatile INT16U No_step;
void CAN_status();
void bldc_motor_run();
INT32U bldc_no_of_revolutions();
void rotaion_time();
void test() 
{
    GREEN_LED_PIN = PORT_OUT_LOW;
    RED_LED_PIN = PORT_OUT_HIGH;
    
    adcm_init();
    //pwm_ADCtrig_init();
   spi1_init();
   tmgr_init();
   bldc_init();
   pwm_slnd_init();
   i2c_init();
    ecan_init(0,0,0);// parameter yet to be implemented
   __builtin_enable_interrupts();
    while (1) {

#if defined(PWR_TEST)
        ENABLE_5V_PIN = PORT_OUT_HIGH;
        //--//printf("\r\n Check 5V_ENABLE is High \r\n");
        //--//printf("\r\n 5V_PGOOD Status %d\r\n", PGOOD_5V_PIN);
        //--//printf("\r\n FLT_TRIP Status %d\r\n", FLT_TRIP_PIN);
#endif   

#if defined(LED_TEST)
        int8_t led_cmd = 0;
        led_cmd = UART1_Get_cmd();
        if (led_cmd == 1) {
            GREEN_LED_PIN = PORT_OUT_HIGH;
            RED_LED_PIN = PORT_OUT_LOW;
        }

        if (led_cmd == 2) {
            GREEN_LED_PIN = PORT_OUT_LOW;
            RED_LED_PIN = PORT_OUT_HIGH;
        }

        if (led_cmd == 3) {
            GREEN_LED_PIN = PORT_OUT_HIGH;
            RED_LED_PIN = PORT_OUT_HIGH;
        }

        if (led_cmd == 4) {
            GREEN_LED_PIN = PORT_OUT_LOW;
            RED_LED_PIN = PORT_OUT_LOW;
        }
#endif

#if defined(ADC_TEST)
        static  INT8U channel = 0;
            INT16U AN_CH[4];
        const INT8U no_channels = 4;
        //ADCON3Lbits.SWCTRG = 1; //Single trigger is generated for all channels with the software
        AN_CH[channel] = ADC_raw_value(channel);
        int voltage = AN_CH[channel] * ADC_CONVERSION_FACTOR;
        if (channel == 0)
            printf("\r\n ADC channel AN0 [ISENSE]  : raw value %d , Voltage %d mv \r\n", AN_CH[channel], voltage);
        if (channel == 1)
            printf("\r\n ADC channel ANA1 [ISENSE_REF] : raw value %d , Voltage %d mv \r\n", AN_CH[channel], voltage);
        if (channel == 2)
            printf("\r\n ADC channel AN3 [SOL_VMON]  : raw value %d , Voltage %d mv \r\n", AN_CH[channel], voltage);
        if (channel == 3)
            printf("\r\n ADC channel AN9 [VMON]  : raw value %d , Voltage %d mv \r\n", AN_CH[channel], voltage);
        channel++;
        if (channel >= no_channels) {
            channel = 0;
        }
        //--//printf("\r\n current value %d\r\n", crnt_get_current_average());
#endif

#if defined(SOL_TEST)
            cmd = UART1_Get_cmd();
            if (cmd == 100) //command 100 to ON UART command should be 100s
                PG1DC = 4999;
            if (cmd == 200) //command 200 to OFF UART command should be 100s
                PG1DC = 0;
            while (PG1STATbits.UPDATE);
            PG1STATbits.UPDREQ = 1;
#endif

#if defined(HEF_TEST)
        ENABLE_5V_PIN = PORT_OUT_HIGH; // This will enable Hall sensor module
        //HEF1,HEF2,HEF3  =>RD5,RD6,RD7=>P90,P11,P89
        //--//printf("\r\n Hall Sensor HEF (HEF1,HEF2,HEF3=>Bit 2,Bit 1,Bit 0) 0x%x \r\n", HALL_SENSORS_READ);
#endif

#if defined(I2C_TEST)
        INT16S Temp = 0;
        i2c_exec();
        Temp = i2c_get_temp();
        //--//printf("\r\n Temperature : %d \r\n", Temp);
#endif

#if defined(UART_TEST)
        UART1_test(); //type command value from -32,768 to 32,767 followed By 'S'
        //'S' indicates the UART driver full command sent
#endif 
        
#if defined(CAN_TEST)
       //CAN loop Back test
       ECAN_HW_MESSAGE rxCanMsg;
       if (ecan_rx_message(&rxCanMsg) == true) 
       {
            ecan_tx_message(&rxCanMsg);
        }
        //--//printf("\r\n Send some CAN message and Verify the loop back \r\n");
#endif

        bldc_motor_run();
        i2c_temp_exec();
        ADC_Isense_RawAvg();
        rotaion_time();
    }
}



//To run the Motor
void bldc_motor_run()
{
    static bool new_msg = false;//consider only for disengage
    ECAN_HW_MESSAGE rxCanMsg;
    INT8U Brake = 0;
    INT32U temp = 0;
    //INT32U trigA = 0;
    INT32U value = 0;
    //INT16U volatile rev = 0;
    value = _bldc_drv_command(BLDC_OPERMODE_READ); //op mode
#if 0
    //check for normal mode reg:  Operation Mode Overview
    if (value & BLDC_DRIVE_MODE) {
        GREEN_LED_PIN = PORT_OUT_HIGH;
        RED_LED_PIN = PORT_OUT_LOW;
       
    } else {
        GREEN_LED_PIN = PORT_OUT_LOW;
        RED_LED_PIN = PORT_OUT_HIGH;

#ifdef UART_DEBUG_BLDC
        INT8U mode;
        mode = bldc_drv_get_OperMode();
        //--//printf("\r\n BLDC Driver Mode (Operation Mode Overview reg) %d \r\n",mode);
#endif
    }
#endif
    static int a =1;
    if (ecan_rx_message(&rxCanMsg) == true) 
    {
        if (1 || (rxCanMsg.Source == 0x03 && rxCanMsg.Dest == 0x05)) /*TBD CAN ID to be implemented*/
        {
           // printf("\r\n rx source %x destination %x\r\n",rxCanMsg.Source,rxCanMsg.Dest);
            Brake = rxCanMsg.D[3];
            Brake = 1;
            /*If Break disengaged then only consider duty cycle*/
            if (Brake == BRAKE_DISENGAGED)
            {
                PG1DC = SOL_DUTY_CYCLE; //25% Duty cycle
                while (PG1STATbits.UPDATE);
                PG1STATbits.UPDREQ = 1;

                delay(1000);
                //rxCanMsg.D[0] = 0;
               // pwm_change_drive_direction(rxCanMsg.D[0]); /* rxCanMsg.D[0] value has to be 0 or 1 */
                //rxCanMsg.D[1] = 1;
                temp = (INT16U) rxCanMsg.D[1];
                temp = temp * MDC_0;
               // trigA = temp;
                temp = (INT32U) temp / 100;
                temp = (INT16U) (MDC_0 - (INT16U) temp);
                MDC = temp;
                PG8TRIGA = 9840;//to rigger at the end just before 1 micro second at the end as the Mosfet on at the end(62.5/9999*159))
                PG2STATbits.UPDREQ = 1;
                PG3STATbits.UPDREQ = 1;
                PG4STATbits.UPDREQ = 1;
                PG8STATbits.UPDREQ = 1;
               // printf("\r\n ------------Speed in duty cycle %d---------- \r\n",rxCanMsg.D[1]);
                //curr_rev = hall_get_position_change_steps_test();//bldc_no_of_revolutions();
               // curr_rev = No_step;
                //new_msg = true;
                a=0;
            }
            else //Otherwise stop the motor and enage the brake
            {
                MDC = MDC_0;
                PG2STATbits.UPDREQ = 1;
                PG3STATbits.UPDREQ = 1;
                PG4STATbits.UPDREQ = 1;
                PG8STATbits.UPDREQ = 1;

                PG1DC = 0; //Brake engage
                while (PG1STATbits.UPDATE);
                PG1STATbits.UPDREQ = 1;
                new_msg = false;
            }
        }
        //CAN_status();//send only when any CAN message is received
    }
#if 0
    if(new_msg = true)
    {
         int a;
        if(req_rev>0)
        {
            rev = hall_get_position_change_steps();//bldc_no_of_revolutions();
            INT16U pos = 6*req_rev;
            INT16U temp = rev - curr_rev;
            if(No_step -  curr_rev <= pos +3)// can behave odd during over flow
            {
                //continue motor run
               
                a++;
            }
            else
            {
                MDC = MDC_0;
                PG2STATbits.UPDREQ = 1;
                PG3STATbits.UPDREQ = 1;
                PG4STATbits.UPDREQ = 1;

                PG1DC = 0; //Brake engage
                while (PG1STATbits.UPDATE);
                PG1STATbits.UPDREQ = 1;
                new_msg = false;
                req_rev = 0;
                curr_rev = 0;
            }
        }
    }
#endif
}

INT32U bldc_no_of_revolutions()
{
    INT32U no_rev = 0;
    INT32U no_pos = 6;/* Total number of possible Hall sensor input signal combinations */
    no_rev = hall_get_position_change_steps();
    no_rev = (INT32U)no_rev/no_pos;
    return no_rev;
}

INT32S * p_time = NULL;

void rotaion_time()
{ 
    INT16S rpm;
    INT16U b = 0;
    INT32U time = 0; 
    p_time = hall_get_rotation_time();
    time = *p_time * 0.8; //u sec
    time = (SECONDS_PER_MINUTE * US_PER_SECOND) / time;
    rpm = (INT16S)time;
  //  a = CCP1TMRL;
    b = hall_get_position_change_steps();
    //delta = (INT16U)(b - prev);
    //--//printf("\r\n RPM : %d  steps %d \r\n",rpm,b);
}
