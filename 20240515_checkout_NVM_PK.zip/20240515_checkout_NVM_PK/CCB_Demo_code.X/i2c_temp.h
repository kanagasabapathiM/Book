/*
 Author(s): Michael Ansolis
 Status: Preliminary
 Release Date:
 Revision:
 Description: Header file for the Actuator/UAP I2C module.
 */

#ifndef I2C_H
#define	I2C_H

/*********************************************************************************************
Includes
*********************************************************************************************/
#include "typedef.h"

/*********************************************************************************************
 * Function declarations
 ********************************************************************************************/

/*********************************************************************************************
 * Author(s):   Michael Ansolis
 * Description: Initializes the I2C module.
 * Parameters:  None
 * Returns:     INIT_FAILED - Initialization failed (failed to read 85 degrees from thermometer).
 *              NO_ERROR    - Initialization succeeded.
*********************************************************************************************/
ERR_RET i2c_init( void );

/*********************************************************************************************
 * Author(s):   Michael Ansolis
 * Description: Performs periodic processing for the I2C module.
 * Parameters:  None
 * Returns:     None
*********************************************************************************************/
void i2c_temp_exec();

/*********************************************************************************************
 * Author(s):   Michael Ansolis
 * Description: Returns the temperature value from the digital thermometer used in the BLDC motor.
 * Parameters:  None
 * Returns:     16-bit signed integer temperature value in degrees Celsius
*********************************************************************************************/
INT16S i2c_get_temp();

#endif	/*I2C_H */
