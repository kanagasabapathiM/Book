/*
 Author(s):    Jonathan R. Saliers
 Status:       Preliminary
 Release Date:
 Revision:
 Description:  Definitions for the Utility module.
 */

/*********************************************************************************************
Includes
*********************************************************************************************/
#include <xc.h>
#include <math.h>
#include "can.h"
#include "can_catalog.h"
#include "global.h"
#include "timer_manager.h"
#include "utility.h"

/*********************************************************************************************
Private Preprocessor definitions
*********************************************************************************************/

/* The length of the arctangent look up table array. */
#define NUM_TANGENT_LUT_MEMBERS     91

/* The length of the square root look up table array. */
#define NUM_SQRT_LUT_MEMBERS        256
/* The square root look up table array member names. */
typedef struct sqrt_lookup_entry_type
{
    INT32S squared;
    INT32S sq_root;
} SQRT_LOOKUP_ENTRY_TYPE;

/*********************************************************************************************
Global Variable definitions
*********************************************************************************************/
const FP32 G_tangent_lut[NUM_TANGENT_LUT_MEMBERS] =
    /*0 */  {0,
             /*1 */  0.017455065,
             /*2 */  0.034920769,
             /*3 */  0.052407779,
             /*4 */  0.069926812,
             /*5 */  0.087488664,
             /*6 */  0.105104235,
             /*7 */  0.122784561,
             /*8 */  0.140540835,
             /*9 */  0.15838444,
             /*10*/  0.176326981,
             /*11*/  0.194380309,
             /*12*/  0.212556562,
             /*13*/  0.230868191,
             /*14*/  0.249328003,
             /*15*/  0.267949192,
             /*16*/  0.286745386,
             /*17*/  0.305730681,
             /*18*/  0.324919696,
             /*19*/  0.344327613,
             /*20*/  0.363970234,
             /*21*/  0.383864035,
             /*22*/  0.404026226,
             /*23*/  0.424474816,
             /*24*/  0.445228685,
             /*25*/  0.466307658,
             /*26*/  0.487732589,
             /*27*/  0.509525449,
             /*28*/  0.531709432,
             /*29*/  0.554309051,
             /*30*/  0.577350269,
             /*31*/  0.600860619,
             /*32*/  0.624869352,
             /*33*/  0.649407593,
             /*34*/  0.674508517,
             /*35*/  0.700207538,
             /*36*/  0.726542528,
             /*37*/  0.75355405,
             /*38*/  0.781285627,
             /*39*/  0.809784033,
             /*40*/  0.839099631,
             /*41*/  0.869286738,
             /*42*/  0.900404044,
             /*43*/  0.932515086,
             /*44*/  0.965688775,
             /*45*/  1,
             /*46*/  1.035530314,
             /*47*/  1.07236871,
             /*48*/  1.110612515,
             /*49*/  1.150368407,
             /*50*/  1.191753593,
             /*51*/  1.234897157,
             /*52*/  1.279941632,
             /*53*/  1.327044822,
             /*54*/  1.37638192,
             /*55*/  1.428148007,
             /*56*/  1.482560969,
             /*57*/  1.539864964,
             /*58*/  1.600334529,
             /*59*/  1.664279482,
             /*60*/  1.732050808,
             /*61*/  1.804047755,
             /*62*/  1.880726465,
             /*63*/  1.962610506,
             /*64*/  2.050303842,
             /*65*/  2.144506921,
             /*66*/  2.246036774,
             /*67*/  2.355852366,
             /*68*/  2.475086853,
             /*69*/  2.605089065,
             /*70*/  2.747477419,
             /*71*/  2.904210878,
             /*72*/  3.077683537,
             /*73*/  3.270852618,
             /*74*/  3.487414444,
             /*75*/  3.732050808,
             /*76*/  4.010780934,
             /*77*/  4.331475874,
             /*78*/  4.704630109,
             /*79*/  5.144554016,
             /*80*/  5.67128182,
             /*81*/  6.313751515,
             /*82*/  7.115369722,
             /*83*/  8.144346428,
             /*84*/  9.514364454,
             /*85*/  11.4300523,
             /*86*/  14.30066626,
             /*87*/  19.08113669,
             /*88*/  28.63625328,
             /*89*/  57.28996163,
             /*90*/  1.63246E+16
            };
/* Define a lookup table for integer square root approximation function */
/* The squared column is (n+0.499)**2 to round off to the nearest integer */
const SQRT_LOOKUP_ENTRY_TYPE G_sqrt_lut[NUM_SQRT_LUT_MEMBERS] =
    { /* squared, root */
        {      0,    0 },
        {      2,    1 },
        {      6,    2 },
        {     12,    3 },
        {     20,    4 },
        {     30,    5 },
        {     42,    6 },
        {     56,    7 },
        {     72,    8 },
        {     90,    9 },
        {    110,   10 },
        {    132,   11 },
        {    156,   12 },
        {    182,   13 },
        {    210,   14 },
        {    240,   15 },
        {    272,   16 },
        {    306,   17 },
        {    342,   18 },
        {    380,   19 },
        {    420,   20 },
        {    462,   21 },
        {    506,   22 },
        {    552,   23 },
        {    600,   24 },
        {    650,   25 },
        {    702,   26 },
        {    756,   27 },
        {    812,   28 },
        {    870,   29 },
        {    930,   30 },
        {    992,   31 },
        {   1056,   32 },
        {   1122,   33 },
        {   1190,   34 },
        {   1260,   35 },
        {   1332,   36 },
        {   1406,   37 },
        {   1482,   38 },
        {   1560,   39 },
        {   1640,   40 },
        {   1722,   41 },
        {   1806,   42 },
        {   1892,   43 },
        {   1980,   44 },
        {   2070,   45 },
        {   2162,   46 },
        {   2256,   47 },
        {   2352,   48 },
        {   2450,   49 },
        {   2550,   50 },
        {   2652,   51 },
        {   2756,   52 },
        {   2862,   53 },
        {   2970,   54 },
        {   3080,   55 },
        {   3192,   56 },
        {   3306,   57 },
        {   3422,   58 },
        {   3540,   59 },
        {   3660,   60 },
        {   3782,   61 },
        {   3906,   62 },
        {   4032,   63 },
        {   4160,   64 },
        {   4290,   65 },
        {   4422,   66 },
        {   4556,   67 },
        {   4692,   68 },
        {   4830,   69 },
        {   4970,   70 },
        {   5112,   71 },
        {   5256,   72 },
        {   5402,   73 },
        {   5550,   74 },
        {   5700,   75 },
        {   5852,   76 },
        {   6006,   77 },
        {   6162,   78 },
        {   6320,   79 },
        {   6480,   80 },
        {   6642,   81 },
        {   6806,   82 },
        {   6972,   83 },
        {   7140,   84 },
        {   7310,   85 },
        {   7482,   86 },
        {   7656,   87 },
        {   7832,   88 },
        {   8010,   89 },
        {   8190,   90 },
        {   8372,   91 },
        {   8556,   92 },
        {   8742,   93 },
        {   8930,   94 },
        {   9120,   95 },
        {   9312,   96 },
        {   9506,   97 },
        {   9702,   98 },
        {   9900,   99 },
        {  10100,  100 },
        {  10302,  101 },
        {  10506,  102 },
        {  10712,  103 },
        {  10920,  104 },
        {  11130,  105 },
        {  11342,  106 },
        {  11556,  107 },
        {  11772,  108 },
        {  11990,  109 },
        {  12210,  110 },
        {  12432,  111 },
        {  12656,  112 },
        {  12882,  113 },
        {  13110,  114 },
        {  13340,  115 },
        {  13572,  116 },
        {  13806,  117 },
        {  14042,  118 },
        {  14280,  119 },
        {  14520,  120 },
        {  14762,  121 },
        {  15006,  122 },
        {  15252,  123 },
        {  15500,  124 },
        {  15750,  125 },
        {  16002,  126 },
        {  16256,  127 },
        {  16512,  128 },
        {  16770,  129 },
        {  17030,  130 },
        {  17292,  131 },
        {  17556,  132 },
        {  17822,  133 },
        {  18090,  134 },
        {  18360,  135 },
        {  18632,  136 },
        {  18906,  137 },
        {  19182,  138 },
        {  19460,  139 },
        {  19740,  140 },
        {  20022,  141 },
        {  20306,  142 },
        {  20592,  143 },
        {  20880,  144 },
        {  21170,  145 },
        {  21462,  146 },
        {  21756,  147 },
        {  22052,  148 },
        {  22350,  149 },
        {  22650,  150 },
        {  22952,  151 },
        {  23256,  152 },
        {  23562,  153 },
        {  23870,  154 },
        {  24180,  155 },
        {  24492,  156 },
        {  24806,  157 },
        {  25122,  158 },
        {  25440,  159 },
        {  25760,  160 },
        {  26082,  161 },
        {  26406,  162 },
        {  26732,  163 },
        {  27060,  164 },
        {  27390,  165 },
        {  27722,  166 },
        {  28056,  167 },
        {  28392,  168 },
        {  28730,  169 },
        {  29070,  170 },
        {  29412,  171 },
        {  29756,  172 },
        {  30102,  173 },
        {  30450,  174 },
        {  30800,  175 },
        {  31152,  176 },
        {  31506,  177 },
        {  31862,  178 },
        {  32220,  179 },
        {  32580,  180 },
        {  32942,  181 },
        {  33306,  182 },
        {  33672,  183 },
        {  34040,  184 },
        {  34410,  185 },
        {  34782,  186 },
        {  35156,  187 },
        {  35532,  188 },
        {  35910,  189 },
        {  36290,  190 },
        {  36672,  191 },
        {  37056,  192 },
        {  37442,  193 },
        {  37830,  194 },
        {  38220,  195 },
        {  38612,  196 },
        {  39006,  197 },
        {  39402,  198 },
        {  39800,  199 },
        {  40200,  200 },
        {  40602,  201 },
        {  41006,  202 },
        {  41412,  203 },
        {  41820,  204 },
        {  42230,  205 },
        {  42642,  206 },
        {  43056,  207 },
        {  43472,  208 },
        {  43890,  209 },
        {  44310,  210 },
        {  44732,  211 },
        {  45156,  212 },
        {  45582,  213 },
        {  46010,  214 },
        {  46440,  215 },
        {  46872,  216 },
        {  47306,  217 },
        {  47742,  218 },
        {  48180,  219 },
        {  48620,  220 },
        {  49062,  221 },
        {  49506,  222 },
        {  49952,  223 },
        {  50400,  224 },
        {  50850,  225 },
        {  51302,  226 },
        {  51756,  227 },
        {  52212,  228 },
        {  52670,  229 },
        {  53130,  230 },
        {  53592,  231 },
        {  54056,  232 },
        {  54522,  233 },
        {  54990,  234 },
        {  55460,  235 },
        {  55932,  236 },
        {  56406,  237 },
        {  56882,  238 },
        {  57360,  239 },
        {  57840,  240 },
        {  58322,  241 },
        {  58806,  242 },
        {  59292,  243 },
        {  59780,  244 },
        {  60270,  245 },
        {  60762,  246 },
        {  61256,  247 },
        {  61752,  248 },
        {  62250,  249 },
        {  62750,  250 },
        {  63252,  251 },
        {  63756,  252 },
        {  64262,  253 },
        {  64770,  254 },
        {  65280,  255 },
    };

/*********************************************************************************************
Function definitions
*********************************************************************************************/
/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: memset function to replace the standard library version. This function is needed
             to satisfy DO-178 review requirements.
Parameters:  p_dest - a pointer to the first member of the target memory location
                      into which the value is to be set.
             val    - the unsigned eight bit value to which all eight bit members of the target
                      memory are to be set
             length - the length in bytes of the destination memory to be set.
Returns:     None
*********************************************************************************************/
void util_memset(void* p_dest, INT8U val, INT16U length)
{
    INT8U* p_int8u = (INT8U*) p_dest;
    while (length-- > 0)
    {
        *p_int8u++ = val;
    }
    return;
}


/*********************************************************************************************
Author(s):   Jonathan R. Saliers
Description: memcpy function to replace the standard library version. This function is needed
             to satisfy DO-178 review requirements.
Parameters:  p_dest - a pointer to the first  member of the target memory location
                      into which the eight values are to be copied.
             p_src  - A pointer to the first member of the memory from which the eight bit
                     values are to be copied.
             length - the length in bytes of the destination memory space.
Returns:     None
*********************************************************************************************/
void util_memcpy(void* p_dest, const void* p_src, INT16U length)
{
    INT8U* p_int8u_dest = (INT8U*) p_dest;
    const INT8U* p_int8u_src = (INT8U*) p_src;
    while (length-- > 0)
    {
        *p_int8u_dest++ = *p_int8u_src++;
    }
    return;
}


/*********************************************************************************************
 * Author(s):   Mark Farver
 * Description: memcpy function that reads from program flash
 * Parameters:  p_dest - a pointer to the first  member of the target memory location
 *                       into which the values are to be copied.
 *              prog_start_addr  - Absolute (24 bit) start address in program memory
 *                       to start copy at.
 *              length - the length in bytes of the destination memory space.
 * Returns:     None
*********************************************************************************************/
void util_memcpy_from_prog(void* p_dest, INT32U prog_start_addr, INT16U length)
{
    INT16U value;

    /* Save the current TBLPAG register value. */
    INT16U saved_TBLPAG = TBLPAG;
    INT32U data_offset = prog_start_addr % PROG_MEM_PAGE_SIZE;
    INT32U end_offset = (INT32U)data_offset  + (INT32U)length;
    INT8U* p_int8u_dest = (INT8U*) p_dest;

    /* Set program memory page number */
    TBLPAG = prog_start_addr / PROG_MEM_PAGE_SIZE;

    while (data_offset < end_offset )
    {
        value = __builtin_tblrdl( data_offset );
        *p_int8u_dest++ = value & 0xFF;
        ++data_offset;
        if (data_offset < end_offset)
        {
            *p_int8u_dest++ = (value>>8) & 0xFF;
        }
        ++data_offset;
    }

    /* Restore TBLPAG register. */
    TBLPAG = saved_TBLPAG;
}



/*********************************************************************************************
Author(s):   Michael Ansolis
Description: atan function similar to the C math.h version. This function is needed
             to satisfy DO-178 review requirements. NOTE THAT THIS FUNCTION IS NOT A DIRECT
             REPLACEMENT FOR THE LIBRARY FUNCTION. IT RETURNS THE ARCTANGENT OF THE GIVEN
             TANGENT IN DEGREES - NOT RADIANS AS THE LIBRARY FUNCTION DOES.
Parameters:  tangent - The tangent (sine/cosine) whose arctangent is needed.
Returns:     The arctangent of the given tangent in degrees in the range 90 to -90.
*********************************************************************************************/
INT16S util_atan(FP32 tangent)
{
    INT16S sign_multiplier = 1;
    INT16S low = 0;
    INT16S high = NUM_TANGENT_LUT_MEMBERS - 1;
    INT16S arctan_candidate;

    /*
     Our tangent lookup table contains tangents for the integer degrees between 0 and 90
     degrees inclusive. Therefore our table contains only positive values. We can still use it
     to find the arctangent of a negative tangent value if we multiply the tangent value by -1
     to make it positive, find the closest match in the table and then multiply the resulting
     arctangent by -1 to make it negative. (The arctangent will have the same sign as the
     supplied tangent value.) So if tangent contains a negative number multiply it by -1 to
     make it positive.
     */
    if (tangent < 0)
    {
        /*
         set sign_multipier to -1 so it can be used to flip the sign of the arctangent value
         before returning it.
         */
        sign_multiplier = -1;

        tangent *= (FP32)sign_multiplier;
    }

    while (low < high)
    {
        /*
         Do a binary search on the tangent look up table to find the tangent value that
         that is closest to the value passed into the function. Note that the index of each
         member of the tangent array is the arctangent of that members contents.
         */
        /* set arc_tan_candidate to the middle of the range between low and high. */
        arctan_candidate = (low + high) >> 1;

        if (tangent > G_tangent_lut[arctan_candidate])
        {
            low = arctan_candidate + 1;
        }
        else if (tangent < G_tangent_lut[arctan_candidate])
        {
            high = arctan_candidate - 1;
        }
        else
        {
            /* We apparently found an exact match. We can stop here because arctan_candidate
               contains the arctangent of the tangent value that was passed into this function. */
            low = arctan_candidate;
            break;
        }
    }

    if (tangent < G_tangent_lut[low])
    {
        low--;
    }

    /* At this point low contains the index of either an exact match or the closest
       match in the tangent lookup table to the passed in tangent value. */
    return (low * sign_multiplier);
}


/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: abs() function to replace the C stdlib.h version. This function is needed
 *              to satisfy DO-178 review requirements. Returns the absolute value of the given
 *              integer.
 * Parameters:  number - A signed integer number.
 * Returns:     The absolute value of the given integer.
*********************************************************************************************/
INT32S util_abs(INT32S number)
{
    return (number < 0) ? -number : number;
}


/*********************************************************************************************
 * Author(s): mfarver
 * Description: memcmp function to replace the standard library version. This function is needed
 *  to satisfy DO-178 review requirements.
 * Parameters:  Ptr1 - a pointer to the first location of the left value to compare
 *              Ptr2  - a pointer to the first location of the right value to compare
 *              length - the length in bytes to compare.
 * Returns:     0 if equal, nonzero if not equal.
*********************************************************************************************/
INT16U util_memcmp(const void *Ptr1, const void *Ptr2, INT16U Count)
{
    INT16U v = 0;
    INT8U *p1 = (INT8U *)Ptr1;
    INT8U *p2 = (INT8U *)Ptr2;

    while(Count-- > 0 && v == 0)
    {
        v = *(p1++) - *(p2++);
    }
    return v;
}

/*********************************************************************************************
 * Author(s): mfarver
 * Description: Endianness swap of a 16bit integer.  pic is little endian, CAN
 *              frames are big endian.
 * Parameters:  num - value to swap
 * Returns:     16 bit integer, reverse byte order.
*********************************************************************************************/
INT16U util_byteswap16(INT16U num)
{
    return (num>>8) | (num<<8);
}

/*********************************************************************************************
 * Author(s): mfarver
 * Description: Endianness swap of a 32bit integer.  pic is little endian, CAN
 *              frames are big endian.
 * Parameters:  num - value to swap
 * Returns:     32 bit integer, reverse byte order.
*********************************************************************************************/
INT32U util_byteswap32(INT32U num)
{
    return ((num>>24)&0xff) |       /* move byte 3 to byte 0 */
           ((num<<8)&0xff0000) |    /* move byte 1 to byte 2 */
           ((num>>8)&0xff00) |      /* move byte 2 to byte 1 */
           ((num<<24)&0xff000000);  /* byte 0 to byte 3 */
}

/*********************************************************************************************
 * Author(s): mfarver
 * Description: Convert a 6 byte hardware part number to ASCII
 * Parameters:  hwpn: pointer to 6 byte packed hardware part number
 *              hwpnstr: pointer to 16 byte ASCII result buffer.
 *              max_strlen: Size of the hwpnstr buffer
 * Returns:     Length of string
*********************************************************************************************/
INT8U util_hwpn2str(HW_PN_TYPE * hwpn, INT8U * hwpnstr, INT8U max_strlen)
{
    INT8U i;
    INT8U index = 0;

    if ( HW_PN_NUM_BYTES * 2 + 1 > max_strlen ) return 0;

    /* i=1 becuase we discard the first byte */
    for (i=1; i < HW_PN_NUM_BYTES; ++i)
    {
        hwpnstr[index++] = (hwpn->bytes[i] % 100) / 10 + '0';
        if (index == 7)
        {
            hwpnstr[index++] = '-';
        }
        hwpnstr[index++] = (hwpn->bytes[i] % 10) + '0';
    }
    return --index;
}

/*********************************************************************************************
 * Author(s): mfarver
 * Description: Convert a 8 byte software part number to ASCII (last two bytes ignored)
 * Parameters:  swpn: pointer to 8 byte packed hardware part number
 *              swpnstr: pointer to 16 byte ASCII result buffer.
 *              max_strlen: Size of the swpnstr buffer
 * Returns:     Length of string
*********************************************************************************************/
INT8U util_swpn2str(SW_PN_TYPE * swpn, INT8U * swpnstr, INT8U max_strlen)
{
    INT8U i;
    INT8U index = 0;

    /* First 4 bytes are 0-99 and are concatenated together ( 8 bytes )
     * Bytes 5 and 6 are already ASCII encoded (2 bytes)
     * For a total of 10 bytes in the response */
    if ( 4 * 2 + 2 > max_strlen) return 0;

    for (i=0; i < 4; ++i)   /* Last two bytes unused */
    {
        if (i != 0)
        {
            swpnstr[index++] = (swpn->bytes[i] % 100) / 10 + '0';
        }
        swpnstr[index++] = (swpn->bytes[i] % 10) + '0';
    }
    swpnstr[index++] = swpn->bytes[6]; /* Last two bytes are ASCII already*/
    swpnstr[index++] = swpn->bytes[7]; /* Last two bytes are ASCII already*/
    return index--;
}

/*********************************************************************************************
 * Author(s): mfarver
 * Description: Convert a 4 bit nybble into ASCII 0-9A-F
 * Parameters:  digit: 4 bit value to convert
 * Returns:     ASCII value 0-9 or A-F
*********************************************************************************************/
INT8U util_nybbletohexchar(INT8U digit)
{
    INT8U result;
    digit &= 0x0F;
    if ( digit < 0xA )
    {
        result = digit + (INT8U)'0';
    }
    else
    {
        result = (digit - 0xA) + (INT8U)'A';
    }
    return result;
}

/*********************************************************************************************
 * Author(s): mfarver
 * Description: Convert a ASCII text character into 4 bit nybble
 * Parameters:  hexchar: ASCII character 0-9 or A-F
 * Returns:     4 bit nybble value, or -1 if failed.
*********************************************************************************************/
INT8S util_hexchartonybble(INT8U hexchar)
{
    if ( (hexchar >= '0') && (hexchar <= '9' ) )
    {
        return hexchar - (INT8U)'0';
    }
    else if ( hexchar >= 'A' && hexchar <= 'F' )
    {
        return (hexchar - (INT8U)'A') + 0xA;
    }
    else
    {
        return -1;
    }
}

/*********************************************************************************************
* Author(s):   E. Miller
* Description: Computes square root by using IEEE 754 floating point representation.
*              Cast to integer, shift to perform root, apply correction and cast to float to obtain first approximation
*              Two iteration Newton method to improve result
* Parameters:  x - The number for which the square root is requested
* Returns:     FP32: 0.0 if x <=0, sqrt(x) otherwise
****************************r*****************************************************************/
INT32S util_sqrt( INT32S num )
{
             FP32 x = (FP32)num;
    volatile FP32   f1, f2;
             INT32U temp;
#define UTIL_SQRT_CORRECTION 0x1FBB4EAFul
#define UTIL_SQRT_DIV_4      0.25f
#define UTIL_SQRT_FLOAT_0    0.0f

    if( x > UTIL_SQRT_FLOAT_0 )
    {
        *((FP32 *)&temp) = x;                          // Cast to integer
        temp = ( temp >> 1ul ) + UTIL_SQRT_CORRECTION; // Perform square root, correct exponent & mantissa
        f1 =  *((FP32 *)&temp);                        // Cast to float
        f2 =  x / f1;                                  // Get paired root. One is under exact value, one is over
        f1 += f2;                                      // Twice average
        f2 =  x / f1;                                  // sqrt(x) / 2
        f1 *= UTIL_SQRT_DIV_4;                         // sqrt(x) / 2 (also)
        f2 += f1;                                      // sum is sqrt(x)
    }
    else
    {
        f2 =  UTIL_SQRT_FLOAT_0;                       // Undefined, return 0
    }
    return (INT32S)f2;                                 // Return result
}

void util_debug_can( INT8U d0, INT8U d1, INT8U d2, INT8U d3, INT8U d4, INT8U d5, INT8U d6, INT8U d7 )
{
    ECAN_HW_MESSAGE msg = {0};
    
    msg.Source = 0x00;
    msg.Dest = BROADCAST_DEST_CAN_ID;
    ecan_fill_sid( &msg, ECAN_LAB_MODE_DEBUG_SID );
    msg.DLC = 8;
    msg.D[0] = d0;
    msg.D[1] = d1;
    msg.D[2] = d2;
    msg.D[3] = d3;
    msg.D[4] = d4;
    msg.D[5] = d5;
    msg.D[6] = d6;
    msg.D[7] = d7;
    (void)ecan_tx_message(&msg);
    
    /* Delay so message can be sent */
    INT32U wait_timeout = tmgr_get_system_time() + 2;
    INT32U current_time = tmgr_get_system_time();
    while( current_time < wait_timeout )
    {
        current_time = tmgr_get_system_time();
    }
    
    return;
}

//just for delay in us 
void delay(unsigned int delay) {
    unsigned int i = 0;
    while (i < delay) {
        i++;
    }
}