/*********************************************************************************************
 *
 * NOTICE - PROPRIETARY INFORMATION COPYRIGHT � 2018
 *
 * B/E AEROSPACE CONSIDERS THIS DOCUMENT TO CONTAIN INFORMATION OF A
 * PROPRIETARY NATURE.  THEREFORE, THE RECEIVER OF THIS DOCUMENT IS REQUESTED
 * TO TREAT IT ACCORDINGLY AND TO NOT TRANSMIT, REVEAL, OR DISCLOSE IT OR ANY
 * PART THEREOF WITHOUT EXPRESS WRITTEN PERMISSION OF B/E AEROSPACE.
 * DISTRIBUTION AND/OR REPRODUCTION OF THIS DOCUMENT (IN WHOLE OR IN PART)
 * OUTSIDE OF B/E AEROSPACE MUST BE AUTHORIZED BY B/E AEROSPACE MANAGEMENT.
 *
 *********************************************************************************************
 *
 * Author:      M VanderZouwen
 * Status:	    Preliminary
 * Date:        ??/??/??
 * Revision:    0.1
 * Description: Header file for the Application Program Interface between the
 *              project-level common Event Manager and LRU-specific function
 *              calls, definitions and file names.
 *
 *********************************************************************************************
 *
 * Revision History:
 *      0.1 MVZ     Initial creation
 *
 ********************************************************************************************/

/*********************************************************************************************
 * Recursive header blocker
 ********************************************************************************************/
#ifndef EVENT_API_H
#define EVENT_API_H

/*********************************************************************************************
 * Included files
 ********************************************************************************************/
#include "global.h"
#include "can_catalog.h"
#include "communications.h"
#include "configuration.h"
#include "config-table-addrs.h"
#include "cpu.h"
#include "crc32-new.h"
#include "dataflash.h"
#include "can.h"
#include "timer_manager.h"
#include "utility.h"

/*********************************************************************************************
 * Module Preprocessor definitions
 ********************************************************************************************/
 /*  Event Manager name                 LRU software name */
#define CAN_EVENT_CATEGORY              ECAN_MAINTENANCE_REQUEST_CODES
#define CAN_EVENT_REPORT_CLEAR_FRAME    ECAN_EVENT_REPORT_CLEAR_FRAME
#define CAN_LRU_STATUS_FRAME            ECAN_LRU_STATUS_FRAME
#define CAN_MAINTENANCE_REQUEST_FRAME   ECAN_MAINTENANCE_REQUEST_FRAME
#define DEST_CAN_ID                     G_scm_can_id
#define INIT_ADDRESS                    0
#define LRU_CAN_ID                      ECAN_LRU_CAN_ID

#define calc_CRC32(buf, siz, crc)       crc32new_buffer(buf, siz, crc)
#define Get_Cfg_Table(tbl, buf)         cfg_load_parameters(tbl, buf)
#define get_status_frame(frame)         comm_LRU_status_frame(frame)
#define get_system_mSec()               tmgr_get_system_time()
#define Init_Address()                  0
#define Log_Device_Init()               flash_init()
#define Log_Erase()                     flash_erase_chip()
#define Log_Read(buf, addr, siz)        flash_read(buf, addr, siz)
#define Log_Write(buf, addr, siz)       flash_write(buf, addr, siz)
#define Send_Status_Event()             comm_send_status_event()
#define Reset_Watchdog()                cpu_service_watchdog()

/*********************************************************************************************
 * Module type definitions
 ********************************************************************************************/
typedef struct
{
    INTU Dest;                   /* Destination CAN ID code */
    INTU Source;                 /* Source CAN ID code */
    INTU SID;                    /* Server ID code */
    INTU DLC;                    /* Data Length Code */
    INT8U D[CAN_NUM_DATA_BYTES]; /* Data Bytes */
} CAN_MSG_PACKET;

/*********************************************************************************************
 * Module function declarations
 ********************************************************************************************/
/*********************************************************************************************
 * Author(s):   M VanderZouwen
 * Description: Translates generic CAN message packet to LRU specific CAN
 *              message and passes it to the CAN interface unit software
 *
 *********************************************************************************************/
void CAN_Tx_Message( CAN_MSG_PACKET* msg );      /* Pointer to message packet */

/*********************************************************************************************
 * Author(s):   M VanderZouwen
 * Description: Calculates the total number of Event Records that will fit in
 *              the Event Log file device
 *
 *********************************************************************************************/
INT32U Log_Device_Total_Records( void );

/*********************************************************************************************
 * Author(s):   T Pashak
 * Description: Saves the event consolidation parameters to program memory. Used
 *              for saving when the LRU prepares to shut down or reboot.
 * Parameters:  table       - pointer to Event consolidation table
 * Returns:     NO_ERROR    - The table was saved successfully.
 *              
 *********************************************************************************************/
ERR_RET Save_Table( void* table );

/*********************************************************************************************
 * Author(s):   Jonathan R. Saliers
 * Description: Retrieves the specified log entry indexed from the end of the log.
 * Parameters:  p_log - pointer to the log to be retrieved.
 *              num_logs_from_end - 0=last log, indexed in reverse.
 * Returns:     ERR_RET - indicates whether the read was successful (NO_ERROR)
 *              or not (ERR_FAILURE).
 *********************************************************************************************/
ERR_RET Log_Read_From_End( INT8U * p_log, INT32U num_logs_from_end );

/*********************************************************************************************
 * Recursive header blocker
 ********************************************************************************************/
#endif  /* EVENT_API_H */
