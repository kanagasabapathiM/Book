/*
Author(s): Dave Zielinski <dzielinski@righthandtech.com>
Status: Preliminary
Release Date:
Revision:
Description: Header for BLDC module. Contains interface for BLDC motor control.
*/

#ifndef BLDC_H
#define BLDC_H

/*********************************************************************************************
Includes
*********************************************************************************************/
#include "typedef.h"

/*********************************************************************************************
Type Definitions
*********************************************************************************************/
/* Description: indicates if the BLDC rotor is stopped */
typedef enum
{
    BLDC_IS_STOPPED,
    BLDC_NOT_STOPPED
}
BLDC_STOPPED_T;

/*********************************************************************************************
Preprocessor definitions
*********************************************************************************************/

/*********************************************************************************************
Function declarations
*********************************************************************************************/

/*********************************************************************************************
 * Author(s):   Dave Zielinski
 * Description: Initializes the this module.
 * Parameters:  None
 * Returns:     NO_ERROR - no error occured while initializing the module.
 *              ERR_FAILURE - an error was detected while initializing the module.
*********************************************************************************************/
ERR_RET bldc_init(void);

/*********************************************************************************************
Author(s):   Dave Zielinski
Description: Periodic execution function for BLDC module.  Checks if we've crossed a 10ms time
             boundary and update the persistent actual.
             RPM value.
Parameters:  None
Returns:     None
*********************************************************************************************/
void bldc_exec(void);

/*********************************************************************************************
Author(s):   Dave Zielinski
Description: Pushes desired speed to the internal drive feedback loop.
Parameters:  desired_rpm (in) - desired speed in RPMs
Returns:     None
*********************************************************************************************/
void bldc_set_desired_speed(INT16S desired_rpm);

/*********************************************************************************************
Author(s):   Dave Zielinski
Description: Asks if the BLDC motor is "stopped".  "Stopped" is defined as without a hall
             sensor change in less than 50ms.
Parameters:  None
Returns:     BLDC_IS_STOPPED - rotor is stopped
             BLDC_NOT_STOPPED - rotor is NOT stopped
*********************************************************************************************/
BLDC_STOPPED_T bldc_is_stopped(void);

/*********************************************************************************************
Author(s):   Juan Kuyoc
Description: Returns the current RPM value.
Parameters:  None
Returns:     INT16S - The current RPM value.
*********************************************************************************************/
INT16S bldc_get_current_RPM();

/*********************************************************************************************
Author(s):   Juan Kuyoc
Description: Returns the commanded RPM value.
Parameters:  None
Returns:     INT16S - The commanded RPM value.
*********************************************************************************************/
INT16S bldc_get_commanded_RPM();

//void UpdateP(FP32 P);
//void UpdateI(FP32 I);
void UpdateP(INT8U D[2]);

void UpdateI(INT8U D[2]);

#endif /* BLDC_H */

