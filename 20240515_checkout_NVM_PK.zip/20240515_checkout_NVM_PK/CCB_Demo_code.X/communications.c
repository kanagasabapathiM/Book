/*
 Author(s): 
 Status: Preliminary
 Release Date:
 Revision:
 Description: Definitions for the Actuator Communications Module.
 Note:  Compile with compiler option -mno-eds-warn to disable EDS warnings.
 History:

*/

/*********************************************************************************************
Includes
*********************************************************************************************/
#include "bldc.h"
#include "bldc-temp.h"
#include "communications.h"
#include "cpu.h"
#include "current.h"
#include "can.h"
#include "global.h"
#include "motion_control.h"
#include "position.h"
#include "pwm.h"
#include "system_monitor.h"
#include "temperature.h"
#include "timer_manager.h"
#include "utility.h"
#include "angle_sensor.h"

ECAN_HW_MESSAGE Out_msg;
ECAN_HW_MESSAGE RxCanMsg;
static bool Direction;
static bool Brake_cmd = 0;
static INT16U RPM_Desired_cmd =0;
static bool Test_cmd = false;//this for continuous test
static bool New_Cmd = false;//this for continuous test
#define BRAKE_DISENGAGED    1

#define STATUS_MSG_DELAY    10 //ms
static void _comm_command();

void comm_exec(void){
    INT32U static cur_systime = 100;
    
    _comm_command();
    if(tmgr_get_system_time() > STATUS_MSG_DELAY + cur_systime){
        cur_systime = tmgr_get_system_time();
        comm_status();        
    }
}

static void _comm_command()
{
    New_Cmd = false;
    if (ecan_rx_message(&RxCanMsg) == true) 
    {
        if (1|| (RxCanMsg.Source == 0x03 && RxCanMsg.Dest == 0x05)) /*TBD CAN ID to be implemented*/
        {
            Direction = RxCanMsg.D[0];
            RPM_Desired_cmd = (INT16U)((RxCanMsg.D[2] << 8) | RxCanMsg.D[1]);
            Brake_cmd = RxCanMsg.D[3];
            Test_cmd = RxCanMsg.D[4];
            New_Cmd = true;
        }
        if(RxCanMsg.D[5] == 0xE3)
        {
            set_flag_angle_sensor_zero_config();
        }
        if(RxCanMsg.D[5] == 0xBB)
        {
            set_flag_print_position();
        }
    }
}

bool  is_New_Msg_cmd()
{
    return New_Cmd;
}

bool  get_Direction_cmd()
{
    return Direction;
}

INT16U  get_Rpm_Desired_cmd()
{
    return RPM_Desired_cmd;
}

bool  get_Test_cmd()
{
    return Test_cmd;
}

bool  get_Brake_cmd()
{
    return Brake_cmd;
}
/*********************************************************************************************
 * Author(s):   Pratheep 
 * Description: For Demo to send CAN messages
 * Parameters:  Board temperature, Current , Angle data
 * Returns:     None.
 ********************************************************************************************/

void comm_status()
{
   // INT16S current,temp;
    //INT16S Angle_deg_1 =0, Angle_deg_2 =0;
    //INT16U No_of_rev_1 = 0,No_of_rev_2=0;
    //INT16U rpm = 0;
    INT16S current = 0;
    INT16U latest_position = psn_get_latest_position();
#if 1
    INT16S angle1 = angle_sensor_current_angle(ANGLESENSOR_01);
#else
    INT16S angle1 = 0;
#endif
    INT16S angle2 = angle_sensor_current_angle(ANGLESENSOR_02);
    current = i2c_get_temp();
    Out_msg.D[0] = (INT8U)current;//LSB
    Out_msg.D[1] = (INT8U)(current>>8);//MSB
    current = crnt_get_current_average();
    if(current < 0)
        current = 0;
    //BLDC current
    Out_msg.D[2] = (INT8U)current;// LSB
    Out_msg.D[3] = (INT8U)(current>>8); //MSB
    
    Out_msg.D[4] = (INT8U)angle1;// LSB
    Out_msg.D[5] = (INT8U)(angle1>>8); //MSB
    
    Out_msg.D[6] = (INT8S)angle2;// LSB
    Out_msg.D[7] = (INT8S)(angle2>>8); //MSB
    
   /* //Angle Value 1
    Out_msg.D[3] = Angle_deg_1;// LSB
    Out_msg.D[4] = (Angle_deg_1>>8); //MSB

    Out_msg.D[5] = No_of_rev_1;// LSB
    Out_msg.D[6] = No_of_rev_1;// MSB
    
    //Angle Value 2
    Out_msg.D[7] = Angle_deg_1;// LSB
    Out_msg.D[8] = (Angle_deg_1>>8); //MSB

    Out_msg.D[9] = No_of_rev_1;// LSB
    Out_msg.D[10] = No_of_rev_1;// MSB
    Out_msg.D[10] = rpm;// MSB
    Out_msg.D[11] = rpm;// MSB*/
    Out_msg.DLC = 8;
    Out_msg.Source = 0x05;
    Out_msg.Dest = 0x03;
    
    ecan_tx_message(&Out_msg);
}